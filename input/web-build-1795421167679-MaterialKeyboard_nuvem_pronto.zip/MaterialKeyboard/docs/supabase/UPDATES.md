# Atualizações próprias (aba "Atualizações")

O app consulta a tabela `app_updates` (leitura pública só das versões publicadas) e baixa o APK por HTTPS.
Nada é conectado até você preencher `updates/UpdatesConfig.kt` (`URL` e `ANON_KEY`, só a chave **anon**).

## 1. SQL (SQL Editor do Supabase)

```sql
create table public.app_updates (
  id             uuid primary key default gen_random_uuid(),
  version_code   integer not null unique,          -- = versionCode do build (maior = mais novo)
  version_name   text    not null,                 -- ex.: '54.4'
  release_notes  text    not null default '',      -- uma novidade por linha
  apk_url        text    not null check (apk_url like 'https://%'),
  apk_size_bytes bigint,
  apk_sha256     text,                             -- opcional, mas recomendado (minúsculas)
  is_mandatory   boolean not null default false,
  is_published   boolean not null default false,
  published_at   timestamptz not null default now()
);
alter table public.app_updates enable row level security;
create policy "ler versoes publicadas" on public.app_updates
  for select to anon, authenticated using (is_published);
```

## 2. APK
Crie um bucket **público** (ex.: `app-updates`), envie o APK e use a URL pública em `apk_url`.
Gere o SHA-256 com `sha256sum app-release.apk`.

## 3. Publicar uma versão
Insira uma linha com `is_published = true` e `version_code` maior que o do app instalado.
O APK precisa ter o mesmo `applicationId` e ser assinado com a MESMA chave do app instalado, senão o Android recusa a instalação.

## Comportamento no app
- Ao abrir as configurações: verificação automática (no máximo a cada 6 h); o item "Atualizações" mostra "Nova versão X disponível".
- Na aba: versão atual × nova, data, tamanho, novidades, "Baixar atualização" (progresso, SHA-256 e pacote conferidos) e instalação.
- Na primeira instalação o Android pede a permissão "instalar apps desconhecidos" para o Material Keyboard.

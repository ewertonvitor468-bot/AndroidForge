# ThemeBoard · servidor (Supabase)

Projeto: `rdfkxquoitxdntcprigh` (sa-east-1). O servidor **já estava montado**; o app foi adaptado a ele.
(Não existe mais `schema.sql` aqui: o esquema vive no próprio projeto. Não rode SQL antigo por cima.)

## Tabelas (public)
| tabela | uso |
|---|---|
| `themes` | tema: `owner_id`, `title`, `description`, `category` (`keys_cafe` = este app, `themeboard` = a outra plataforma), `tags`, `preview_path`, `status` (`pending/approved/rejected/hidden/removed`) |
| `theme_versions` | versão: `version`, `package_path` (`<uid>/<theme_id>/<versão>/arquivo.mkt`), `sha256`, `size_bytes`, `spec_version`, `min_app_version`, `status` |
| `theme_stats` | `download_count`, `rating_avg`, `rating_count` (criada por trigger) |
| `theme_downloads` | só via função `register_download(theme_id, version, client_uuid)` |
| `ratings`, `comments` | avaliações 1–5 e comentários (comentário nasce `pending`) |
| `reports` | denúncias: `category` (`copyright/inappropriate/spam/other`), `reason` 5–500 letras |
| `profiles` | `display_name` (criado por trigger ao cadastrar) |
| `user_roles` | `moderator` / `admin` |
| `moderation_log` | log automático das revisões |

Buckets privados: `theme-packages` (10 MB, zip/octet-stream) e `theme-previews` (5 MB, webp/png/jpeg).
A leitura é liberada por regra: pacote só de tema+versão aprovados (ou do dono / moderador); miniatura de tema aprovado.

## Fluxo do app
- **Ver/baixar:** sem conta. Lista `themes` aprovados com versão aprovada, baixa do bucket, confere SHA-256, valida o pacote e instala.
- **Publicar/denunciar/Meus temas:** exigem conta (e-mail + senha, Supabase Auth). Publicar = linha em `themes` → pacote → miniatura → linha em `theme_versions`, tudo `pending`.
- **Moderação:** pela **fila dentro do app** (ThemeBoard → botão **Moderar**, só aparece para contas em `user_roles`). Aba *Temas*: "Revisar"
  baixa o pacote sem instalar, mostra a prévia e a imagem de fundo (se houver) e permite **Aprovar** ou **Recusar** (motivo obrigatório,
  aparece para o autor). Aba *Denúncias*: **Descartar** ou **Ocultar tema**. Tudo passa pelas funções abaixo; o servidor confere se a conta é moderadora.

## Configuração do app
`keyscafe/ThemeBoardConfig.kt`: `URL` e `ANON_KEY` (chave anon pública). Em código, e não em BuildConfig, para compilar no PocketCode.

## Pendências no painel do Supabase (não dá para fazer pelo app)
- Authentication → Sign In / Providers → Email: decida se exige confirmação de e-mail.
- Authentication → Policies/Password: ligar **Leaked password protection**.
- Alertas do advisor sobre `register_download` executável por anon são intencionais (contador de downloads).

## Funções de moderação (public, SECURITY INVOKER; só `authenticated`, e só moderador consegue executar)
- `moderate_theme(p_theme_id, p_approve, p_reason)`: aprova/recusa o tema **e** a versão pendente numa transação. Recusar exige motivo (3+ letras).
  Erros: `not_allowed`, `reason_required`, `no_version`, `not_pending`.
- `moderate_report(p_report_id, p_hide_theme, p_note)`: descarta a denúncia, ou oculta o tema (`hidden`) e resolve todas as denúncias abertas dele.
- Os gatilhos já existentes preenchem `reviewed_by/reviewed_at` e gravam o `moderation_log`.
- Para ser moderador: inserir a conta em `user_roles` (`role = 'moderator'`) pelo painel do Supabase. O app não consegue se dar esse papel.

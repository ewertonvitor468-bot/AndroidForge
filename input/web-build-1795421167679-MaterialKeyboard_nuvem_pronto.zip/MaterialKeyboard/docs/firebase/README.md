# Conta e nuvem (Firebase): login com Google + backup das configurações

Versão simplificada do "Material Cloud". **Não** mexe no Theme Board, no Keys Café nem no Supabase.
Tudo roda no **plano gratuito (Spark)**, sem cartão. O teclado continua funcionando offline e sem login:
o Firebase só é iniciado quando a pessoa abre **Configurações > Geral > Conta e nuvem** (ou se ligou o backup automático).

## O que o app faz
- **Entrar com o Google** (único método de login).
- **Fazer backup agora**: grava UM documento em `users/{uid}/backup/settings` (alguns KB).
- **Restaurar do backup**: lê o documento, mostra a data e o aparelho, e só aplica depois de confirmar.
- **Backup automático** (opcional, desligado por padrão): ao sair das configurações, envia só se algo mudou (no máx. 1 vez a cada 3 min).
- **Apagar backup da nuvem**.

Entram no backup: as preferências do teclado (cores, formas, tamanhos, sons, idioma, barra de ícones, posição das letras, bichinhos...)
e as 4 opções do Tradutor. **Não entram**: histórico da área de transferência, palavras aprendidas, imagem/vídeo de fundo, sons importados,
temas do Keys Café, a chave do ditado por voz e flags internas. Um tema "patch" só vai se for um dos que já vêm no app
(as cores dele vão de qualquer forma). A lista fica em `Prefs.kt` (`CLOUD_Z/I/S`); para uma preferência nova entrar no backup, acrescente lá.

## Custo (conferido na página oficial de preços do Firebase)
- Login com Google (social sign-in): sem custo, sem limite relevante no Spark.
- Firestore **edição Standard**, no Spark: 1 GiB armazenado, 20 mil escritas/dia e 50 mil leituras/dia sem custo.
  Este app usa 1 escrita por backup e 1 leitura por restauração.
- No Spark, se uma cota for estourada, o produto é **desligado até o fim do mês** (não há cobrança). **Não** clique em "Upgrade/Blaze" e **não** vincule
  conta de faturamento: é isso que passaria a cobrar. Se algum passo abaixo pedir plano Blaze ou cartão, **pare**.
- Escolha a edição **Standard** do Firestore (a Enterprise tem cobrança por unidades).

## Passo a passo
1. **Projeto**: https://console.firebase.google.com > Adicionar projeto (pode desligar o Google Analytics). Fica no plano Spark.
2. **App Android**: Configurações do projeto > Seus apps > Android. Nome do pacote: `com.example.materialkeyboard`.
   Adicione o **SHA-1** (e o SHA-256) da chave que assina o APK:
   - APK do GitHub Actions: a chave do segredo `MK_KEYSTORE` (alias `mk`):
     `keytool -list -v -keystore SEU.jks -alias mk`
   - Se também compila sem essa chave (debug local): `keytool -list -v -keystore ~/.android/debug.keystore -alias androiddebugkey -storepass android`
     e adicione esse SHA-1 também. **Cada chave de assinatura diferente precisa estar cadastrada**, senão o login falha.
   - O arquivo `google-services.json` **não** precisa entrar no projeto (não usamos o plugin); só abra-o para copiar os valores do passo 5.
3. **Login**: Authentication > Sign-in method > ative **Google** (escolha um e-mail de suporte). Depois de salvar, baixe o `google-services.json` de novo.
4. **Banco**: Firestore Database > Criar banco de dados > edição **Standard** > modo produção > escolha a região (não dá para mudar depois).
   Na aba **Regras**, cole o conteúdo de `docs/firebase/firestore.rules` e **Publique**.
5. **Preencha `app/src/main/java/com/example/materialkeyboard/cloud/CloudConfig.kt`** (os 4 valores):

   | Constante | Onde achar |
   |---|---|
   | `API_KEY` | `google-services.json` > `client[0].api_key[0].current_key` |
   | `APP_ID` | `google-services.json` > `client[0].client_info.mobilesdk_app_id` (começa com `1:`) |
   | `PROJECT_ID` | `google-services.json` > `project_info.project_id` |
   | `WEB_CLIENT_ID` | `google-services.json` > `client[0].oauth_client` > item com `"client_type": 3` > `client_id` (termina em `.apps.googleusercontent.com`). Também está em Authentication > Google > Web SDK configuration |

   Com algum valor em branco, o item "Conta e nuvem" some e o app fica idêntico ao de antes.
6. (Recomendado, por último) Restrinja a chave de API ao app: Google Cloud Console > APIs e serviços > Credenciais > chave Android >
   Restrições de aplicativo: Apps Android > pacote `com.example.materialkeyboard` + os SHA-1 do passo 2. Teste o login depois.
   Esses valores não são segredos; quem protege os dados são as regras do Firestore.
7. Compile, instale, abra **Configurações > Geral > Conta e nuvem** > Entrar com o Google > Fazer backup agora.

## Problemas comuns
- **"Não foi possível entrar (...)"** logo ao tocar: SHA-1 da chave de assinatura não cadastrada, `WEB_CLIENT_ID` errado (precisa ser o do tipo Web), ou Google não ativado no Authentication.
  Foi só no APK **release** e funciona no debug? Confira se `proguard-rules.pro` tem a regra do Credential Manager (já incluída).
- **"Nenhuma conta Google neste aparelho"**: adicione uma conta em Ajustes do Android. Aparelhos sem Google Play Services não conseguem entrar (o teclado funciona normalmente).
- **"Sem permissão no servidor"**: as regras do passo 4 não foram publicadas, ou o banco não foi criado.
- **"Sem conexão"**: backup e restauração precisam de internet; nada é enviado sozinho em segundo plano além do backup automático opcional.

## Versões usadas (compatíveis com compileSdk 34 / AGP 8.5.2 / Kotlin 2.0.0 do projeto)
Firebase BoM 33.1.2 (`firebase-auth`, `firebase-firestore`), `androidx.credentials` 1.2.2 (a 1.3+ exige compileSdk 35),
`googleid` 1.1.1. Se um dia subir o compileSdk, estas versões podem ser atualizadas.

-dontwarn java.awt.**
-dontwarn com.sun.jna.**
# Credential Manager (login com Google): o provedor do Play Services é achado por reflexão; sem isto o login só falha no APK release (R8).
-if class androidx.credentials.CredentialManager
-keep class androidx.credentials.playservices.** { *; }

package com.example.materialkeyboard.keyscafe

import android.content.Context
import com.example.materialkeyboard.Palette
import com.example.materialkeyboard.Patch
import com.example.materialkeyboard.Patches
import com.example.materialkeyboard.Prefs

/**
 * Pontes entre o ThemeSpec e o que o teclado já entende.
 *  - [toPatch]: o teclado desenha qualquer Patch; assim um tema da comunidade aparece sem mexer no KeyView.
 *  - [fromPatch]: os temas embutidos viram ThemeSpec (para exportar e para o editor partir deles).
 *  - [capture]: "salvar o visual de agora" a partir das preferências atuais.
 *
 * Passos 1-3: o desenho usa paleta + acabamento + extras (balão, texto, animação, cantos, cenário), tudo pelo
 * mesmo caminho de [Patches.apply], o que mantém "Remover patch" restaurando tudo certo. Gradientes e imagem
 * ainda são só guardados.
 */
object ThemeSpecMapper {

    fun toPatch(s: ThemeSpec): Patch = Patch(
        id = s.id, name = s.name, category = Patches.COMMUNITY,
        desc = s.description.ifEmpty { s.inspiredBy },
        dark = s.palette.dark,
        surface = s.palette.surface, normal = s.palette.normal, special = s.palette.special, accent = s.palette.accent,
        onNormal = s.palette.onNormal, onSpecial = s.palette.onSpecial, onAccent = s.palette.onAccent,
        keyStyle = s.keys.keyStyle, keyShape = s.keys.keyShape, pressGlow = s.keys.pressGlow, keyAlpha = s.keys.keyAlpha,
        radius = s.keys.keyRadius, gap = s.keys.keyGap, fontStyle = s.text.fontStyle, blur = s.keys.blurAmount,
        extras = extras(s)
    )

    /** Passo 3: campos do tema que vão para as preferências além do Patch básico (mesmas chaves de [Prefs.EXTRA_KEYS]). */
    private fun extras(s: ThemeSpec): Map<String, Int> = linkedMapOf(
        "boardRadius" to s.keys.boardRadius, "accentShape" to s.keys.accentShape, "textScale" to s.text.textScale,
        "fontColorOn" to if (s.text.fontColor != null) 1 else 0,
        "fontColor" to (s.text.fontColor?.toInt() ?: 0xFFFFFFFF.toInt()),
        "previewShape" to s.bubble.shape, "previewSize" to s.bubble.size, "previewColor" to s.bubble.color,
        "previewHue" to s.bubble.hue, "previewAnim" to if (s.bubble.anim) 1 else 0,
        "animSpeed" to s.animation.speed, "animBounce" to s.animation.bounce, "scene" to s.animation.scene,
        "expressive" to if (s.keys.expressive) 1 else 0, "micShape" to s.bar.micShape, "toolShape" to s.bar.toolShape,
        "keyBorder" to s.keys.keyBorder, "keyDepth" to s.keys.keyDepth, "barStyle" to s.bar.barStyle
    )

    fun fromPatch(p: Patch): ThemeSpec = ThemeSpec(
        id = p.id, name = p.name, description = p.desc,
        tags = listOfNotNull(Patches.CATEGORY_NAMES.getOrNull(p.category)?.lowercase()),
        palette = SpecPalette(
            dark = p.dark, surface = p.surface, normal = p.normal, special = p.special, accent = p.accent,
            onNormal = p.onNormal, onSpecial = p.onSpecial, onAccent = p.onAccent
        ),
        keys = SpecKeys(
            keyStyle = p.keyStyle, keyShape = p.keyShape, keyRadius = p.radius, keyGap = p.gap,
            keyAlpha = p.keyAlpha, blurAmount = p.blur, pressGlow = p.pressGlow,
            // v54.2: o que o tema embutido define em extras também vai para o editor/exportação
            boardRadius = p.extras["boardRadius"] ?: 26, accentShape = p.extras["accentShape"] ?: 0,
            keyBorder = p.extras["keyBorder"] ?: 0, keyDepth = p.extras["keyDepth"] ?: 0,
            expressive = (p.extras["expressive"] ?: 1) != 0
        ),
        text = SpecText(
            fontStyle = p.fontStyle, textScale = p.extras["textScale"] ?: 108,
            fontColor = if ((p.extras["fontColorOn"] ?: 0) != 0) (p.extras["fontColor"] ?: 0xFFFFFFFF.toInt()).toLong() and 0xFFFFFFFFL else null
        ),
        bubble = SpecBubble(
            shape = p.extras["previewShape"] ?: 0, size = p.extras["previewSize"] ?: 100, color = p.extras["previewColor"] ?: 0,
            hue = p.extras["previewHue"] ?: 260, anim = (p.extras["previewAnim"] ?: 1) != 0
        ),
        animation = SpecAnimation(
            speed = p.extras["animSpeed"] ?: 100, bounce = p.extras["animBounce"] ?: 50, scene = p.extras["scene"] ?: 0
        ),
        bar = SpecBar(micShape = p.extras["micShape"] ?: 0, toolShape = p.extras["toolShape"] ?: 0, barStyle = p.extras["barStyle"] ?: 0)
    )

    /**
     * Fotografa o visual atual do teclado. Devolve null quando há imagem de fundo ativa
     * (a imagem ainda não entra no pacote; sem isso as cores guardadas não bateriam com o que se vê).
     */
    fun capture(
        ctx: Context, prefs: Prefs, id: String, name: String,
        author: String = "", description: String = "", inspiredBy: String = "", tags: List<String> = emptyList()
    ): ThemeSpec? {
        if (prefs.themeImage) return null
        val pal = Palette.build(ctx, prefs)
        fun c(v: Int): Long = v.toLong() and 0xFFFFFFFFL or 0xFF000000L
        return ThemeSpec(
            id = id, name = name, author = author, description = description, inspiredBy = inspiredBy, tags = tags,
            palette = SpecPalette(
                dark = pal.isDark, surface = c(pal.surface), normal = c(pal.keyNormal), special = c(pal.keySpecial),
                accent = c(pal.keyAccent), onNormal = c(pal.onNormal), onSpecial = c(pal.onSpecial), onAccent = c(pal.onAccent)
            ),
            keys = SpecKeys(
                keyStyle = prefs.keyStyle.coerceIn(SpecLimits.KEY_STYLE),
                keyShape = prefs.keyShape.coerceIn(SpecLimits.KEY_SHAPE),
                accentShape = prefs.accentShape.coerceIn(SpecLimits.ACCENT_SHAPE),
                keyRadius = prefs.keyRadius.coerceIn(SpecLimits.KEY_RADIUS),
                boardRadius = prefs.boardRadius.coerceIn(SpecLimits.BOARD_RADIUS),
                keyGap = prefs.keyGap.coerceIn(SpecLimits.KEY_GAP),
                keyAlpha = prefs.keyAlpha.coerceIn(SpecLimits.KEY_ALPHA),
                blurAmount = prefs.blurAmount.coerceIn(SpecLimits.BLUR),
                pressGlow = prefs.pressGlow,
                keyBorder = prefs.keyBorder.coerceIn(SpecLimits.KEY_BORDER),
                keyDepth = prefs.keyDepth.coerceIn(SpecLimits.KEY_DEPTH),
                expressive = prefs.expressive
            ),
            text = SpecText(
                fontStyle = prefs.fontStyle.coerceIn(SpecLimits.FONT_STYLE),
                textScale = prefs.textScale.coerceIn(SpecLimits.TEXT_SCALE),
                fontColor = if (prefs.fontColorOn) c(prefs.fontColor) else null
            ),
            bubble = SpecBubble(
                shape = prefs.previewShape.coerceIn(SpecLimits.BUBBLE_SHAPE),
                size = prefs.previewSize.coerceIn(SpecLimits.BUBBLE_SIZE),
                color = prefs.previewColor.coerceIn(SpecLimits.BUBBLE_COLOR),
                hue = prefs.previewHue.coerceIn(SpecLimits.BUBBLE_HUE),
                anim = prefs.previewAnim
            ),
            animation = SpecAnimation(
                speed = prefs.animSpeed.coerceIn(SpecLimits.ANIM_SPEED),
                bounce = prefs.animBounce.coerceIn(SpecLimits.ANIM_BOUNCE),
                scene = prefs.scene.coerceIn(SpecLimits.SCENE)
            ),
            bar = SpecBar(
                micShape = prefs.micShape.coerceIn(SpecLimits.BAR_BUTTON_SHAPE),
                toolShape = prefs.toolShape.coerceIn(SpecLimits.BAR_BUTTON_SHAPE),
                barStyle = prefs.barStyle.coerceIn(SpecLimits.BAR_STYLE)
            )
        )
    }
}

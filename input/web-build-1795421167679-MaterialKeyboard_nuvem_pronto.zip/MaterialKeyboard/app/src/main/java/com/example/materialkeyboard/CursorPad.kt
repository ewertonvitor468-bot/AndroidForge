package com.example.materialkeyboard

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import androidx.core.graphics.ColorUtils

/**
 * Painel do modo cursor (estilo iPhone): as teclas somem e esta área vira um "trackpad".
 * Arrastar para os lados move o cursor do texto; arrastar para cima/baixo ou só tocar volta ao teclado.
 */
class CursorPad(ctx: Context) : View(ctx) {
    var bg = 0xFF2C2C30.toInt()
    var fg = 0xFFFFFFFF.toInt()
    var radius = 24f
    var hint = "Arraste o dedo aqui"
    /** Quantos pixels de arrasto valem um caractere. */
    var stepPx = 28f
    /** Chamado com o número de caracteres a andar (negativo = esquerda). */
    var onMoveChars: ((Int) -> Unit)? = null
    /** Chamado ao pedir para sair do modo cursor. */
    var onExit: (() -> Unit)? = null
    /** Chamado quando o dedo encosta (vibração, etc.). */
    var onTouched: (() -> Unit)? = null

    private val slop = ViewConfiguration.get(ctx).scaledTouchSlop.toFloat()
    private val rect = RectF()
    private val boxPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER; typeface = Typeface.DEFAULT_BOLD }
    private val arrowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND }
    private val path = Path()

    private var downX = 0f
    private var downY = 0f
    private var lastX = 0f
    private var acc = 0f
    private var moved = false
    private var exitIntent = false
    private var nudge = 0f          // deslocamento visual das setas enquanto arrasta

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        val m = h * 0.04f
        rect.set(m, m, w - m, h - m)
        boxPaint.color = bg
        c.drawRoundRect(rect, radius, radius, boxPaint)

        val cx = w / 2f + nudge; val cy = h / 2f
        val a = ColorUtils.setAlphaComponent(fg, 200)
        textPaint.color = a
        textPaint.textSize = (h * 0.15f).coerceIn(30f, 64f)
        c.drawText(hint, cx, cy + textPaint.textSize * 0.35f, textPaint)

        // setas ‹ › nos dois lados do texto
        arrowPaint.color = ColorUtils.setAlphaComponent(fg, 150)
        arrowPaint.strokeWidth = (h * 0.025f).coerceAtLeast(4f)
        val aw = h * 0.07f
        val gap = textPaint.measureText(hint) / 2f + h * 0.12f
        path.reset()
        path.moveTo(cx - gap + aw, cy - aw); path.lineTo(cx - gap, cy); path.lineTo(cx - gap + aw, cy + aw)
        path.moveTo(cx + gap - aw, cy - aw); path.lineTo(cx + gap, cy); path.lineTo(cx + gap - aw, cy + aw)
        c.drawPath(path, arrowPaint)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = e.x; downY = e.y; lastX = e.x
                acc = 0f; moved = false; exitIntent = false
                parent?.requestDisallowInterceptTouchEvent(true)
                onTouched?.invoke()
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = e.x - lastX
                lastX = e.x
                val totalX = e.x - downX; val totalY = e.y - downY
                if (!moved && Math.abs(totalY) > slop * 3 && Math.abs(totalY) > Math.abs(totalX) * 1.5f) exitIntent = true
                if (Math.abs(totalX) > slop || moved) moved = true
                if (exitIntent) return true
                if (moved) {
                    acc += dx
                    nudge = (nudge + dx * 0.25f).coerceIn(-stepPx, stepPx)
                    val steps = (acc / stepPx).toInt()
                    if (steps != 0) {
                        acc -= steps * stepPx
                        onMoveChars?.invoke(steps)
                    }
                    invalidate()
                }
            }
            MotionEvent.ACTION_UP -> {
                parent?.requestDisallowInterceptTouchEvent(false)
                nudge = 0f; invalidate()
                // deslizar para cima/baixo, ou só tocar, volta para o teclado
                if (exitIntent || !moved) onExit?.invoke()
            }
            MotionEvent.ACTION_CANCEL -> { nudge = 0f; invalidate() }
        }
        return true
    }
}

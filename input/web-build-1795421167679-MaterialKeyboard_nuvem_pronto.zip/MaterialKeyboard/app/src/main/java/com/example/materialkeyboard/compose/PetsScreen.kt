package com.example.materialkeyboard.compose

import android.graphics.Color as AColor
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import com.example.materialkeyboard.Prefs
import com.example.materialkeyboard.tr

private val BODY_SWATCHES = intArrayOf(
    0xFFC68642.toInt(), 0xFF6B4423.toInt(), 0xFF2B2B2B.toInt(), 0xFFF4F1EC.toInt(), 0xFF9E9E9E.toInt(), 0xFFEBD9B4.toInt(),
    0xFFF2A65A.toInt(), 0xFFE0B24F.toInt(), 0xFF6AA9FF.toInt(), 0xFFFF8FB8.toInt(), 0xFF7BD88F.toInt(), 0xFFB08CFF.toInt()
)
private val DETAIL_SWATCHES = intArrayOf(
    0xFF5A3A1E.toInt(), 0xFF222222.toInt(), 0xFFFFB3B8.toInt(), 0xFFFFFFFF.toInt(), 0xFFE05252.toInt(), 0xFF4F8CFF.toInt(),
    0xFF4CAF50.toInt(), 0xFFFFD54F.toInt(), 0xFF8E5BD6.toInt(), 0xFFFF8A3D.toInt(), 0xFF777777.toInt(), 0xFFEBD9B4.toInt()
)
private val PET_TITLES = listOf("Cachorro", "Gato", "Coelho")

/** Seção "Bichinhos" da página Patches: cachorro, gato e coelho que andam pelo teclado. */
@Composable
fun PageCtx.PetsSection() {
    MkCard("Bichinhos".tr()) {
        MkNote("Cachorro, gato e coelho andam pelo teclado. Toque 3 vezes em um bichinho para ele falar; toque no balão para ver a tradução. Enquanto você digita, os toques passam direto para as teclas.".tr())
        MkSwitch("Tocar nos bichinhos".tr(), "Desligue se preferir que eles só passeiem".tr(), prefs.petsTouch) {
            prefs.putBool("petsTouch", it); refresh()
        }
        MkSlider("Tamanho dos bichinhos".tr(), prefs.petSize, 24, 56, "dp") { prefs.putInt("petSize", it) }
    }
    for (k in 0 until 3) PetCard(k)
}

@Composable
private fun PageCtx.PetCard(k: Int) {
    MkCard(PET_TITLES[k].tr()) {
        MkSwitch("Mostrar no teclado".tr(), null, prefs.petOn[k]) { prefs.putBool("petOn$k", it); refresh() }
        if (prefs.petOn[k]) {
            PetNameField(k)
            PetColorRow("Cor do corpo".tr(), prefs.petBody[k], BODY_SWATCHES) { prefs.putInt("petBody$k", it); refresh() }
            PetColorRow("Cor dos detalhes (orelhas, nariz, manchas)".tr(), prefs.petDetail[k], DETAIL_SWATCHES) { prefs.putInt("petDetail$k", it); refresh() }
            MkAction("Restaurar cores".tr()) {
                prefs.putInt("petBody$k", Prefs.PET_BODY[k]); prefs.putInt("petDetail$k", Prefs.PET_DETAIL[k]); refresh()
            }
        }
    }
}

@Composable
private fun PageCtx.PetNameField(k: Int) {
    var text by remember(prefs.petName[k]) { mutableStateOf(prefs.petName[k]) }
    val save = { prefs.putString("petName$k", text.trim().ifBlank { Prefs.PET_NAMES[k] }); refresh() }
    Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        OutlinedTextField(
            text, { text = it.take(14) }, singleLine = true, label = { Text("Nome".tr()) },
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
            keyboardActions = KeyboardActions(onDone = { save() }),
            modifier = Modifier.weight(1f)
        )
        MkGap()
        FilledTonalButton(onClick = { save() }) { Text("Salvar".tr(), fontWeight = FontWeight.SemiBold) }
    }
}

@Composable
private fun PetColorRow(title: String, color: Int, swatches: IntArray, onPick: (Int) -> Unit) {
    val cs = MaterialTheme.colorScheme
    Text(title, color = cs.onSurface, fontWeight = FontWeight.Medium, modifier = Modifier.padding(top = 10.dp))
    LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.padding(vertical = 8.dp)) {
        items(swatches.toList()) { c ->
            val on = c == color
            Box(
                Modifier.size(34.dp).clip(CircleShape).background(Color(c))
                    .border(if (on) 3.dp else 1.dp, if (on) cs.primary else cs.onSurface.copy(alpha = 0.25f), CircleShape)
                    .clickable { onPick(c) }
            )
        }
    }
    var hue by remember(color) { mutableFloatStateOf(FloatArray(3).also { AColor.colorToHSV(color, it) }[0]) }
    Text("Matiz personalizado".tr(), color = cs.onSurface.copy(alpha = 0.62f), style = MaterialTheme.typography.bodySmall)
    Slider(hue, { hue = it }, valueRange = 0f..360f,
        onValueChangeFinished = { onPick(AColor.HSVToColor(floatArrayOf(hue, 0.6f, 0.95f))) })
}

package com.example.materialkeyboard

import android.content.Context
import android.graphics.Matrix
import android.graphics.Outline
import android.graphics.RenderEffect
import android.graphics.Shader
import android.graphics.SurfaceTexture
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.media.MediaMuxer
import android.media.MediaPlayer
import android.net.Uri
import android.view.Surface
import android.view.TextureView
import android.view.View
import android.view.ViewOutlineProvider
import android.widget.FrameLayout
import java.io.File
import java.nio.ByteBuffer

/**
 * Fundo animado: o vídeo da galeria é recortado (no máximo 5 s), regravado SEM áudio num MP4 próprio
 * (sem recodificar, então é rápido) e guardado na pasta do app. O primeiro quadro vira a imagem de fundo
 * normal ([ThemeImage]), então cores, escurecimento e opacidade das teclas continuam funcionando.
 */
object VideoBg {
    const val MAX_MS = 5000L
    private const val MAX_SIDE = 1920   // acima disso a decodificação gasta bateria demais para um fundo

    fun file(ctx: Context) = File(ctx.applicationContext.filesDir, "theme_bg.mp4")
    fun delete(ctx: Context) { file(ctx).delete() }

    /** Duração do vídeo em ms; 0 se não der para ler. */
    fun durationMs(ctx: Context, uri: Uri): Long = try {
        val r = MediaMetadataRetriever()
        try { r.setDataSource(ctx, uri); r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L }
        finally { r.release() }
    } catch (_: Throwable) { 0L }

    /** Quadro do vídeo no instante pedido (para a prévia do trecho). */
    fun frameAt(ctx: Context, uri: Uri, ms: Long) = try {
        val r = MediaMetadataRetriever()
        try { r.setDataSource(ctx, uri); r.getFrameAtTime(ms * 1000, MediaMetadataRetriever.OPTION_CLOSEST_SYNC) }
        finally { r.release() }
    } catch (_: Throwable) { null }

    /** Resultado: null = ok, senão a mensagem de erro. Chamar fora da thread principal. */
    fun import(ctx: Context, uri: Uri, startMs: Long): String? {
        val tmp = File(ctx.applicationContext.filesDir, "theme_bg_tmp.mp4")
        val ex = MediaExtractor()
        try {
            val meta = MediaMetadataRetriever()
            val rot: Int
            try {
                meta.setDataSource(ctx, uri)
                rot = meta.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
                val w = meta.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 0
                val h = meta.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 0
                if (maxOf(w, h) > MAX_SIDE) return "Vídeo muito grande (máx. Full HD, 1920 px)"
            } finally { meta.release() }

            ex.setDataSource(ctx, uri, null)
            var track = -1
            for (i in 0 until ex.trackCount) {
                if (ex.getTrackFormat(i).getString(MediaFormat.KEY_MIME)?.startsWith("video/") == true) { track = i; break }
            }
            if (track < 0) return "Esse arquivo não tem vídeo"
            val fmt = ex.getTrackFormat(track)
            ex.selectTrack(track)   // só a faixa de vídeo: o áudio fica de fora

            val mux = MediaMuxer(tmp.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            var started = false
            try {
                mux.setOrientationHint(rot)
                val dst = mux.addTrack(fmt)
                mux.start(); started = true
                ex.seekTo(startMs * 1000, MediaExtractor.SEEK_TO_PREVIOUS_SYNC)   // começa no quadro-chave mais próximo
                val first = ex.sampleTime.coerceAtLeast(0L)
                val endUs = minOf(startMs * 1000 + MAX_MS * 1000, first + MAX_MS * 1000)
                val cap = if (fmt.containsKey(MediaFormat.KEY_MAX_INPUT_SIZE)) fmt.getInteger(MediaFormat.KEY_MAX_INPUT_SIZE) else 0
                val buf = ByteBuffer.allocate(maxOf(cap, 2 * 1024 * 1024))
                val info = android.media.MediaCodec.BufferInfo()
                while (true) {
                    val t = ex.sampleTime
                    if (t < 0 || t > endUs) break
                    buf.clear()
                    val size = ex.readSampleData(buf, 0)
                    if (size < 0) break
                    info.set(0, size, (t - first).coerceAtLeast(0L),
                        if (ex.sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC != 0) android.media.MediaCodec.BUFFER_FLAG_KEY_FRAME else 0)
                    mux.writeSampleData(dst, buf, info)
                    ex.advance()
                }
            } finally {
                try { if (started) mux.stop() } catch (_: Throwable) { }
                mux.release()
            }

            // capa = primeiro quadro do clipe já pronto
            val r = MediaMetadataRetriever()
            val frame = try { r.setDataSource(tmp.absolutePath); r.getFrameAtTime(0, MediaMetadataRetriever.OPTION_CLOSEST_SYNC) } finally { r.release() }
            if (frame == null || !ThemeImage.saveBitmap(ctx, frame)) return "Não foi possível ler esse vídeo"
            val out = file(ctx)
            out.delete()
            return if (tmp.renameTo(out)) null else "Não foi possível salvar o vídeo"
        } catch (_: Throwable) {
            return "Formato de vídeo não suportado"
        } finally {
            ex.release()
            tmp.delete()
        }
    }
}

/**
 * Camada do vídeo atrás do teclado: a capa (imagem) aparece até o primeiro quadro, o vídeo toca em loop, mudo.
 * [resume]/[pause] são chamados quando a janela do teclado abre/fecha: fechado = decodificador parado (bateria).
 */
class VideoBgView(ctx: Context, private val src: File, cover: android.graphics.drawable.Drawable, topR: Float, private val pos: Float = 0.5f) : FrameLayout(ctx) {
    private val tv = TextureView(ctx)
    private var mp: MediaPlayer? = null
    private var surf: Surface? = null
    private var ready = false
    private var want = false
    private var vw = 0   // tamanho real do vídeo (para recortar sem esticar)
    private var vh = 0

    /**
     * O TextureView estica o vídeo até o tamanho da view. Aqui desfazemos isso: o vídeo é ampliado com a
     * MESMA proporção até cobrir o teclado inteiro (largura e altura) e o que sobra é cortado. [pos] (0..1)
     * escolhe qual parte aparece na vertical (o mesmo controle "Posição da imagem" da imagem de fundo).
     */
    private fun fit() {
        val w = tv.width.toFloat(); val h = tv.height.toFloat()
        if (w <= 0f || h <= 0f || vw <= 0 || vh <= 0) return
        val s = maxOf(w / vw, h / vh)
        val sx = vw * s / w
        val sy = vh * s / h
        val m = Matrix()
        m.setScale(sx, sy, 0f, 0f)
        m.postTranslate(-(sx * w - w) * 0.5f, -(sy * h - h) * pos.coerceIn(0f, 1f))
        tv.setTransform(m)
    }

    /** Desfoque (0..100) do vídeo e da capa; só Android 12+ (RenderEffect). */
    fun setBlur(percent: Int) {
        if (android.os.Build.VERSION.SDK_INT < 31) return
        val r = percent.coerceIn(0, 100) / 100f * 24f * resources.displayMetrics.density
        setRenderEffect(if (r < 0.5f) null else RenderEffect.createBlurEffect(r, r, Shader.TileMode.CLAMP))
    }

    init {
        background = cover
        addView(tv, LayoutParams(-1, -1))
        // cantos de cima arredondados, como o corpo do teclado
        outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(v: View, o: Outline) { o.setRoundRect(0, 0, v.width, v.height + topR.toInt() + 1, topR) }
        }
        clipToOutline = true
        isClickable = false; isFocusable = false
        tv.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> fit() }
        tv.surfaceTextureListener = object : TextureView.SurfaceTextureListener {
            override fun onSurfaceTextureAvailable(st: SurfaceTexture, w: Int, h: Int) { open(st) }
            override fun onSurfaceTextureSizeChanged(st: SurfaceTexture, w: Int, h: Int) { fit() }
            override fun onSurfaceTextureDestroyed(st: SurfaceTexture): Boolean { close(); return true }
            override fun onSurfaceTextureUpdated(st: SurfaceTexture) {}
        }
    }

    private fun open(st: SurfaceTexture) {
        close()
        try {
            mp = MediaPlayer().apply {
                setDataSource(src.absolutePath)
                surf = Surface(st)
                setSurface(surf)
                setVolume(0f, 0f)
                isLooping = true
                setOnVideoSizeChangedListener { _, w, h -> vw = w; vh = h; fit() }
                setOnPreparedListener { ready = true; if (want) it.start() }
                setOnErrorListener { _, _, _ -> close(); true }   // se falhar, fica só a capa
                prepareAsync()
            }
        } catch (_: Throwable) { close() }
    }

    private fun close() {
        ready = false
        mp?.let { try { it.release() } catch (_: Throwable) { } }
        mp = null
        surf?.release(); surf = null
    }

    fun resume() { want = true; if (ready) try { mp?.start() } catch (_: Throwable) { } }
    fun pause() { want = false; if (ready) try { mp?.pause() } catch (_: Throwable) { } }
    fun release() { want = false; close() }
}

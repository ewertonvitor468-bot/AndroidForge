package com.example.materialkeyboard

import com.example.materialkeyboard.compose.applyMkBars
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.os.Bundle
import android.os.SystemClock
import android.provider.Settings
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.graphics.ColorUtils
import androidx.dynamicanimation.animation.DynamicAnimation
import androidx.dynamicanimation.animation.FloatPropertyCompat
import androidx.dynamicanimation.animation.SpringAnimation
import androidx.dynamicanimation.animation.SpringForce
import com.google.android.material.button.MaterialButton
import com.google.android.material.color.DynamicColors
import com.google.android.material.color.MaterialColors
import com.google.android.material.R as M
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Assistente de primeira abertura: 1) Boas-vindas  2) Ativar o teclado  3) Selecionar o teclado.
 * As páginas deslizam com mola e o conteúdo de cada uma entra em cascata.
 */
class OnboardingActivity : AppCompatActivity() {

    private class Step(val title: String, val body: String, val button: String)

    private lateinit var steps: List<Step>

    private fun buildSteps() = listOf(
        Step("Bem-vindo ao\nMaterial Keyboard".tr(), "Um teclado com Material You, tema com suas fotos e animações fluidas. Vamos deixar tudo pronto em dois passos.".tr(), "Continuar".tr()),
        Step("Ativar teclado".tr(), "Abra as configurações do Android e ligue o Material Keyboard na lista de teclados.".tr(), "Ativar teclado".tr()),
        Step("Selecionar teclado".tr(), "Agora escolha o Material Keyboard como o teclado que você está usando.".tr(), "Selecionar teclado".tr())
    )

    private lateinit var prefs: Prefs
    private lateinit var stage: FrameLayout
    private lateinit var dots: DotsView
    private val pages = ArrayList<LinearLayout>()
    private val arts = ArrayList<KeyboardArtView>()
    private val buttons = ArrayList<MaterialButton>()
    private val bodies = ArrayList<TextView>()
    private var current = 0

    private val back = object : OnBackPressedCallback(false) {
        override fun handleOnBackPressed() { if (current > 0) go(current - 1) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        DynamicColors.applyToActivityIfAvailable(this)
        super.onCreate(savedInstanceState)
        prefs = Prefs.get(this)
        steps = buildSteps()
        onBackPressedDispatcher.addCallback(this, back)

        val root = FrameLayout(this).apply { fitsSystemWindows = true }
        stage = FrameLayout(this)
        root.addView(stage, FrameLayout.LayoutParams(-1, -1))

        steps.forEachIndexed { i, st -> buildPage(i, st) }

        dots = DotsView(this, steps.size)
        root.addView(dots, FrameLayout.LayoutParams(-2, dp(10), Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply { topMargin = dp(28) })

        root.addView(TextView(this).apply {
            text = "Pular".tr()
            setTextAppearance(M.style.TextAppearance_Material3_LabelLarge)
            setTextColor(MaterialColors.getColor(this, M.attr.colorPrimary))
            setPadding(dp(16), dp(12), dp(16), dp(12))
            setOnClickListener { finishOnboarding() }
        }, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.END).apply { topMargin = dp(12); marginEnd = dp(8) })

        setContentView(root)

        applyMkBars()
        showOnly(0)
        stage.post {
            enter(0)
            dots.springIn(fromY = -18f, fromScale = 0.5f, delay = 250L, stiffness = 320f, damping = 0.55f)
            root.getChildAt(root.childCount - 1).springIn(fromY = -14f, fromScale = 0.8f, delay = 380L, stiffness = 320f, damping = 0.6f)
            stage.postDelayed(pulse, 2400L)
        }
    }

    override fun onResume() {
        super.onResume()
        refreshState()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) refreshState()    // volta do seletor/configurações do Android
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density + 0.5f).toInt()

    private fun isEnabled(): Boolean = try {
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
            .enabledInputMethodList.any { it.packageName == packageName }
    } catch (_: Exception) { false }

    private fun isSelected(): Boolean = try {
        Settings.Secure.getString(contentResolver, Settings.Secure.DEFAULT_INPUT_METHOD)
            ?.startsWith("$packageName/") == true
    } catch (_: Exception) { false }

    /** Ajusta botões conforme o que o usuário já fez nas configurações do Android. */
    private fun refreshState() {
        if (buttons.size < 3) return
        val enabled = isEnabled()
        val selected = isSelected()
        if (enabled) {
            bodies[1].text = "Pronto! O Material Keyboard está ativado.".tr()
            buttons[1].text = "Continuar".tr()
        }
        if (selected) {
            bodies[2].text = "Tudo certo! O Material Keyboard já é o seu teclado.".tr()
            buttons[2].text = "Concluir".tr()
        }
        // se o usuário ativou agora (voltando das configurações), avança sozinho
        if (current == 1 && enabled && justOpenedSettings) { justOpenedSettings = false; go(2) }
        if (current == 2 && selected && justOpenedPicker) { justOpenedPicker = false; arts[2].restart() }
    }

    private var justOpenedSettings = false
    private var justOpenedPicker = false

    private fun onPrimary(i: Int) {
        when (i) {
            0 -> go(1)
            1 -> if (isEnabled()) go(2) else {
                justOpenedSettings = true
                startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
            }
            2 -> if (isSelected()) finishOnboarding() else {
                justOpenedPicker = true
                (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
            }
        }
    }

    private fun finishOnboarding() {
        prefs.onboarded = true
        startActivity(Intent(this, SettingsActivity::class.java))
        finish()
    }

    // ---------- Construção ----------

    private fun buildPage(i: Int, st: Step) {
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(28), dp(72), dp(28), dp(28))
        }
        val art = KeyboardArtView(this, i)
        page.addView(art, LinearLayout.LayoutParams(-1, 0, 1.15f))
        arts.add(art)

        page.addView(TextView(this).apply {
            text = st.title
            gravity = Gravity.CENTER
            setTextAppearance(M.style.TextAppearance_Material3_HeadlineLarge)
            tag = "t"
        }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) })

        val body = TextView(this).apply {
            text = st.body
            gravity = Gravity.CENTER
            alpha = 0.75f
            setTextAppearance(M.style.TextAppearance_Material3_BodyLarge)
            tag = "b"
        }
        bodies.add(body)
        page.addView(body, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(14) })

        if (i == 0) page.addView(languageChips(), LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(20) })

        val btn = MaterialButton(this).apply {
            text = st.button
            textSize = 16f
            cornerRadius = dp(28)
            insetTop = 0; insetBottom = 0
            setOnClickListener { onPrimary(i) }
            tag = "btn"
        }
        buttons.add(btn)
        page.addView(btn, LinearLayout.LayoutParams(-1, dp(56)).apply { topMargin = dp(32) })

        stage.addView(page, FrameLayout.LayoutParams(-1, -1))
        pages.add(page)
    }

    /** Seletor de idioma do aplicativo inteiro; trocar recria o assistente já traduzido. */
    private fun languageChips(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER_HORIZONTAL
        L.NATIVE.entries.chunked(3).forEach { chunk ->
            addView(languageChipRow(chunk.map { it.key to it.value }), LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(4) })
        }
    }

    private fun languageChipRow(items: List<Pair<String, String>>): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER
        val ink = MaterialColors.getColor(this, M.attr.colorOnSurface, android.graphics.Color.WHITE)
        val accent = MaterialColors.getColor(this, M.attr.colorPrimary, android.graphics.Color.BLUE)
        val onAccent = MaterialColors.getColor(this, M.attr.colorOnPrimary, android.graphics.Color.WHITE)
        items.forEach { (code, name) ->
            val sel = prefs.language == code
            addView(TextView(this@OnboardingActivity).apply {
                text = name
                textSize = 13f
                gravity = Gravity.CENTER
                setPadding(dp(12), dp(8), dp(12), dp(8))
                setTextColor(if (sel) onAccent else ink)
                background = android.graphics.drawable.GradientDrawable().apply {
                    cornerRadius = dp(20).toFloat()
                    if (sel) setColor(accent) else setStroke(dp(1), ColorUtils.setAlphaComponent(ink, 70))
                }
                setOnClickListener {
                    if (prefs.language != code || prefs.uiLang.isNotEmpty()) { prefs.putString("uiLang", ""); prefs.putString("language", code); L.code = code; recreate() }
                }
            }, LinearLayout.LayoutParams(-2, -2).apply { marginStart = dp(3); marginEnd = dp(3) })
        }
    }

    private fun showOnly(i: Int) {
        pages.forEachIndexed { idx, p -> p.visibility = if (idx == i) View.VISIBLE else View.GONE }
        dots.moveTo(i.toFloat())
    }

    /**
     * Entrada de uma página: a ilustração cai e cresce com mola larga; título, texto e idiomas sobem em
     * cascata; o botão "incha" por último, com ricochete. Depois de um tempo, o botão dá um pulso de atenção.
     */
    private fun enter(i: Int) {
        val p = pages[i]
        arts[i].restart()
        for (c in 0 until p.childCount) {
            val v = p.getChildAt(c)
            when {
                v === arts[i] -> v.springIn(fromY = 44f, fromScale = 0.8f, stiffness = 240f, damping = 0.6f)
                v.tag == "btn" -> v.springIn(fromY = 22f, fromScale = 0.62f, delay = 70L * c + 90L, stiffness = 320f, damping = 0.5f)
                else -> v.springIn(fromY = 28f, fromScale = 0.96f, delay = 70L * c, stiffness = 300f, damping = 0.76f)
            }
        }
    }

    /** Pulso discreto no botão principal, a cada poucos segundos, chamando para o próximo passo. */
    private val pulse = object : Runnable {
        override fun run() {
            if (prefs.fluid) buttons.getOrNull(current)?.pop(0.94f, 0L, 520f, 0.3f)
            stage.postDelayed(this, 3400L)
        }
    }

    override fun onDestroy() { if (::stage.isInitialized) stage.removeCallbacks(pulse); super.onDestroy() }

    /**
     * Troca de página com paralaxe: a página sai encolhendo e some, a nova entra crescendo; dentro de cada uma,
     * a ilustração anda mais que o texto e o botão, o que dá profundidade (cada camada com sua mola).
     */
    private fun go(to: Int) {
        if (to == current || to !in pages.indices) return
        val dir = if (to > current) 1 else -1
        val out = pages[current]
        val inn = pages[to]
        val w = stage.width.toFloat().coerceAtLeast(1f)
        val depth = floatArrayOf(1.6f, 1.15f, 0.95f, 0.8f, 0.7f, 0.6f)

        for (c in 0 until out.childCount) out.getChildAt(c).springTo(DynamicAnimation.TRANSLATION_X, -dir * w * 0.30f * depth[c.coerceAtMost(5)], 300f, 1f)
        out.springTo(DynamicAnimation.SCALE_X, 0.93f, 320f, 1f)
        out.springTo(DynamicAnimation.SCALE_Y, 0.93f, 320f, 1f)
        out.springTo(DynamicAnimation.ALPHA, 0f, 520f, 1f) {
            if (current != pages.indexOf(out)) {
                out.visibility = View.GONE
                out.scaleX = 1f; out.scaleY = 1f
                for (c in 0 until out.childCount) out.getChildAt(c).translationX = 0f
            }
        }

        inn.visibility = View.VISIBLE
        inn.scaleX = 1.06f; inn.scaleY = 1.06f
        inn.springTo(DynamicAnimation.SCALE_X, 1f, 300f, 0.85f)
        inn.springTo(DynamicAnimation.SCALE_Y, 1f, 300f, 0.85f)
        inn.alpha = 0f
        inn.springTo(DynamicAnimation.ALPHA, 1f, 480f, 1f)
        for (c in 0 until inn.childCount) {
            val v = inn.getChildAt(c)
            v.translationX = dir * w * 0.45f * depth[c.coerceAtMost(5)]
            v.springTo(DynamicAnimation.TRANSLATION_X, 0f, 260f + 20f * c, 0.78f)
        }
        current = to
        back.isEnabled = to > 0
        dots.moveTo(to.toFloat())
        refreshState()
        enter(to)
    }
}

/** Indicador de passos: o ponto ativo vira uma pílula, com mola. */
class DotsView(ctx: Context, private val n: Int) : View(ctx) {
    private var pos = 0f
    private var anim: SpringAnimation? = null
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val prop = object : FloatPropertyCompat<DotsView>("pos") {
        override fun getValue(o: DotsView) = o.pos
        override fun setValue(o: DotsView, v: Float) { o.pos = v; o.invalidate() }
    }
    private val d = resources.displayMetrics.density
    private val on = MaterialColors.getColor(this, M.attr.colorPrimary)
    private val off = ColorUtils.setAlphaComponent(MaterialColors.getColor(this, M.attr.colorOnSurface), 70)

    fun moveTo(p: Float) {
        anim?.cancel()
        anim = SpringAnimation(this, prop).also {
            it.setSpring(SpringForce(p).setStiffness(350f).setDampingRatio(0.7f)); it.start()
        }
    }

    private fun wOf(i: Int) = (8f + 18f * (1f - minOf(1f, abs(pos - i)))) * d

    override fun onMeasure(w: Int, h: Int) {
        setMeasuredDimension(((26f * n + 8f * (n - 1)) * d).toInt(), (10 * d).toInt())
    }

    override fun onDraw(c: Canvas) {
        var total = -8f * d
        for (i in 0 until n) total += wOf(i) + 8f * d
        var x = (width - total) / 2f
        val h = 8f * d
        val top = (height - h) / 2f
        for (i in 0 until n) {
            val w = wOf(i)
            val t = (1f - minOf(1f, abs(pos - i)))
            paint.color = ColorUtils.blendARGB(off, on, t)
            c.drawRoundRect(RectF(x, top, x + w, top + h), h / 2, h / 2, paint)
            x += w + 8f * d
        }
    }
}

/**
 * Ilustração animada: um teclado com teclas em pílula que "brotam" com mola e depois ondulam.
 * Etapa 1 mostra um interruptor ligando; etapa 2 mostra um selo de confirmação.
 */
class KeyboardArtView(ctx: Context, private val mode: Int) : View(ctx) {

    private var start = SystemClock.uptimeMillis()
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private val check = Path()
    private val d = resources.displayMetrics.density

    private val cKey = MaterialColors.getColor(this, M.attr.colorSurfaceContainerHighest)
    private val cKeyAlt = MaterialColors.getColor(this, M.attr.colorSecondaryContainer)
    private val cPrimary = MaterialColors.getColor(this, M.attr.colorPrimary)
    private val cOnPrimary = MaterialColors.getColor(this, M.attr.colorOnPrimary)
    private val cTrack = MaterialColors.getColor(this, M.attr.colorOutline)

    private val rows = intArrayOf(10, 9, 7)

    fun restart() { start = SystemClock.uptimeMillis(); invalidate() }

    /** Resposta ao degrau de uma mola subamortecida (0 → 1 com leve ultrapassagem). */
    private fun pop(t: Float): Float {
        if (t <= 0f) return 0f
        val zeta = 0.45f; val w0 = 16f
        val wd = w0 * sqrt(1f - zeta * zeta)
        val e = exp(-zeta * w0 * t)
        return 1f - e * (cos(wd * t) + (zeta * w0 / wd) * sin(wd * t))
    }

    private val measure = android.graphics.PathMeasure()
    private val seg = Path()

    override fun onDraw(c: Canvas) {
        val t = (SystemClock.uptimeMillis() - start) / 1000f
        val w = width.toFloat(); val h = height.toFloat()
        if (w <= 0f) return

        val kbW = minOf(w, 360f * d)
        val gap = 6f * d
        val keyH = minOf((h * 0.62f - gap * 3) / 4f, 46f * d)
        val kbH = keyH * 4 + gap * 3
        val left0 = (w - kbW) / 2f
        val baseTop = (h - kbH) / 2f - (if (mode == 0) 0f else 18f * d)
        // depois de montado, o teclado flutua devagar
        val amp = (t - 1.2f).coerceIn(0f, 1f)
        val bob = sin(t * 1.7f) * 3.5f * d * amp
        val top0 = baseTop + bob

        // sombra suave embaixo, acompanhando a flutuação
        val sh = pop(t - 0.7f).coerceIn(0f, 1f)
        paint.color = ColorUtils.setAlphaComponent(cPrimary, (34 * sh).toInt())
        rect.set(left0 + kbW * 0.14f - bob, baseTop + kbH + 16f * d, left0 + kbW * 0.86f + bob, baseTop + kbH + 26f * d)
        c.drawOval(rect, paint)

        val unit = (kbW - gap * 9) / 10f
        var idx = 0
        for (r in rows.indices) {
            val n = rows[r]
            val inset = (10 - n) * 0.5f
            for (k in 0 until n) {
                val col = inset + k
                // as teclas brotam a partir do centro, uma onda circular
                val dx = (col + 0.5f) - 5f; val dy = (r - 1f) * 1.7f
                val dist = sqrt(dx * dx + dy * dy)
                val tt = t - (0.05f + dist * 0.06f)
                val s = pop(tt).coerceAtLeast(0f)
                val a = minOf(1f, tt * 8f).coerceAtLeast(0f)
                // depois da entrada, um anel de brilho se espalha do centro, de tempos em tempos
                var glow = 0f
                if (t > 1.7f) {
                    val ring = ((t - 1.7f) * 5.5f) % 14f
                    glow = (1f - abs(ring - dist * 1.2f) / 1.8f).coerceIn(0f, 1f)
                }
                val x = left0 + col * (unit + gap)
                val y = top0 + r * (keyH + gap) - (1f - s.coerceAtMost(1f)) * 26f * d   // cai ao brotar
                val sc = s * (1f + 0.12f * glow)
                val cx = x + unit / 2f; val cy = y + keyH / 2f
                rect.set(cx - unit / 2f * sc, cy - keyH / 2f * sc, cx + unit / 2f * sc, cy + keyH / 2f * sc)
                val base = if ((idx % 7) == 3) cKeyAlt else cKey
                paint.color = ColorUtils.setAlphaComponent(ColorUtils.blendARGB(base, cPrimary, glow * 0.85f), (255 * a).toInt())
                val rad = keyH / 2f * (1f - 0.35f * glow)
                c.drawRoundRect(rect, rad, rad, paint)
                idx++
            }
        }
        // barra de espaço
        run {
            val tt = t - 0.55f
            val s = pop(tt).coerceAtLeast(0f); val a = minOf(1f, tt * 7f).coerceAtLeast(0f)
            val y = top0 + 3 * (keyH + gap) - (1f - s.coerceAtMost(1f)) * 26f * d
            val sw = kbW * 0.62f
            val cx = w / 2f; val cy = y + keyH / 2f
            rect.set(cx - sw / 2f * s, cy - keyH / 2f * s, cx + sw / 2f * s, cy + keyH / 2f * s)
            paint.color = ColorUtils.setAlphaComponent(cKey, (255 * a).toInt())
            c.drawRoundRect(rect, keyH / 2f, keyH / 2f, paint)
        }

        val under = baseTop + kbH + 34f * d
        when (mode) {
            1 -> drawSwitch(c, w / 2f, under + 20f * d, t)
            2 -> drawBadge(c, w / 2f, under + 20f * d, t)
        }
        postInvalidateOnAnimation()
    }

    private fun drawSwitch(c: Canvas, cx: Float, cy: Float, t: Float) {
        val cyc = t % 4f
        val p = (if (cyc >= 3.4f) 1f - pop(cyc - 3.4f) else pop(cyc - 1.0f)).coerceIn(0f, 1f)
        val enter = pop(t - 0.9f).coerceIn(0f, 1.2f)
        val tw = 76f * d; val th = 44f * d
        val sc = enter
        // enquanto desligado, um anel pulsa em volta do interruptor chamando o toque
        if (p < 0.4f && enter > 0.9f) {
            val ph = (t % 1.6f) / 1.6f
            val grow = ph * 14f * d
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 2f * d
            paint.color = ColorUtils.setAlphaComponent(cPrimary, ((1f - ph) * 130f).toInt())
            rect.set(cx - tw / 2f - grow, cy - th / 2f - grow, cx + tw / 2f + grow, cy + th / 2f + grow)
            c.drawRoundRect(rect, th / 2f + grow, th / 2f + grow, paint)
            paint.style = Paint.Style.FILL
        }
        rect.set(cx - tw / 2f * sc, cy - th / 2f * sc, cx + tw / 2f * sc, cy + th / 2f * sc)
        paint.color = ColorUtils.blendARGB(cTrack, cPrimary, p)
        c.drawRoundRect(rect, th / 2f, th / 2f, paint)
        val kr = (12f + 4f * p) * d * sc
        val kx = cx + (-tw / 2f + th / 2f + (tw - th) * p) * sc
        paint.color = ColorUtils.blendARGB(0xFFFFFFFF.toInt(), cOnPrimary, p)
        c.drawCircle(kx, cy, kr, paint)
    }

    /** Selo ondulado que gira devagar, o visto se desenha aos poucos e confetes saem do centro. */
    private fun drawBadge(c: Canvas, cx: Float, cy: Float, t: Float) {
        val cyc = t % 4f
        val s = if (cyc >= 3.5f) (1f - pop(cyc - 3.5f)).coerceAtLeast(0f) else pop(cyc - 0.8f).coerceAtLeast(0f)
        val r = 30f * d * s
        c.save()
        c.rotate(t * 24f, cx, cy)
        rect.set(cx - r, cy - r, cx + r, cy + r)
        check.reset()
        PopupShapes.scallop(check, rect, 10, 0.13f, false)
        paint.color = cPrimary
        c.drawPath(check, paint)
        c.restore()

        val q = ((cyc - 1.05f) / 0.45f).coerceIn(0f, 1f)
        val prog = 1f - (1f - q) * (1f - q)
        if (cyc < 3.5f && prog > 0f) {
            check.reset()
            check.moveTo(cx - 12f * d, cy + 1f * d)
            check.lineTo(cx - 3f * d, cy + 10f * d)
            check.lineTo(cx + 13f * d, cy - 9f * d)
            measure.setPath(check, false)
            seg.reset()
            measure.getSegment(0f, measure.length * prog, seg, true)
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 4f * d
            paint.strokeCap = Paint.Cap.ROUND
            paint.strokeJoin = Paint.Join.ROUND
            paint.color = cOnPrimary
            c.drawPath(seg, paint)
            paint.style = Paint.Style.FILL
        }

        val ct = cyc - 0.9f
        if (ct in 0f..1f) {
            val ease = 1f - (1f - ct) * (1f - ct)
            for (i in 0 until 10) {
                val ang = (i * 36f) * PI.toFloat() / 180f
                val dist = (24f + 44f * ease) * d
                paint.color = ColorUtils.setAlphaComponent(if (i % 2 == 0) cPrimary else cKeyAlt, ((1f - ct) * 255f).toInt())
                c.drawCircle(cx + cos(ang) * dist, cy + sin(ang) * dist, (1f + 3f * (1f - ct)) * d, paint)
            }
        }
    }
}

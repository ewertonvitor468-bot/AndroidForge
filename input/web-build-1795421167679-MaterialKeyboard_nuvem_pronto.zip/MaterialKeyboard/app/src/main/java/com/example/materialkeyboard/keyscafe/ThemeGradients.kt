package com.example.materialkeyboard.keyscafe

import android.graphics.drawable.GradientDrawable
import com.example.materialkeyboard.Prefs

/**
 * Passo 3: desenha o gradiente de FUNDO ("surface") do tema ativo. Só lê o ThemeSpec guardado na biblioteca;
 * nenhum código vem do pacote. Gradientes de tecla e de destaque ([forKey]) são desenhados pelo KeyView.
 */
object ThemeGradients {

    /** Ângulo (graus, 0 = esquerda→direita, 90 = baixo→cima) ajustado ao múltiplo de 45° mais próximo. */
    fun orientation(angle: Int): GradientDrawable.Orientation {
        val a = (((Math.round(angle / 45f) * 45) % 360) + 360) % 360
        return when (a) {
            0 -> GradientDrawable.Orientation.LEFT_RIGHT
            45 -> GradientDrawable.Orientation.BL_TR
            90 -> GradientDrawable.Orientation.BOTTOM_TOP
            135 -> GradientDrawable.Orientation.BR_TL
            180 -> GradientDrawable.Orientation.RIGHT_LEFT
            225 -> GradientDrawable.Orientation.TR_BL
            270 -> GradientDrawable.Orientation.TOP_BOTTOM
            else -> GradientDrawable.Orientation.TL_BR
        }
    }

    /** Gradiente de tecla ("key") ou de destaque ("accent") do tema ativo, ou null. Imagem de fundo desliga (cores não bateriam). */
    fun forKey(prefs: Prefs, target: String): SpecGradient? {
        val id = prefs.patch
        if (id.isEmpty() || prefs.themeImage) return null
        return ThemeLibrary.get(id)?.gradients?.firstOrNull { it.target == target && it.colors.size >= 2 }
    }

    /** Fundo em gradiente do tema ativo, ou null se o tema não tem (ou não há tema da comunidade ativo). */
    fun surface(prefs: Prefs, topRadius: Float): GradientDrawable? {
        val id = prefs.patch
        if (id.isEmpty()) return null
        val g = ThemeLibrary.get(id)?.gradients?.firstOrNull { it.target == "surface" } ?: return null
        if (g.colors.size < 2) return null
        return GradientDrawable(orientation(g.angle), g.colors.map { it.toInt() }.toIntArray()).apply {
            cornerRadii = floatArrayOf(topRadius, topRadius, topRadius, topRadius, 0f, 0f, 0f, 0f)
        }
    }
}

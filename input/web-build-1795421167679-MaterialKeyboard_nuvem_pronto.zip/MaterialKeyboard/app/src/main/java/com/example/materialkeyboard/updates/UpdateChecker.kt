package com.example.materialkeyboard.updates

import android.content.Context
import androidx.core.content.pm.PackageInfoCompat
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Uma versão publicada como release no GitHub. */
data class AppUpdate(
    val versionCode: Long, val versionName: String, val notes: String, val apkUrl: String,
    val sizeBytes: Long, val sha256: String, val mandatory: Boolean, val publishedAt: String
)

sealed class UpdateResult {
    data class Ok(val update: AppUpdate?) : UpdateResult()   // null = nenhuma versão publicada
    object NotConfigured : UpdateResult()
    data class Fail(val reason: String) : UpdateResult()
}

/** Consulta o último release do GitHub (HttpURLConnection + org.json, sem dependências novas). Funções bloqueantes: fora da thread principal. */
object UpdateChecker {
    private const val SP = "mk_updates"

    fun currentCode(ctx: Context): Long = try {
        PackageInfoCompat.getLongVersionCode(ctx.packageManager.getPackageInfo(ctx.packageName, 0))
    } catch (_: Exception) { 0L }

    fun currentName(ctx: Context): String = try {
        ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName ?: ""
    } catch (_: Exception) { "" }

    /** Número comparável de um nome de versão: "54.7" -> 54_007_000 (aceita prefixo v/V e sufixos). */
    fun verKey(name: String): Long {
        val parts = name.trim().removePrefix("v").removePrefix("V").split('.', '-', '_')
        var k = 0L
        for (i in 0 until 3) {
            val n = parts.getOrNull(i)?.takeWhile { it.isDigit() }?.toLongOrNull() ?: 0L
            k = k * 1000 + n
        }
        return k
    }

    fun isNewer(ctx: Context, u: AppUpdate) = verKey(u.versionName) > verKey(currentName(ctx))

    /** Busca os releases do GitHub e escolhe o de MAIOR número de versão (o "latest" do GitHub usa a data do commit, que engana). */
    fun check(ctx: Context): UpdateResult {
        if (!UpdatesConfig.configured) return UpdateResult.NotConfigured
        return try {
            val api = "https://api.github.com/repos/${UpdatesConfig.GITHUB_OWNER}/${UpdatesConfig.GITHUB_REPO}/releases?per_page=30"
            val c = URL(api).openConnection() as HttpURLConnection
            try {
                c.connectTimeout = 10_000; c.readTimeout = 15_000
                c.setRequestProperty("Accept", "application/vnd.github+json")
                c.setRequestProperty("User-Agent", "MaterialKeyboard-Updater")
                if (c.responseCode == 404) return UpdateResult.Fail("Repositório não encontrado. Ele precisa ser público.")
                if (c.responseCode !in 200..299) return UpdateResult.Fail("Não foi possível verificar agora.")
                val text = c.inputStream.use { it.readBytes().toString(Charsets.UTF_8) }
                val arr = org.json.JSONArray(text)
                var best: AppUpdate? = null
                for (i in 0 until arr.length()) {
                    val o = arr.optJSONObject(i) ?: continue
                    if (o.optBoolean("draft") || o.optBoolean("prerelease")) continue
                    val u = parseRelease(o) ?: continue
                    if (best == null || u.versionCode > best.versionCode) best = u
                }
                save(ctx, best)
                UpdateResult.Ok(best)
            } finally { c.disconnect() }
        } catch (_: java.net.UnknownHostException) { UpdateResult.Fail("Sem internet.") }
        catch (_: java.net.SocketTimeoutException) { UpdateResult.Fail("A conexão demorou demais.") }
        catch (_: java.io.IOException) { UpdateResult.Fail("Falha de rede.") }
        catch (_: Exception) { UpdateResult.Fail("Resposta inesperada do servidor.") }
    }

    /** Release do GitHub -> AppUpdate. Usa o 1º arquivo .apk anexado; a tag (sem o "v") é o nome da versão. */
    private fun parseRelease(o: JSONObject): AppUpdate? {
        val name = o.str("tag_name").removePrefix("v").removePrefix("V")
        if (name.isEmpty()) return null
        val assets = o.optJSONArray("assets") ?: return null
        var apk: JSONObject? = null
        for (i in 0 until assets.length()) {
            val a = assets.optJSONObject(i) ?: continue
            if (a.str("name").endsWith(".apk", ignoreCase = true)) { apk = a; break }
        }
        val a = apk ?: return null
        val url = a.str("browser_download_url")
        if (!url.startsWith("https://")) return null            // só HTTPS
        val digest = a.str("digest")                              // "sha256:..." (o GitHub preenche nos uploads novos)
        val sha = if (digest.startsWith("sha256:")) digest.removePrefix("sha256:").lowercase() else ""
        return AppUpdate(
            versionCode = verKey(name), versionName = name, notes = o.str("body"), apkUrl = url,
            sizeBytes = a.optLong("size", 0L), sha256 = sha, mandatory = false, publishedAt = o.str("published_at")
        ).takeIf { it.versionCode > 0 }
    }

    private fun JSONObject.str(k: String) = if (isNull(k)) "" else optString(k, "")

    private fun parse(o: JSONObject): AppUpdate? {
        val url = o.str("apk_url")
        if (!url.startsWith("https://")) return null            // só HTTPS
        return AppUpdate(
            versionCode = o.optLong("version_code", 0), versionName = o.str("version_name"),
            notes = o.str("release_notes"), apkUrl = url,
            sizeBytes = if (o.isNull("apk_size_bytes")) 0L else o.optLong("apk_size_bytes", 0),
            sha256 = o.str("apk_sha256").lowercase(), mandatory = o.optBoolean("is_mandatory", false),
            publishedAt = o.str("published_at")
        ).takeIf { it.versionCode > 0 }
    }

    // ---- cache: a tela inicial mostra "nova versão" sem depender de rede ----

    private fun save(ctx: Context, u: AppUpdate?) {
        val o = u?.let {
            JSONObject().put("version_code", it.versionCode).put("version_name", it.versionName)
                .put("release_notes", it.notes).put("apk_url", it.apkUrl).put("apk_size_bytes", it.sizeBytes)
                .put("apk_sha256", it.sha256).put("is_mandatory", it.mandatory).put("published_at", it.publishedAt)
        }
        ctx.applicationContext.getSharedPreferences(SP, Context.MODE_PRIVATE).edit()
            .putString("latest", o?.toString() ?: "").putLong("last", System.currentTimeMillis()).apply()
    }

    /** Última versão publicada conhecida (do cache), só se for mais nova que a instalada. */
    fun cachedNewer(ctx: Context): AppUpdate? = try {
        val s = ctx.applicationContext.getSharedPreferences(SP, Context.MODE_PRIVATE).getString("latest", "") ?: ""
        if (s.isEmpty()) null else parse(JSONObject(s))?.takeIf { isNewer(ctx, it) }
    } catch (_: Exception) { null }

    /** Verificação automática em segundo plano: no máximo uma a cada [UpdatesConfig.AUTO_CHECK_MS]. */
    fun refreshIfDue(ctx: Context) {
        if (!UpdatesConfig.configured) return
        val app = ctx.applicationContext
        val sp = app.getSharedPreferences(SP, Context.MODE_PRIVATE)
        if (System.currentTimeMillis() - sp.getLong("last", 0L) < UpdatesConfig.AUTO_CHECK_MS) return
        sp.edit().putLong("last", System.currentTimeMillis()).apply()   // evita disparos repetidos
        Thread { check(app) }.start()
    }
}

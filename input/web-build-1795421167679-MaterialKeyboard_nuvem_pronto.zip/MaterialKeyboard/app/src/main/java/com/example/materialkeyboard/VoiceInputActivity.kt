package com.example.materialkeyboard

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.os.Bundle
import android.speech.RecognizerIntent
import android.widget.Toast

/**
 * Plano B do microfone: quando o aparelho não tem a "Digitação por voz do Google" como método
 * de entrada, abre o reconhecimento de voz do Google e devolve o texto ao teclado.
 * A activity é transparente: o usuário só vê o diálogo "Fale agora".
 */
class VoiceInputActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (savedInstanceState != null) return
        val lang = when (Prefs.get(this).language) {
            Prefs.LANG_EN -> "en-US"; Prefs.LANG_RU -> "ru-RU"; Prefs.LANG_ES -> "es-ES"; Prefs.LANG_AR -> "ar-SA"; Prefs.LANG_FR -> "fr-FR"; Prefs.LANG_TR -> "tr-TR"; Prefs.LANG_VI -> "vi-VN"; else -> "pt-BR"
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
        }
        try {
            @Suppress("DEPRECATION")
            startActivityForResult(intent, REQ)
        } catch (_: ActivityNotFoundException) {
            Toast.makeText(this, "Reconhecimento de voz do Google não encontrado".tr(), Toast.LENGTH_LONG).show()
            finish()
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ && resultCode == RESULT_OK) {
            val text = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!text.isNullOrBlank()) KeyboardService.deliverVoice(text)
        }
        finish()
    }

    private companion object { const val REQ = 77 }
}

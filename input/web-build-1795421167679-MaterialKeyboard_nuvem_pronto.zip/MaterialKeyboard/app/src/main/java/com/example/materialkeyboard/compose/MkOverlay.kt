package com.example.materialkeyboard.compose

import androidx.compose.runtime.Composable

/**
 * Overlay visual por cima do teclado (tamanho total, sem toque).
 * Reservado para efeitos futuros; hoje não desenha nada e só confirma no logcat que o Compose roda.
 */
@Composable
fun MkOverlay() {
    ComposeLayer.logActive()
}

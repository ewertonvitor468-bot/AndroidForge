package com.example.materialkeyboard.keyscafe

import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.security.MessageDigest
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

sealed class PackageRead {
    data class Ok(
        val spec: ThemeSpec,
        val warnings: List<String>,
        /** Só os arquivos que o tema realmente usa, por caminho ("assets/bg.webp"). */
        val assets: Map<String, ByteArray>,
        val preview: ByteArray?,
        /** SHA-256 do pacote inteiro, em hexadecimal minúsculo (é o que o ThemeBoard registra). */
        val sha256: String
    ) : PackageRead()
    data class Fail(val reason: String) : PackageRead()
}

sealed class PackageBuild {
    data class Ok(val bytes: ByteArray, val sha256: String) : PackageBuild()
    data class Fail(val reason: String) : PackageBuild()
}

/**
 * Pacote de Tema (.mkt): um zip com
 *   theme.json        o ThemeSpec
 *   preview.webp      miniatura (opcional)
 *   assets/<nome>     imagens usadas pelo tema (png, jpg ou webp)
 * Tudo que vem de fora é tratado como NÃO CONFIÁVEL: lista fechada de nomes, limites de tamanho
 * (inclusive depois de descompactar), conferência dos primeiros bytes das imagens e nenhum
 * arquivo que não seja dado. Sons e fontes ainda NÃO são aceitos nesta versão do formato.
 */
object ThemePackage {
    const val EXTENSION = "mkt"
    const val MAX_PACKAGE_BYTES = 10 * 1024 * 1024
    const val MAX_UNPACKED_BYTES = 12 * 1024 * 1024
    const val MAX_ENTRIES = 12
    private const val MAX_JSON_BYTES = 256 * 1024
    private const val MAX_PREVIEW_BYTES = 512 * 1024
    private const val MAX_IMAGE_BYTES = 6 * 1024 * 1024

    private const val THEME_JSON = "theme.json"
    private const val PREVIEW = "preview.webp"
    private val ENTRY_NAME = Regex("^(theme\\.json|preview\\.webp|assets/[A-Za-z0-9._-]{1,64})$")
    private val UNSUPPORTED_EXT = setOf("ogg", "wav", "mp3", "m4a", "aac", "flac", "ttf", "otf", "woff", "woff2")

    // ---------------------------------------------------------------- ler

    fun read(input: InputStream, appVersion: Int = Int.MAX_VALUE): PackageRead {
        val raw = readLimited(input, MAX_PACKAGE_BYTES) ?: return PackageRead.Fail("O pacote é grande demais.")
        if (raw.isEmpty()) return PackageRead.Fail("O pacote está vazio.")
        val sha = sha256(raw)

        var json: ByteArray? = null
        var preview: ByteArray? = null
        val assets = LinkedHashMap<String, ByteArray>()
        val seen = HashSet<String>()
        var entries = 0
        var unpacked = 0L

        try {
            ZipInputStream(ByteArrayInputStream(raw)).use { zin ->
                while (true) {
                    val e: ZipEntry = zin.nextEntry ?: break
                    if (e.isDirectory) continue
                    entries++
                    if (entries > MAX_ENTRIES) return PackageRead.Fail("O pacote tem arquivos demais.")
                    val name = e.name
                    if (name.contains("..") || !ENTRY_NAME.matches(name)) {
                        val ext = name.substringAfterLast('.', "").lowercase()
                        return if (ext in UNSUPPORTED_EXT) PackageRead.Fail("Sons e fontes ainda não são aceitos nos pacotes.")
                        else PackageRead.Fail("O pacote tem um arquivo não permitido.")
                    }
                    if (!seen.add(name)) return PackageRead.Fail("O pacote tem arquivos repetidos.")

                    val cap = when {
                        name == THEME_JSON -> MAX_JSON_BYTES
                        name == PREVIEW -> MAX_PREVIEW_BYTES
                        else -> MAX_IMAGE_BYTES
                    }
                    val data = readLimited(zin, cap) ?: return PackageRead.Fail("Um arquivo do pacote é grande demais.")
                    unpacked += data.size
                    if (unpacked > MAX_UNPACKED_BYTES) return PackageRead.Fail("O pacote descompactado é grande demais.")

                    when {
                        name == THEME_JSON -> json = data
                        name == PREVIEW -> {
                            if (!looksLikeImage(data, name)) return PackageRead.Fail("A miniatura não é uma imagem válida.")
                            preview = data
                        }
                        else -> {
                            val ext = name.substringAfterLast('.', "").lowercase()
                            if (ext in UNSUPPORTED_EXT) return PackageRead.Fail("Sons e fontes ainda não são aceitos nos pacotes.")
                            if (!looksLikeImage(data, name)) return PackageRead.Fail("O arquivo $name não é uma imagem válida.")
                            assets[name] = data
                        }
                    }
                }
            }
        } catch (_: Exception) {
            return PackageRead.Fail("O pacote está corrompido.")
        }

        val jsonBytes = json ?: return PackageRead.Fail("O pacote não tem theme.json.")
        val parsed = when (val r = ThemeSpecJson.parse(String(jsonBytes, Charsets.UTF_8), appVersion)) {
            is SpecParse.Fail -> return PackageRead.Fail(r.reason)
            is SpecParse.Ok -> r
        }

        val warnings = ArrayList<String>(parsed.warnings)
        val used = LinkedHashMap<String, ByteArray>()
        val wanted = parsed.spec.image?.asset
        if (wanted != null) {
            val bytes = assets[wanted] ?: return PackageRead.Fail("A imagem de fundo do tema não está no pacote.")
            used[wanted] = bytes
        }
        if (assets.keys.any { it !in used }) warnings.add("Arquivos que o tema não usa foram descartados")
        return PackageRead.Ok(parsed.spec, warnings, used, preview, sha)
    }

    // ---------------------------------------------------------------- gerar

    fun build(spec: ThemeSpec, preview: ByteArray?, assets: Map<String, ByteArray>): PackageBuild {
        val json = ThemeSpecJson.toJson(spec)
        if (json.length > SpecLimits.JSON_MAX_CHARS) return PackageBuild.Fail("O tema é grande demais.")
        if (preview != null) {
            if (preview.size > MAX_PREVIEW_BYTES) return PackageBuild.Fail("A miniatura é grande demais.")
            if (!looksLikeImage(preview, PREVIEW)) return PackageBuild.Fail("A miniatura não é uma imagem válida.")
        }
        if (assets.size > MAX_ENTRIES - 2) return PackageBuild.Fail("Arquivos demais no tema.")
        for ((name, data) in assets) {
            if (name.contains("..") || !ENTRY_NAME.matches(name) || !name.startsWith("assets/"))
                return PackageBuild.Fail("Nome de arquivo não permitido: $name")
            if (data.size > MAX_IMAGE_BYTES) return PackageBuild.Fail("O arquivo $name é grande demais.")
            if (!looksLikeImage(data, name)) return PackageBuild.Fail("O arquivo $name precisa ser png, jpg ou webp.")
        }
        spec.image?.let { if (it.asset !in assets) return PackageBuild.Fail("A imagem de fundo do tema não foi enviada.") }

        val baos = ByteArrayOutputStream()
        ZipOutputStream(baos).use { z ->
            fun put(name: String, data: ByteArray) {
                z.putNextEntry(ZipEntry(name)); z.write(data); z.closeEntry()
            }
            put(THEME_JSON, json.toByteArray(Charsets.UTF_8))
            if (preview != null) put(PREVIEW, preview)
            for ((name, data) in assets) put(name, data)
        }
        val out = baos.toByteArray()
        if (out.size > MAX_PACKAGE_BYTES) return PackageBuild.Fail("O pacote passou do limite de tamanho.")
        return PackageBuild.Ok(out, sha256(out))
    }

    // ---------------------------------------------------------------- apoio

    fun sha256(b: ByteArray): String =
        MessageDigest.getInstance("SHA-256").digest(b).joinToString("") { "%02x".format(it) }

    /** Lê até [max] bytes; devolve null se passar do limite (protege de zip-bomb). */
    private fun readLimited(input: InputStream, max: Int): ByteArray? {
        val out = ByteArrayOutputStream()
        val buf = ByteArray(8192)
        var total = 0
        while (true) {
            val n = input.read(buf)
            if (n < 0) break
            total += n
            if (total > max) return null
            out.write(buf, 0, n)
        }
        return out.toByteArray()
    }

    /** Confere só os primeiros bytes (assinatura do formato). A decodificação real fica por conta do BitmapFactory. */
    private fun looksLikeImage(b: ByteArray, name: String): Boolean {
        fun at(i: Int, v: Int) = b.size > i && (b[i].toInt() and 0xFF) == v
        return when (name.substringAfterLast('.', "").lowercase()) {
            "png" -> at(0, 0x89) && at(1, 0x50) && at(2, 0x4E) && at(3, 0x47)
            "jpg", "jpeg" -> at(0, 0xFF) && at(1, 0xD8) && at(2, 0xFF)
            "webp" -> at(0, 'R'.code) && at(1, 'I'.code) && at(2, 'F'.code) && at(3, 'F'.code) &&
                at(8, 'W'.code) && at(9, 'E'.code) && at(10, 'B'.code) && at(11, 'P'.code)
            else -> false
        }
    }
}

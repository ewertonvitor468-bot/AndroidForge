package com.example.materialkeyboard

import android.content.Context

/**
 * Sugestões, autocorreção e próxima palavra com dicionário embutido pequeno
 * mais palavras aprendidas com o uso (guardadas localmente, limitadas).
 * Consultas são feitas fora da thread principal pelo serviço.
 */
class Suggestions(ctx: Context) {

    private val appCtx = ctx.applicationContext
    private val sp = ctx.applicationContext.getSharedPreferences("learned_words", Context.MODE_PRIVATE)
    private val learned = java.util.concurrent.ConcurrentHashMap<String, Int>()   // palavra -> frequência

    init {
        try { sp.all.forEach { (k, v) -> if (v is Int) learned[k] = v } } catch (_: Exception) { }
    }

    private val pt = ("de a o que e do da em um para é com não uma os no se na por mais as dos como mas foi ao ele das tem à seu sua ou ser quando muito há nos já está eu também só pelo pela até isso ela entre era depois sem mesmo aos ter seus quem nas me esse eles estão você tinha foram essa num nem suas meu às minha têm numa pelos elas havia seja qual será nós tenho lhe deles essas esses pelas este fosse dele tu te vocês vos lhes meus minhas teu tua teus tuas nosso nossa nossos nossas dela delas esta estes estas aquele aquela aqueles aquelas isto aquilo " +
            "olá oi tudo bem obrigado obrigada por favor desculpa tchau amanhã hoje ontem agora depois antes aqui ali onde quando porque então vamos vou vai fazer fazendo feito casa trabalho amigo amiga família tempo dia noite tarde manhã semana mês ano vida coisa pessoa gente lugar mundo parte forma caso ponto água comida carro telefone mensagem ligar falar dizer saber querer poder dever precisar ficar chegar passar deixar parecer começar acabar pensar encontrar sentir pedir esperar conseguir trazer levar comprar vender abrir fechar ouvir ver olhar gostar amar viver morrer sempre nunca talvez também ainda outra outro outras outros grande pequeno novo velho bom boa melhor pior primeiro último verdade certo claro sim aqui lá cada todo toda todos todas nada tudo alguém ninguém algum alguma qualquer jogo música filme livro cidade país escola hora minuto segundo preciso podemos estou estamos estava estavam tenho temos tinha fazer disse falou parabéns beleza blz valeu legal combinado fechado").split(" ").filter { it.isNotEmpty() }
    private val en = ("the be to of and a in that have i it for not on with he as you do at this but his by from they we say her she or an will my one all would there their what so up out if about who get which go me when make can like time no just him know take people into year your good some could them see other than then now look only come its over think also back after use two how our work first well way even new want because any these give day most us hello hi thanks thank please sorry good morning night today tomorrow yesterday friend family house phone message call talk need love life world right left home school great little large").split(" ").filter { it.isNotEmpty() }

    private val ptExtra = ("sobre ainda aqui nosso nossa precisa preciso quero queria posso podia pode sabe sabia vejo veja vamos venha vem vim fui foi fomos fiz fez fazem faço digo disse diga falar fala falei tenho tinha tive teve temos têm terá seria seríamos estou estava estive esteve estamos estão estaria haver haja houve houver pessoas coisas tempo vezes vez dias noites horas minutos segundos anos meses semanas hoje cedo logo breve rápido devagar sempre jamais nunca algo alguns algumas outros outras mesmo mesma tanto tanta tantos tantas pouco pouca poucos poucas muita muitos muitas todo toda demais apenas somente também ainda já agora enquanto durante depois antes contra entre sobre sob desde até para pela pelo pelas pelos perto longe dentro fora acima abaixo frente atrás lado meio fim começo início final " +
            "exemplo problema questão resposta pergunta ideia informação número nome história trabalho empresa projeto reunião aula prova estudo curso professor professora aluno aluna médico médica hospital remédio saúde dinheiro preço valor pagamento conta banco cartão compra loja mercado padaria restaurante almoço jantar café lanche fome sede sono cansado cansada feliz triste bravo brava calma calmo animado animada pronto pronta ocupado ocupada livre aberto fechada " +
            "celular internet aplicativo mensagem ligação chamada vídeo foto imagem arquivo email senha usuário conta site página link rede wifi bateria carregador computador notebook teclado tela " +
            "mãe pai filho filha irmão irmã tio tia avô avó primo prima marido esposa namorado namorada amigos amigas vizinho colega chefe cliente " +
            "segunda terça quarta quinta sexta sábado domingo janeiro fevereiro março abril maio junho julho agosto setembro outubro novembro dezembro " +
            "obrigadão saudade saudades abraço beijo beijos carinho cuidado atenção desculpe perdão parabéns feliz natal aniversário viagem passeio festa domingo praia sol chuva calor frio " +
            "acho achei acha achar entendi entendo entende entender lembro lembrar esqueci esquecer perdi perder ganhei ganhar mandei mandar manda enviar enviei recebi receber responder respondi chamar chamei esperando esperei encontrei sair saí saiu entrar entrei voltar voltei chegou cheguei partir parti").split(" ").map { it.trim() }.filter { it.isNotEmpty() }

    // Abreviações e gírias de digitação rápida (PT): trocadas direto na autocorreção
    private val shortcuts: Map<String, String> = mapOf(
        "q" to "que",
        "n" to "não",
        "nn" to "não",
        "ñ" to "não",
        "vc" to "você",
        "vcs" to "vocês",
        "tb" to "também",
        "tbm" to "também",
        "tmb" to "também",
        "pq" to "porque",
        "porq" to "porque",
        "oq" to "o que",
        "ow" to "o que",
        "bbm" to "bem",
        "bm" to "bem",
        "bn" to "bem",
        "blz" to "beleza",
        "blza" to "beleza",
        "vlw" to "valeu",
        "vlww" to "valeu",
        "flw" to "falou",
        "falow" to "falou",
        "obg" to "obrigado",
        "obgd" to "obrigado",
        "obgda" to "obrigada",
        "td" to "tudo",
        "tdo" to "tudo",
        "tds" to "todos",
        "nd" to "nada",
        "mt" to "muito",
        "mto" to "muito",
        "mta" to "muita",
        "mts" to "muitos",
        "msm" to "mesmo",
        "hj" to "hoje",
        "amh" to "amanhã",
        "amnh" to "amanhã",
        "cmg" to "comigo",
        "ctg" to "contigo",
        "dps" to "depois",
        "fds" to "fim de semana",
        "pfv" to "por favor",
        "pf" to "por favor",
        "pfvr" to "por favor",
        "sdd" to "saudade",
        "sdds" to "saudades",
        "sla" to "sei lá",
        "ent" to "então",
        "entt" to "então",
        "eh" to "é",
        "ta" to "tá",
        "to" to "tô",
        "tou" to "tô",
        "ngm" to "ninguém",
        "algm" to "alguém",
        "qnd" to "quando",
        "qdo" to "quando",
        "qnt" to "quanto",
        "qto" to "quanto",
        "qm" to "quem",
        "ms" to "mas",
        "mnh" to "minha",
        "vdd" to "verdade",
        "mds" to "meu Deus",
        "ctz" to "certeza",
        "cmo" to "como",
        "cm" to "com",
        "hrs" to "horas",
        "dnv" to "de novo",
        "agr" to "agora",
        "agra" to "agora",
        "aq" to "aqui",
        "vo" to "vou",
        "vms" to "vamos",
        "tmj" to "tamo junto",
        "bjs" to "beijos",
        "bjo" to "beijo",
        "qria" to "queria",
        "qro" to "quero",
        "qer" to "quer",
        "msg" to "mensagem",
        "fzr" to "fazer",
        "pdc" to "pode crer",
        "vlh" to "velho",
        "mlr" to "mulher",
        "mlk" to "moleque",
        "tlgd" to "sabe como é",
        "tipw" to "tipo",
        "dms" to "demais",
        "dmr" to "demais",
        "blzz" to "beleza",
        "sdc" to "saudade",
        "nunk" to "nunca",
        "sepa" to "talvez",
        "inclsv" to "inclusive",
        "obs" to "observação"
    )

    private val ptExtra2 = ("pessoal galera cara mano amigo parceiro tranquilo tranquila suave certeza claro exatamente realmente totalmente completamente " +
        "chegando saindo indo vindo voltando fazendo falando dizendo pensando vendo olhando comendo bebendo dormindo acordando trabalhando estudando jogando assistindo " +
        "quero queria queremos querem posso podemos podem preciso precisamos precisam vou vamos vão iria iremos fui fomos foram seria sejam estaria estariam " +
        "tenho temos tem têm tinha tínhamos tinham terei teremos teriam fiz fizemos fizeram faço fazemos fazem farei faremos faria diria disse dissemos disseram " +
        "gosto gostei gostou gostamos adoro adorei amo amei odeio detesto prefiro lembro lembrei esqueci acho achei acredito sei soube conheço conheci entendo entendi " +
        "ontem hoje amanhã agora depois antes cedo tarde noite madrugada semana mês ano sempre nunca jamais talvez quase apenas somente também ainda já logo " +
        "porque porquê porém contudo portanto então assim aliás inclusive exceto conforme enquanto embora quando onde aonde como quanto quantos quantas qual quais " +
        "alguém ninguém algo nada tudo todo todos cada outro outra mesmo mesma próprio própria diferente igual maior menor melhor pior mais menos muito pouco " +
        "bem mal bom boa ruim lindo linda feio feia grande pequeno novo nova velho velha alto alta baixo baixa fácil difícil rápido lento forte fraco cheio vazio " +
        "casa quarto sala cozinha banheiro rua avenida bairro prédio apartamento escritório escola faculdade igreja praça shopping mercado farmácia padaria posto " +
        "carro moto ônibus metrô trem avião barco bicicleta táxi uber motorista passagem viagem hotel aeroporto estrada trânsito " +
        "comida bebida água suco refrigerante cerveja vinho pão arroz feijão carne frango peixe ovo leite queijo fruta salada doce chocolate pizza hambúrguer " +
        "roupa camisa calça sapato tênis bolsa óculos relógio anel colar boné " +
        "cabeça rosto olho nariz boca orelha mão braço perna pé coração corpo cabelo barriga costas dente " +
        "desculpa desculpe licença perdão com\u00A0licença pode\u00A0ser claro\u00A0que sim não talvez ok beleza fechado combinado valeu tmj partiu bora").split(" ").map { it.trim() }.filter { it.isNotEmpty() && !it.contains('\u00A0') }

    private val ru = ("я ты он она оно мы вы они это этот эта эти тот та те мой моя моё мои твой твоя твоё твои наш наша наше наши ваш ваша ваше ваши его её их себя кто что какой какая какое какие чей где куда откуда когда почему зачем как сколько и в не на с к но а по из у о за от до для при про без над под перед между через после около вместо кроме если чтобы потому хотя пока либо тоже также даже уже ещё только именно просто почти совсем вообще опять снова вместе быть был была было были будет буду будем есть нет да нету можно нельзя надо нужно должен должна должны привет здравствуйте здравствуй пока спасибо пожалуйста извините извини прости хорошо плохо отлично конечно ладно окей согласен согласна понятно ясно понимаю понял поняла знаю знаешь знаем думаю думаешь говорю говоришь сказал сказала скажи сделать делаю делаешь делаем хочу хочешь хотим хотят могу можешь можем могут умею умеешь работа работать работаю работаешь дом домой семья друг друзья подруга любовь любить люблю любишь жизнь время день ночь утро вечер сегодня завтра вчера сейчас потом всегда никогда иногда очень много мало больше меньше самый лучший хороший плохой новый старый большой маленький быстро медленно рано поздно здесь там туда сюда один одна одно два две три четыре пять шесть семь восемь девять десять сто тысяча миллион первый второй третий последний следующий другой каждый любой весь целый деньги магазин город страна мир вода еда хлеб молоко чай кофе сахар мясо рыба овощи фрукты суп картошка яблоко машина автобус метро поезд самолёт телефон компьютер интернет сообщение письмо звонок книга фильм музыка игра фото видео школа университет урок студент студентка учитель врач больница болезнь здоровье голова рука нога глаз лицо сердце спина живот зуб слово вопрос ответ проблема решение идея мысль правда ложь история случай место часть конец начало причина смысл пример результат понедельник вторник среда четверг пятница суббота воскресенье январь февраль март апрель май июнь июль август сентябрь октябрь ноябрь декабрь добрый доброе утро ночи свидания увидимся встреча встретимся приходи приходите иди идите пойдём давай давайте позвони напиши скажи подожди смотри слушай помоги помощь счастье радость грусть улыбка смех красивый красивая милый милая дорогой дорогая прекрасно замечательно ужасно страшно весело скучно интересно люди человек мужчина женщина ребёнок дети мама папа брат сестра муж жена сын дочь бабушка дедушка дела делаешь делает идёт иду идёшь пришёл пришла приду буду будешь был уехал вернусь вернулся жду ждать ждёшь позже скоро сразу видел видела вижу смотрю слышу слышал читаю читать писать пишу пишешь звонить звоню купить покупаю продать открыть закрыть начать закончить помнить забыл забыла рад рада благодарю обожаю ненавижу устал устала голоден голодна занят занята свободен свободна готов готова дома").split(" ").filter { it.isNotEmpty() }

    private val nextRu = mapOf(
        "я" to listOf("не", "хочу", "думаю"), "как" to listOf("дела", "ты", "это"),
        "что" to listOf("ты", "это", "то"), "не" to listOf("знаю", "могу", "хочу"),
        "спасибо" to listOf("большое", "тебе", "за"), "доброе" to listOf("утро"),
        "добрый" to listOf("день", "вечер"), "до" to listOf("свидания", "завтра", "встречи"),
        "спокойной" to listOf("ночи"), "привет" to listOf("как", "что", "друг"),
        "очень" to listOf("хорошо", "рад", "много"), "ты" to listOf("где", "как", "можешь"),
        "мне" to listOf("нужно", "кажется", "надо"), "на" to listOf("работе", "улице", "самом"),
        "в" to listOf("городе", "доме", "школе"), "это" to listOf("очень", "не", "было"),
        "сегодня" to listOf("вечером", "я", "мы"), "давай" to listOf("встретимся", "поговорим", "пойдём")
    )

    private val nextPt = mapOf(
        "eu" to listOf("vou", "estou", "tenho"), "você" to listOf("está", "pode", "quer"),
        "bom" to listOf("dia", "trabalho", "lugar"), "boa" to listOf("noite", "tarde", "sorte"),
        "muito" to listOf("obrigado", "bom", "bem"), "por" to listOf("favor", "que", "isso"),
        "tudo" to listOf("bem", "certo", "isso"), "não" to listOf("sei", "vou", "tem"),
        "o" to listOf("que", "melhor", "dia"), "a" to listOf("gente", "vida", "casa"),
        "de" to listOf("novo", "nada", "manhã"), "em" to listOf("casa", "breve", "frente"),
        "que" to listOf("bom", "horas", "legal"), "vou" to listOf("ligar", "ver", "tentar"),
        "obrigado" to listOf("pela", "por", "mesmo"), "até" to listOf("amanhã", "logo", "mais"),
        "como" to listOf("vai", "você", "está"), "estou" to listOf("indo", "chegando", "com")
    )
    private val nextEn = mapOf(
        "i" to listOf("am", "will", "have"), "you" to listOf("are", "can", "have"),
        "thank" to listOf("you", "god", "goodness"), "good" to listOf("morning", "night", "luck"),
        "see" to listOf("you", "the", "what"), "how" to listOf("are", "is", "about"),
        "what" to listOf("is", "are", "do"), "the" to listOf("same", "best", "first"),
        "do" to listOf("you", "not", "it"), "to" to listOf("be", "do", "the")
    )

    private val es = ("de la que el en y a los se del las un por con no una su para es al lo como más pero sus le ya o fue este " +
        "ha sí porque esta son entre está cuando muy sin sobre también me hasta hay donde han quien están estado desde todo nos durante todos uno les ni contra otros " +
        "fueron ese eso había ante ellos esto antes algunos qué unos yo otro otras otra él tanto esa estos mucho quienes nada muchos cual sea poco ella estar haber estas " +
        "estaba estamos algunas algo nosotros mi mis tú te ti tu tus ellas nosotras vosotros os mío mía tuyo tuya suyo suya nuestro nuestra nuestros nuestras vuestro vuestra hola buenos " +
        "buenas días tardes noches gracias muchas favor perdón perdona disculpa lo siento adiós luego mañana hoy ayer ahora después aquí allí allá dónde cuándo cómo cuánto cuántos cuál quién quiero " +
        "quería queremos quieres quiere puedo puedes puede podemos tengo tienes tiene tenemos voy vas va vamos vienes vengo viene venimos hacer hago haces hace hacemos digo dices dice decir dime " +
        "dijo sé sabes sabe saber veo ves vemos ver doy das da damos necesito necesitas necesita necesitamos estoy estás estamos soy eres somos tenía había fui fuiste fuimos trabajo casa " +
        "familia amigo amiga amigos amigas madre padre hijo hija hermano hermana tío tía abuelo abuela novio novia esposo esposa niño niña hombre mujer persona gente tiempo año años mes semana " +
        "día noche tarde hora minuto momento vez veces cosa cosas vida mundo país ciudad calle escuela colegio universidad oficina empresa proyecto reunión clase examen estudio curso profesor profesora jefe cliente " +
        "compañero vecino teléfono móvil celular internet aplicación mensaje llamada vídeo foto imagen archivo correo contraseña usuario cuenta página enlace red batería cargador ordenador computadora pantalla teclado comida bebida agua café " +
        "té cerveza vino pan arroz carne pollo pescado huevo leche queso fruta ensalada postre chocolate pizza hamburguesa desayuno almuerzo cena restaurante bueno buena malo mala mejor peor grande pequeño pequeña " +
        "nuevo nueva viejo vieja alto alta bajo baja fácil difícil rápido lento feliz triste cansado cansada contento contenta enfermo ocupado ocupada listo lista claro cierto verdad mentira bonito bonita hermoso " +
        "hermosa siempre nunca jamás quizás quizá casi apenas solo sola solamente además incluso aunque mientras entonces así aún todavía pronto temprano mucho muchas demasiado bastante lunes martes miércoles jueves viernes " +
        "sábado domingo enero febrero marzo abril mayo junio julio agosto septiembre octubre noviembre diciembre cumpleaños navidad felicidades enhorabuena bienvenido bienvenida encantado encantada igualmente vale acuerdo perfecto genial estupendo regular nada " +
        "problema pregunta respuesta idea información número nombre historia viaje fiesta playa carro coche autobús metro tren avión aeropuerto hotel dinero banco tienda mercado precio pagar comprar vender necesidad ayuda ayudar " +
        "gustar gusta encanta amor cariño abrazo beso besos saludos extraño extrañar pienso creo entiendo entendí recuerdo olvidé llamar llamo llamas llama escribir escribo enviar envié recibí esperar espero espera salir " +
        "salgo sale llegar llego llega volver vuelvo vuelve ").split(" ").filter { it.isNotEmpty() }

    private val ar = ("في من على إلى أن هذا هذه ذلك تلك التي الذي كان ما لا لم لن قد هو هي هم هن أنا أنت أنتِ نحن أنتم هناك هنا مع عن " +
        "كل بعد قبل بين حتى عند ثم أو و لكن إذا كيف لماذا متى أين ماذا هل نعم شكرا شكراً جزيلا عفوا مرحبا أهلا سلام السلام عليكم وعليكم ورحمة الله " +
        "وبركاته صباح مساء الخير النور تصبح خير السلامة إن شاء ما الحمد لله بسم فضلك سمحت آسف أسف معذرة تفضل أرجو أريد أحب أعرف أقول أذهب أعمل أكتب أقرأ أرى " +
        "أسمع أفهم أفكر أحتاج أستطيع يمكن يجب ممكن لازم اليوم غدا أمس الآن قليل دائما أبدا ربما جدا كثير كبير صغير جديد قديم جميل سيء جيد حسن سعيد حزين متعب " +
        "مشغول جاهز صحيح خطأ حقيقة بيت منزل عائلة أب أم ابن بنت أخ أخت صديق صديقة زوج زوجة طفل رجل امرأة شخص ناس وقت سنة شهر أسبوع يوم ليلة ساعة " +
        "دقيقة مرة شيء حياة عالم بلد مدينة شارع مدرسة جامعة مكتب شركة مشروع اجتماع درس امتحان دراسة معلم طالب هاتف جوال انترنت تطبيق رسالة مكالمة فيديو صورة ملف بريد كلمة " +
        "المرور حساب صفحة رابط شبكة بطارية شاحن حاسوب طعام شراب ماء قهوة شاي خبز أرز لحم دجاج سمك بيض حليب جبن فاكهة حلوى السبت الأحد الاثنين الثلاثاء الأربعاء الخميس الجمعة " +
        "يناير فبراير مارس أبريل مايو يونيو يوليو أغسطس سبتمبر أكتوبر نوفمبر ديسمبر كل عام وأنتم بخير مبروك عيد مبارك رمضان كريم ").split(" ").filter { it.isNotEmpty() }

    private val nextEs = mapOf(
        "buenos" to listOf("días", "amigos"), "buenas" to listOf("noches", "tardes", "días"),
        "muchas" to listOf("gracias", "felicidades"), "por" to listOf("favor", "qué", "fin"),
        "de" to listOf("nada", "nuevo", "acuerdo"), "hasta" to listOf("luego", "mañana", "pronto"),
        "yo" to listOf("quiero", "tengo", "no"), "no" to listOf("sé", "puedo", "tengo"),
        "cómo" to listOf("estás", "está", "te"), "qué" to listOf("tal", "hora", "haces"),
        "te" to listOf("quiero", "llamo", "veo"), "me" to listOf("gusta", "llamo", "voy"),
        "lo" to listOf("siento", "que", "sé"), "gracias" to listOf("por", "a", "de"),
        "hola" to listOf("cómo", "qué", "buenas"), "estoy" to listOf("en", "bien", "aquí"),
        "voy" to listOf("a", "al", "con"), "muy" to listOf("bien", "bueno", "gracias"),
        "un" to listOf("poco", "momento", "día"), "feliz" to listOf("cumpleaños", "navidad", "día"),
        "nos" to listOf("vemos", "vamos", "llamamos"), "que" to listOf("tal", "te", "me"),
        "en" to listOf("casa", "la", "el"), "el" to listOf("día", "de", "que")
    )

    private val nextAr = mapOf(
        "السلام" to listOf("عليكم"), "صباح" to listOf("الخير", "النور"), "مساء" to listOf("الخير", "النور"),
        "كيف" to listOf("حالك", "الحال", "أنت"), "شكرا" to listOf("لك", "جزيلا", "على"),
        "إن" to listOf("شاء"), "ما" to listOf("شاء", "هذا", "اسمك"), "لا" to listOf("بأس", "أعرف", "أدري"),
        "أنا" to listOf("بخير", "أريد", "أحب"), "مع" to listOf("السلامة", "السلام"),
        "من" to listOf("فضلك", "أين", "هو"), "في" to listOf("البيت", "العمل", "الصباح"),
        "هل" to listOf("يمكنك", "أنت", "تريد"), "إلى" to listOf("اللقاء", "اليوم"),
        "كل" to listOf("عام", "يوم", "شيء"), "الحمد" to listOf("لله"), "جزاك" to listOf("الله"),
        "أريد" to listOf("أن", "شيئا", "ماء"), "أين" to listOf("أنت", "هو", "المكان")
    )

    // Abreviações de digitação rápida (ES)
    private val shortcutsEs: Map<String, String> = mapOf(
        "q" to "que", "xq" to "porque", "pq" to "porque", "tb" to "también", "tmb" to "también",
        "xfa" to "por favor", "pf" to "por favor", "dnd" to "dónde", "ke" to "que", "bn" to "bien",
        "msj" to "mensaje", "grax" to "gracias", "gracs" to "gracias", "tqm" to "te quiero mucho"
    )

    private fun shortcutFor(w: String): String? = when (lang) {
        Prefs.LANG_PT -> shortcuts[w]
        Prefs.LANG_ES -> shortcutsEs[w]
        else -> null
    }

    @Volatile private var lang = Prefs.LANG_PT
    @Volatile private var dict: List<String> = (pt + ptExtra + ptExtra2).distinct()
    @Volatile private var normDict: List<String> = dict.map { norm(it) }
    @Volatile private var dictSet: HashSet<String> = HashSet(dict)
    @Volatile private var normMap: HashMap<String, String> = HashMap<String, String>().also { m -> dict.forEachIndexed { i, w -> m.putIfAbsent(normDict[i], w) } }
    @Volatile private var loadToken = 0
    @Volatile private var openFor = ""        // idioma para o qual o dicionário aberto já foi pedido

    /** Troca o dicionário. A ordem de escrita importa: quem lê pega `dict` primeiro e depois `normDict[i]`. */
    private fun install(words: List<String>) {
        val norms = words.map { norm(it) }
        val set = HashSet(words)
        val map = HashMap<String, String>()
        words.forEachIndexed { i, w -> map.putIfAbsent(norms[i], w) }
        dictSet = set; normMap = map; normDict = norms; dict = words
    }

    /** Corretor mais preciso (opção "Melhorar precisão do corretor"). */
    @Volatile var precise = false

    /** Chamado depois de baixar um dicionário: relê o idioma atual. */
    fun reloadOpenDictionary() { openFor = ""; setLanguage(lang) }

    fun setLanguage(l: String) {
        if (l == lang && openFor == l) return        // o serviço chama isto a cada mudança de preferência
        openFor = l
        lang = l
        dict = (when (l) {
            Prefs.LANG_EN -> en
            Prefs.LANG_RU -> ru
            Prefs.LANG_ES -> es
            Prefs.LANG_AR -> ar
            Prefs.LANG_FR, Prefs.LANG_TR, Prefs.LANG_VI -> emptyList()   // sem lista embutida: vêm do dicionário baixado (OpenDictionary)
            else -> pt + ptExtra + ptExtra2
        }).distinct()
        normDict = dict.map { norm(it) }
        dictSet = HashSet(dict)
        normMap = HashMap<String, String>().also { m -> dict.forEachIndexed { i, w -> m.putIfAbsent(normDict[i], w) } }
        // Soma o dicionário aberto (assets/dict/<idioma>.txt) em segundo plano; se não existir, nada muda.
        val token = ++loadToken
        val base = dict
        Thread {
            var extra = OpenDictionary.load(appCtx, l)
            if (extra.isEmpty() && DictionaryDownloader.shouldAutoTry(appCtx, l) && DictionaryDownloader.download(appCtx, l))
                extra = OpenDictionary.load(appCtx, l)
            if (extra.isEmpty() || token != loadToken) return@Thread
            install((base + extra).distinct())
        }.apply { priority = Thread.MIN_PRIORITY; isDaemon = true; start() }
    }

    private val trLocale = java.util.Locale("tr")
    /** minúsculas/maiúsculas respeitando o turco (I↔ı, İ↔i); nos demais idiomas é o comportamento de sempre. */
    private fun low(s: String): String = if (lang == Prefs.LANG_TR) s.lowercase(trLocale) else s.lowercase()
    private fun up(s: String): String = if (lang == Prefs.LANG_TR) s.uppercase(trLocale) else s.uppercase()

    private fun norm(s: String): String {
        val d = java.text.Normalizer.normalize(low(s), java.text.Normalizer.Form.NFD)
        val sb = StringBuilder(d.length)
        for (ch in d) {
            val c = ch.code
            val mark = (c in 0x300..0x36F) || (c in 0x64B..0x65F) || c == 0x670 || c == 0x640   // acentos latinos, harakat árabes e tatweel
            if (!mark) sb.append(when (ch) { 'ı' -> 'i'; 'đ' -> 'd'; else -> ch })   // ı (turco) e đ (vietnamita) não se decompõem sozinhos
        }
        return sb.toString()
    }

    // posição (linha, coluna) das letras no teclado, para saber se duas teclas são vizinhas
    private val keyPos: Map<Char, Pair<Int, Int>> = HashMap<Char, Pair<Int, Int>>().also { m ->
        listOf("qwertyuiop", "asdfghjklç", "zxcvbnm").forEachIndexed { r, row -> row.forEachIndexed { c, ch -> m[ch] = r to c } }
    }

    private fun adjacent(a: Char, b: Char): Boolean {
        val pa = keyPos[a] ?: return false
        val pb = keyPos[b] ?: return false
        val dr = Math.abs(pa.first - pb.first); val dc = Math.abs(pa.second - pb.second)
        return (dr == 0 && dc == 1) || (dr == 1 && dc <= 1)
    }

    /** Distância de edição (inserção, remoção, troca, inversão); trocar por tecla vizinha custa menos. */
    private fun dist(a: String, b: String): Double {
        val n = a.length; val m = b.length
        val d = Array(n + 1) { DoubleArray(m + 1) }
        for (i in 0..n) d[i][0] = i.toDouble()
        for (j in 0..m) d[0][j] = j.toDouble()
        for (i in 1..n) for (j in 1..m) {
            val c = if (a[i - 1] == b[j - 1]) 0.0 else if (adjacent(a[i - 1], b[j - 1])) 0.5 else 1.0
            var v = minOf(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + c)
            if (i > 1 && j > 1 && a[i - 1] == b[j - 2] && a[i - 2] == b[j - 1]) v = minOf(v, d[i - 2][j - 2] + 1)
            d[i][j] = v
        }
        return d[n][m]
    }

    private fun consonants(s: String) = norm(s).filter { it !in "aeiou" }

    /** Modo bruto: acento, sem-vogais (hj, dps, tdo), e erro pesado de digitação com desempate por frequência. */
    private fun correctPrecise(word: String): String? {
        if (word.length < 2 || word.any { !it.isLetter() }) return null
        val w = low(word)
        if (w in dictSet || learned.containsKey(w)) return null
        val nw = norm(w)
        // 1) só faltou/errou o acento (nao -> não, voce -> você)
        normMap[nw]?.let { return matchCase(word, it) }
        // 2) sem vogais (hj -> hoje, dps -> depois, mt -> muito): palavra mais comum com as mesmas consoantes
        if (nw.none { it in "aeiou" }) {
            for (i in dict.indices) if (normDict[i].length > nw.length && consonants(dict[i]) == nw) return matchCase(word, dict[i])
        }
        if (w.length < 3) return null
        // nomes próprios (Maiúscula + minúsculas) não são "consertados" por distância
        if (word[0].isUpperCase() && word.drop(1).all { it.isLowerCase() }) return null
        // 3) erro de digitação, bem mais agressivo que o modo normal
        val maxD = when { w.length <= 3 -> 1.0; w.length <= 5 -> 1.5; w.length <= 7 -> 2.0; else -> 2.5 }
        var best: String? = null
        var bestScore = Double.MAX_VALUE
        fun consider(c: String, nc: String, bonus: Double, rank: Double) {
            if (Math.abs(nc.length - nw.length) > maxD) return
            var d = dist(nw, nc)
            if (nc[0] != nw[0] && !adjacent(nc[0], nw[0])) d += 0.4
            if (d > maxD) return
            val sc = d - bonus + rank
            if (sc < bestScore) { bestScore = sc; best = c }
        }
        for (i in dict.indices) consider(dict[i], normDict[i], 0.0, minOf(i, 2000) * 0.0002)
        for ((k, v) in learned) consider(k, norm(k), minOf(v, 5) * 0.08, 0.0)
        return best?.let { matchCase(word, it) }
    }

    /**
     * Digitação por deslize: recebe as letras (em ordem) por onde o dedo passou e devolve até 4 palavras
     * que começam e terminam nas mesmas letras e cujas letras aparecem, em ordem, no caminho.
     * Palavras mais comuns e com menos teclas "puladas" ganham.
     */
    fun glide(path: String): List<String> {
        if (path.length < 2) return emptyList()
        val p = norm(path)
        val d = dict; val nd = normDict
        val n = minOf(d.size, nd.size)
        val scored = ArrayList<Pair<String, Double>>()
        fun consider(word: String, nw: String, rank: Int, lastLoose: Boolean) {
            val cw = StringBuilder()
            for (ch in nw) if (cw.isEmpty() || cw.last() != ch) cw.append(ch)   // "hello" -> "helo": letra dobrada = um só toque
            if (cw.length < 2 || cw.length > p.length) return
            if (cw.first() != p.first()) return
            val core = if (lastLoose) cw.substring(0, cw.length - 1) else cw.toString()
            if (lastLoose && !adjacent(cw.last(), p.last())) return
            if (!lastLoose && cw.last() != p.last()) return
            var j = 0
            for (ch in p) if (j < core.length && core[j] == ch) j++
            if (j < core.length) return
            val skipped = (p.length - cw.length).coerceAtLeast(0)
            var s = -Math.log(1.0 + rank) * 0.45 - skipped * 0.22 + cw.length * 0.25 - (if (lastLoose) 1.2 else 0.0)
            if (learned.containsKey(word)) s += 0.8
            scored.add(word to s)
        }
        for (i in 0 until n) {
            val nw = nd[i]
            if (nw.isEmpty() || !nw.all { it.isLetter() }) continue
            consider(d[i], nw, i, false)
        }
        for ((k, _) in learned) { val nk = norm(k); if (nk.all { it.isLetter() }) consider(k, nk, 0, false) }
        if (scored.isEmpty()) for (i in 0 until n) {
            val nw = nd[i]
            if (nw.isEmpty() || !nw.all { it.isLetter() }) continue
            consider(d[i], nw, i, true)
        }
        return scored.sortedByDescending { it.second }.map { it.first }.distinct().take(4)
    }

    /** Até 3 sugestões para o prefixo digitado (mantém a caixa da primeira letra). */
    fun complete(prefix: String): List<String> {
        if (prefix.isEmpty()) return emptyList()
        val p = low(prefix)
        val out = LinkedHashSet<String>()
        shortcutFor(p)?.let { out.add(it) }
        learned.entries.filter { it.key.startsWith(p) && it.key != p }
            .sortedByDescending { it.value }.forEach { out.add(it.key) }
        for (w in dict) { if (w.startsWith(p) && w != p) out.add(w); if (out.size >= 6) break }
        if (precise && out.size < 3) {
            val np = norm(p)
            // aceita prefixo sem acento (voc -> você)
            for (i in dict.indices) { if (normDict[i].startsWith(np) && dict[i] != p) out.add(dict[i]); if (out.size >= 6) break }
            // e prefixo com erro de digitação (cmeçar -> começar)
            if (out.size < 3 && np.length >= 3) {
                val fz = ArrayList<Pair<String, Double>>()
                for (i in dict.indices) {
                    val c = normDict[i]
                    if (c.length < np.length || c == np) continue
                    val d = dist(np, c.take(np.length))
                    if (d <= 1.0) fz.add(dict[i] to d + minOf(i, 2000) * 0.0001)
                }
                fz.sortBy { it.second }
                fz.forEach { out.add(it.first) }
            }
        }
        return out.take(3).map { matchCase(prefix, it) }
    }

    /**
     * Correção conservadora: só corrige palavras com 4+ letras que NÃO estão no dicionário e que
     * diferem de UMA única palavra do dicionário por uma letra trocada/acentuada ou duas letras
     * invertidas (mesmo tamanho). Antes, inserir/remover letra também valia e o teclado trocava
     * palavras certas ("fica" virava "ficar"); agora, se houver dúvida, não mexe.
     */
    fun correct(word: String): String? {
        shortcutFor(low(word))?.let { return matchCase(word, it) }
        if (lang == Prefs.LANG_VI) return null        // vietnamita: a palavra sai do Telex já acentuada; corrigir por distância estragaria
        if (precise) return correctPrecise(word)
        if (word.length < 4 || word.any { !it.isLetter() }) return null
        val w = low(word)
        if (w in dictSet || learned.containsKey(w)) return null
        var best: String? = null
        var bestIdx = -1
        val d = dict
        for (i in d.indices) {
            val c = d[i]
            if (c.length != w.length || c[0] != w[0]) continue
            if (sameLengthOneOff(w, c)) {
                if (best == null) { best = c; bestIdx = i }
                else if (bestIdx < 4000 && i > bestIdx * 4 + 50) break      // o 1º é bem mais comum que o 2º: fica com ele
                else return null                                           // ambíguo: não corrige
            }
        }
        return best?.let { matchCase(word, it) }
    }

    fun next(previous: String): List<String> {
        val m = when (lang) { Prefs.LANG_EN -> nextEn; Prefs.LANG_RU -> nextRu; Prefs.LANG_ES -> nextEs; Prefs.LANG_AR -> nextAr; Prefs.LANG_FR, Prefs.LANG_TR, Prefs.LANG_VI -> emptyMap(); else -> nextPt }
        return m[low(previous)] ?: emptyList()
    }

    fun learn(word: String) {
        val w = low(word)
        if (w.length < 3 || w.any { !it.isLetter() } || w in dictSet) return
        val n = (learned[w] ?: 0) + 1
        learned[w] = n
        if (learned.size > 500) {
            learned.entries.minByOrNull { it.value }?.let { learned.remove(it.key); sp.edit().remove(it.key).apply() }
        }
        sp.edit().putInt(w, n).apply()
    }

    private fun matchCase(src: String, w: String): String =
        if (src.isNotEmpty() && src.all { it.isUpperCase() } && src.length > 1) up(w)
        else if (src.isNotEmpty() && src[0].isUpperCase()) w.replaceFirstChar { up(it.toString()) } else w

    private fun sameLengthOneOff(a: String, b: String): Boolean {
        if (a.length != b.length) return false
        var first = -1; var diffs = 0
        for (i in a.indices) if (a[i] != b[i]) { if (first < 0) first = i; diffs++; if (diffs > 2) return false }
        return when (diffs) {
            1 -> true
            2 -> first + 1 < a.length && a[first] == b[first + 1] && a[first + 1] == b[first]   // inversão
            else -> false
        }
    }
}

package com.example.materialkeyboard.cloud

import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.example.materialkeyboard.L
import com.example.materialkeyboard.tr
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import java.text.DateFormat
import java.util.Date

/** Estado que a tela "Conta e nuvem" mostra. */
class CloudUi {
    var user by mutableStateOf<CloudUser?>(null)
    var busy by mutableStateOf(false)
    var message by mutableStateOf("")
    var lastBackup by mutableStateOf(0L)
    var auto by mutableStateOf(false)
}

/** Liga a tela "Conta e nuvem" ao login ([CloudAuth]) e ao backup ([CloudSync]). Vive junto da SettingsActivity. */
class CloudController(private val act: AppCompatActivity, private val onRestored: () -> Unit) {
    val ui = CloudUi()
    val configured: Boolean get() = CloudConfig.configured

    /** Lê o estado atual (conta, último backup). Só aqui o Firebase é iniciado, e só se a nuvem estiver configurada. */
    fun reload() {
        ui.auto = CloudSync.autoBackup(act)
        ui.lastBackup = CloudSync.lastBackupAt(act)
        ui.user = if (configured && CloudAuth.ensure(act)) CloudAuth.user() else null
    }

    private fun alive() = !act.isFinishing && !act.isDestroyed
    private fun toast(s: String) { if (alive()) Toast.makeText(act, s, Toast.LENGTH_SHORT).show() }

    fun signIn() {
        if (ui.busy) return
        ui.busy = true; ui.message = ""
        CloudAuth.signIn(act) { r ->
            ui.busy = false
            if (r.user != null) {
                reload()
            } else {
                ui.message = when (r.fail) {
                    CloudAuth.Fail.CANCELLED -> "Login cancelado.".tr()
                    CloudAuth.Fail.NO_ACCOUNT -> "Nenhuma conta Google neste aparelho. Adicione uma nas configurações do Android.".tr()
                    CloudAuth.Fail.NOT_CONFIGURED -> "A nuvem não está configurada neste APK.".tr()
                    else -> L.f("Não foi possível entrar (%s).", r.detail)
                }
            }
        }
    }

    fun signOut() {
        if (ui.busy) return
        CloudAuth.signOut(act)
        ui.user = null; ui.message = ""
    }

    fun setAuto(v: Boolean) { CloudSync.setAutoBackup(act, v); ui.auto = v }

    fun backup() {
        if (ui.busy) return
        ui.busy = true; ui.message = ""
        CloudSync.backup(act) { r ->
            ui.busy = false
            if (r.err == null) { ui.lastBackup = r.value ?: 0L; ui.message = "Backup enviado ✓".tr() } else { ui.message = errText(r.err, r.detail) }
        }
    }

    /** Busca o backup, mostra de quando é e só aplica depois da confirmação. */
    fun restore() {
        if (ui.busy) return
        ui.busy = true; ui.message = ""
        CloudSync.fetch(act) { r ->
            ui.busy = false
            val remote = r.value
            if (remote == null) { ui.message = errText(r.err, r.detail); return@fetch }
            if (!alive()) return@fetch
            val whenTxt = if (remote.at > 0) DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT).format(Date(remote.at)) else "?"
            MaterialAlertDialogBuilder(act)
                .setTitle("Restaurar este backup?".tr())
                .setMessage(L.f("Backup de %s (aparelho: %s). As configurações atuais deste aparelho serão substituídas.", whenTxt, remote.device.ifBlank { "?" }))
                .setNegativeButton("Cancelar".tr(), null)
                .setPositiveButton("Restaurar".tr()) { _, _ ->
                    try { CloudSync.applyRemote(act, remote); ui.message = "Backup restaurado ✓".tr(); toast(ui.message) }
                    catch (_: Exception) { ui.message = "O backup está incompleto ou corrompido.".tr() }
                    if (alive()) onRestored()
                }
                .show()
        }
    }

    fun deleteBackup() {
        if (ui.busy || !alive()) return
        MaterialAlertDialogBuilder(act)
            .setTitle("Apagar backup da nuvem?".tr())
            .setMessage("O backup guardado na sua conta será excluído. As configurações deste aparelho não mudam.".tr())
            .setNegativeButton("Cancelar".tr(), null)
            .setPositiveButton("Apagar".tr()) { _, _ ->
                ui.busy = true; ui.message = ""
                CloudSync.deleteBackup(act) { r ->
                    ui.busy = false
                    if (r.err == null) { ui.lastBackup = 0L; ui.message = "Backup apagado ✓".tr() } else { ui.message = errText(r.err, r.detail) }
                }
            }
            .show()
    }

    private fun errText(e: CloudSync.Err?, detail: String): String = when (e) {
        CloudSync.Err.NO_LOGIN -> "Entre com sua conta Google primeiro.".tr()
        CloudSync.Err.NOT_CONFIGURED -> "A nuvem não está configurada neste APK.".tr()
        CloudSync.Err.OFFLINE -> "Sem conexão com a internet. Tente de novo quando estiver online.".tr()
        CloudSync.Err.DENIED -> "Sem permissão no servidor. Confira as regras do Firestore.".tr()
        CloudSync.Err.NO_BACKUP -> "Ainda não há backup nesta conta.".tr()
        CloudSync.Err.TOO_NEW -> "Este backup é de uma versão mais nova do app. Atualize o Material Keyboard e tente de novo.".tr()
        CloudSync.Err.BAD_DATA -> "O backup está incompleto ou corrompido.".tr()
        else -> L.f("Não foi possível concluir (%s).", detail)
    }
}

package com.example.materialkeyboard

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.*
import android.view.View
import android.view.animation.LinearInterpolator

/** Selo "cookie" (borda ondulada) do estilo Expressive. Gira devagar e pulsa ao aparecer. */
class CookieBadge(ctx: Context, private val fill: Int, private val ink: Int, private val lobes: Int = 9) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private var rot = 0f
    private val spin = ValueAnimator.ofFloat(0f, 360f).apply {
        duration = 24000; repeatCount = ValueAnimator.INFINITE; interpolator = LinearInterpolator()
        addUpdateListener { rot = it.animatedValue as Float; invalidate() }
    }
    init { scaleX = 0f; scaleY = 0f }
    override fun onAttachedToWindow() {
        super.onAttachedToWindow(); spin.start()
        animate().scaleX(1f).scaleY(1f).setDuration(520)
            .setInterpolator(android.view.animation.OvershootInterpolator(2.2f)).start()
    }
    override fun onDetachedFromWindow() { spin.cancel(); super.onDetachedFromWindow() }
    override fun onDraw(c: Canvas) {
        val cx = width / 2f; val cy = height / 2f; val r = minOf(cx, cy)
        path.rewind()
        val n = 120
        for (i in 0..n) {
            val a = i * 2 * Math.PI / n
            val rr = r * (0.88f + 0.12f * Math.cos(a * lobes).toFloat())
            val x = cx + (rr * Math.cos(a)).toFloat(); val y = cy + (rr * Math.sin(a)).toFloat()
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        path.close()
        c.save(); c.rotate(rot, cx, cy)
        p.color = fill; c.drawPath(path, p)
        c.restore()
        // ícone: grade de pontos (como no selo de "desfoque")
        p.color = ink
        val g = r * 0.42f
        for (i in -1..1) for (j in -1..1) c.drawCircle(cx + i * g * 0.7f, cy + j * g * 0.7f, r * 0.09f, p)
    }
}

/** 10 formatos para as teclas, no estilo Material 3 Expressive: cantos suaves, nada pontudo, nada "inchado". */
object KeyShapes {
    val NAMES = listOf("Arredondada", "Pílula", "Squircle", "Chanfrada", "Hexágono", "Cookie", "Folha", "Ingresso", "Inclinada", "Flor")

    /**
     * Superelipse (n alto = mais quadrada) com ondulação distribuída pelo PERÍMETRO, não pelo ângulo:
     * os gomos têm o mesmo tamanho em teclas altas, estreitas ou largas, e a ondulação é só um recuo
     * (nunca ultrapassa o retângulo da tecla, então não encosta nas vizinhas).
     */
    private fun organic(p: Path, rc: RectF, lobes: Int, amp: Float, n: Float) {
        val cx = rc.centerX(); val cy = rc.centerY(); val a = rc.width() / 2f; val b = rc.height() / 2f
        val steps = 240
        val bx = FloatArray(steps + 1); val by = FloatArray(steps + 1); val cum = FloatArray(steps + 1)
        val ex = 2.0 / n
        for (i in 0..steps) {
            val t = i * 2 * Math.PI / steps
            val c = Math.cos(t); val s = Math.sin(t)
            bx[i] = (a * Math.signum(c) * Math.pow(Math.abs(c), ex)).toFloat()
            by[i] = (b * Math.signum(s) * Math.pow(Math.abs(s), ex)).toFloat()
            if (i > 0) cum[i] = cum[i - 1] + Math.hypot((bx[i] - bx[i - 1]).toDouble(), (by[i] - by[i - 1]).toDouble()).toFloat()
        }
        val total = cum[steps].coerceAtLeast(1f)
        for (i in 0..steps) {
            val k = if (lobes <= 0 || amp <= 0f) 1f
                    else 1f - amp * (1f - Math.cos(2 * Math.PI * lobes * cum[i] / total).toFloat()) / 2f
            val px = cx + bx[i] * k; val py = cy + by[i] * k
            if (i == 0) p.moveTo(px, py) else p.lineTo(px, py)
        }
        p.close()
    }

    /** Polígono com todos os cantos arredondados (curva quadrática em cada vértice). */
    private fun poly(p: Path, pts: List<PointF>, rad: Float) {
        val n = pts.size
        for (i in 0 until n) {
            val cur = pts[i]; val prev = pts[(i + n - 1) % n]; val next = pts[(i + 1) % n]
            val d1 = Math.hypot((prev.x - cur.x).toDouble(), (prev.y - cur.y).toDouble()).toFloat().coerceAtLeast(0.01f)
            val d2 = Math.hypot((next.x - cur.x).toDouble(), (next.y - cur.y).toDouble()).toFloat().coerceAtLeast(0.01f)
            val r = minOf(rad, d1 / 2f, d2 / 2f)
            val ax = cur.x + (prev.x - cur.x) * r / d1; val ay = cur.y + (prev.y - cur.y) * r / d1
            val bx = cur.x + (next.x - cur.x) * r / d2; val by = cur.y + (next.y - cur.y) * r / d2
            if (i == 0) p.moveTo(ax, ay) else p.lineTo(ax, ay)
            p.quadTo(cur.x, cur.y, bx, by)
        }
        p.close()
    }

    fun build(p: Path, rc: RectF, r0: Float, shape: Int) {
        val w = rc.width(); val h = rc.height()
        val m = minOf(w, h)
        val r = r0.coerceAtMost(m / 2f)
        val l = rc.left; val t = rc.top; val rt = rc.right; val b = rc.bottom; val my = rc.centerY()
        val wide = maxOf(w, h) / m > 1.7f            // barra de espaço, Shift largo...: sempre lisa e elegante
        val perim = 2f * (w + h) * 0.9f
        when (shape) {
            1 -> p.addRoundRect(rc, m / 2f, m / 2f, Path.Direction.CW)
            2 -> organic(p, rc, 0, 0f, 4f)
            3 -> { val c = m * 0.3f
                poly(p, listOf(PointF(l + c, t), PointF(rt - c, t), PointF(rt, t + c), PointF(rt, b - c),
                    PointF(rt - c, b), PointF(l + c, b), PointF(l, b - c), PointF(l, t + c)), r * 0.55f) }
            4 -> { val c = minOf(h * 0.3f, w * 0.28f)
                poly(p, listOf(PointF(l + c, t), PointF(rt - c, t), PointF(rt, my), PointF(rt - c, b),
                    PointF(l + c, b), PointF(l, my)), r * 0.9f) }
            5 -> if (wide) organic(p, rc, 0, 0f, 3.2f)
                 else organic(p, rc, Math.round(perim / (m * 0.7f)).coerceIn(6, 14), 0.05f, 2.8f)   // Cookie: gomos finos
            6 -> { val big = m * 0.5f; val sm = r * 0.3f
                p.addRoundRect(rc, floatArrayOf(big, big, sm, sm, big, big, sm, sm), Path.Direction.CW) }
            7 -> { p.addRoundRect(rc, r, r, Path.Direction.CW)
                val n = Path(); val nr = m * 0.17f
                n.addCircle(l, my, nr, Path.Direction.CW); n.addCircle(rt, my, nr, Path.Direction.CW)
                p.op(n, Path.Op.DIFFERENCE) }
            8 -> { val s = m * 0.26f
                poly(p, listOf(PointF(l + s, t), PointF(rt, t), PointF(rt - s, b), PointF(l, b)), r * 0.6f) }
            9 -> if (wide) organic(p, rc, 0, 0f, 3.2f)
                 else organic(p, rc, Math.round(perim / (m * 1.15f)).coerceIn(5, 8), 0.085f, 2.4f)  // Flor: poucas pétalas largas
            else -> p.addRoundRect(rc, r, r, Path.Direction.CW)
        }
    }
}

/** Miniatura de um formato, para o seletor das configurações. */
class ShapeTile(ctx: Context, private val shape: Int, private val sel: Boolean, private val on: Int, private val off: Int) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path(); private val rc = RectF()
    override fun onDraw(c: Canvas) {
        val d = resources.displayMetrics.density
        rc.set(4 * d, 4 * d, width - 4 * d, height - 4 * d)
        path.rewind(); KeyShapes.build(path, rc, 12 * d, shape)
        p.style = Paint.Style.FILL; p.color = if (sel) on else off; c.drawPath(path, p)
        if (sel) { p.style = Paint.Style.STROKE; p.strokeWidth = 2 * d; p.color = off; c.drawPath(path, p) }
    }
}

/** Fundo em cookie (círculo com borda ondulada suave), estático. */
class CookieDrawable(private val color: Int, private val lobes: Int = 8) : android.graphics.drawable.Drawable() {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    override fun onBoundsChange(b: Rect) {
        path.rewind()
        val cx = b.exactCenterX(); val cy = b.exactCenterY(); val r = minOf(b.width(), b.height()) / 2f
        val n = 180
        for (i in 0..n) {
            val a = i * 2 * Math.PI / n
            val rr = r * (0.91f + 0.09f * Math.cos(a * lobes).toFloat())
            val x = cx + (rr * Math.cos(a)).toFloat(); val y = cy + (rr * Math.sin(a)).toFloat()
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        path.close()
    }
    override fun draw(c: Canvas) { p.color = color; c.drawPath(path, p) }
    override fun setAlpha(a: Int) { p.alpha = a }
    override fun setColorFilter(f: ColorFilter?) { p.colorFilter = f }
    @Suppress("OVERRIDE_DEPRECATION") override fun getOpacity() = PixelFormat.TRANSLUCENT
}


/** v54.2: formatos dos botões redondos da barra (microfone e seta). 0 é o cookie de sempre. */
object BarShapes {
    val NAMES = listOf("Cookie", "Flor", "Círculo", "Squircle", "Quadrado", "Selo")

    fun build(p: Path, rc: RectF, id: Int) {
        val m = minOf(rc.width(), rc.height())
        when (id) {
            1 -> PopupShapes.scallop(p, rc, 6, 0.30f, true)             // Flor: 6 pétalas largas
            2 -> p.addOval(rc, Path.Direction.CW)                        // Círculo
            3 -> p.addRoundRect(rc, m * 0.36f, m * 0.36f, Path.Direction.CW)   // Squircle
            4 -> p.addRoundRect(rc, m * 0.18f, m * 0.18f, Path.Direction.CW)   // Quadrado arredondado
            5 -> PopupShapes.scallop(p, rc, 12, 0.09f, false)           // Selo: borda com "espinhos"
            else -> PopupShapes.scallop(p, rc, 8, 0.18f, false)         // Cookie (o desenho original)
        }
    }
}

/** Fundo de um botão da barra em qualquer formato de [BarShapes], estático. */
class BadgeDrawable(private val color: Int, private val shape: Int) : android.graphics.drawable.Drawable() {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val rc = RectF()
    override fun onBoundsChange(b: Rect) {
        path.rewind()
        val s = minOf(b.width(), b.height()).toFloat()
        rc.set(b.exactCenterX() - s / 2f, b.exactCenterY() - s / 2f, b.exactCenterX() + s / 2f, b.exactCenterY() + s / 2f)
        BarShapes.build(path, rc, shape)
    }
    override fun draw(c: Canvas) { p.color = color; c.drawPath(path, p) }
    override fun setAlpha(a: Int) { p.alpha = a }
    override fun setColorFilter(f: ColorFilter?) { p.colorFilter = f }
    @Suppress("OVERRIDE_DEPRECATION") override fun getOpacity() = PixelFormat.TRANSLUCENT
}

/** Formatos do popup das teclas. Cookie, Flor e Selo usam a mesma família de formas do botão do microfone. */
object PopupShapes {
    val NAMES = listOf("Arredondado", "Círculo", "Quadrado", "Pílula", "Cookie", "Flor", "Selo")
    const val FIRST_BADGE = 4

    /**
     * Contorno ondulado em volta do centro: [lobes] gomos, com recuo de até [depth] (0..1) entre eles.
     * [petal] deixa os gomos gordos e os vales fundos (flor); sem ele a borda é suave (cookie e selo).
     * O gomo de cima fica sempre no topo.
     */
    fun scallop(p: Path, rc: RectF, lobes: Int, depth: Float, petal: Boolean) {
        val cx = rc.centerX(); val cy = rc.centerY()
        val rx = rc.width() / 2f; val ry = rc.height() / 2f
        val n = 240
        for (i in 0..n) {
            val t = i * 2 * Math.PI / n
            val c = Math.cos(lobes * t).toFloat()
            val k = if (petal) 1f - depth * (1f - Math.pow(((1f + c) / 2f).toDouble(), 0.6).toFloat())
                    else 1f - depth * (1f - c) / 2f
            val a = t - Math.PI / 2
            val x = cx + (rx * k * Math.cos(a)).toFloat(); val y = cy + (ry * k * Math.sin(a)).toFloat()
            if (i == 0) p.moveTo(x, y) else p.lineTo(x, y)
        }
        p.close()
    }

    /** Só para os formatos de selo (4..6). */
    fun badge(p: Path, rc: RectF, id: Int) = when (id) {
        4 -> scallop(p, rc, 9, 0.13f, false)     // Cookie
        5 -> scallop(p, rc, 6, 0.30f, true)      // Flor
        else -> scallop(p, rc, 12, 0.09f, false) // Selo (bolinha com "espinhos", como o microfone)
    }

    fun build(p: Path, rc: RectF, d: Float, id: Int) {
        val m = minOf(rc.width(), rc.height())
        when (id) {
            1 -> p.addOval(rc, Path.Direction.CW)
            2 -> p.addRoundRect(rc, 8 * d, 8 * d, Path.Direction.CW)
            3 -> p.addRoundRect(rc, m / 2f, m / 2f, Path.Direction.CW)
            in FIRST_BADGE..6 -> badge(p, rc, id)
            else -> p.addRoundRect(rc, m * 0.32f, m * 0.32f, Path.Direction.CW)
        }
    }
}

/** Miniatura de um formato de popup, para o seletor das configurações. */
class PopupShapeTile(ctx: Context, private val id: Int, private val sel: Boolean, private val on: Int, private val off: Int) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path(); private val rc = RectF()
    override fun onDraw(c: Canvas) {
        val d = resources.displayMetrics.density
        val s = minOf(width, height) - 8 * d
        rc.set((width - s) / 2f, (height - s) / 2f, (width + s) / 2f, (height + s) / 2f)
        path.rewind(); PopupShapes.build(path, rc, d, id)
        p.style = Paint.Style.FILL; p.color = if (sel) on else off; c.drawPath(path, p)
        if (sel) { p.style = Paint.Style.STROKE; p.strokeWidth = 2 * d; p.color = off; c.drawPath(path, p) }
    }
}

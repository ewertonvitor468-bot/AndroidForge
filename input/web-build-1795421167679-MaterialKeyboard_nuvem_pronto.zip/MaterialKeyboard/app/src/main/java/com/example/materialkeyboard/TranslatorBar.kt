package com.example.materialkeyboard

import android.content.Context
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/**
 * Barra do tradutor, acima das teclas (o teclado continua utilizável). Traduz sozinha o que está no
 * campo (ou só a seleção) depois de uma pequena pausa na digitação. "Inserir" troca o texto no app
 * pela tradução; "Desfazer" devolve o original.
 */
class TranslatorBar(
    ctx: Context, private val p: Palette,
    private val tp: TranslatorPrefs, private val engine: TranslationEngine, compact: Boolean,
    private val read: () -> Triple<String, String, String>,        // antes, seleção, depois
    private val write: (text: String, wholeField: Boolean) -> Unit,
    private val canRead: () -> Boolean
) : LinearLayout(ctx) {

    private val main = Handler(Looper.getMainLooper())
    private var open = false
    private var paused = false
    private var picking = 0                 // 0 nada, 1 escolhendo origem, 2 escolhendo destino
    private var result: String? = null
    private var lastSource: String? = null
    private var lastPair = ""
    private var afterInsert: String? = null // texto do campo logo após inserir (evita retraduzir a própria tradução)
    private var undoFull: String? = null
    private val job = Runnable { update() }

    private val chipH = if (compact) 32 else 38
    private val srcChip = chip { pick(1) }
    private val dstChip = chip { pick(2) }
    private val pauseBtn: ImageView = iconButton(ctx, R.drawable.ic_pause, p.onSpecial, "Pausar tradução".tr(), 36) { togglePause() }
    private val resultView = TextView(ctx).apply { textSize = 15f; setTextColor(p.onSpecial) }
    private val insertChip = chip(accent = true) { onInsert() }
    private val resultRow = LinearLayout(ctx)
    private val pickerRow = LinearLayout(ctx)
    private val pickerScroll = android.widget.HorizontalScrollView(ctx)
    private val pickerChips = ArrayList<TextView>()

    private fun chip(accent: Boolean = false, onClick: () -> Unit) = TextView(context).apply {
        gravity = Gravity.CENTER; textSize = 14f; maxLines = 1
        setPadding(context.dpi(12), 0, context.dpi(12), 0)
        setOnClickListener { pop(0.92f, 0L, 700f, 0.45f); onClick() }
        styleChip(this, accent)
    }

    private fun styleChip(v: TextView, accent: Boolean) {
        v.setTextColor(if (accent) p.onAccent else p.onNormal)
        v.background = roundedBg(if (accent) p.keyAccent else p.keyNormal, context.dpi(40).toFloat(), if (accent) p.onAccent else p.onNormal)
    }

    init {
        orientation = VERTICAL
        visibility = GONE
        layoutParams = LayoutParams(-1, -2).apply { setMargins(0, ctx.dpi(2), 0, ctx.dpi(4)) }
        setPadding(ctx.dpi(6), ctx.dpi(4), ctx.dpi(6), ctx.dpi(4))
        background = GradientDrawable().apply { cornerRadius = ctx.dpi(22).toFloat(); setColor(p.keySpecial) }

        val top = LinearLayout(ctx).apply { orientation = HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        top.addView(srcChip, LayoutParams(-2, ctx.dpi(chipH)))
        top.addView(iconButton(ctx, R.drawable.ic_swap, p.onSpecial, "Trocar idiomas".tr(), 36) { swap() })
        top.addView(dstChip, LayoutParams(-2, ctx.dpi(chipH)))
        top.addView(View(ctx), LayoutParams(0, 1, 1f))
        top.addView(pauseBtn)
        top.addView(iconButton(ctx, R.drawable.ic_close, p.onSpecial, "Fechar tradutor".tr(), 36) { close() })
        addView(top)

        val h = ctx.dpi(if (compact) 40 else 54)
        resultRow.orientation = HORIZONTAL
        resultRow.gravity = Gravity.CENTER_VERTICAL
        resultRow.addView(ScrollView(ctx).apply {
            isVerticalScrollBarEnabled = false
            setPadding(ctx.dpi(6), 0, ctx.dpi(6), 0)
            addView(resultView)
        }, LayoutParams(0, h, 1f))
        resultRow.addView(insertChip, LayoutParams(-2, ctx.dpi(chipH + 4)).apply { setMargins(ctx.dpi(4), 0, 0, 0) })
        addView(resultRow, LayoutParams(-1, h))

        pickerRow.orientation = HORIZONTAL
        pickerScroll.visibility = GONE
        pickerScroll.isHorizontalScrollBarEnabled = false
        pickerRow.gravity = Gravity.CENTER_VERTICAL
        TLangs.all.forEach { l ->
            val v = chip { choose(l.code) }
            v.text = l.name.tr()
            pickerChips.add(v)
            pickerRow.addView(v, LayoutParams(-2, ctx.dpi(chipH + 4)).apply { setMargins(ctx.dpi(2), 0, ctx.dpi(2), 0) })
        }
        pickerScroll.addView(pickerRow, android.widget.FrameLayout.LayoutParams(-2, -1))
        addView(pickerScroll, LayoutParams(-1, h).apply { gravity = Gravity.CENTER_VERTICAL })

        refreshChrome()
        showHint(EMPTY)
    }

    // ---------- Abrir / fechar ----------

    fun isOpen() = open
    fun toggle() { if (open) close() else open() }

    fun open() {
        open = true; paused = false; picking = 0
        reset()
        refreshChrome()
        visibility = VISIBLE
        if (Prefs.get(context).fluid) springIn(fromY = -10f, fromScale = 0.96f, stiffness = 420f, damping = 0.76f)
        schedule(0)
    }

    fun close() {
        open = false
        shutdown()
        if (Prefs.get(context).fluid && visibility == VISIBLE) {
            // some com um fade curto e sobe um pouco; só então libera o espaço
            springTo(androidx.dynamicanimation.animation.DynamicAnimation.TRANSLATION_Y, -8f * resources.displayMetrics.density, 520f, 1f)
            springTo(androidx.dynamicanimation.animation.DynamicAnimation.ALPHA, 0f, 700f, 1f) {
                if (!open) { visibility = GONE; alpha = 1f; translationY = 0f; scaleX = 1f; scaleY = 1f }
            }
        } else visibility = GONE
    }

    /** Cancela trabalho pendente (teclado fechado, destruído ou recriado). */
    fun shutdown() { main.removeCallbacks(job); engine.cancel() }

    /** Novo campo de texto: recomeça do zero. */
    fun onNewInput() {
        if (!open) return
        reset(); picking = 0; refreshChrome(); schedule(0)
    }

    /** Chamado quando o texto do campo pode ter mudado (digitação, colar, voz...). */
    fun onTextChanged() {
        if (!open || paused) return
        schedule(tp.delayMs.toLong())
    }

    // ---------- Tradução ----------

    private fun reset() {
        main.removeCallbacks(job); engine.cancel()
        result = null; lastSource = null; afterInsert = null; undoFull = null
        showHint(EMPTY); refreshInsert()
    }

    private fun schedule(delay: Long) {
        main.removeCallbacks(job)
        if (delay <= 0) main.post(job) else main.postDelayed(job, delay)
    }

    private fun currentSource(): String {
        val (b, s, a) = read()
        return if (s.isNotEmpty()) s else b + a
    }

    private fun update() {
        if (!open || paused) return
        if (!canRead()) {
            engine.cancel(); result = null
            showHint("Tradução desativada em campos de senha.".tr()); refreshInsert(); return
        }
        val src = currentSource()
        val after = afterInsert
        if (after != null) {
            if (src == after) return                       // é a tradução que acabamos de inserir
            afterInsert = null; undoFull = null; refreshInsert()
        }
        if (src.isBlank()) {
            engine.cancel(); lastSource = null; result = null
            showHint(EMPTY); refreshInsert(); return
        }
        val pair = "${tp.source}>${tp.target}"
        if (src == lastSource && pair == lastPair) return
        lastSource = src; lastPair = pair
        resultView.alpha = 0.6f
        engine.translate(src, tp.source, tp.target, tp.wifiOnly,
            onDownloading = {
                showHint(if (tp.wifiOnly) "Baixando modelo de idioma (aguarda Wi-Fi)… só na primeira vez.".tr()
                         else "Baixando modelo de idioma… só na primeira vez.".tr())
            },
            onResult = { r ->
                r.onSuccess { result = it; showResult(it) }
                 .onFailure { result = null; lastSource = null; showHint(it.message ?: "Erro ao traduzir.".tr()) }
                refreshInsert()
            })
    }

    // ---------- Inserir / desfazer ----------

    private fun onInsert() {
        val u = undoFull
        if (u != null) {
            write(u, true)
            undoFull = null; afterInsert = null; lastSource = null
            refreshInsert(); schedule(0)
            return
        }
        val res = result ?: return
        if (paused) return
        val (b, s, a) = read()
        val src = if (s.isNotEmpty()) s else b + a
        if (src != lastSource) { schedule(0); return }   // tradução desatualizada: atualiza antes de inserir
        undoFull = b + s + a
        afterInsert = if (s.isNotEmpty()) b + res + a else res
        write(res, s.isEmpty())
        refreshInsert()
    }

    // ---------- Idiomas, pausa ----------

    private fun pick(side: Int) {
        picking = if (picking == side) 0 else side
        refreshChrome()
    }

    private fun choose(code: String) {
        if (picking == 1) { if (code == tp.target) tp.target = tp.source; tp.source = code }
        else if (picking == 2) { if (code == tp.source) tp.source = tp.target; tp.target = code }
        picking = 0
        langsChanged()
    }

    private fun swap() {
        val s = tp.source; tp.source = tp.target; tp.target = s
        picking = 0
        langsChanged()
    }

    private fun langsChanged() {
        reset(); refreshChrome()
        if (paused) showHint(PAUSED) else schedule(0)
    }

    private fun togglePause() {
        paused = !paused
        refreshChrome()
        if (paused) {
            main.removeCallbacks(job); engine.cancel()
            if (result == null) showHint(PAUSED) else resultView.alpha = 0.45f
        } else {
            lastSource = null
            schedule(0)
        }
        refreshInsert()
    }

    // ---------- Visual ----------

    private fun refreshChrome() {
        srcChip.text = TLangs.of(tp.source).name.tr()
        dstChip.text = TLangs.of(tp.target).name.tr()
        styleChip(srcChip, picking == 1); styleChip(dstChip, picking == 2)
        val cur = if (picking == 1) tp.source else tp.target
        pickerChips.forEachIndexed { i, v -> styleChip(v, picking != 0 && TLangs.all[i].code == cur) }
        resultRow.visibility = if (picking == 0) VISIBLE else GONE
        pickerScroll.visibility = if (picking == 0) GONE else VISIBLE
        if (picking != 0) {                      // mais de 40 idiomas: a lista rola, e já abre no idioma escolhido
            val i = TLangs.indexOf(cur)
            pickerScroll.post { pickerChips.getOrNull(i)?.let { pickerScroll.scrollTo((it.left - width / 3).coerceAtLeast(0), 0) } }
        }
        pauseBtn.setImageResource(if (paused) R.drawable.ic_play else R.drawable.ic_pause)
        pauseBtn.contentDescription = if (paused) "Retomar tradução".tr() else "Pausar tradução".tr()
    }

    private fun refreshInsert() {
        val undo = undoFull != null
        insertChip.text = if (undo) "↩ Desfazer".tr() else "Inserir".tr()
        insertChip.alpha = if (undo || (result != null && !paused)) 1f else 0.4f
    }

    private fun showHint(t: String) {
        resultView.text = t; resultView.alpha = 0.65f; resultView.setTypeface(null, Typeface.ITALIC)
    }

    private fun showResult(t: String) {
        resultView.text = t; resultView.alpha = 1f; resultView.setTypeface(null, Typeface.NORMAL)
    }

    private companion object {
        val EMPTY: String get() = "Digite no campo: a tradução aparece aqui.".tr()
        val PAUSED: String get() = "Tradução pausada. Toque em ▶ para continuar.".tr()
    }
}

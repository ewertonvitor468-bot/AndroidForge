package com.example.materialkeyboard.compose

import android.graphics.Color as AColor
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import com.example.materialkeyboard.Palette
import com.example.materialkeyboard.Prefs
import com.example.materialkeyboard.tr
import kotlin.math.abs
import kotlin.math.roundToInt

private val SEEDS = listOf(0xFF22C55E, 0xFF3B82F6, 0xFF8B5CF6, 0xFFEC4899, 0xFFF97316, 0xFFEF4444, 0xFF14B8A6, 0xFFEAB308).map { it.toInt() }
private val FONTS = listOf(0xFFFFFFFF, 0xFF000000, 0xFFFFEB3B, 0xFF4DD0E1, 0xFF69F0AE, 0xFFFF80AB, 0xFFFFAB40, 0xFFFF5252).map { it.toInt() }
private val bounce = spring<Float>(Spring.DampingRatioMediumBouncy, Spring.StiffnessMedium)

/** Tela de tema do zero: prévia ao vivo (deslize para trocar a cor), temas, cor própria, modo e formato. */
@Composable
fun ThemeScreen(prefs: Prefs) {
    val ctx = LocalContext.current
    var rev by remember { mutableIntStateOf(0) }
    val pal = remember(rev) { Palette.build(ctx, prefs) }
    MkTheme(colors = paletteColorScheme(pal)) {
        val cs = MaterialTheme.colorScheme
        val bg by animateColorAsState(Color(pal.surface), spring(stiffness = 300f), label = "bg")
        val card = Color(pal.keyNormal).copy(alpha = 0.55f)
        val seedIdx = if (prefs.preset == 0 && prefs.useCustomColor) SEEDS.indexOf(prefs.customColor) else -1
        Column(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp)).background(bg).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Preview(pal, prefs) { dir ->
                val n = SEEDS.size
                prefs.putCustomColor(SEEDS[if (seedIdx < 0) 0 else (seedIdx + dir + n) % n]); rev++
            }
            Text("Deslize o teclado para trocar de cor".tr(), color = cs.onSurface.copy(alpha = 0.6f),
                style = MaterialTheme.typography.bodySmall, modifier = Modifier.align(Alignment.CenterHorizontally))

            Block("Modo".tr(), card) {
                Segmented(listOf("Sistema".tr(), "Claro".tr(), "Escuro".tr()), prefs.theme) { prefs.putInt("theme", it); rev++ }
            }
            Block("Cores".tr(), card) {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.padding(vertical = 4.dp)) {
                    itemsIndexed(SEEDS) { i, c -> Dot(Color(c), i == seedIdx, 44) { prefs.putCustomColor(c); rev++ } }
                }
                val hue = remember(rev) { FloatArray(3).also { AColor.colorToHSV(prefs.customColor, it) }[0] }
                Text("Matiz personalizado".tr(), color = cs.onSurface.copy(alpha = 0.7f), style = MaterialTheme.typography.bodySmall)
                Slider(hue, { prefs.putCustomColor(AColor.HSVToColor(floatArrayOf(it, 0.75f, 0.85f))); rev++ }, valueRange = 0f..360f)
            }
            Block("Temas prontos".tr(), card) {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    itemsIndexed(Palette.PRESETS) { i, p ->
                        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.width(72.dp)) {
                            Dot(Color(p.surface), prefs.preset == i + 1, 52, Color(p.accent)) { prefs.putInt("preset", i + 1); rev++ }
                            Text(p.name, color = cs.onSurface, style = MaterialTheme.typography.labelSmall, maxLines = 1,
                                modifier = Modifier.padding(top = 6.dp))
                        }
                    }
                }
            }
            Block("Formato".tr(), card) {
                SliderRow("Arredondamento das teclas".tr(), prefs.keyRadius, 0..32) { prefs.putInt("keyRadius", it); rev++ }
                SliderRow("Arredondamento do teclado".tr(), prefs.boardRadius, 0..40) { prefs.putInt("boardRadius", it); rev++ }
            }
            Block("Fundo do teclado".tr(), card) {
                SliderRow("Opacidade".tr(), prefs.bgOpacity, 0..100, " %") { prefs.putInt("bgOpacity", it); rev++ }
                if (android.os.Build.VERSION.SDK_INT >= 31) {
                    SliderRow("Desfoque".tr(), prefs.bgBlur, 0..100, " %") { prefs.putInt("bgBlur", it); rev++ }
                    Text("O desfoque aparece atrás do teclado quando a opacidade está abaixo de 100%.".tr(), color = cs.onSurface.copy(alpha = 0.6f),
                        style = MaterialTheme.typography.bodySmall)
                } else Text("O desfoque precisa do Android 12 ou mais novo.".tr(), color = cs.onSurface.copy(alpha = 0.6f),
                    style = MaterialTheme.typography.bodySmall)
            }
            Block("Cor das fontes".tr(), card) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Mudar cor das letras".tr(), color = cs.onSurface, modifier = Modifier.weight(1f))
                    Switch(prefs.fontColorOn, { prefs.putBool("fontColorOn", it); rev++ })
                }
                LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.padding(top = 6.dp)) {
                    itemsIndexed(FONTS) { _, c ->
                        Dot(Color(c), prefs.fontColorOn && (prefs.fontColor or 0xFF000000.toInt()) == c, 36) { prefs.putFontColor(c); rev++ }
                    }
                }
            }
            Button(
                onClick = {
                    prefs.putCustomColor(SEEDS[0]); prefs.putInt("theme", 0); prefs.putBool("fontColorOn", false); rev++
                },
                modifier = Modifier.fillMaxWidth().height(52.dp)
            ) { Text("Restaurar verde padrão".tr(), fontWeight = FontWeight.SemiBold) }
        }
    }
}

@Composable
private fun Block(title: String, bg: Color, content: @Composable () -> Unit) {
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(bg).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(title, color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
        content()
    }
}

@Composable
private fun Dot(c: Color, selected: Boolean, size: Int, inner: Color? = null, onClick: () -> Unit) {
    val s by animateFloatAsState(if (selected) 1.12f else 1f, bounce, label = "dot")
    val ring = MaterialTheme.colorScheme.primary
    Box(
        Modifier.size(size.dp).scale(s).clip(CircleShape).background(c)
            .border(if (selected) 3.dp else 1.dp, if (selected) ring else Color.Gray.copy(alpha = 0.4f), CircleShape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { if (inner != null) Box(Modifier.size((size * 0.42f).dp).clip(CircleShape).background(inner)) }
}

@Composable
internal fun Segmented(options: List<String>, sel: Int, onSel: (Int) -> Unit) {
    val cs = MaterialTheme.colorScheme
    var acc by remember { mutableFloatStateOf(0f) }
    BoxWithConstraints(
        Modifier.fillMaxWidth().height(46.dp).clip(CircleShape).background(cs.onSurface.copy(alpha = 0.08f))
            .pointerInput(sel) {
                detectHorizontalDragGestures(onDragEnd = {
                    if (abs(acc) > 40f) onSel((sel + if (acc > 0) 1 else -1).coerceIn(0, options.size - 1)); acc = 0f
                }) { _, d -> acc += d }
            }
    ) {
        val w = maxWidth / options.size
        val x by animateDpAsState(w * sel, spring(Spring.DampingRatioLowBouncy, Spring.StiffnessMediumLow), label = "seg")
        Box(Modifier.offset(x = x).width(w).fillMaxHeight().padding(3.dp).clip(CircleShape).background(cs.primary))
        Row(Modifier.fillMaxWidth().fillMaxHeight()) {
            options.forEachIndexed { i, t ->
                Box(Modifier.weight(1f).fillMaxHeight().clickable(
                    interactionSource = remember { MutableInteractionSource() }, indication = null) { onSel(i) },
                    contentAlignment = Alignment.Center) {
                    Text(t, color = if (i == sel) cs.onPrimary else cs.onSurface, fontWeight = FontWeight.Medium)
                }
            }
        }
    }
}

@Composable
private fun SliderRow(label: String, v: Int, r: IntRange, unit: String = " dp", onChange: (Int) -> Unit) {
    val cs = MaterialTheme.colorScheme
    Row { Text(label, color = cs.onSurface, modifier = Modifier.weight(1f)); Text("$v$unit", color = cs.primary, fontWeight = FontWeight.Bold) }
    Slider(v.toFloat(), { onChange(it.roundToInt()) }, valueRange = r.first.toFloat()..r.last.toFloat())
}

@Composable
private fun Preview(pal: Palette, prefs: Prefs, onSwipe: (Int) -> Unit) {
    var drag by remember { mutableFloatStateOf(0f) }
    val off by animateFloatAsState(drag, bounce, label = "drag")
    val h = (prefs.keyHeight * 0.7f).dp
    val r = prefs.keyRadius.dp
    Column(
        Modifier.fillMaxWidth().offset { IntOffset((off / 4).roundToInt(), 0) }
            .clip(RoundedCornerShape(prefs.boardRadius.dp)).background(Color(pal.keyNormal).copy(alpha = 0.35f))
            .pointerInput(Unit) {
                detectHorizontalDragGestures(
                    onDragEnd = { if (abs(drag) > 120f) onSwipe(if (drag < 0) 1 else -1); drag = 0f },
                    onDragCancel = { drag = 0f }
                ) { _, d -> drag += d }
            }.padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        listOf("qwertyuiop", "asdfghjkl", "zxcvbnm").forEach { row ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                row.forEach { Key(it.toString(), 1f, h, r, Color(pal.keyNormal), Color(pal.onNormal)) }
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
            Key("123", 1.5f, h, r, Color(pal.keySpecial), Color(pal.onSpecial))
            Key("", 5f, h, r, Color(pal.keyNormal), Color(pal.onNormal))
            Key("↵", 1.5f, h, r, Color(pal.keyAccent), Color(pal.onAccent))
        }
    }
}

@Composable
private fun RowScope.Key(label: String, w: Float, h: androidx.compose.ui.unit.Dp, r: androidx.compose.ui.unit.Dp, bg: Color, fg: Color) {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val sc by animateFloatAsState(if (pressed) 0.86f else 1f, bounce, label = "key")
    val c by animateColorAsState(bg, spring(stiffness = 300f), label = "keyc")
    Box(
        Modifier.weight(w).height(h).scale(sc).clip(RoundedCornerShape(r)).background(c)
            .clickable(interactionSource = src, indication = null) { },
        contentAlignment = Alignment.Center
    ) { Text(label, color = fg, fontWeight = FontWeight.Medium) }
}

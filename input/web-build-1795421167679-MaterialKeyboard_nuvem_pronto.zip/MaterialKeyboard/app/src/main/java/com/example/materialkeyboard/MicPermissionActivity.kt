package com.example.materialkeyboard

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast

/**
 * Um teclado (IME) não consegue mostrar o diálogo de permissão. Esta activity transparente pede
 * RECORD_AUDIO uma única vez e fecha, devolvendo o foco ao app onde o usuário estava digitando.
 */
class MicPermissionActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (savedInstanceState != null) return
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            finish(); return
        }
        requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), REQ)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ) {
            val ok = grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED
            if (ok) {
                Toast.makeText(this, "Microfone liberado. Toque no microfone para ditar.".tr(), Toast.LENGTH_LONG).show()
            } else {
                // Depois de negar duas vezes o Android não mostra mais o diálogo: leva às configurações do app.
                Toast.makeText(this, "Ative a permissão do microfone nas configurações do app.".tr(), Toast.LENGTH_LONG).show()
                try {
                    startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
                } catch (_: Exception) { }
            }
        }
        finish()
    }

    private companion object { const val REQ = 78 }
}

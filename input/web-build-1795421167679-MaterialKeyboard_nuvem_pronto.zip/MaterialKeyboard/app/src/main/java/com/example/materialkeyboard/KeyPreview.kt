package com.example.materialkeyboard

import android.content.Context
import android.graphics.*
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.PopupWindow
import androidx.core.graphics.ColorUtils
import androidx.dynamicanimation.animation.DynamicAnimation
import androidx.dynamicanimation.animation.SpringAnimation
import androidx.dynamicanimation.animation.SpringForce

/** Balão desenhado em Canvas com o formato da tecla (Expressive). */
private class PreviewView(ctx: Context) : View(ctx) {
    var text = ""; var bg = 0; var fg = 0; var textPx = 40f
    var shape = 0; var shapeId = 0
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER; typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    }
    private val path = Path(); private val rc = RectF()
    override fun onDraw(c: Canvas) {
        val d = resources.displayMetrics.density
        val w = width.toFloat(); val h = height.toFloat(); val m = minOf(w, h)
        val st = 1.2f * d
        rc.set(st, st, w - st, h - st)
        path.rewind()
        when (shapeId) {
            1 -> path.addOval(rc, Path.Direction.CW)
            2 -> path.addRoundRect(rc, 8 * d, 8 * d, Path.Direction.CW)
            3 -> path.addRoundRect(rc, m / 2f, m / 2f, Path.Direction.CW)
            4, 5, 6 -> PopupShapes.badge(path, rc, shapeId)
            else -> if (shape == 0) path.addRoundRect(rc, m * 0.32f, m * 0.32f, Path.Direction.CW)
                    else KeyShapes.build(path, rc, m * 0.32f, shape)
        }
        p.style = Paint.Style.FILL; p.color = ColorUtils.setAlphaComponent(bg, 255); c.drawPath(path, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = st; p.color = ColorUtils.setAlphaComponent(fg, 50); c.drawPath(path, p)
        tp.color = fg; tp.textSize = textPx
        c.drawText(text, w / 2f, h / 2f - (tp.ascent() + tp.descent()) / 2f, tp)
    }
}

/**
 * Balão acima da tecla. Uma janela só, reaproveitada; molas únicas (sem acúmulo em toque rápido).
 * Anti-travamento: um vigia confere a cada 80 ms se a tecla dona ainda está pressionada.
 *
 * v66: a janela (PopupWindow) é fixa e cobre a largura do teclado + a faixa acima dele; ao trocar de tecla
 * só o balão se move DENTRO dela (translation, no mesmo quadro do desenho). Antes a janela inteira era
 * reposicionada no sistema a cada toque: isso gerava atraso na digitação rápida e o texto novo aparecia
 * por um instante no lugar da tecla anterior (o "balão bugado").
 */
class KeyPreview(private val ctx: Context, private val pal: Palette, private val prefs: Prefs) {
    private var pw: PopupWindow? = null
    private var v: PreviewView? = null
    private var host: FrameLayout? = null
    private var owner: KeyView? = null
    private var want = false
    private var lastEventT = 0L          // quando o balão foi mostrado/escondido pela última vez
    private var sA: SpringAnimation? = null
    private var sX: SpringAnimation? = null
    private var sY: SpringAnimation? = null
    private var sTx: SpringAnimation? = null
    private var sTy: SpringAnimation? = null
    private var winY = Int.MIN_VALUE; private var winW = -1; private var winH = -1

    private val watch = object : Runnable {
        override fun run() {
            val o = owner
            if (!want) return
            if (o == null || !o.isDown || !o.isAttachedToWindow) hideNow() else v?.postDelayed(this, 80)
        }
    }

    private fun colors(): Pair<Int, Int> = when (prefs.previewColor) {
        1 -> pal.keySpecial to pal.onSpecial
        2 -> pal.keyNormal to pal.onNormal
        3 -> {
            val c = Color.HSVToColor(floatArrayOf(prefs.previewHue.coerceIn(0, 360).toFloat(), 0.55f, 0.92f))
            c to (if (ColorUtils.calculateLuminance(c) > 0.45) 0xFF111114.toInt() else 0xFFFFFFFF.toInt())
        }
        else -> pal.keyAccent to pal.onAccent
    }

    private fun spring(view: View, prop: DynamicAnimation.ViewProperty) =
        SpringAnimation(view, prop, 1f).apply { setMinimumVisibleChange(0.002f) }

    private fun go(a: SpringAnimation?, t: Float, stiff: Float, damp: Float) {
        a ?: return
        a.spring.setStiffness(stiff).setDampingRatio(damp)
        a.animateToFinalPosition(t)
    }

    fun show(anchor: View, text: String, textPx: Float) {
        if (text.isEmpty() || !anchor.isAttachedToWindow || anchor !is KeyView) return
        try {
            owner = anchor
            val d = ctx.resources.displayMetrics.density
            val root = anchor.rootView
            val rootW = if (root.width > 0) root.width else ctx.resources.displayMetrics.widthPixels
            val s = prefs.previewSize.coerceIn(70, 160) / 100f
            val base = maxOf(anchor.width * 1.3f, 54 * d) * s
            val sid = prefs.previewShape
            val badge = sid >= PopupShapes.FIRST_BADGE
            val w = (if (sid == 3) base * 0.9f else if (badge) base * 1.08f else base).toInt()
            val h = (if (sid == 1) base else if (badge) base * 1.08f else base * 1.25f).toInt()
            val (bg, fg) = colors()
            // tudo em coordenadas da janela do teclado (as mesmas que o sistema usa para posicionar a janela)
            val al = IntArray(2); anchor.getLocationInWindow(al)
            val pad = (4 * d).toInt()
            val px = (al[0] + anchor.width / 2 - w / 2).coerceIn(pad, maxOf(pad, rootW - w - pad))
            val py = al[1] - h - (2 * d).toInt()
            // a janela do balão: toda a largura, do topo do balão até o fim do teclado
            val wy = minOf(0, py - pad)
            val wh = maxOf(root.height, al[1] + anchor.height) - wy
            val tx = px.toFloat(); val ty = (py - wy).toFloat()

            var view = v
            val win = pw
            val wasVisible = view != null && view.alpha > 0.08f && view.visibility == View.VISIBLE
            if (view == null || win == null || !win.isShowing) {
                release()
                val hv = FrameLayout(ctx).apply { clipChildren = false; clipToPadding = false }
                view = PreviewView(ctx).also { v = it }
                view.alpha = 0f
                hv.addView(view, FrameLayout.LayoutParams(w, h))
                view.translationX = tx; view.translationY = ty
                val p = PopupWindow(hv, rootW, wh, false).apply {
                    isFocusable = false; isTouchable = false; isOutsideTouchable = false
                    isClippingEnabled = false
                    inputMethodMode = PopupWindow.INPUT_METHOD_NOT_NEEDED
                    setWindowLayoutType(WindowManager.LayoutParams.TYPE_APPLICATION_PANEL)
                }
                view.text = text; view.bg = bg; view.fg = fg; view.textPx = textPx * 1.55f * s
                view.shape = anchor.shape; view.shapeId = sid
                p.showAtLocation(root, Gravity.TOP or Gravity.LEFT, 0, wy)
                pw = p; host = hv
                winY = wy; winW = rootW; winH = wh
                sA = spring(view, DynamicAnimation.ALPHA)
                sX = spring(view, DynamicAnimation.SCALE_X)
                sY = spring(view, DynamicAnimation.SCALE_Y)
                sTx = spring(view, DynamicAnimation.TRANSLATION_X).apply { setMinimumVisibleChange(1f) }
                sTy = spring(view, DynamicAnimation.TRANSLATION_Y).apply { setMinimumVisibleChange(1f) }
            } else {
                view.text = text; view.bg = bg; view.fg = fg; view.textPx = textPx * 1.55f * s
                view.shape = anchor.shape; view.shapeId = sid
                val lp = view.layoutParams
                if (lp.width != w || lp.height != h) { lp.width = w; lp.height = h; view.layoutParams = lp }
                // só reposiciona a janela se o teclado mudou de tamanho/posição (raro), nunca a cada toque
                if (wy != winY || rootW != winW || wh > winH || wh < winH - (24 * d).toInt()) {
                    win.update(0, wy, rootW, wh)
                    winY = wy; winW = rootW; winH = wh
                }
                // v75.1: o balão NUNCA desliza (antes uma mola o arrastava de uma tecla à outra e ele ficava
                // atrasado, "flutuando" sobre a tecla errada/as sugestões). Agora vai direto para a tecla tocada.
                sTx?.cancel(); sTy?.cancel()
                view.translationX = tx; view.translationY = ty
                view.invalidate()
            }
            val vw = view ?: return
            want = true
            vw.visibility = View.VISIBLE
            vw.pivotX = w / 2f; vw.pivotY = h.toFloat()
            vw.removeCallbacks(watch); vw.postDelayed(watch, 120)
            // Digitando rápido (ou balão ainda visível): sem animação nenhuma, o balão só troca de tecla, firme.
            // A animação de "nascer" só toca quando ele surge do zero, depois de um tempinho sem digitar.
            val now = android.os.SystemClock.uptimeMillis()
            val fast = now - lastEventT < 220 || wasVisible
            lastEventT = now
            if (prefs.previewAnim && !fast) {
                vw.scaleX = 0.7f; vw.scaleY = 0.7f
                go(sA, 1f, 2200f, 1f)
                go(sX, 1f, 1500f, 0.7f)
                go(sY, 1f, 1500f, 0.7f)
            } else {
                sA?.cancel(); sX?.cancel(); sY?.cancel()
                vw.alpha = 1f; vw.scaleX = 1f; vw.scaleY = 1f
            }
        } catch (_: Exception) { release() }
    }

    fun hide(who: View) {
        if (owner != null && owner !== who) return
        hideNow()
    }

    private fun hideNow() {
        want = false; owner = null
        lastEventT = android.os.SystemClock.uptimeMillis()
        val vw = v ?: return
        vw.removeCallbacks(watch)
        // v75.1: some na hora ao soltar (sem fade): nada fica pairando sobre a próxima tecla nem sobre as sugestões
        sA?.cancel(); sX?.cancel(); sY?.cancel(); sTx?.cancel(); sTy?.cancel()
        vw.alpha = 0f; vw.visibility = View.INVISIBLE
    }

    private val endL = object : DynamicAnimation.OnAnimationEndListener {
        override fun onAnimationEnd(a: DynamicAnimation<*>?, canceled: Boolean, value: Float, velocity: Float) {
            a?.removeEndListener(this)
            if (!want && value <= 0.05f) v?.visibility = View.INVISIBLE
        }
    }

    fun release() {
        want = false
        v?.removeCallbacks(watch)
        sA?.cancel(); sX?.cancel(); sY?.cancel(); sTx?.cancel(); sTy?.cancel()
        try { pw?.dismiss() } catch (_: Exception) { }
        pw = null; v = null; host = null; owner = null; sA = null; sX = null; sY = null; sTx = null; sTy = null
        winY = Int.MIN_VALUE; winW = -1; winH = -1
    }
}

package com.example.materialkeyboard.compose

import androidx.compose.animation.core.FiniteAnimationSpec
import androidx.compose.animation.core.snap
import androidx.compose.animation.core.spring
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.Composable
import androidx.compose.runtime.staticCompositionLocalOf

enum class MkSpeed { Fast, Default, Slow }

/**
 * Motion Scheme Expressive do teclado (molas), no mesmo modelo do Material 3 Expressive:
 *  - spatial: movimento/forma/tamanho — com leve "quique" (amortecimento < 1);
 *  - effects: cor/opacidade — sem quique (amortecimento 1).
 * Valores de referência da especificação M3 Expressive (spatial: 0.6/800, 0.8/380, 0.8/200;
 * effects: 1.0 com rigidez 3800/1600/800). Implementação própria, pois a API oficial
 * (MotionScheme.expressive) só existe em Material3 1.5+, que exige AGP 9.x e compileSdk 37.
 *
 * [enabled] = false (ex.: usuário desligou as animações fluidas) troca tudo por snap().
 */
class MkMotionScheme(val enabled: Boolean = true) {

    fun <T> spatial(speed: MkSpeed = MkSpeed.Default): FiniteAnimationSpec<T> =
        if (!enabled) snap() else when (speed) {
            MkSpeed.Fast -> spring(dampingRatio = 0.6f, stiffness = 800f)
            MkSpeed.Default -> spring(dampingRatio = 0.8f, stiffness = 380f)
            MkSpeed.Slow -> spring(dampingRatio = 0.8f, stiffness = 200f)
        }

    fun <T> effects(speed: MkSpeed = MkSpeed.Default): FiniteAnimationSpec<T> =
        if (!enabled) snap() else when (speed) {
            MkSpeed.Fast -> spring(dampingRatio = 1f, stiffness = 3800f)
            MkSpeed.Default -> spring(dampingRatio = 1f, stiffness = 1600f)
            MkSpeed.Slow -> spring(dampingRatio = 1f, stiffness = 800f)
        }
}

val LocalMkMotion = staticCompositionLocalOf { MkMotionScheme() }

/** Atalho: `Mk.motion.spatial()` dentro de qualquer composable. */
object Mk {
    val motion: MkMotionScheme
        @Composable @ReadOnlyComposable get() = LocalMkMotion.current
}

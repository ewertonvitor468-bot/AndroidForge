package com.example.materialkeyboard.compose

import android.graphics.BitmapFactory
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SwipeToDismissBox
import androidx.compose.material3.SwipeToDismissBoxValue
import androidx.compose.material3.Text
import androidx.compose.material3.rememberSwipeToDismissBoxState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.lerp
import androidx.compose.ui.unit.sp
import com.example.materialkeyboard.AnimCfg
import com.example.materialkeyboard.ClipboardStore
import com.example.materialkeyboard.EmojiData
import com.example.materialkeyboard.EmojiRecents
import com.example.materialkeyboard.L
import com.example.materialkeyboard.R
import com.example.materialkeyboard.tr
import kotlin.math.abs
import kotlin.math.roundToInt
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/*
 * Painéis do teclado em Jetpack Compose + Material 3 Expressive (substituem as Views desenhadas à mão):
 *  - histórico (LazyColumn com lista segmentada, deslizar para apagar e reordenação em mola);
 *  - emojis (LazyVerticalGrid + abas que fazem morfing de forma);
 *  - linha de ações extras (grupo de botões que mudam de forma ao pressionar).
 */

// ------------------------------------------------------------------------------------------------
// Área de transferência
// ------------------------------------------------------------------------------------------------

/** Estado observável do histórico: o serviço chama [refresh] quando o [ClipboardStore] muda. */
class MkClipboardState(private val store: ClipboardStore) {
    var items by mutableStateOf(store.all())
        private set
    /** Filtro: 0 = tudo, 1 = texto, 2 = imagens. */
    var filter by mutableIntStateOf(0)
    /** Caminho da imagem aberta em tela cheia (visualização), ou null. */
    var preview by mutableStateOf<String?>(null)

    fun refresh() {
        items = store.all()
        val p = preview
        if (p != null && items.none { it is ClipboardStore.Entry.Image && it.path == p }) preview = null
    }
}

private fun clipKey(e: ClipboardStore.Entry): String = when (e) {
    is ClipboardStore.Entry.Text -> "t:" + e.text
    is ClipboardStore.Entry.Image -> "i:" + e.path
}

@Composable
fun MkClipboardPanel(
    state: MkClipboardState,
    onBack: () -> Unit,
    onClear: () -> Unit,
    onDelete: (ClipboardStore.Entry) -> Unit,
    onPasteText: (String) -> Unit,
    onPasteImage: (String) -> Unit
) {
    val cs = MaterialTheme.colorScheme
    val motion = Mk.motion
    val all = state.items
    val items = when (state.filter) {
        1 -> all.filterIsInstance<ClipboardStore.Entry.Text>()
        2 -> all.filterIsInstance<ClipboardStore.Entry.Image>()
        else -> all
    }
    Box(Modifier.fillMaxSize()) {
    Column(Modifier.fillMaxSize().padding(horizontal = 6.dp)) {
        Row(Modifier.fillMaxWidth().height(44.dp), verticalAlignment = Alignment.CenterVertically) {
            MkIconButton(onClick = onBack) { MkBackArrow() }
            Text(
                "Área de transferência".tr(), color = cs.onSurface,
                style = MaterialTheme.typography.titleMedium,
                modifier = Modifier.weight(1f).padding(start = 10.dp)
            )
            MkIconButton(onClick = onClear) { MkIcon(R.drawable.ic_trash, "Apagar tudo".tr()) }
        }
        if (all.isNotEmpty()) {
            Row(Modifier.fillMaxWidth().padding(bottom = 6.dp, start = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Tudo".tr(), "Texto".tr(), "Imagens".tr()).forEachIndexed { i, label ->
                    FilterChip(selected = state.filter == i, onClick = { state.filter = i }, label = { Text(label) })
                }
            }
        }
        if (items.isEmpty()) {
            Column(
                Modifier.fillMaxSize().padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                val cookie = remember { MorphShape(MkMorphs.circleToCookie, 1f) }
                Box(
                    Modifier.size(64.dp).clip(cookie).background(cs.secondaryContainer),
                    contentAlignment = Alignment.Center
                ) { MkIcon(R.drawable.ic_clipboard, null, cs.onSecondaryContainer, 28.dp) }
                Text(
                    if (all.isEmpty()) L.f("Nada copiado ainda.\nTudo que você copiar aparece aqui (até %d). Passou do limite, o mais antigo sai. Fica até você excluir.", ClipboardStore.MAX_ITEMS)
                    else "Nenhum item neste filtro.".tr(),
                    color = cs.onSurfaceVariant, style = MaterialTheme.typography.bodyMedium,
                    textAlign = TextAlign.Center, modifier = Modifier.padding(top = 12.dp)
                )
            }
        } else {
            LazyColumn(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                itemsIndexed(items, key = { _, e -> clipKey(e) }) { i, entry ->
                    ClipRow(
                        entry = entry,
                        first = i == 0,
                        last = i == items.lastIndex,
                        onPaste = {
                            when (entry) {
                                is ClipboardStore.Entry.Text -> onPasteText(entry.text)
                                is ClipboardStore.Entry.Image -> onPasteImage(entry.path)
                            }
                        },
                        onDelete = { onDelete(entry) },
                        onPreview = { if (entry is ClipboardStore.Entry.Image) state.preview = entry.path },
                        modifier = Modifier.animateItem(
                            fadeInSpec = motion.effects<Float>(),
                            placementSpec = motion.spatial<IntOffset>(),
                            fadeOutSpec = motion.effects<Float>()
                        )
                    )
                }
            }
        }
    }
    state.preview?.let { path ->
        ClipPreview(
            path = path,
            onClose = { state.preview = null },
            onUse = { onPasteImage(path); state.preview = null },
            onDelete = { onDelete(ClipboardStore.Entry.Image(path)); state.preview = null }
        )
    }
    }
}

/** Visualização da imagem em tela cheia dentro do painel, com Usar / Excluir. */
@Composable
private fun ClipPreview(path: String, onClose: () -> Unit, onUse: () -> Unit, onDelete: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val bmp by produceState<ImageBitmap?>(null, path) {
        value = withContext(Dispatchers.IO) { decodeThumb(path, 1280) }
    }
    Column(
        Modifier.fillMaxSize().background(cs.surfaceContainerHigh)
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { }
            .padding(horizontal = 6.dp)
    ) {
        Row(Modifier.fillMaxWidth().height(44.dp), verticalAlignment = Alignment.CenterVertically) {
            MkIconButton(onClick = onClose) { MkBackArrow() }
            Text("Imagem".tr(), color = cs.onSurface, style = MaterialTheme.typography.titleMedium,
                modifier = Modifier.weight(1f).padding(start = 10.dp))
            MkIconButton(onClick = onDelete) { MkIcon(R.drawable.ic_trash, "Apagar item".tr()) }
        }
        Box(Modifier.weight(1f).fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(cs.surfaceContainer),
            contentAlignment = Alignment.Center) {
            bmp?.let { Image(it, "Imagem".tr(), contentScale = ContentScale.Fit, modifier = Modifier.fillMaxSize()) }
        }
        FilledTonalButton(onClick = onUse, modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
            Text("Usar".tr())
        }
    }
}

/** Linha de lista segmentada (Expressive): cantos grandes nas pontas, pequenos no meio; "abre" ao pressionar. */
@Composable
private fun ClipRow(
    entry: ClipboardStore.Entry,
    first: Boolean,
    last: Boolean,
    onPaste: () -> Unit,
    onDelete: () -> Unit,
    onPreview: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val cs = MaterialTheme.colorScheme
    val motion = Mk.motion
    val source = remember { MutableInteractionSource() }
    val pressed by source.collectIsPressedAsState()
    val press = animateFloatAsState(if (pressed) 1f else 0f, motion.spatial(MkSpeed.Fast), label = "mkClipPress")
    val big = 22.dp
    val small = 6.dp
    val currentDelete by rememberUpdatedState(onDelete)
    val dismiss = rememberSwipeToDismissBoxState(
        confirmValueChange = { v ->
            if (v == SwipeToDismissBoxValue.Settled) false else { currentDelete(); true }
        }
    )
    Box(
        modifier = modifier
            .fillMaxWidth()
            .graphicsLayer {
                val t = press.value.coerceIn(0f, 1f)
                val top = lerp(if (first) big else small, 14.dp, t)
                val bottom = lerp(if (last) big else small, 14.dp, t)
                shape = RoundedCornerShape(topStart = top, topEnd = top, bottomEnd = bottom, bottomStart = bottom)
                clip = true
                val s = 1f - 0.03f * t
                scaleX = s; scaleY = s
            }
    ) {
        SwipeToDismissBox(
            state = dismiss,
            backgroundContent = {
                Box(
                    Modifier.fillMaxSize().background(cs.errorContainer).padding(horizontal = 18.dp),
                    contentAlignment = Alignment.CenterEnd
                ) { MkIcon(R.drawable.ic_trash, null, cs.onErrorContainer, 22.dp) }
            }
        ) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .background(cs.surfaceContainerHigh)
                    .clickable(interactionSource = source, indication = null, role = Role.Button, onClick = onPaste)
                    .padding(start = 14.dp, end = 4.dp, top = 6.dp, bottom = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                when (entry) {
                    is ClipboardStore.Entry.Text -> Text(
                        entry.text, color = cs.onSurfaceVariant, style = MaterialTheme.typography.bodyMedium,
                        maxLines = 2, overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f).padding(vertical = 4.dp)
                    )
                    is ClipboardStore.Entry.Image -> {
                        ClipThumb(entry.path, onPreview)
                        Text(
                            "Imagem".tr(), color = cs.onSurfaceVariant, style = MaterialTheme.typography.bodyMedium,
                            modifier = Modifier.weight(1f).padding(start = 12.dp)
                        )
                    }
                }
                MkIconButton(onClick = onDelete, tonal = false, size = 36.dp) {
                    MkIcon(R.drawable.ic_trash, "Apagar item".tr(), size = 20.dp)
                }
            }
        }
    }
}

/** Miniatura leve: decodifica em segundo plano, com fator de redução calculado antes. */
@Composable
private fun ClipThumb(path: String, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val px = with(LocalDensity.current) { 52.dp.roundToPx() }
    val bmp by produceState<ImageBitmap?>(null, path) {
        value = withContext(Dispatchers.IO) { decodeThumb(path, px) }
    }
    Box(Modifier.size(52.dp).clip(RoundedCornerShape(12.dp)).background(cs.secondaryContainer).clickable(onClick = onClick)) {
        bmp?.let {
            Image(it, contentDescription = "Imagem".tr(), contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
        }
    }
}

private fun decodeThumb(path: String, req: Int): ImageBitmap? = try {
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeFile(path, bounds)
    var sample = 1
    while (bounds.outWidth / (sample * 2) >= req && bounds.outHeight / (sample * 2) >= req) sample *= 2
    BitmapFactory.decodeFile(path, BitmapFactory.Options().apply { inSampleSize = sample })?.asImageBitmap()
} catch (_: Exception) { null }

// ------------------------------------------------------------------------------------------------
// Emojis
// ------------------------------------------------------------------------------------------------

/** Estado do painel de emojis. Os recentes só mudam ao abrir o painel ou ao tocar na aba 🕘 (não reordenam ao escolher). */
class MkEmojiState(private val recents: EmojiRecents) {
    var recent by mutableStateOf(recents.all())
        private set
    var current by mutableIntStateOf(if (recents.all().isEmpty()) 1 else 0)
        private set

    fun select(i: Int) { current = i; if (i == 0) refresh() }
    fun refresh() { recent = recents.all() }
    fun pick(e: String) { recents.add(e) }
    /** Chamado ao reabrir o painel. */
    fun onShown() { if (current == 0) refresh() }
}

@Composable
fun MkEmojiPanel(state: MkEmojiState, onPick: (String) -> Unit, onBack: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val motion = Mk.motion
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().height(44.dp), verticalAlignment = Alignment.CenterVertically) {
            MkIconButton(onClick = onBack) { MkBackArrow() }
            MkGap(6.dp)
            Row(
                Modifier.weight(1f).horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(2.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                EmojiData.tabs.forEachIndexed { i, label ->
                    val tabScale by animateFloatAsState(if (state.current == i) 1.18f else 1f, motion.spatial(MkSpeed.Fast), label = "mkEmojiTab")
                    MkIconButton(onClick = { state.select(i) }, selected = state.current == i, tonal = false) {
                        Text(label, fontSize = 18.sp, maxLines = 1, modifier = Modifier.graphicsLayer { scaleX = tabScale; scaleY = tabScale })
                    }
                }
            }
        }
        AnimatedContent(
            targetState = state.current,
            modifier = Modifier.weight(1f).fillMaxWidth(),
            transitionSpec = {
                val dir = if (targetState > initialState) 1 else -1
                (slideInHorizontally(motion.spatial<IntOffset>()) { it / 5 * dir } + scaleIn(motion.spatial<Float>(), initialScale = 0.92f) + fadeIn(motion.effects()))
                    .togetherWith(slideOutHorizontally(motion.spatial<IntOffset>()) { -it / 5 * dir } + scaleOut(motion.spatial<Float>(), targetScale = 0.96f) + fadeOut(motion.effects()))
            },
            label = "mkEmojiPage"
        ) { cat ->
            val list = if (cat == 0) state.recent else EmojiData.categories[cat]
            if (list.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("Nada por aqui ainda".tr(), color = cs.onSurfaceVariant, style = MaterialTheme.typography.bodyMedium)
                }
            } else {
                LazyVerticalGrid(columns = GridCells.Adaptive(46.dp), modifier = Modifier.fillMaxSize()) {
                    itemsIndexed(list, key = { i, _ -> i }) { i, e ->
                        EmojiCell(e, i) { state.pick(e); onPick(e) }
                    }
                }
            }
        }
    }
}

@Composable
private fun EmojiCell(emoji: String, index: Int, onClick: () -> Unit) {
    val motion = Mk.motion
    val source = remember { MutableInteractionSource() }
    val pressed by source.collectIsPressedAsState()
    val scale = animateFloatAsState(if (pressed) 0.72f else 1f, motion.spatial(MkSpeed.Fast), label = "mkEmojiScale")
    // entrada em cascata: cada emoji "brota" com mola, um pouquinho depois do anterior (só os primeiros, para não pesar)
    val enter = remember { Animatable(if (motion.enabled && index < 40) 0f else 1f) }
    LaunchedEffect(Unit) {
        if (enter.value < 1f) {
            delay((index % 8) * 14L + (index / 8) * 22L)
            enter.animateTo(1f, spring(dampingRatio = 0.55f, stiffness = 420f))
        }
    }
    Box(
        Modifier
            .fillMaxWidth()
            .height(46.dp)
            .graphicsLayer {
                val k = scale.value * (0.4f + 0.6f * enter.value)
                scaleX = k; scaleY = k
                alpha = enter.value.coerceIn(0f, 1f)
            }
            .clickable(interactionSource = source, indication = null, role = Role.Button, onClick = onClick),
        contentAlignment = Alignment.Center
    ) { Text(emoji, fontSize = 26.sp, maxLines = 1, softWrap = false) }
}

// ------------------------------------------------------------------------------------------------
// Linha de ações extras (Tudo · Copiar · Colar · Cortar · ◀ · ▶ · Demo · Ocultar)
// ------------------------------------------------------------------------------------------------

/** Uma ação da linha extra: rótulo opcional, ícone e o que fazer ao tocar. */
private class ExtraAct(val label: String, val icon: Int, val iconRotation: Float = 0f, val repeat: Boolean = false, val onClick: () -> Unit)

/**
 * Linha de ações extras, agora em duas páginas que se trocam **deslizando o dedo para o lado**
 * (como um carrossel), em vez de amontoar tudo numa fileira só de texto:
 *  - página 1: edição de texto (selecionar tudo, copiar, colar, cortar);
 *  - página 2: navegação pelo texto e outras ferramentas (mover o cursor, demo, ocultar).
 * Uma fileira de pontinhos embaixo mostra em que página está e pode ser tocada para pular direto.
 */
@Composable
fun MkExtraRow(
    scale: Float,
    feedback: () -> Unit,
    onSelectAll: () -> Unit,
    onCopy: () -> Unit,
    onPaste: () -> Unit,
    onCut: () -> Unit,
    onLeft: () -> Unit,
    onRight: () -> Unit,
    showDemo: Boolean,
    onDemo: () -> Unit,
    onHide: () -> Unit
) {
    val cs = MaterialTheme.colorScheme
    val motion = Mk.motion

    val editOps = remember(onSelectAll, onCopy, onPaste, onCut) {
        listOf(
            ExtraAct("Tudo".tr(), R.drawable.ic_select_all, onClick = onSelectAll),
            ExtraAct("Copiar".tr(), R.drawable.ic_copy, onClick = onCopy),
            ExtraAct("Colar".tr(), R.drawable.ic_paste, onClick = onPaste),
            ExtraAct("Cortar".tr(), R.drawable.ic_cut, onClick = onCut)
        )
    }
    val moveOps = remember(onLeft, onRight, showDemo, onDemo, onHide) {
        buildList {
            add(ExtraAct("", R.drawable.ic_back, repeat = true, onClick = onLeft))
            add(ExtraAct("", R.drawable.ic_back, iconRotation = 180f, repeat = true, onClick = onRight))
            if (showDemo) add(ExtraAct("Demo".tr(), R.drawable.ic_play, onClick = onDemo))
            add(ExtraAct("Ocultar".tr(), R.drawable.ic_hide_kb, onClick = onHide))
        }
    }
    val pages = remember(editOps, moveOps) { listOf(editOps, moveOps) }

    var page by remember { mutableIntStateOf(0) }
    var drag by remember { mutableFloatStateOf(0f) }
    var widthPx by remember { mutableFloatStateOf(0f) }
    val target = (-page * widthPx + drag).coerceIn(-(pages.size - 1) * widthPx, 0f)
    val animOffset by animateFloatAsState(target, motion.spatial(MkSpeed.Fast), label = "mkExtraPage")

    Column(Modifier.fillMaxSize().padding(horizontal = 2.dp, vertical = 2.dp)) {
        Box(
            Modifier
                .weight(1f)
                .fillMaxWidth()
                .onSizeChanged { widthPx = it.width.toFloat() }
                .clipToBounds()
                .pointerInput(pages.size) {
                    detectHorizontalDragGestures(
                        onDragEnd = {
                            if (abs(drag) > widthPx * 0.2f) page = (page + (if (drag < 0) 1 else -1)).coerceIn(0, pages.size - 1)
                            drag = 0f
                        },
                        onDragCancel = { drag = 0f }
                    ) { _, d -> drag += d }
                }
        ) {
            Row(
                Modifier
                    .fillMaxHeight()
                    .width(with(LocalDensity.current) { (widthPx * pages.size).toDp() })
                    .offset { IntOffset(animOffset.roundToInt(), 0) }
            ) {
                pages.forEach { group ->
                    Row(
                        Modifier.width(with(LocalDensity.current) { widthPx.toDp() }).fillMaxHeight(),
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        group.forEach { act ->
                            MkActionChip(act.label, scale, Modifier.weight(1f), icon = act.icon, iconRotation = act.iconRotation,
                                repeat = act.repeat, feedback = feedback, onClick = act.onClick)
                        }
                    }
                }
            }
        }
        Row(Modifier.fillMaxWidth().height(8.dp), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
            pages.indices.forEach { i ->
                val active = i == page
                val w by animateDpAsState(if (active) 14.dp else 6.dp, motion.spatial(MkSpeed.Fast), label = "mkExtraDot")
                Box(
                    Modifier.padding(horizontal = 3.dp).size(w, 4.dp).clip(RoundedCornerShape(2.dp))
                        .background(if (active) cs.primary else cs.onSurface.copy(alpha = 0.28f))
                        .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { page = i }
                )
            }
        }
    }
}

/**
 * Botão da linha de ações: pílula que vira quadrado arredondado ao pressionar (mola spatial).
 * Com [repeat], segurar repete e vai acelerando (como as setas do teclado). Com [icon], mostra
 * o ícone ao lado do rótulo (ou sozinho, se o rótulo vier vazio, como nas setas de navegação).
 */
@Composable
private fun MkActionChip(
    label: String,
    scale: Float,
    modifier: Modifier = Modifier,
    icon: Int? = null,
    iconRotation: Float = 0f,
    repeat: Boolean = false,
    maxLines: Int = 1,
    fontSp: Float = 12f,
    feedback: () -> Unit,
    onClick: () -> Unit
) {
    val cs = MaterialTheme.colorScheme
    val motion = Mk.motion
    val scope = rememberCoroutineScope()
    val action by rememberUpdatedState(onClick)
    val fb by rememberUpdatedState(feedback)
    var down by remember { mutableStateOf(false) }
    val corner by animateDpAsState(if (down) 10.dp else 20.dp, motion.spatial<Dp>(MkSpeed.Fast), label = "mkChipCorner")
    val s = animateFloatAsState(if (down) 0.94f else 1f, motion.spatial(MkSpeed.Fast), label = "mkChipScale")
    val bg by animateColorAsState(if (down) cs.primary else cs.secondaryContainer, motion.effects(), label = "mkChipBg")
    val fg by animateColorAsState(if (down) cs.onPrimary else cs.onSecondaryContainer, motion.effects(), label = "mkChipFg")
    Box(
        modifier = modifier
            .fillMaxHeight()
            .graphicsLayer {
                scaleX = s.value; scaleY = s.value
                shape = RoundedCornerShape(corner.coerceAtLeast(0.dp))
                clip = true
            }
            .background(bg)
            .pointerInputChip(repeat, scope, { down = it }, { fb() }, { action() }),
        contentAlignment = Alignment.Center
    ) {
        if (icon != null) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(painterResource(icon), null, tint = fg,
                    modifier = Modifier.size(15.dp).graphicsLayer { rotationZ = iconRotation })
                if (label.isNotEmpty()) {
                    Spacer(Modifier.width(4.dp))
                    Text(label, color = fg, fontSize = (fontSp * scale).sp, fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold,
                        maxLines = maxLines, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center,
                        lineHeight = (fontSp * scale * 1.1f).sp)
                }
            }
        } else {
            Text(label, color = fg, fontSize = (fontSp * scale).sp, fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold,
                maxLines = maxLines, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center,
                lineHeight = (fontSp * scale * 1.1f).sp)
        }
    }
}

private fun Modifier.pointerInputChip(
    repeat: Boolean,
    scope: kotlinx.coroutines.CoroutineScope,
    setDown: (Boolean) -> Unit,
    feedback: () -> Unit,
    action: () -> Unit
): Modifier = this.pointerInput(repeat) {
    detectTapGestures(
        onPress = {
            setDown(true)
            feedback()
            if (repeat) {
                val job = scope.launch {
                    action()
                    var n = 0
                    delay((350f / AnimCfg.repeatSpeed).toLong())
                    while (true) {
                        action(); n++
                        val iv = (120f - minOf(n, 22) * 4f).coerceAtLeast(26f) / AnimCfg.repeatSpeed
                        delay(iv.toLong().coerceAtLeast(12L))
                    }
                }
                try { awaitRelease() } finally { job.cancel(); setDown(false) }
            } else {
                try { awaitRelease() } finally { setDown(false) }
            }
        },
        onTap = { if (!repeat) action() }
    )
}

package com.example.materialkeyboard

import android.content.Context
import android.media.AudioAttributes
import android.media.SoundPool
import java.io.File

/**
 * Sons das teclas: 6 pacotes (assets/sounds/p0..p5), cada tecla com o seu clipe
 * (letras, Espaço, Shift, Enter, Apagar...). Tocados por um [SoundPool]: baixa latência e vários
 * toques ao mesmo tempo. Cada tecla especial pode usar outro pacote (veja [Slot]).
 */
class SoundBank(ctx: Context) {

    private val app = ctx.applicationContext
    private val pool: SoundPool = SoundPool.Builder()
        .setMaxStreams(10)
        .setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
        ).build()

    private val ids = java.util.concurrent.ConcurrentHashMap<String, Int>()   // "pacote/clipe" -> id no SoundPool
    private val ready = HashSet<Int>()
    private val loaded = HashSet<Int>()
    private val rnd = java.util.Random()

    init {
        discover(app)
        pool.setOnLoadCompleteListener { _, id, status -> if (status == 0) synchronized(ready) { ready.add(id) } }
    }

    /** Carrega todos os clipes do pacote (uma tecla = um clipe). Chamar fora da thread principal. */
    @Synchronized fun prepare(type: Int) {
        val t = norm(type)
        if (!loaded.add(t)) return
        try {
            if (t >= CUSTOM) { val cf = customFiles(app).getOrNull(t - CUSTOM) ?: return; ids["$t/*"] = pool.load(cf.absolutePath, 1); return }
            for (clip in CLIPS + CLIPS.map { it + "_up" }) {      // "_up" = som de soltar (só nos pacotes que têm)
                for (ext in EXTS) {
                    try { app.assets.openFd("sounds/p$t/$clip.$ext").use { ids["$t/$clip"] = pool.load(it, 1) }; break } catch (_: Exception) { }
                }
            }
        } catch (_: Exception) { }
    }

    fun prepareAll(types: Collection<Int>) { types.forEach { prepare(it) } }

    /**
     * Toca o clipe da tecla [clip] no pacote [type]; se ainda não estiver pronto, apenas pula
     * (nunca bloqueia a digitação). [pitch] 0.5..2 muda o tom; [humanize] varia um pouco a cada toque.
     */
    fun play(type: Int, clip: String, volume: Float, pitch: Float = 1f, humanize: Boolean = false) {
        val t = norm(type)
        val id = if (clip.endsWith("_up")) (ids["$t/$clip"] ?: return)
                 else (ids["$t/$clip"] ?: ids["$t/*"] ?: ids["$t/a"] ?: run { prepare(t); return })
        if (!synchronized(ready) { ready.contains(id) }) return
        val rate = (pitch * (if (humanize) 1f + (rnd.nextFloat() - 0.5f) * 0.12f else 1f)).coerceIn(0.5f, 2f)
        try { pool.play(id, volume, volume, 1, 0, rate) } catch (_: Exception) { }
    }

    fun release() { try { pool.release() } catch (_: Exception) { } }

    /** Teclas que podem ter um pacote de som próprio. */
    object Slot {
        const val Q = 0; const val Z = 1; const val P = 2; const val M = 3; const val A = 4; const val L = 5
        const val ENTER = 6; const val DELETE = 7; const val EDGE = 8; const val SPACE = 9; const val SHIFT = 10
        const val COUNT = 11
        val NAMES = listOf("Q", "Z", "P", "M", "A", "L", "Enter", "Apagar", "Símbolos, emoji e idioma", "Espaço", "Shift")

        /** Tecla de letra/símbolo -> slot (ou -1). Bordas: 1, 0 e ç (extremos das fileiras). */
        fun of(c: Char, letterKey: Boolean): Int = when {
            letterKey -> when (c.lowercaseChar()) {
                'q' -> Q; 'z' -> Z; 'p' -> P; 'm' -> M; 'a' -> A; 'l' -> L; 'ç', 'ñ' -> EDGE; else -> -1
            }
            c == '1' || c == '0' -> EDGE
            else -> -1
        }

        /** Clipe da tecla especial do slot (ou null para teclas comuns). */
        fun clip(slot: Int): String? = when (slot) {
            ENTER -> "enter"; DELETE -> "back"; EDGE -> "sym"; SPACE -> "space"; SHIFT -> "shift"; else -> null
        }
    }

    companion object {
        /** Clipes de cada pacote: a-z, espaço, enter, apagar, shift, símbolos, vírgula, ponto e números. */
        val CLIPS = ('a'..'z').map { it.toString() } + listOf("space", "enter", "back", "shift", "sym", "comma", "period", "num")

        /** Clipe do caractere digitado. */
        fun clipOf(c: Char): String = when {
            c.lowercaseChar() in 'a'..'z' -> c.lowercaseChar().toString()
            c.isDigit() -> "num"
            c == ',' -> "comma"
            c == '.' -> "period"
            c == ' ' -> "space"
            c == '\n' -> "enter"
            c.isLetter() -> "a"
            else -> "sym"
        }

        /** Pacotes de som (pasta assets/sounds/p<N>), com o nome real de cada teclado. */
        private val BASE_NAMES = listOf(
            "Hayyoth ASMR", "Clicky Perfect", "CIDOO QK61 V2",
            "GravaStar V75", "Kailh Crystal Jade (clicky)", "Bolhas"
        )
        private val EXTS = listOf("ogg", "wav", "mp3")

        /**
         * Pacotes embutidos. Descobertos automaticamente: basta colocar uma pasta assets/sounds/p<N>
         * (N sequencial) com os clipes (a.ogg ... z.ogg, space, enter, back, shift, sym, comma, period, num;
         * "<clipe>_up" opcional) e, se quiser, um name.txt com o nome. Ogg, wav ou mp3.
         */
        @Volatile var NAMES: List<String> = BASE_NAMES
        @Volatile private var discovered = false
        @Synchronized fun discover(ctx: Context) {
            if (discovered) return
            try {
                val dirs = (ctx.assets.list("sounds") ?: emptyArray()).mapNotNull { d ->
                    if (d.length > 1 && d[0] == 'p' && d.substring(1).all { it.isDigit() }) d.substring(1).toInt() else null
                }.sorted()
                val n = maxOf(BASE_NAMES.size, (dirs.maxOrNull() ?: -1) + 1)
                NAMES = (0 until n).map { i ->
                    val file = try { ctx.assets.open("sounds/p$i/name.txt").bufferedReader().use { it.readLine()?.trim() } } catch (_: Exception) { null }
                    if (!file.isNullOrEmpty()) file else BASE_NAMES.getOrElse(i) { "Pacote ${i + 1}" }
                }
            } catch (_: Exception) { }
            discovered = true
        }
        const val CUSTOM = 1000
        @Volatile var customNames: List<String> = emptyList()
        private fun norm(t: Int) = if (t >= CUSTOM) t else t.coerceIn(0, NAMES.size - 1)
        fun customDir(c: Context) = File(c.filesDir, "custom_sounds").also { it.mkdirs() }
        fun customFiles(c: Context): List<File> =
            (customDir(c).listFiles()?.sortedBy { it.name } ?: emptyList()).also { l -> customNames = l.map { it.name.substringAfter('_') } }
        fun label(t: Int): String {
            if (t >= CUSTOM) return "🎵 Meu som · ".tr() + customNames.getOrElse(t - CUSTOM) { "?" }
            return NAMES.getOrElse(t) { "?" }
        }
    }
}

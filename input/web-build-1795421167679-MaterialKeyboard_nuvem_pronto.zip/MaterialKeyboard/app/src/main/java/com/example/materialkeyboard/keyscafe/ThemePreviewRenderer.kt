package com.example.materialkeyboard.keyscafe

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.os.Build
import androidx.core.graphics.ColorUtils
import java.io.ByteArrayOutputStream

/**
 * Gera a miniatura (WebP) de um [ThemeSpec] desenhando um mini teclado com Canvas: sem tela, sem rede.
 * Usada pelo editor ao salvar, para o tema já ter imagem quando for publicado no ThemeBoard.
 */
object ThemePreviewRenderer {
    private const val W = 480
    private const val H = 240

    /** Shader linear que cobre o retângulo [w]x[h] no [angle] (0 = esq→dir, 90 = baixo→cima). */
    fun shader(colors: IntArray, angle: Int, w: Float, h: Float): LinearGradient {
        val rad = Math.toRadians(angle.toDouble())
        val dx = Math.cos(rad).toFloat(); val dy = -Math.sin(rad).toFloat()
        val half = (Math.abs(dx) * w + Math.abs(dy) * h) / 2f
        val cx = w / 2f; val cy = h / 2f
        return LinearGradient(cx - dx * half, cy - dy * half, cx + dx * half, cy + dy * half, colors, null, Shader.TileMode.CLAMP)
    }

    fun render(s: ThemeSpec): ByteArray? = try {
        val bmp = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        val scale = W / 360f                                   // 1 dp do editor = 1.33 px aqui
        fun grad(target: String) = s.gradients.firstOrNull { it.target == target && it.colors.size >= 2 }

        // fundo do teclado
        val board = RectF(0f, 0f, W.toFloat(), H.toFloat())
        val br = s.keys.boardRadius * scale
        grad("surface")?.let { p.shader = shader(it.colors.map { c2 -> c2.toInt() }.toIntArray(), it.angle, W.toFloat(), H.toFloat()) }
            ?: run { p.shader = null; p.color = s.palette.surface.toInt() }
        c.drawRoundRect(board, br, br, p); p.shader = null

        // teclas: 3 fileiras de letras + fileira de baixo com especial, espaço e destaque
        val pad = 14f * scale
        val gap = s.keys.keyGap.coerceAtLeast(2) * scale
        val rows = listOf("QWERTYUIOP", "ASDFGHJKL", "ZXCVBNM")
        val keyH = (H - pad * 2 - gap * 3) / 4f
        val r = s.keys.keyRadius * scale
        val alpha = if (s.keys.keyStyle == 3) (s.keys.keyAlpha / 100f * 255).toInt().coerceIn(40, 255) else 255
        val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textAlign = Paint.Align.CENTER
            textSize = keyH * 0.42f * (s.text.textScale / 108f)
            typeface = when (s.text.fontStyle) {
                1 -> Typeface.create(Typeface.DEFAULT, Typeface.BOLD); 2 -> Typeface.SERIF; 3 -> Typeface.MONOSPACE
                4 -> Typeface.create("cursive", Typeface.NORMAL); else -> Typeface.DEFAULT }
        }
        fun key(rect: RectF, base: Long, ink: Long, target: String?, label: String) {
            val g = target?.let { grad(it) }
            if (g != null) { p.shader = LinearGradient(rect.left, rect.top, rect.right, rect.bottom, g.colors.map { it.toInt() }.toIntArray(), null, Shader.TileMode.CLAMP) }
            else { p.shader = null; p.color = base.toInt() }
            p.alpha = alpha
            c.drawRoundRect(rect, r, r, p); p.shader = null; p.alpha = 255
            text.color = (s.text.fontColor ?: ink).toInt()
            c.drawText(label, rect.centerX(), rect.centerY() + text.textSize * 0.35f, text)
        }
        for ((ri, row) in rows.withIndex()) {
            val n = row.length
            val inset = if (n == 10) 0f else (10 - n) / 2f * ((W - pad * 2 + gap) / 10f)
            val kw = (W - pad * 2 - gap * 9) / 10f
            val top = pad + ri * (keyH + gap)
            for ((i, ch) in row.withIndex()) {
                val left = pad + inset + i * (kw + gap)
                key(RectF(left, top, left + kw, top + keyH), s.palette.normal, s.palette.onNormal, "key", ch.toString())
            }
        }
        val top = pad + 3 * (keyH + gap)
        val kw = (W - pad * 2 - gap * 9) / 10f
        val l1 = pad; val r1 = pad + kw * 2 + gap
        key(RectF(l1, top, r1, top + keyH), s.palette.special, s.palette.onSpecial, null, "?123")
        val r2 = W - pad - kw * 2 - gap
        key(RectF(r1 + gap, top, r2 - gap, top + keyH), s.palette.normal, s.palette.onNormal, "key", "")
        key(RectF(r2, top, W - pad, top + keyH), s.palette.accent, s.palette.onAccent, "accent", "↵")

        val out = ByteArrayOutputStream()
        val fmt = if (Build.VERSION.SDK_INT >= 30) Bitmap.CompressFormat.WEBP_LOSSY else @Suppress("DEPRECATION") Bitmap.CompressFormat.WEBP
        bmp.compress(fmt, 80, out)
        bmp.recycle()
        out.toByteArray().takeIf { it.isNotEmpty() && it.size < 400 * 1024 }
    } catch (_: Exception) { null }
}

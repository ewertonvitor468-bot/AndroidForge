package com.example.materialkeyboard.compose

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.compositeOver
import androidx.compose.ui.graphics.LinearGradientShader
import androidx.compose.ui.graphics.Shader
import androidx.compose.ui.graphics.ShaderBrush
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.materialkeyboard.BarShapes
import com.example.materialkeyboard.L
import com.example.materialkeyboard.Prefs
import com.example.materialkeyboard.keyscafe.InstallResult
import com.example.materialkeyboard.keyscafe.SpecAnimation
import com.example.materialkeyboard.keyscafe.SpecBar
import com.example.materialkeyboard.keyscafe.SpecBubble
import com.example.materialkeyboard.keyscafe.SpecGradient
import com.example.materialkeyboard.keyscafe.SpecKeys
import com.example.materialkeyboard.keyscafe.SpecLimits
import com.example.materialkeyboard.keyscafe.SpecPalette
import com.example.materialkeyboard.keyscafe.SpecText
import com.example.materialkeyboard.keyscafe.ThemeLibrary
import com.example.materialkeyboard.keyscafe.ThemePreviewRenderer
import com.example.materialkeyboard.keyscafe.ThemeSpec
import com.example.materialkeyboard.keyscafe.ThemeSpecMapper
import com.example.materialkeyboard.tr

/** Ponto de partida de um tema novo: tons neutros do Material, claro. */
private fun blankSpec() = ThemeSpec(
    id = "meu-novo", name = "Meu tema",
    palette = SpecPalette(false, 0xFFF4EFF4, 0xFFFFFFFF, 0xFFE6E0E9, 0xFF6750A4, 0xFF1D1B20, 0xFF1D1B20, 0xFFFFFFFF)
)

/** Pincel de gradiente linear com ângulo (0 = esquerda→direita, 90 = baixo→cima), do tamanho do que ele pinta. */
private class AngleBrush(private val colors: List<Color>, private val angle: Int) : ShaderBrush() {
    override fun createShader(size: Size): Shader {
        val rad = Math.toRadians(angle.toDouble())
        val dx = Math.cos(rad).toFloat(); val dy = -Math.sin(rad).toFloat()
        val half = (Math.abs(dx) * size.width + Math.abs(dy) * size.height) / 2f
        val c = Offset(size.width / 2f, size.height / 2f)
        return LinearGradientShader(Offset(c.x - dx * half, c.y - dy * half), Offset(c.x + dx * half, c.y + dy * half), colors)
    }
}

private fun gradientBrush(s: ThemeSpec, target: String): AngleBrush? =
    s.gradients.firstOrNull { it.target == target && it.colors.size >= 2 }?.let { g -> AngleBrush(g.colors.map { Color(it.toInt()) }, g.angle) }

/** Prévia ao vivo do tema (mesmas ideias da miniatura que vai para o ThemeBoard). */
@Composable
private fun SpecPreview(s: ThemeSpec) {
    val gap = s.keys.keyGap.coerceAtLeast(1).dp
    val shape = RoundedCornerShape(s.keys.keyRadius.dp)
    val alpha = if (s.keys.keyStyle == 3) s.keys.keyAlpha / 100f else 1f
    val family = when (s.text.fontStyle) { 2 -> FontFamily.Serif; 3 -> FontFamily.Monospace; 4 -> FontFamily.Cursive; else -> FontFamily.Default }
    val weight = when (s.text.fontStyle) { 1 -> FontWeight.Black; 5 -> FontWeight.Light; else -> FontWeight.Normal }
    val size = (14f * s.text.textScale / 108f).sp
    val board = RoundedCornerShape(topStart = s.keys.boardRadius.dp, topEnd = s.keys.boardRadius.dp)
    val surfaceBrush = gradientBrush(s, "surface")
    // profundidade 3D: a do estilo (iOS 2 dp, Mecânico 4 dp) ou a escolhida; borda fina com a cor da letra
    val depth = when { s.keys.keyStyle == 3 -> 0; s.keys.keyDepth > 0 -> s.keys.keyDepth; s.keys.keyStyle == 1 -> 2; s.keys.keyStyle == 4 -> 4; else -> 0 }
    @Composable fun Key(mod: Modifier, base: Long, ink: Long, target: String?, label: String) {
        val b = target?.let { gradientBrush(s, it) }
        val fill = if (b != null) Modifier.clip(shape).background(b, alpha = alpha) else Modifier.clip(shape).background(Color(base.toInt()).copy(alpha = alpha))
        val line = if (s.keys.keyBorder > 0) Modifier.border(s.keys.keyBorder.dp, Color(ink.toInt()).copy(alpha = 0.43f), shape) else Modifier
        Box(mod.height(38.dp)) {
            if (depth > 0) Box(Modifier.matchParentSize().padding(top = depth.dp).clip(shape)
                .background(Color.Black.copy(alpha = 0.5f).compositeOver(Color(base.toInt()).copy(alpha = alpha))))
            Box(Modifier.fillMaxSize().padding(bottom = depth.dp).then(fill).then(line), contentAlignment = Alignment.Center) {
                Text(label, color = Color((s.text.fontColor ?: ink).toInt()), fontFamily = family, fontWeight = weight, fontSize = size)
            }
        }
    }
    val bg = if (surfaceBrush != null) Modifier.background(surfaceBrush) else Modifier.background(Color(s.palette.surface.toInt()))
    Column(Modifier.fillMaxWidth().clip(board).then(bg).padding(8.dp), verticalArrangement = Arrangement.spacedBy(gap)) {
        listOf("QWERTYUIOP", "ASDFGHJKL", "ZXCVBNM").forEach { row ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(gap)) {
                if (row.length < 10) Box(Modifier.weight((10 - row.length) / 2f))
                row.forEach { ch -> Key(Modifier.weight(1f), s.palette.normal, s.palette.onNormal, "key", ch.toString()) }
                if (row.length < 10) Box(Modifier.weight((10 - row.length) / 2f))
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(gap)) {
            Key(Modifier.weight(2f), s.palette.special, s.palette.onSpecial, null, "?123")
            Key(Modifier.weight(6f), s.palette.normal, s.palette.onNormal, "key", "")
            Key(Modifier.weight(2f), s.palette.accent, s.palette.onAccent, "accent", "↵")
        }
    }
}

@Composable
private fun Section(title: String, open: Boolean, onToggle: () -> Unit, content: @Composable () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(cs.surfaceVariant.copy(alpha = 0.45f)).padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(Modifier.fillMaxWidth().clickable { onToggle() }, verticalAlignment = Alignment.CenterVertically) {
            Text(title.tr(), Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
            Text(if (open) "−" else "+", color = cs.primary, style = MaterialTheme.typography.titleMedium)
        }
        if (open) content()
    }
}

@Composable
private fun Chips(labels: List<String>, selected: Int, onPick: (Int) -> Unit) {
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        labels.forEachIndexed { i, l -> FilterChip(selected == i, { onPick(i) }, { Text(l.tr()) }) }
    }
}

/**
 * Editor de temas do Keys Café. Mexe num [ThemeSpec] (só dados), mostra a prévia ao vivo e salva na biblioteca local
 * (id "meu-…"), de onde o tema pode ser aplicado, exportado ou publicado no ThemeBoard.
 * Não edita temas que têm imagem de fundo (o editor ainda não gerencia arquivos do pacote).
 */
@Composable
fun ThemeEditorDialog(prefs: Prefs, onClose: () -> Unit, onSaved: (ThemeSpec, Boolean) -> Unit, start: ThemeSpec? = null) {
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    var spec by remember { mutableStateOf<ThemeSpec?>(start) }          // start: parte direto de um tema (ex.: um clássico)
    var editingId by remember { mutableStateOf<String?>(null) }     // id existente quando se edita um tema meu
    var openSec by remember { mutableStateOf(setOf("Cores")) }
    var error by remember { mutableStateOf<String?>(null) }
    fun toggle(t: String) { openSec = if (t in openSec) openSec - t else openSec + t }

    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxSize(), color = cs.surface) {
            val s = spec
            if (s == null) {
                // ---------- tela inicial: de onde partir
                Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Editor de temas".tr(), Modifier.weight(1f), color = cs.primary, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge)
                        TextButton(onClick = onClose) { Text("Fechar".tr()) }
                    }
                    Text("Escolha de onde partir.".tr(), color = cs.onSurface.copy(alpha = 0.7f))
                    error?.let { Text(it, color = cs.error) }
                    Button(onClick = {
                        val cap = ThemeSpecMapper.capture(ctx.applicationContext, prefs, "meu-novo", "Meu tema")
                        if (cap == null) error = "Desligue a imagem de fundo para partir do visual atual.".tr() else { error = null; editingId = null; spec = cap }
                    }, modifier = Modifier.fillMaxWidth()) { Text("Do meu visual atual".tr()) }
                    OutlinedButton(onClick = { editingId = null; spec = blankSpec() }, modifier = Modifier.fillMaxWidth()) { Text("Em branco".tr()) }
                    val mine = ThemeLibrary.list().filter { it.id.startsWith("meu-") }
                    if (mine.isNotEmpty()) Text("Editar um tema meu".tr(), fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 8.dp))
                    mine.forEach { m ->
                        OutlinedButton(enabled = m.image == null, onClick = { editingId = m.id; spec = m }, modifier = Modifier.fillMaxWidth()) {
                            Text(if (m.image == null) m.name else L.f("%s (tem imagem de fundo)", m.name))
                        }
                    }
                }
            } else {
                var name by remember { mutableStateOf(s.name) }
                fun upd(f: (ThemeSpec) -> ThemeSpec) { spec = f(spec ?: return) }
                fun pal(f: (SpecPalette) -> SpecPalette) = upd { it.copy(palette = f(it.palette)) }
                fun keys(f: (SpecKeys) -> SpecKeys) = upd { it.copy(keys = f(it.keys)) }
                fun txt(f: (SpecText) -> SpecText) = upd { it.copy(text = f(it.text)) }
                fun bub(f: (SpecBubble) -> SpecBubble) = upd { it.copy(bubble = f(it.bubble)) }
                fun ani(f: (SpecAnimation) -> SpecAnimation) = upd { it.copy(animation = f(it.animation)) }
                fun bar(f: (SpecBar) -> SpecBar) = upd { it.copy(bar = f(it.bar)) }

                fun save(apply: Boolean) {
                    val nm = name.trim().take(SpecLimits.NAME_MAX)
                    if (nm.isEmpty()) { error = "Dê um nome ao tema.".tr(); return }
                    val id = editingId ?: ThemeLibrary.newLocalId(nm)
                    val final = s.copy(id = id, name = nm, description = s.description.take(SpecLimits.DESC_MAX))
                    when (val r = ThemeLibrary.saveLocal(final, ThemePreviewRenderer.render(final))) {
                        is InstallResult.Fail -> error = r.reason.tr()
                        is InstallResult.Ok -> {
                            if (apply) ThemeLibrary.apply(prefs, id)
                            onSaved(final, apply)
                        }
                    }
                }

                Column(Modifier.fillMaxSize()) {
                    Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 8.dp, top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("Editor de temas".tr(), Modifier.weight(1f), color = cs.primary, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                        TextButton(onClick = onClose) { Text("Fechar".tr()) }
                    }
                    // prévia fixa no topo; os controles rolam embaixo
                    Box(Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) { SpecPreview(s) }
                    Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedTextField(name, { if (it.length <= SpecLimits.NAME_MAX) name = it }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                            label = { Text("Nome do tema".tr()) })
                        OutlinedTextField(s.description, { if (it.length <= SpecLimits.DESC_MAX) upd { x -> x.copy(description = it) } },
                            modifier = Modifier.fillMaxWidth(), label = { Text("Descrição (opcional)".tr()) })
                        error?.let { Text(it, color = cs.error, style = MaterialTheme.typography.bodySmall) }

                        Section("Cores", "Cores" in openSec, { toggle("Cores") }) {
                            SwitchRow("Tema escuro", s.palette.dark) { v -> pal { it.copy(dark = v) } }
                            ColorField("Fundo do teclado", s.palette.surface) { v -> pal { it.copy(surface = v) } }
                            ColorField("Teclas", s.palette.normal) { v -> pal { it.copy(normal = v) } }
                            ColorField("Teclas especiais", s.palette.special) { v -> pal { it.copy(special = v) } }
                            ColorField("Destaque (enter)", s.palette.accent) { v -> pal { it.copy(accent = v) } }
                            ColorField("Letra das teclas", s.palette.onNormal) { v -> pal { it.copy(onNormal = v) } }
                            ColorField("Letra das especiais", s.palette.onSpecial) { v -> pal { it.copy(onSpecial = v) } }
                            ColorField("Letra do destaque", s.palette.onAccent) { v -> pal { it.copy(onAccent = v) } }
                        }

                        Section("Gradientes", "Gradientes" in openSec, { toggle("Gradientes") }) {
                            listOf("surface" to "Fundo", "key" to "Teclas", "accent" to "Destaque").forEach { (target, label) ->
                                val g = s.gradients.firstOrNull { it.target == target }
                                fun setG(n: SpecGradient?) = upd { x -> x.copy(gradients = x.gradients.filter { it.target != target } + listOfNotNull(n)) }
                                SwitchRow("Gradiente: $label", g != null) { on ->
                                    if (on) setG(SpecGradient(target, 90, listOf(if (target == "accent") s.palette.accent else if (target == "key") s.palette.normal else s.palette.surface,
                                        if (target == "accent") s.palette.surface else s.palette.special))) else setG(null)
                                }
                                if (g != null) {
                                    NumSlider("Ângulo", g.angle, 0..359) { a -> setG(g.copy(angle = a)) }
                                    g.colors.forEachIndexed { i, col ->
                                        ColorField(L.f("Cor %d", i + 1), col) { v -> setG(g.copy(colors = g.colors.toMutableList().also { it[i] = v })) }
                                    }
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        if (g.colors.size < SpecLimits.GRADIENT_COLORS.last)
                                            OutlinedButton(onClick = { setG(g.copy(colors = g.colors + g.colors.last())) }) { Text("+ cor".tr()) }
                                        if (g.colors.size > SpecLimits.GRADIENT_COLORS.first)
                                            OutlinedButton(onClick = { setG(g.copy(colors = g.colors.dropLast(1))) }) { Text("− cor".tr()) }
                                    }
                                }
                            }
                        }

                        Section("Teclas", "Teclas" in openSec, { toggle("Teclas") }) {
                            Text("Estilo".tr(), style = MaterialTheme.typography.labelMedium)
                            Chips(listOf("Material You", "iOS", "One UI", "Vidro", "Mecânico"), s.keys.keyStyle) { i -> keys { it.copy(keyStyle = i) } }
                            NumSlider("Formato das teclas", s.keys.keyShape, SpecLimits.KEY_SHAPE) { v -> keys { it.copy(keyShape = v) } }
                            NumSlider("Formato do destaque", s.keys.accentShape, SpecLimits.ACCENT_SHAPE) { v -> keys { it.copy(accentShape = v) } }
                            NumSlider("Cantos das teclas (dp)", s.keys.keyRadius, SpecLimits.KEY_RADIUS) { v -> keys { it.copy(keyRadius = v) } }
                            NumSlider("Cantos do teclado (dp)", s.keys.boardRadius, SpecLimits.BOARD_RADIUS) { v -> keys { it.copy(boardRadius = v) } }
                            NumSlider("Espaço entre teclas (dp)", s.keys.keyGap, SpecLimits.KEY_GAP) { v -> keys { it.copy(keyGap = v) } }
                            NumSlider("Borda das teclas (dp)", s.keys.keyBorder, SpecLimits.KEY_BORDER) { v -> keys { it.copy(keyBorder = v) } }
                            NumSlider("Profundidade 3D (dp)", s.keys.keyDepth, SpecLimits.KEY_DEPTH) { v -> keys { it.copy(keyDepth = v) } }
                            SwitchRow("Formas livres (liga os formatos escolhidos)", !s.keys.expressive) { v -> keys { it.copy(expressive = !v) } }
                            NumSlider("Opacidade das teclas (%)", s.keys.keyAlpha, SpecLimits.KEY_ALPHA) { v -> keys { it.copy(keyAlpha = v) } }
                            NumSlider("Desfoque (vidro)", s.keys.blurAmount, SpecLimits.BLUR) { v -> keys { it.copy(blurAmount = v) } }
                            SwitchRow("Brilho ao tocar", s.keys.pressGlow) { v -> keys { it.copy(pressGlow = v) } }
                            Text("A prévia mostra cantos e espaços; os formatos especiais aparecem no teclado real.".tr(),
                                style = MaterialTheme.typography.bodySmall, color = cs.onSurface.copy(alpha = 0.6f))
                        }

                        Section("Barra e microfone", "Barra" in openSec, { toggle("Barra") }) {
                            Text("Formato do microfone".tr(), style = MaterialTheme.typography.labelMedium)
                            Chips(BarShapes.NAMES, s.bar.micShape) { i -> bar { it.copy(micShape = i) } }
                            Text("Formato do botão de seta".tr(), style = MaterialTheme.typography.labelMedium)
                            Chips(BarShapes.NAMES, s.bar.toolShape) { i -> bar { it.copy(toolShape = i) } }
                            Text("Faixa de ícones".tr(), style = MaterialTheme.typography.labelMedium)
                            Chips(listOf("Pílula", "Reta", "Retangular"), s.bar.barStyle) { i -> bar { it.copy(barStyle = i) } }
                            Text("Os botões da barra aparecem no teclado real, não na prévia.".tr(),
                                style = MaterialTheme.typography.bodySmall, color = cs.onSurface.copy(alpha = 0.6f))
                        }

                        Section("Texto", "Texto" in openSec, { toggle("Texto") }) {
                            Chips(listOf("Padrão", "Black", "Serifa", "Mono", "Casual", "Fina"), s.text.fontStyle) { i -> txt { it.copy(fontStyle = i) } }
                            NumSlider("Tamanho do texto (%)", s.text.textScale, SpecLimits.TEXT_SCALE) { v -> txt { it.copy(textScale = v) } }
                            SwitchRow("Cor própria para todas as letras", s.text.fontColor != null) { on -> txt { it.copy(fontColor = if (on) s.palette.onNormal else null) } }
                            s.text.fontColor?.let { fc -> ColorField("Cor das letras", fc) { v -> txt { it.copy(fontColor = v) } } }
                        }

                        Section("Balão ao tocar", "Balão" in openSec, { toggle("Balão") }) {
                            NumSlider("Formato", s.bubble.shape, SpecLimits.BUBBLE_SHAPE) { v -> bub { it.copy(shape = v) } }
                            NumSlider("Tamanho (%)", s.bubble.size, SpecLimits.BUBBLE_SIZE) { v -> bub { it.copy(size = v) } }
                            Chips(listOf("Tema", "Destaque", "Matiz", "Neutro"), s.bubble.color) { i -> bub { it.copy(color = i) } }
                            NumSlider("Matiz do balão", s.bubble.hue, SpecLimits.BUBBLE_HUE) { v -> bub { it.copy(hue = v) } }
                            SwitchRow("Animar balão", s.bubble.anim) { v -> bub { it.copy(anim = v) } }
                        }

                        Section("Animação e cenário", "Animação" in openSec, { toggle("Animação") }) {
                            NumSlider("Velocidade (%)", s.animation.speed, SpecLimits.ANIM_SPEED) { v -> ani { it.copy(speed = v) } }
                            NumSlider("Elasticidade", s.animation.bounce, SpecLimits.ANIM_BOUNCE) { v -> ani { it.copy(bounce = v) } }
                            Chips(listOf("Desligado", "Outono", "Inverno", "Tempestade"), s.animation.scene) { i -> ani { it.copy(scene = i) } }
                        }
                        Text("Dica: depois de salvar, publique em ThemeBoard → Meus temas.".tr(), style = MaterialTheme.typography.bodySmall,
                            color = cs.onSurface.copy(alpha = 0.6f), textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp))
                    }
                    Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { save(false) }, modifier = Modifier.weight(1f)) { Text("Salvar".tr()) }
                        Button(onClick = { save(true) }, modifier = Modifier.weight(1f)) { Text("Salvar e aplicar".tr()) }
                    }
                }
            }
        }
    }
}

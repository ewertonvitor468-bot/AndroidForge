package com.example.materialkeyboard.compose

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.material3.Switch
import com.example.materialkeyboard.tr

/** Cor ARGB em Long (0xAARRGGBB, sempre positivo) a partir dos componentes HSV, mantendo o alfa [alpha]. */
private fun hsvToArgb(h: Float, s: Float, v: Float, alpha: Int): Long =
    android.graphics.Color.HSVToColor(alpha, floatArrayOf(h.coerceIn(0f, 360f), s.coerceIn(0f, 1f), v.coerceIn(0f, 1f))).toLong() and 0xFFFFFFFFL

fun argbHex(v: Long): String = "#%06X".format(v and 0xFFFFFFL)

/** Interpreta "#RRGGBB", "RRGGBB" ou "#AARRGGBB"; null se inválido. [alpha] vale quando não há alfa no texto. */
fun parseHex(text: String, alpha: Int): Long? {
    val t = text.trim().removePrefix("#")
    if (!t.matches(Regex("[0-9a-fA-F]{6}|[0-9a-fA-F]{8}"))) return null
    val n = t.toLong(16)
    return if (t.length == 6) (alpha.toLong() shl 24) or n else n
}

/**
 * Campo de cor: toque na amostra para abrir os controles (matiz, saturação, brilho e hexadecimal).
 * O alfa original da cor é preservado (o editor não mexe em transparência por aqui).
 */
@Composable
fun ColorField(label: String, value: Long, onChange: (Long) -> Unit) {
    val cs = MaterialTheme.colorScheme
    var open by remember { mutableStateOf(false) }
    val alpha = ((value shr 24) and 0xFF).toInt()
    val init = remember { FloatArray(3).also { android.graphics.Color.colorToHSV(value.toInt(), it) } }
    var h by remember { mutableFloatStateOf(init[0]) }
    var s by remember { mutableFloatStateOf(init[1]) }
    var v by remember { mutableFloatStateOf(init[2]) }
    var hex by remember { mutableStateOf(argbHex(value)) }

    // mudança vinda de fora (hex digitado, outro controle): ressincroniza sem perder o matiz quando a cor não mudou de fato
    LaunchedEffect(value) {
        if (hsvToArgb(h, s, v, alpha) != value) {
            val a = FloatArray(3); android.graphics.Color.colorToHSV(value.toInt(), a); h = a[0]; s = a[1]; v = a[2]
        }
        if (parseHex(hex, alpha) != value) hex = argbHex(value)
    }
    fun push() { val c = hsvToArgb(h, s, v, alpha); hex = argbHex(c); onChange(c) }

    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable { open = !open }.padding(vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(32.dp).clip(RoundedCornerShape(10.dp)).background(Color(value.toInt()))
                .border(1.dp, cs.outline, RoundedCornerShape(10.dp)))
            Spacer(Modifier.width(10.dp))
            Text(label.tr(), Modifier.weight(1f))
            Text(argbHex(value), color = cs.onSurface.copy(alpha = 0.6f), style = MaterialTheme.typography.bodySmall)
        }
        if (open) {
            Text("Matiz".tr(), style = MaterialTheme.typography.labelSmall)
            Slider(h, { h = it; push() }, valueRange = 0f..360f)
            Text("Saturação".tr(), style = MaterialTheme.typography.labelSmall)
            Slider(s, { s = it; push() }, valueRange = 0f..1f)
            Text("Brilho".tr(), style = MaterialTheme.typography.labelSmall)
            Slider(v, { v = it; push() }, valueRange = 0f..1f)
            OutlinedTextField(hex, { t -> hex = t.take(9); parseHex(t, alpha)?.let { onChange(it) } }, singleLine = true,
                modifier = Modifier.fillMaxWidth(), label = { Text("Hexadecimal".tr()) })
        }
    }
}

/** Slider de inteiro com rótulo e valor atual. */
@Composable
fun NumSlider(label: String, value: Int, range: IntRange, onChange: (Int) -> Unit) {
    Column(Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth()) {
            Text(label.tr(), Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
            Text(value.toString(), color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodyMedium)
        }
        Slider(value.toFloat(), { onChange(Math.round(it).coerceIn(range.first, range.last)) },
            valueRange = range.first.toFloat()..range.last.toFloat(), steps = (range.last - range.first - 1).coerceIn(0, 200))
    }
}

/** Linha com texto e interruptor. */
@Composable
fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label.tr(), Modifier.weight(1f))
        Switch(checked, onChange)
    }
}

package com.example.materialkeyboard.updates

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.core.content.FileProvider
import androidx.core.content.pm.PackageInfoCompat
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest

class UpdateException(msg: String) : Exception(msg)

/** Baixa o APK para o cache (validando tamanho, SHA-256 e pacote) e abre o instalador do Android. */
object ApkInstaller {
    private fun dir(ctx: Context) = File(ctx.cacheDir, "updates")

    /** Bloqueante. [onProgress] recebe 0f..1f. Lança [UpdateException] com mensagem em português. */
    fun download(ctx: Context, u: AppUpdate, onProgress: (Float) -> Unit): File {
        val d = dir(ctx); d.mkdirs(); d.listFiles()?.forEach { it.delete() }
        val out = File(d, "MaterialKeyboard-${u.versionCode}.apk")
        try {
            val c = URL(u.apkUrl).openConnection() as HttpURLConnection
            try {
                c.connectTimeout = 15_000; c.readTimeout = 30_000
                if (c.responseCode != 200) throw UpdateException("Não foi possível baixar a atualização.")
                val total = c.contentLengthLong.takeIf { it > 0 } ?: u.sizeBytes
                if (total > UpdatesConfig.MAX_APK_BYTES) throw UpdateException("Não foi possível baixar a atualização.")
                val sha = MessageDigest.getInstance("SHA-256")
                var done = 0L; var last = -1
                c.inputStream.use { ins -> out.outputStream().use { os ->
                    val buf = ByteArray(32 * 1024)
                    while (true) {
                        val n = ins.read(buf); if (n < 0) break
                        done += n
                        if (done > UpdatesConfig.MAX_APK_BYTES) throw UpdateException("Não foi possível baixar a atualização.")
                        os.write(buf, 0, n); sha.update(buf, 0, n)
                        if (total > 0) { val p = (done * 100 / total).toInt(); if (p != last) { last = p; onProgress(p / 100f) } }
                    }
                } }
                if (u.sha256.isNotEmpty() && sha.digest().joinToString("") { "%02x".format(it) } != u.sha256)
                    throw UpdateException("O arquivo baixado está corrompido.")
            } finally { c.disconnect() }
            val info = ctx.packageManager.getPackageArchiveInfo(out.absolutePath, 0)
            if (info == null || info.packageName != ctx.packageName || PackageInfoCompat.getLongVersionCode(info) < UpdateChecker.currentCode(ctx))
                throw UpdateException("O arquivo baixado não é uma atualização válida do Material Keyboard.")
            onProgress(1f)
            return out
        } catch (e: UpdateException) { out.delete(); throw e }
        catch (e: java.io.IOException) { out.delete(); throw UpdateException("Falha de rede.") }
    }

    /** false = falta a permissão "instalar apps desconhecidos": abrimos a tela certa e o usuário toca em Instalar de novo. */
    fun install(ctx: Context, apk: File): Boolean {
        if (!ctx.packageManager.canRequestPackageInstalls()) {
            ctx.startActivity(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:${ctx.packageName}"))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            return false
        }
        val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.clipfiles", apk)
        ctx.startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(uri, "application/vnd.android.package-archive")
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK))
        return true
    }
}

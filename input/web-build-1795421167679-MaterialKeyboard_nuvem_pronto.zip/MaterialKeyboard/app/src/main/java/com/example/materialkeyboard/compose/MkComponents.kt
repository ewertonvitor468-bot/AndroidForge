package com.example.materialkeyboard.compose

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.selection.toggleable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.annotation.DrawableRes
import androidx.compose.material3.Icon
import androidx.compose.material3.LocalContentColor
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.material3.MaterialTheme
import androidx.compose.ui.res.painterResource
import com.example.materialkeyboard.R
import com.example.materialkeyboard.tr
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.lerp
import androidx.compose.ui.unit.IntSize

/*
 * Componentes Expressive reutilizáveis do teclado. Todos:
 *  - leem cores/formas/tipografia do tema ([MkTheme]) e as molas de [Mk.motion];
 *  - mudam de FORMA ao pressionar/selecionar (a assinatura do Material 3 Expressive) e fazem "mola" de escala;
 *  - leem o estado animado só na fase de desenho (graphicsLayer/drawBehind), sem recompor a cada quadro.
 */

private val Pill = 28.dp
private val Squircle = 12.dp

enum class MkButtonStyle { Filled, Tonal, Outlined }

/** Botão: pílula que vira "quadrado arredondado" ao pressionar. */
@Composable
fun MkButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    style: MkButtonStyle = MkButtonStyle.Filled,
    enabled: Boolean = true
) {
    val cs = MaterialTheme.colorScheme
    val motion = Mk.motion
    val source = remember { MutableInteractionSource() }
    val pressed by source.collectIsPressedAsState()
    val corner = animateDpAsState(if (pressed) Squircle else Pill, motion.spatial(MkSpeed.Fast), label = "mkBtnCorner")
    val scale = animateFloatAsState(if (pressed) 0.95f else 1f, motion.spatial(MkSpeed.Fast), label = "mkBtnScale")
    val container = when (style) {
        MkButtonStyle.Filled -> cs.primary
        MkButtonStyle.Tonal -> cs.secondaryContainer
        MkButtonStyle.Outlined -> Color.Transparent
    }
    val content = when (style) {
        MkButtonStyle.Filled -> cs.onPrimary
        MkButtonStyle.Tonal -> cs.onSecondaryContainer
        MkButtonStyle.Outlined -> cs.primary
    }
    val outline = cs.outline
    Box(
        modifier = modifier
            .defaultMinSize(minHeight = 40.dp)
            .graphicsLayer {
                scaleX = scale.value; scaleY = scale.value
                shape = RoundedCornerShape(corner.value.coerceAtLeast(0.dp))
                clip = true
                alpha = if (enabled) 1f else 0.38f
            }
            .background(container)
            .drawBehind {
                if (style == MkButtonStyle.Outlined) {
                    val w = 1.dp.toPx()
                    drawRoundRect(
                        color = outline,
                        topLeft = Offset(w / 2f, w / 2f),
                        size = Size(size.width - w, size.height - w),
                        cornerRadius = CornerRadius(corner.value.coerceAtLeast(0.dp).toPx()),
                        style = Stroke(width = w)
                    )
                }
            }
            .clickable(interactionSource = source, indication = null, enabled = enabled, role = Role.Button, onClick = onClick)
            .padding(horizontal = 20.dp, vertical = 10.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = content, style = MaterialTheme.typography.labelLarge, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

/** Botão de alternar: pílula quando desligado, "quadrado arredondado" colorido quando ligado. */
@Composable
fun MkToggleButton(
    text: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    val cs = MaterialTheme.colorScheme
    val motion = Mk.motion
    val source = remember { MutableInteractionSource() }
    val pressed by source.collectIsPressedAsState()
    val target = if (pressed) 8.dp else if (checked) 14.dp else Pill
    val corner = animateDpAsState(target, motion.spatial(MkSpeed.Fast), label = "mkTogCorner")
    val scale = animateFloatAsState(if (pressed) 0.95f else 1f, motion.spatial(MkSpeed.Fast), label = "mkTogScale")
    val container by animateColorAsState(
        if (checked) cs.primary else cs.secondaryContainer, motion.effects(), label = "mkTogBg")
    val content by animateColorAsState(
        if (checked) cs.onPrimary else cs.onSecondaryContainer, motion.effects(), label = "mkTogFg")
    Box(
        modifier = modifier
            .defaultMinSize(minHeight = 40.dp)
            .graphicsLayer {
                scaleX = scale.value; scaleY = scale.value
                shape = RoundedCornerShape(corner.value.coerceAtLeast(0.dp))
                clip = true
            }
            .drawBehind { drawRect(container) }
            .toggleable(value = checked, interactionSource = source, indication = null,
                role = Role.Switch, onValueChange = onCheckedChange)
            .padding(horizontal = 18.dp, vertical = 10.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = content, style = MaterialTheme.typography.labelLarge, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

/**
 * Botão de ícone (40dp) com morfing REAL (graphics-shapes): círculo -> quadrado arredondado ao pressionar,
 * círculo -> cookie quando [selected]. Aceita [tonal] = false para um botão sem fundo (só o ícone).
 */
@Composable
fun MkIconButton(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    selected: Boolean = false,
    tonal: Boolean = true,
    size: Dp = 40.dp,
    content: @Composable () -> Unit
) {
    val cs = MaterialTheme.colorScheme
    val motion = Mk.motion
    val source = remember { MutableInteractionSource() }
    val pressed by source.collectIsPressedAsState()
    val progress = animateFloatAsState(
        if (pressed || selected) 1f else 0f, motion.spatial(MkSpeed.Fast), label = "mkIcoMorph")
    val scale = animateFloatAsState(if (pressed) 0.92f else 1f, motion.spatial(MkSpeed.Fast), label = "mkIcoScale")
    val bg by animateColorAsState(
        if (selected) cs.primary else if (tonal) cs.secondaryContainer else Color.Transparent,
        motion.effects(), label = "mkIcoBg")
    val morph = if (selected && !pressed) MkMorphs.circleToCookie else MkMorphs.circleToSquircle
    val fg = if (selected) cs.onPrimary else if (tonal) cs.onSecondaryContainer else cs.onSurfaceVariant
    Box(
        modifier = modifier
            .size(size)
            .graphicsLayer {
                scaleX = scale.value; scaleY = scale.value
                shape = MorphShape(morph, progress.value)
                clip = true
            }
            .drawBehind { drawRect(bg) }
            .clickable(interactionSource = source, indication = null, role = Role.Button, onClick = onClick),
        contentAlignment = Alignment.Center
    ) { CompositionLocalProvider(LocalContentColor provides fg) { content() } }
}

/** Ícone vetorial do projeto (res/drawable) tingido pelo tema: sem Canvas, sem dependência de material-icons. */
@Composable
fun MkIcon(@DrawableRes res: Int, description: String?, tint: Color = LocalContentColor.current, size: Dp = 22.dp) {
    Icon(painterResource(res), contentDescription = description, tint = tint, modifier = Modifier.size(size))
}

/**
 * Grupo de botões conectados (segmentado): o item selecionado vira pílula e ganha mais espaço,
 * os vizinhos encolhem — tudo com molas spatial.
 */
@Composable
fun MkButtonGroup(
    options: List<String>,
    selected: Int,
    onSelect: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val cs = MaterialTheme.colorScheme
    val motion = Mk.motion
    Row(modifier = modifier, horizontalArrangement = Arrangement.spacedBy(2.dp)) {
        options.forEachIndexed { i, label ->
            val isSel = i == selected
            val source = remember { MutableInteractionSource() }
            val pressed by source.collectIsPressedAsState()
            val weight by animateFloatAsState(if (isSel) 1.35f else 1f, motion.spatial(), label = "mkGrpW")
            val pill = animateFloatAsState(if (isSel) 1f else 0f, motion.spatial(MkSpeed.Fast), label = "mkGrpPill")
            val scale = animateFloatAsState(if (pressed) 0.96f else 1f, motion.spatial(MkSpeed.Fast), label = "mkGrpScale")
            val bg by animateColorAsState(if (isSel) cs.primary else cs.secondaryContainer, motion.effects(), label = "mkGrpBg")
            val fg by animateColorAsState(if (isSel) cs.onPrimary else cs.onSecondaryContainer, motion.effects(), label = "mkGrpFg")
            val first = i == 0
            val last = i == options.lastIndex
            Box(
                modifier = Modifier
                    .weight(weight.coerceAtLeast(0.1f))
                    .defaultMinSize(minHeight = 36.dp)
                    .graphicsLayer {
                        scaleX = scale.value; scaleY = scale.value
                        // cantos externos sempre em pílula; os internos "abrem" quando selecionado
                        val inner = lerp(6.dp, Pill, pill.value.coerceIn(0f, 1f))
                        val start = if (first) Pill else inner
                        val end = if (last) Pill else inner
                        shape = RoundedCornerShape(topStart = start, topEnd = end, bottomEnd = end, bottomStart = start)
                        clip = true
                    }
                    .drawBehind { drawRect(bg) }
                    .clickable(interactionSource = source, indication = null, role = Role.Tab) { onSelect(i) }
                    .padding(horizontal = 8.dp, vertical = 8.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(label, color = fg, style = MaterialTheme.typography.labelMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
    }
}

/** Seção expansível: o conteúdo abre/fecha com mola e a seta gira. */
@Composable
fun MkExpandableSection(
    title: String,
    modifier: Modifier = Modifier,
    initiallyExpanded: Boolean = false,
    content: @Composable ColumnScope.() -> Unit
) {
    val cs = MaterialTheme.colorScheme
    val motion = Mk.motion
    var expanded by remember { mutableStateOf(initiallyExpanded) }
    val rotation = animateFloatAsState(if (expanded) 180f else 0f, motion.spatial(MkSpeed.Fast), label = "mkChevron")
    val arrow = cs.onSurfaceVariant
    Column(
        modifier = modifier
            .fillMaxWidth()
            .graphicsLayer { shape = RoundedCornerShape(20.dp); clip = true }
            .background(cs.surfaceContainerHigh)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clickable(indication = null, interactionSource = remember { MutableInteractionSource() },
                    role = Role.Button) { expanded = !expanded }
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(title, color = cs.onSurface, style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f))
            Icon(
                painterResource(R.drawable.ic_expand), contentDescription = null, tint = arrow,
                modifier = Modifier.size(20.dp).graphicsLayer { rotationZ = rotation.value }
            )
        }
        AnimatedVisibility(
            visible = expanded,
            enter = expandVertically(motion.spatial<IntSize>()) + fadeIn(motion.effects()),
            exit = shrinkVertically(motion.spatial<IntSize>()) + fadeOut(motion.effects())
        ) {
            Column(Modifier.padding(start = 16.dp, end = 16.dp, bottom = 14.dp), content = content)
        }
    }
}

/** Item de menu: aparece em cascata (mola) e, quando selecionado, vira pílula colorida com "✓". */
@Composable
fun MkMenuItem(
    index: Int,
    label: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val cs = MaterialTheme.colorScheme
    val motion = Mk.motion
    val appear = remember { Animatable(if (motion.enabled) 0f else 1f) }
    LaunchedEffect(Unit) {
        if (motion.enabled) {
            repeat(index * 2) { withFrameNanos { } }       // cascata: ~2 quadros por item
            appear.animateTo(1f, motion.spatial())
        }
    }
    val source = remember { MutableInteractionSource() }
    val pressed by source.collectIsPressedAsState()
    val corner = animateDpAsState(if (pressed) 10.dp else if (selected) Pill else 16.dp, motion.spatial(MkSpeed.Fast), label = "mkMenuCorner")
    val bg by animateColorAsState(if (selected) cs.secondaryContainer else Color.Transparent, motion.effects(), label = "mkMenuBg")
    Row(
        modifier = modifier
            .fillMaxWidth()
            .graphicsLayer {
                val a = appear.value
                alpha = a.coerceIn(0f, 1f)
                translationY = (1f - a) * 14.dp.toPx()
                shape = RoundedCornerShape(corner.value.coerceAtLeast(0.dp))
                clip = true
            }
            .drawBehind { drawRect(bg) }
            .clickable(interactionSource = source, indication = null, role = Role.Button, onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, color = if (selected) cs.onSecondaryContainer else cs.onSurface,
            style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
        if (selected) Text("✓", color = cs.onSecondaryContainer, style = MaterialTheme.typography.titleSmall)
    }
}

/** Contêiner de menu (lista de [MkMenuItem]). */
@Composable
fun MkMenu(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    val cs = MaterialTheme.colorScheme
    Column(
        modifier = modifier
            .fillMaxWidth()
            .graphicsLayer { shape = RoundedCornerShape(24.dp); clip = true }
            .background(cs.surfaceContainerHigh)
            .padding(6.dp),
        content = content
    )
}

/** Seta "voltar" (vetor do projeto, tingido pelo tema). */
@Composable
fun MkBackArrow(color: Color = LocalContentColor.current) {
    Icon(painterResource(R.drawable.ic_back), contentDescription = "Voltar ao teclado".tr(), tint = color, modifier = Modifier.size(22.dp))
}

/** Espaçador horizontal curto. */
@Composable
fun MkGap(width: Dp = 8.dp) { Spacer(Modifier.width(width)) }

/**
 * Indicador de carregamento Expressive: uma forma que gira e faz morfing (cookie <-> flor).
 * Anima só enquanto está na tela; use apenas em esperas curtas (ex.: baixar modelo de tradução).
 */
@Composable
fun MkLoadingIndicator(
    modifier: Modifier = Modifier,
    size: Dp = 48.dp,
    color: Color = MaterialTheme.colorScheme.primary
) {
    val t = rememberInfiniteTransition(label = "mkLoading")
    val rot = t.animateFloat(0f, 360f, infiniteRepeatable<Float>(tween<Float>(4200, easing = LinearEasing)), label = "mkLoadRot")
    val p = t.animateFloat(0f, 1f, infiniteRepeatable<Float>(tween<Float>(850, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "mkLoadMorph")
    Box(
        modifier = modifier
            .size(size)
            .graphicsLayer {
                rotationZ = rot.value
                shape = MorphShape(MkMorphs.cookieToFlower, p.value)
                clip = true
            }
            .background(color)
    )
}

package com.example.materialkeyboard.compose

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.materialkeyboard.PreviewKeyboard
import com.example.materialkeyboard.Prefs
import com.example.materialkeyboard.R
import com.example.materialkeyboard.SoundBank
import com.example.materialkeyboard.tr

private val bounce = spring<Float>(Spring.DampingRatioMediumBouncy, Spring.StiffnessMedium)

/**
 * Sons do teclado: toque no cartão para ESCOLHER o pacote, no ▶ para TESTAR (sem escolher).
 * [forKey] = -1: som geral; senão, slot da tecla (com a opção "Padrão").
 * [types]: pacotes embutidos + meus sons. [onTest] toca a prévia; [onPick] salva a escolha.
 */
@Composable
fun SoundsScreen(prefs: Prefs, forKey: Int, types: List<Int>, onTest: (Int) -> Unit, onPick: (Int) -> Unit) = PageHost(prefs) {
    val cs = MaterialTheme.colorScheme
    var cur by remember { mutableIntStateOf(if (forKey < 0) prefs.soundType else prefs.keySounds[forKey]) }
    var testing by remember { mutableIntStateOf(-2) }
    val ctx = LocalContext.current
    Enter(0) {
        AndroidView(factory = { PreviewKeyboard(it, prefs) }, modifier = Modifier.fillMaxWidth())
    }
    MkNote(if (forKey < 0) "Toque nas teclas acima para ouvir o som atual.".tr()
           else (SoundBank.Slot.NAMES[forKey].tr() + " · " + "toque na tecla acima para ouvir.".tr()))
    val items = (if (forKey >= 0) listOf(-1) else emptyList()) + types
    MkCard("Pacotes de som".tr()) {
        items.forEachIndexed { i, t ->
            val on = cur == t
            val src = remember { MutableInteractionSource() }
            val pressed by src.collectIsPressedAsState()
            val sc by animateFloatAsState(if (pressed) 0.97f else 1f, bounce, label = "snd$i")
            val bg by animateColorAsState(if (on) cs.primary.copy(alpha = 0.16f) else androidx.compose.ui.graphics.Color.Transparent, label = "sb$i")
            val ring by animateColorAsState(if (on) cs.primary else cs.onSurface.copy(alpha = 0.08f), label = "sr$i")
            Row(
                Modifier.fillMaxWidth().padding(vertical = 4.dp).scale(sc).clip(RoundedCornerShape(20.dp)).background(bg)
                    .border(1.dp, ring, RoundedCornerShape(20.dp))
                    .clickable(interactionSource = src, indication = null) { cur = t; onPick(t) }
                    .padding(start = 14.dp, top = 8.dp, bottom = 8.dp, end = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(Modifier.size(22.dp).clip(CircleShape).background(if (on) cs.primary else cs.onSurface.copy(alpha = 0.12f)), contentAlignment = Alignment.Center) {
                    if (on) Icon(painterResource(R.drawable.ic_check), null, tint = cs.onPrimary, modifier = Modifier.size(15.dp))
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(if (t < 0) "Padrão (som geral)".tr() else SoundBank.label(t), color = cs.onSurface,
                        fontWeight = if (on) FontWeight.Bold else FontWeight.Medium, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    if (t >= 0 && t < SoundBank.CUSTOM) Text(L2("Pacote %d").format(t + 1), color = cs.onSurface.copy(alpha = 0.55f), style = MaterialTheme.typography.bodySmall)
                }
                if (t >= 0) {
                    val tb by animateColorAsState(if (testing == t) cs.primary else cs.primary.copy(alpha = 0.14f), label = "tb$i")
                    Box(Modifier.size(44.dp).clip(CircleShape).background(tb).clickable { testing = t; onTest(t) }, contentAlignment = Alignment.Center) {
                        Icon(painterResource(R.drawable.ic_play), "Testar".tr(), tint = if (testing == t) cs.onPrimary else cs.primary, modifier = Modifier.size(22.dp))
                    }
                }
            }
        }
    }
}

private fun L2(s: String) = s.tr()

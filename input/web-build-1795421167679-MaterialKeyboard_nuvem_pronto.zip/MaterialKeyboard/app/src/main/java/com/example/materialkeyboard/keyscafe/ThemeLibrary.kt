package com.example.materialkeyboard.keyscafe

import android.content.Context
import androidx.core.content.pm.PackageInfoCompat
import com.example.materialkeyboard.Patch
import com.example.materialkeyboard.Patches
import com.example.materialkeyboard.Prefs
import org.json.JSONObject
import java.io.File
import java.util.concurrent.ConcurrentHashMap

sealed class InstallResult {
    data class Ok(val spec: ThemeSpec, val warnings: List<String>, val replaced: Boolean) : InstallResult()
    data class Fail(val reason: String) : InstallResult()
}

/**
 * Biblioteca local do Keys Café: temas instalados (do ThemeBoard, de arquivo ou criados pela pessoa).
 * Fica em filesDir/keyscafe/<id>/ { theme.json, preview.webp, assets/, meta.json }.
 * Funciona 100% offline e NÃO conhece o Supabase: o ThemeBoard só entrega um pacote e chama [install].
 *
 * Os temas instalados viram [Patch] e são achados por [Patches.byId], então o teclado os desenha
 * exatamente como desenha os temas embutidos.
 *
 * Observação: instalar por cima de um tema que está ativo troca as cores na biblioteca, mas só aparece
 * no teclado depois de [apply] de novo (a tela deve chamar apply após um update).
 */
object ThemeLibrary {
    private const val DIR = "keyscafe"
    private const val MAX_THEMES = 100

    private val lock = Any()
    private var root: File? = null
    private val specs = LinkedHashMap<String, ThemeSpec>()          // protegido por lock
    private val patches = ConcurrentHashMap<String, Patch>()        // leitura sem lock (caminho de desenho)
    @Volatile private var appVersion = Int.MAX_VALUE
    /** versionCode do app em execução (usado para respeitar o minAppVersion dos temas). */
    val appVersionCode: Int get() = appVersion

    /** Chamado uma vez, cedo (no init do Prefs). Lê as pastas; são poucos arquivos pequenos. */
    fun attach(ctx: Context) {
        synchronized(lock) {
            if (root != null) return
            val app = ctx.applicationContext
            appVersion = try {
                PackageInfoCompat.getLongVersionCode(app.packageManager.getPackageInfo(app.packageName, 0)).toInt()
            } catch (_: Exception) { Int.MAX_VALUE }
            val r = File(app.filesDir, DIR)
            r.mkdirs()
            root = r
            loadAll(r)
        }
    }

    private fun loadAll(r: File) {
        val dirs = r.listFiles()?.toList() ?: return
        for (d in dirs.sortedBy { it.name }) {
            if (!d.isDirectory) continue
            if (d.name.startsWith(".")) { d.deleteRecursively(); continue }     // sobras de instalação interrompida
            val f = File(d, "theme.json")
            if (!f.isFile || f.length() > SpecLimits.JSON_MAX_CHARS * 3L) continue
            val parsed = try { ThemeSpecJson.parse(f.readText(Charsets.UTF_8), appVersion) } catch (_: Exception) { null }
            if (parsed is SpecParse.Ok && parsed.spec.id == d.name && !isBuiltIn(parsed.spec.id)) register(parsed.spec)
        }
    }

    private fun register(spec: ThemeSpec) {
        specs[spec.id] = spec
        patches[spec.id] = ThemeSpecMapper.toPatch(spec)
    }

    fun isBuiltIn(id: String): Boolean = Patches.ALL.any { it.id == id } || Patches.CLASSIC_LIST.any { it.id == id }

    fun list(): List<ThemeSpec> = synchronized(lock) { specs.values.toList() }
    fun get(id: String): ThemeSpec? = synchronized(lock) { specs[id] }

    /** Temas instalados como [Patch], na ordem de instalação (para a lista da tela de Patches). */
    fun allPatches(): List<Patch> = synchronized(lock) { specs.keys.mapNotNull { patches[it] } }

    /** Lê um pacote já checando se o app é novo o bastante para o tema (min_app_version). */
    fun readPackage(input: java.io.InputStream): PackageRead = ThemePackage.read(input, appVersion)

    /** Id novo e livre para um tema criado no aparelho: "meu-<nome>-<4 hex>". */
    fun newLocalId(name: String): String {
        val base = java.text.Normalizer.normalize(name, java.text.Normalizer.Form.NFD)
            .replace(Regex("\\p{M}+"), "")
            .lowercase()
            .replace(Regex("[^a-z0-9]+"), "-")
            .trim('-')
            .take(24)
            .trim('-')
            .ifEmpty { "tema" }
        var id: String
        do {
            id = "meu-" + base + "-" + Integer.toHexString(kotlin.random.Random.nextInt(0x1000, 0xFFFF))
        } while (isBuiltIn(id) || get(id) != null)
        return id
    }

    /** Usado por [Patches.byId]. Sem lock: é chamado ao desenhar o teclado. */
    fun patchById(id: String): Patch? = if (id.isEmpty()) null else patches[id]

    /** Arquivo de um asset do tema (por exemplo a imagem de fundo), ou null se não existir. */
    fun assetFile(id: String, asset: String): File? {
        val r = root ?: return null
        if (!Regex("^assets/[A-Za-z0-9._-]{1,64}$").matches(asset) || asset.contains("..")) return null
        if (get(id) == null) return null
        return File(r, "$id/$asset").takeIf { it.isFile }
    }

    fun previewFile(id: String): File? {
        val r = root ?: return null
        if (get(id) == null) return null
        return File(r, "$id/preview.webp").takeIf { it.isFile }
    }

    // ---------------------------------------------------------------- instalar

    /** Instala um pacote JÁ validado por [ThemePackage.read]. [source]: "themeboard:<theme_id>:<versão>", "file", "local"... */
    fun install(pkg: PackageRead.Ok, source: String = "file"): InstallResult {
        val r = root ?: return InstallResult.Fail("A biblioteca de temas ainda não foi iniciada.")
        val spec = pkg.spec
        if (isBuiltIn(spec.id)) return InstallResult.Fail("Este id é reservado a um tema do app.")
        return synchronized(lock) {
            val replaced = specs.containsKey(spec.id)
            if (!replaced && specs.size >= MAX_THEMES) {
                return@synchronized InstallResult.Fail("Limite de $MAX_THEMES temas na biblioteca.")
            }
            val tmp = File(r, ".${spec.id}.tmp")
            val bak = File(r, ".${spec.id}.bak")
            val dst = File(r, spec.id)
            try {
                tmp.deleteRecursively(); bak.deleteRecursively()
                tmp.mkdirs()
                File(tmp, "theme.json").writeText(ThemeSpecJson.toJson(spec), Charsets.UTF_8)
                pkg.preview?.let { File(tmp, "preview.webp").writeBytes(it) }
                if (pkg.assets.isNotEmpty()) {
                    File(tmp, "assets").mkdirs()
                    for ((name, bytes) in pkg.assets) File(tmp, name).writeBytes(bytes)
                }
                val meta = JSONObject()
                meta.put("source", source); meta.put("sha256", pkg.sha256); meta.put("installed_at", System.currentTimeMillis())
                File(tmp, "meta.json").writeText(meta.toString(), Charsets.UTF_8)

                val hadOld = dst.exists()
                if (hadOld && !dst.renameTo(bak)) {
                    tmp.deleteRecursively()
                    return@synchronized InstallResult.Fail("Não foi possível salvar o tema.")
                }
                if (!tmp.renameTo(dst)) {
                    tmp.deleteRecursively()
                    if (hadOld) bak.renameTo(dst)
                    return@synchronized InstallResult.Fail("Não foi possível salvar o tema.")
                }
                bak.deleteRecursively()
            } catch (_: Exception) {
                tmp.deleteRecursively()
                return@synchronized InstallResult.Fail("Não foi possível salvar o tema.")
            }
            register(spec)
            InstallResult.Ok(spec, pkg.warnings, replaced)
        }
    }

    /** Guarda um tema criado no aparelho (editor ou [ThemeSpecMapper.capture]). Revalida tudo antes. */
    fun saveLocal(spec: ThemeSpec, preview: ByteArray? = null, assets: Map<String, ByteArray> = emptyMap()): InstallResult {
        return when (val built = ThemePackage.build(spec, preview, assets)) {
            is PackageBuild.Fail -> InstallResult.Fail(built.reason)
            is PackageBuild.Ok -> when (val read = ThemePackage.read(built.bytes.inputStream(), appVersion)) {
                is PackageRead.Fail -> InstallResult.Fail(read.reason)
                is PackageRead.Ok -> install(read, "local")
            }
        }
    }

    // ---------------------------------------------------------------- usar, remover, exportar

    /** Aplica o tema (um único edit/apply no Prefs, com restauração pelo "Remover patch"). */
    fun apply(prefs: Prefs, id: String): Boolean {
        val s = get(id) ?: return false
        Patches.apply(prefs, ThemeSpecMapper.toPatch(s))
        return true
    }

    /** Remove o tema. Se ele estiver ativo, volta ao visual anterior antes de apagar. */
    fun remove(prefs: Prefs, id: String): Boolean {
        val r = root ?: return false
        if (get(id) == null) return false
        if (prefs.patch == id) prefs.removePatch()
        synchronized(lock) {
            File(r, id).deleteRecursively()
            specs.remove(id)
            patches.remove(id)
        }
        return true
    }

    /** Gera o .mkt de um tema instalado (para publicar no ThemeBoard ou compartilhar). */
    fun export(id: String, author: String? = null, description: String? = null): PackageBuild {
        val r = root ?: return PackageBuild.Fail("A biblioteca de temas ainda não foi iniciada.")
        val base = get(id) ?: return PackageBuild.Fail("Tema não encontrado.")
        val spec = base.copy(author = author ?: base.author, description = description ?: base.description)
        val dir = File(r, id)
        val preview = File(dir, "preview.webp").takeIf { it.isFile }?.readBytes()
        val assets = LinkedHashMap<String, ByteArray>()
        spec.image?.let { im -> File(dir, im.asset).takeIf { it.isFile }?.let { assets[im.asset] = it.readBytes() } }
        return ThemePackage.build(spec, preview, assets)
    }
}

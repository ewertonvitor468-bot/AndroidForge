package com.example.materialkeyboard

import android.content.Context
import android.graphics.BitmapFactory
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.Executors
import java.io.InputStream
import java.security.MessageDigest

/**
 * Histórico de clipboard: texto e imagens (prints, figurinhas) em qualidade original, até 50 itens no total, sem duplicar
 * texto nem imagem repetidos. Ao passar do limite, o item mais antigo sai (e o arquivo da imagem, se for o caso,
 * é apagado). Os itens ficam até o usuário excluir.
 * Só ficam de fora cópias marcadas como sensíveis pelo sistema ou que pareçam senha/cartão/chave/e-mail
 * (ver [looksSensitive]; o filtro de verdade roda em KeyboardService.captureClip()).
 * Toda leitura/gravação em disco, e toda decodificação de imagem, roda fora da thread principal.
 */
class ClipboardStore private constructor(ctx: Context) {

    /** Um item do histórico: texto puro ou caminho de um arquivo de imagem já salvo pelo app. */
    sealed class Entry {
        data class Text(val text: String) : Entry()
        data class Image(val path: String) : Entry()
    }

    private val appCtx = ctx.applicationContext
    private val sp = appCtx.getSharedPreferences("clipboard_history", Context.MODE_PRIVATE)
    private val imagesDir = File(appCtx.filesDir, "clip_images")   // filesDir: o sistema não apaga como faz com o cache.apply { mkdirs() }
    private val io = Executors.newSingleThreadExecutor()
    private val items = ArrayList<Entry>()
    @Volatile var onChange: (() -> Unit)? = null

    init {
        try {
            val arr = JSONArray(sp.getString("items", "[]"))
            for (i in 0 until arr.length()) {
                when (val v = arr.opt(i)) {
                    is String -> if (v.isNotBlank()) items.add(Entry.Text(v))   // formato antigo (só texto)
                    is JSONObject -> {
                        if (v.optString("type") == "image") {
                            val f = File(v.optString("path"))
                            if (f.exists()) items.add(Entry.Image(f.absolutePath))
                        } else {
                            val t = v.optString("text")
                            if (t.isNotBlank()) items.add(Entry.Text(t))
                        }
                    }
                    else -> {}
                }
            }
        } catch (_: Exception) { }
        pruneOrphanImages()
    }

    /** Assinatura da última cópia vista: evita readicionar, ao abrir o teclado, um item que o usuário excluiu. */
    var lastSig: String?
        get() = sp.getString("last_sig", null)
        set(v) { sp.edit().putString("last_sig", v).apply() }

    @Synchronized fun all(): List<Entry> = items.toList()

    @Synchronized fun addText(text: String): Boolean {
        val t = text.trim()
        if (t.isEmpty() || t.length > MAX_LEN) return false
        items.removeAll { it is Entry.Text && it.text == t }
        items.add(0, Entry.Text(t))
        trimAndPersist()
        return true
    }

    /**
     * Guarda uma imagem (bytes já lidos fora da thread principal) como arquivo próprio do app, com os
     * bytes ORIGINAIS (sem redimensionar nem recomprimir). O nome vem do hash do conteúdo, então a mesma
     * imagem copiada de novo não duplica: só sobe para o topo. Chamar sempre fora da thread principal.
     */
    @Synchronized fun addImage(bytes: ByteArray): Boolean {
        if (bytes.isEmpty() || bytes.size > MAX_IMAGE_BYTES) return false
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o)
        if (o.outWidth <= 0 || o.outHeight <= 0) return false
        val ext = when (o.outMimeType) {
            "image/png" -> "png"; "image/jpeg" -> "jpg"; "image/webp" -> "webp"; "image/gif" -> "gif"
            else -> return false
        }
        val hash = MessageDigest.getInstance("SHA-256").digest(bytes).take(8).joinToString("") { "%02x".format(it) }
        val f = File(imagesDir, "clip_$hash.$ext")
        return try {
            if (!f.exists()) FileOutputStream(f).use { it.write(bytes) }
            items.removeAll { it is Entry.Image && it.path == f.absolutePath }
            items.add(0, Entry.Image(f.absolutePath))
            trimAndPersist()
            true
        } catch (_: Exception) {
            try { f.delete() } catch (_: Exception) { }
            false
        }
    }

    @Synchronized fun remove(entry: Entry) {
        if (items.remove(entry)) { deleteFileIfImage(entry); persist(); onChange?.invoke() }
    }

    @Synchronized fun clear() {
        items.filterIsInstance<Entry.Image>().forEach { deleteFileIfImage(it) }
        items.clear()
        persist()
        onChange?.invoke()
    }

    private fun deleteFileIfImage(e: Entry) {
        if (e is Entry.Image) io.execute { try { File(e.path).delete() } catch (_: Exception) { } }
    }

    private fun trimAndPersist() {
        while (items.size > MAX_ITEMS) deleteFileIfImage(items.removeAt(items.size - 1))
        persist()
        onChange?.invoke()
    }

    private fun persist() {
        val arr = JSONArray()
        for (e in items) when (e) {
            is Entry.Text -> arr.put(JSONObject().put("type", "text").put("text", e.text))
            is Entry.Image -> arr.put(JSONObject().put("type", "image").put("path", e.path))
        }
        val json = arr.toString()
        io.execute { try { sp.edit().putString("items", json).apply() } catch (_: Exception) { } }
    }

    /** Remove arquivos de imagem "órfãos" (ex.: o app foi encerrado no meio de uma gravação). */
    private fun pruneOrphanImages() {
        io.execute {
            try {
                val kept = items.filterIsInstance<Entry.Image>().map { it.path }.toSet()
                imagesDir.listFiles()?.forEach { f -> if (f.absolutePath !in kept) f.delete() }
            } catch (_: Exception) { }
        }
    }

    companion object {
        const val MAX_ITEMS = 50
        const val MAX_LEN = 50_000
        const val MAX_IMAGE_BYTES = 16 * 1024 * 1024   // 16 MB: além disso, ignora (um print comum fica bem abaixo)

        @Volatile private var inst: ClipboardStore? = null
        fun get(ctx: Context): ClipboardStore =
            inst ?: synchronized(this) { inst ?: ClipboardStore(ctx).also { inst = it } }

        private val card = Regex("^\\d[\\d -]{11,22}\\d$")                          // cartão (13–19 dígitos)
        private val assign = Regex("(senha|password|passwd|token|secret|api[_-]?key|bearer|cvv)\\s*[:=]", RegexOption.IGNORE_CASE)
        private val keyword = Regex("(senha|password|passwd|token|secret|api[_-]?key|bearer|cvv)", RegexOption.IGNORE_CASE)
        private val tokenLike = Regex("^[A-Za-z0-9_+=-]{24,256}$")                  // chave/token colado (sem pontos nem barras: URL não cai aqui)

        /** Só o que realmente parece segredo. Textos comuns (frases, links, e-mails, telefones) sempre entram. */
        fun looksSensitive(t: String): Boolean {
            val s = t.trim()
            if (assign.containsMatchIn(s)) return true
            if (s.length <= 40 && keyword.containsMatchIn(s)) return true
            if (card.matches(s) && s.count { it.isDigit() } in 13..19) return true
            return tokenLike.matches(s) && s.any { it.isDigit() } && s.any { it.isLetter() }
        }

        fun mimeOf(path: String): String = when (path.substringAfterLast('.').lowercase()) {
            "jpg", "jpeg" -> "image/jpeg"; "webp" -> "image/webp"; "gif" -> "image/gif"; else -> "image/png"
        }

        /** Lê até [max] bytes; devolve null se passar (evita estourar memória com imagens enormes). */
        fun readCapped(input: InputStream, max: Int): ByteArray? {
            val out = java.io.ByteArrayOutputStream()
            val buf = ByteArray(16384)
            var total = 0
            while (true) {
                val n = input.read(buf)
                if (n < 0) break
                total += n
                if (total > max) return null
                out.write(buf, 0, n)
            }
            return out.toByteArray()
        }
    }
}

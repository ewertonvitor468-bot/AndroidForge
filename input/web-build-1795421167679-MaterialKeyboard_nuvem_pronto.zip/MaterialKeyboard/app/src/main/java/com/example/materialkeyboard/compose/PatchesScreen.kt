package com.example.materialkeyboard.compose

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.withFrameNanos
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import android.view.View
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.materialkeyboard.BarShapes
import com.example.materialkeyboard.L
import com.example.materialkeyboard.Palette
import com.example.materialkeyboard.Patch
import com.example.materialkeyboard.Patches
import com.example.materialkeyboard.Prefs
import com.example.materialkeyboard.R
import com.example.materialkeyboard.SceneDrawable
import com.example.materialkeyboard.keyscafe.InstallResult
import com.example.materialkeyboard.keyscafe.ThemeLibrary
import com.example.materialkeyboard.keyscafe.ThemeSpec
import com.example.materialkeyboard.keyscafe.ThemeSpecMapper
import com.example.materialkeyboard.tr
import kotlin.math.abs
import kotlin.math.roundToInt

private val patchPop = spring<Float>(Spring.DampingRatioMediumBouncy, Spring.StiffnessMedium)

/** Vira true depois da primeira montagem completa da tela; nas próximas aberturas (mesmo processo) tudo aparece direto. */
private var patchesWarm = false

/** Página "Patches": coleção Keys Café (temas completos: paleta + acabamento). */
@Composable
fun PatchesScreen(prefs: Prefs, onImport: () -> Unit = {}, onExport: (String) -> Unit = {}) = PageHost(prefs) {
    val cs = MaterialTheme.colorScheme
    val appCtx = LocalContext.current
    var tab by remember { mutableIntStateOf(0) }            // 0 Patches, 1 Clássicos, 2 Cenário, 3 Bichinhos, 4 Keys Café, 5 ThemeBoard
    var sel by remember { mutableIntStateOf(0) }            // só na aba Patches: 0 todos, 1..5 categorias, 6 favoritos
    var query by remember { mutableStateOf("") }
    var peek by remember { mutableStateOf<Patch?>(null) }
    var saving by remember { mutableStateOf(false) }
    var removing by remember { mutableStateOf<Patch?>(null) }
    var note by remember { mutableStateOf<String?>(null) }
    var board by remember { mutableStateOf(false) }
    var editor by remember { mutableStateOf(false) }
    var editorStart by remember { mutableStateOf<ThemeSpec?>(null) }   // v54.2: abre o editor já com um tema embutido
    val boardOn = com.example.materialkeyboard.keyscafe.ThemeBoardApi.configured
    val favs = prefs.patchFavs.split(",").filter { it.isNotEmpty() }
    val all = Patches.ALL + Patches.CLASSIC_LIST + ThemeLibrary.allPatches()       // embutidos + clássicos + instalados (ThemeBoard, arquivo, criados aqui)
    val mine = all.filter { it.category == Patches.COMMUNITY }
    val list = (if (sel == 6) all else Patches.ALL).filter { p ->
        (sel == 0 || (sel in 1..5 && p.category == sel - 1) || (sel == 6 && p.id in favs)) &&
            (query.isBlank() || p.name.tr().contains(query.trim(), ignoreCase = true))
    }
    fun applyPatch(p: Patch) { Patches.apply(prefs, p); refresh() }

    // Carregamento em etapas: na primeira abertura os cartões entram 3 por quadro (o app não congela e a barra mostra o avanço real).
    var shown by remember { mutableIntStateOf(if (patchesWarm) Int.MAX_VALUE else 0) }
    LaunchedEffect(list.size) {
        if (shown == Int.MAX_VALUE) return@LaunchedEffect
        while (shown < list.size) { withFrameNanos { }; shown += 3 }
        shown = Int.MAX_VALUE
        patchesWarm = true
    }
    val loading = shown < list.size
    val shownList = if (loading) list.take(shown) else list

    SwipePreview(pal, prefs.keyRadius, prefs.keyStyle, prefs.keyGap, prefs.scene) { dir ->
        val src = if (tab == 1) Patches.CLASSIC_LIST else if (tab == 4 && mine.isNotEmpty()) mine else if (list.isEmpty()) all else list
        val i = src.indexOfFirst { it.id == prefs.patch }
        val next = if (i < 0) (if (dir > 0) 0 else src.size - 1) else (i + dir + src.size) % src.size
        applyPatch(src[next])
    }

    val active = Patches.byId(prefs.patch)
    if (active != null) Text(L.f("Patch ativo: %s", active.name.tr()), color = cs.primary, fontWeight = FontWeight.SemiBold,
        style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(start = 4.dp))

    // Cada coisa em sua própria aba, para ninguém confundir: temas prontos, cenário, bichinhos, coleção Keys Café e loja online ThemeBoard.
    val tabNames = buildList { add("Patches"); add("Clássicos"); add("Cenário"); add("Bichinhos"); add("Keys Café"); if (boardOn) add("ThemeBoard") }
    ChipRow(tabNames.map { it.tr() }, tab.coerceAtMost(tabNames.size - 1)) { tab = it }

    when (tab) {
        0 -> {
            MkNote("Temas prontos que já vêm no app. Toque para aplicar; segure para ver em tela cheia. Deslize a prévia do teclado para trocar de patch.".tr())
            if (loading) {
                MkCard("Carregando patches".tr()) {
                    Column(Modifier.fillMaxWidth().padding(vertical = 12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        LinearProgressIndicator(progress = { (shown.toFloat() / list.size.coerceAtLeast(1)).coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth())
                        Text(L.f("%d de %d", shown.coerceAtMost(list.size), list.size), color = cs.onSurface.copy(alpha = 0.7f), style = MaterialTheme.typography.bodySmall)
                        Text("Na primeira vez pode demorar um pouco. Depois abre na hora.".tr(), color = cs.onSurface.copy(alpha = 0.62f), style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
            OutlinedTextField(query, { query = it }, singleLine = true, shape = CircleShape, modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("Buscar patch".tr()) })
            ChipRow(listOf("Todos", "Jogos", "Material You", "Marcas", "Liquid Glass", "AMOLED", "Favoritos").map { it.tr() }, sel) { sel = it }
            if (list.isEmpty()) MkNote("Nenhum patch encontrado".tr())
            shownList.groupBy { it.category }.toSortedMap().forEach { (cat, group) ->
                PatchRow(Patches.CATEGORY_NAMES[cat].tr(), group, prefs.patch, favs, onTap = { applyPatch(it) }, onHold = { peek = it },
                    onFav = { prefs.toggleFav(it.id); refresh() })
            }
            if (prefs.patch.isNotEmpty()) MkAction("Remover patch".tr(), danger = true) { prefs.removePatch(); refresh() }
        }
        1 -> {
            MkNote("Cinco visuais de referência: Padrão 2017, Mecânico, Material, Padrão Gboard e Gboard Escuro. Toque para aplicar; segure para ver em tela cheia.".tr())
            PatchRow("Clássicos".tr(), Patches.CLASSIC_LIST, prefs.patch, favs, onTap = { applyPatch(it) }, onHold = { peek = it },
                onFav = { prefs.toggleFav(it.id); refresh() })
            if (prefs.patch.isNotEmpty()) MkAction("Remover patch".tr(), danger = true) { prefs.removePatch(); refresh() }

            // Personalização ilimitada: vale para qualquer tema (clássico, patch ou seu); muda na hora
            MkCard("Personalização ilimitada".tr()) {
                MkNote("Tudo aqui muda na hora, em cima do tema que estiver ativo. Para guardar o resultado, use Salvar meu visual como tema.".tr())
                Sub("Estilo das teclas".tr())
                ChipRow(listOf("Material You".tr(), "iOS", "One UI", "Vidro".tr(), "Mecânico".tr()), prefs.keyStyle.coerceIn(0, 4)) { prefs.putInt("keyStyle", it); refresh() }
                MkSlider("Borda das teclas".tr(), prefs.keyBorder, 0, 6, "dp") { prefs.putInt("keyBorder", it) }
                MkSlider("Profundidade 3D das teclas".tr(), prefs.keyDepth, 0, 8, "dp") { prefs.putInt("keyDepth", it) }
                MkSlider("Cantos das teclas".tr(), prefs.keyRadius, 0, 32, "dp") { prefs.putInt("keyRadius", it) }
                MkSlider("Espaço entre as teclas".tr(), prefs.keyGap, 1, 12, "dp") { prefs.putInt("keyGap", it) }
                MkSwitch("Formas livres nas teclas".tr(), "Liga os formatos escolhidos (Enter em cookie, flor...) no lugar do visual uniforme".tr(), !prefs.expressive) {
                    prefs.putBool("expressive", !it); refresh()
                }
                Sub("Formato do microfone".tr())
                ChipRow(BarShapes.NAMES.map { it.tr() }, prefs.micShape.coerceIn(0, BarShapes.NAMES.size - 1)) { prefs.putInt("micShape", it); refresh() }
                Sub("Formato do botão de seta".tr())
                ChipRow(BarShapes.NAMES.map { it.tr() }, prefs.toolShape.coerceIn(0, BarShapes.NAMES.size - 1)) { prefs.putInt("toolShape", it); refresh() }
                Sub("Faixa de ícones".tr())
                ChipRow(listOf("Pílula", "Reta", "Retangular").map { it.tr() }, prefs.barStyle.coerceIn(0, 2)) { prefs.putInt("barStyle", it); refresh() }
                MkNav(R.drawable.ic_tune, "Personalizar o tema ativo no editor".tr(), "Cores, gradientes, texto, balão, animação e mais".tr()) {
                    editorStart = Patches.byId(prefs.patch)?.takeIf { it.category != Patches.COMMUNITY }
                        ?.let { ThemeSpecMapper.fromPatch(it).copy(id = "meu-novo", name = L.f("%s (meu)", it.name.tr()).take(40)) }
                    editor = true
                }
            }
        }
        2 -> MkCard("Cenário animado".tr()) {
            ChipRow(listOf("Desligado", "Outono", "Inverno", "Tempestade").map { it.tr() }, prefs.scene.coerceIn(0, 3)) { prefs.putInt("scene", it); refresh() }
            MkNote("Só as partículas caem sobre o teclado; o fundo continua sendo o tema ou a imagem que você escolher.".tr())
        }
        3 -> PetsSection()
        4 -> {
            MkNote("Keys Café é a sua coleção: temas que você importou, criou ou salvou. Ficam só no seu aparelho.".tr())
            MkCard("Keys Café".tr()) {
                MkNav(R.drawable.ic_patch, "Importar tema (.mkt)".tr(), "Instalar um tema a partir de um arquivo".tr()) { onImport() }
                MkNav(R.drawable.ic_palette, "Salvar meu visual como tema".tr(), "Guarda as cores e o acabamento de agora".tr()) { saving = true }
                MkNav(R.drawable.ic_tune, "Editor de temas".tr(), "Criar ou ajustar um tema à mão".tr()) { editor = true }
            }
            note?.let { MkNote(it) }
            if (mine.isEmpty()) MkNote("Nenhum tema seu ainda. Importe um arquivo .mkt ou salve o seu visual atual.".tr())
            else PatchRow("Meus temas".tr(), mine, prefs.patch, favs, onTap = { applyPatch(it) }, onHold = { peek = it },
                onFav = { prefs.toggleFav(it.id); refresh() })
        }
        else -> MkCard("ThemeBoard".tr()) {
            MkNote("ThemeBoard é a loja online: temas de outras pessoas, revisados antes de aparecer. Precisa de internet e de uma conta para publicar.".tr())
            MkNav(R.drawable.ic_globe, "Abrir ThemeBoard".tr(), "Explorar e publicar temas da comunidade".tr()) { board = true }
        }
    }

    if (editor) ThemeEditorDialog(prefs, start = editorStart, onClose = { editor = false; editorStart = null }, onSaved = { saved, applied ->
        editor = false; editorStart = null; tab = 4; note = L.f(if (applied) "Tema salvo e aplicado: %s" else "Tema salvo: %s", saved.name); refresh() })

    if (board) ThemeBoardDialog(prefs, onClose = { board = false; refresh() }, onChanged = { refresh() },
        onCreate = { board = false; editorStart = null; editor = true })

    peek?.let { pk ->
        val mine = pk.category == Patches.COMMUNITY
        val ex: (() -> Unit)? = if (mine) ({ onExport(pk.id) }) else null
        val rm: (() -> Unit)? = if (mine) ({ removing = pk }) else null
        PatchFullPreview(pk, { peek = null }, ex, rm)
    }

    if (saving) SaveThemeDialog(onDismiss = { saving = false }) { name ->
        saving = false
        val spec = ThemeSpecMapper.capture(appCtx, prefs, ThemeLibrary.newLocalId(name), name)
        note = if (spec == null) "Desligue a imagem de fundo para salvar o visual como tema.".tr()
        else when (val r = ThemeLibrary.saveLocal(spec)) {
            is InstallResult.Fail -> r.reason.tr()
            is InstallResult.Ok -> { tab = 4; L.f("Tema salvo: %s", name) }
        }
        refresh()
    }

    removing?.let { rp ->
        AlertDialog(
            onDismissRequest = { removing = null },
            title = { Text("Remover este tema?".tr()) },
            text = { Text(rp.name) },
            confirmButton = {
                TextButton(onClick = {
                    ThemeLibrary.remove(prefs, rp.id)
                    removing = null; peek = null
                    refresh()
                }) { Text("Remover tema".tr()) }
            },
            dismissButton = { TextButton(onClick = { removing = null }) { Text("Cancelar".tr()) } }
        )
    }
}

@Composable
private fun Sub(t: String) = Text(t, color = MaterialTheme.colorScheme.onSurface, fontWeight = FontWeight.Medium, modifier = Modifier.padding(top = 10.dp))

/** Faixa de patches de uma categoria: título e cartões que deslizam para o lado. */
@Composable
private fun PatchRow(title: String, group: List<Patch>, activeId: String, favs: List<String>,
                     onTap: (Patch) -> Unit, onHold: (Patch) -> Unit, onFav: (Patch) -> Unit) {
    val cs = MaterialTheme.colorScheme
    Row(Modifier.fillMaxWidth().padding(start = 4.dp, top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(title, color = cs.primary, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f))
        Text(if (group.size > 2) "${group.size}  ›" else "${group.size}", color = cs.onSurface.copy(alpha = 0.5f),
            style = MaterialTheme.typography.labelMedium, modifier = Modifier.padding(end = 6.dp))
    }
    LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(horizontal = 2.dp, vertical = 4.dp)) {
        items(group, key = { it.id }) { p ->
            Box(Modifier.width(172.dp)) {
                PatchCard(p, p.id == activeId, p.id in favs, onTap = { onTap(p) }, onHold = { onHold(p) }, onFav = { onFav(p) })
            }
        }
    }
}

/** Pergunta o nome do tema que vai guardar o visual atual do teclado. */
@Composable
private fun SaveThemeDialog(onDismiss: () -> Unit, onSave: (String) -> Unit) {
    var name by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Salvar meu visual como tema".tr()) },
        text = {
            OutlinedTextField(name, { if (it.length <= 40) name = it }, singleLine = true,
                placeholder = { Text("Nome do tema".tr()) })
        },
        confirmButton = { TextButton(onClick = { onSave(name.trim()) }, enabled = name.isNotBlank()) { Text("Salvar".tr()) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar".tr()) } }
    )
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun PatchCard(p: Patch, active: Boolean, fav: Boolean, onTap: () -> Unit, onHold: () -> Unit, onFav: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val sc by animateFloatAsState(if (pressed) 0.94f else if (active) 1.03f else 1f, patchPop, label = "patchCard")
    val pal = remember(p.id) { Palette.fromPatch(p) }
    val accent = Color(p.accent)
    val shape = RoundedCornerShape(22.dp)
    Column(
        Modifier.fillMaxWidth().scale(sc).clip(shape)
            .background(cs.onSurface.copy(alpha = 0.07f))
            .border(if (active) 3.dp else 1.dp, if (active) accent else cs.onSurface.copy(alpha = 0.12f), shape)
            .combinedClickable(interactionSource = src, indication = null, onClick = onTap, onLongClick = onHold)
            .padding(10.dp)
    ) {
        Box {
            KbThumb(pal, p.radius, p.keyStyle, p.gap, big = false)
            val checkScale by animateFloatAsState(if (active) 1f else 0f, patchPop, label = "patchCheck")
            if (checkScale > 0.01f) {
                Box(
                    Modifier.align(Alignment.TopEnd).padding(4.dp)
                        .graphicsLayer { scaleX = checkScale; scaleY = checkScale; alpha = checkScale.coerceIn(0f, 1f) }
                        .size(22.dp).clip(CircleShape).background(accent),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(painterResource(R.drawable.ic_check), null, tint = Color(pal.onAccent), modifier = Modifier.size(14.dp))
                }
            }
        }
        Row(Modifier.padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(p.name.tr(), color = cs.onSurface, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis,
                    style = MaterialTheme.typography.bodyMedium)
                Text(Patches.CATEGORY_NAMES[p.category].tr(), color = cs.onSurface.copy(alpha = 0.62f), maxLines = 1,
                    style = MaterialTheme.typography.labelSmall)
            }
            Text(if (fav) "★" else "☆", color = cs.primary, fontSize = 20.sp,
                modifier = Modifier.clip(CircleShape).clickable(onClick = onFav).padding(6.dp))
        }
    }
}

/** Prévia do topo: o teclado com as cores atuais; deslizar para os lados troca de patch ao vivo. */
@Composable
private fun SwipePreview(pal: Palette, radius: Int, style: Int, gap: Int, scene: Int, onSwipe: (Int) -> Unit) {
    var drag by remember { mutableFloatStateOf(0f) }
    val off by animateFloatAsState(drag, patchPop, label = "patchDrag")
    val cb by rememberUpdatedState(onSwipe)
    Box(
        Modifier.fillMaxWidth().offset { IntOffset((off / 4).roundToInt(), 0) }
            .pointerInput(Unit) {
                detectHorizontalDragGestures(
                    onDragEnd = { if (abs(drag) > 120f) cb(if (drag < 0) 1 else -1); drag = 0f },
                    onDragCancel = { drag = 0f }
                ) { _, d -> drag += d }
            }
    ) { KbThumb(pal, radius, style, gap, big = true, labels = true, scene = scene) }
}

/** Prévia em tela cheia (pressionar e segurar): mostra o patch sem aplicar. */
@Composable
private fun PatchFullPreview(p: Patch, onClose: () -> Unit, onExport: (() -> Unit)? = null, onRemove: (() -> Unit)? = null) {
    val pal = remember(p.id) { Palette.fromPatch(p) }
    val txt = Color(pal.onSurface)
    val bg = if (p.keyStyle == 3) Brush.linearGradient(listOf(Color(p.accent).copy(alpha = 0.55f), Color(pal.surface), Color(0xFF7B5BD6).copy(alpha = 0.5f)))
    else Brush.linearGradient(listOf(Color(pal.surface), Color(pal.surface)))
    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)) {
        Box(
            Modifier.fillMaxSize().background(bg)
                .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { onClose() }
                .padding(20.dp),
            contentAlignment = Alignment.BottomCenter
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Text(p.name.tr(), color = txt, fontWeight = FontWeight.Bold, fontSize = 24.sp)
                Text(p.desc.tr(), color = txt.copy(alpha = 0.75f), textAlign = TextAlign.Center)
                KbThumb(pal, p.radius, p.keyStyle, p.gap, big = true, labels = true)
                if (onExport != null || onRemove != null) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (onExport != null) TextButton(onClick = onExport) { Text("Exportar tema".tr(), color = txt) }
                        if (onRemove != null) TextButton(onClick = onRemove) { Text("Remover tema".tr(), color = txt) }
                    }
                }
                Text("Prévia · toque para fechar".tr(), color = txt.copy(alpha = 0.6f), style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

/** Miniatura do teclado: três fileiras de teclas + fileira com tecla de destaque, na paleta dada. */
@Composable
internal fun KbThumb(pal: Palette, radius: Int, style: Int, gap: Int, big: Boolean, labels: Boolean = false, scene: Int = 0) {
    val kh = if (big) 34.dp else 15.dp
    val r = (radius * (if (big) 0.9f else 0.45f)).coerceAtMost(if (big) 17f else 7.5f).dp
    val g = (if (big) gap + 2 else (gap / 2).coerceAtLeast(1)).dp
    val fs = if (big) 13f else 8f
    Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(if (big) 20.dp else 12.dp)).background(Color(pal.surface))) {
    Column(Modifier.fillMaxWidth().padding(if (big) 10.dp else 6.dp), verticalArrangement = Arrangement.spacedBy(g)) {
        listOf("qwertyuiop", "asdfghjkl", "zxcvbnm").forEach { row ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(g)) {
                val pad = (10 - row.length) / 2f
                if (pad > 0f) Spacer(Modifier.weight(pad))
                row.forEach { ThumbKey(if (labels) it.toString() else "", 1f, kh, r, style, Color(pal.keyNormal), Color(pal.onNormal), fs) }
                if (pad > 0f) Spacer(Modifier.weight(pad))
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(g)) {
            ThumbKey(if (labels) "123" else "", 1.5f, kh, r, style, Color(pal.keySpecial), Color(pal.onSpecial), fs)
            ThumbKey("", 5f, kh, r, style, Color(pal.keyNormal), Color(pal.onNormal), fs)
            ThumbKey(if (labels) "↵" else "", 1.5f, kh, r, style, Color(pal.keyAccent), Color(pal.onAccent), fs)
        }
    }
    // Cenário animado por cima da miniatura (só partículas; o fundo é o da paleta)
    if (scene > 0) AndroidView({ c -> View(c).apply { foreground = SceneDrawable(scene, 0f, c.resources.displayMetrics.density) } },
        Modifier.matchParentSize())
    }
}

@Composable
private fun RowScope.ThumbKey(t: String, w: Float, h: Dp, r: Dp, style: Int, bg: Color, fg: Color, fs: Float) {
    val shape = RoundedCornerShape(r)
    val base = Modifier.weight(w).height(h).clip(shape)
    val look = when (style) {
        3 -> Modifier.background(Brush.verticalGradient(listOf(bg.copy(alpha = 0.75f), bg.copy(alpha = 0.35f))))
            .border(1.dp, Color.White.copy(alpha = 0.5f), shape)                       // Liquid Glass: vidro com borda iluminada
        2 -> Modifier.background(Brush.verticalGradient(listOf(lerp(bg, Color.White, 0.12f), bg)))
        4 -> Modifier.background(Brush.verticalGradient(0f to lerp(bg, Color.White, 0.14f), 0.78f to bg,          // Mecânico: topo claro + lateral escura
            0.78f to lerp(bg, Color.Black, 0.5f), 1f to lerp(bg, Color.Black, 0.5f)))
        else -> Modifier.background(bg)
    }
    Box(base.then(look), contentAlignment = Alignment.Center) {
        if (t.isNotEmpty()) Text(t, color = fg, fontSize = fs.sp, fontWeight = FontWeight.Medium)
    }
}

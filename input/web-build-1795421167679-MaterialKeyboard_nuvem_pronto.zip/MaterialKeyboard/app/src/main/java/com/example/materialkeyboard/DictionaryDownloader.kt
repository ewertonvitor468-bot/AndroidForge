package com.example.materialkeyboard

import android.content.Context
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/**
 * Baixa, uma única vez por idioma, uma lista de frequência de palavras de código aberto
 * (projeto FrequencyWords, de hermitdave: código MIT, conteúdo CC-BY-SA 4.0, feito de legendas modernas,
 * 50 mil palavras por idioma, ~0,7 MB) e guarda em filesDir/dict/<idioma>.txt. [OpenDictionary] lê dali.
 * Sempre chamar fora da thread principal.
 */
object DictionaryDownloader {
    private const val BASE = "https://raw.githubusercontent.com/hermitdave/FrequencyWords/master/content"
    private const val MAX_BYTES = 8 * 1024 * 1024
    private const val RETRY_MS = 24L * 60 * 60 * 1000

    private fun urls(lang: String): List<String> = when (lang) {
        Prefs.LANG_PT -> listOf("$BASE/2018/pt_br/pt_br_50k.txt", "$BASE/2018/pt/pt_50k.txt", "$BASE/2016/pt_br/pt_br_50k.txt")
        Prefs.LANG_EN -> listOf("$BASE/2018/en/en_50k.txt")
        Prefs.LANG_RU -> listOf("$BASE/2018/ru/ru_50k.txt")
        Prefs.LANG_ES -> listOf("$BASE/2018/es/es_50k.txt")
        Prefs.LANG_AR -> listOf("$BASE/2018/ar/ar_50k.txt")
        Prefs.LANG_FR -> listOf("$BASE/2018/fr/fr_50k.txt")
        Prefs.LANG_TR -> listOf("$BASE/2018/tr/tr_50k.txt")
        Prefs.LANG_VI -> listOf("$BASE/2018/vi/vi_50k.txt")
        else -> emptyList()
    }

    fun file(ctx: Context, lang: String): File = File(File(ctx.applicationContext.filesDir, "dict"), "$lang.txt")
    fun has(ctx: Context, lang: String): Boolean = file(ctx, lang).let { it.isFile && it.length() > 10_000 }

    /** Para o download automático: no máximo uma tentativa por dia por idioma. */
    fun shouldAutoTry(ctx: Context, lang: String): Boolean {
        if (urls(lang).isEmpty() || has(ctx, lang)) return false
        val sp = ctx.applicationContext.getSharedPreferences("dict_dl", Context.MODE_PRIVATE)
        val last = sp.getLong("try_$lang", 0L)
        if (System.currentTimeMillis() - last < RETRY_MS) return false
        sp.edit().putLong("try_$lang", System.currentTimeMillis()).apply()
        return true
    }

    /** true se o arquivo foi baixado e validado. Tenta cada endereço da lista até um dar certo. */
    fun download(ctx: Context, lang: String): Boolean {
        val dest = file(ctx, lang)
        dest.parentFile?.mkdirs()
        for (u in urls(lang)) {
            val tmp = File(dest.parentFile, "$lang.tmp")
            try {
                val c = URL(u).openConnection() as HttpURLConnection
                c.connectTimeout = 10_000; c.readTimeout = 30_000
                if (c.responseCode != 200) { c.disconnect(); continue }
                var total = 0
                c.inputStream.use { ins -> tmp.outputStream().use { out ->
                    val buf = ByteArray(16 * 1024)
                    while (true) {
                        val n = ins.read(buf); if (n < 0) break
                        total += n; if (total > MAX_BYTES) throw java.io.IOException("grande demais")
                        out.write(buf, 0, n)
                    }
                } }
                c.disconnect()
                val lines = tmp.useLines { it.take(6000).count() }
                if (lines < 5000) { tmp.delete(); continue }          // arquivo estranho: não confia
                if (dest.exists()) dest.delete()
                if (tmp.renameTo(dest)) { OpenDictionary.forget(lang); return true }
            } catch (_: Exception) { tmp.delete() }
        }
        return false
    }
}

package com.example.materialkeyboard

import java.text.Normalizer

/**
 * Digitação vietnamita no método Telex (o mesmo do Gboard, UniKey etc.).
 *
 *  - aa → â · ee → ê · oo → ô · aw → ă · ow → ơ · uw → ư · dd → đ · w sozinho → ư
 *  - tons: s = sắc (á) · f = huyền (à) · r = hỏi (ả) · x = ngã (ã) · j = nặng (ạ) · z tira o tom
 *  - repetir a tecla desfaz (aaa → aa, ss → s)
 *
 * [compose] recebe TODAS as teclas da palavra e devolve a palavra pronta; assim o tom é reposicionado
 * sozinho quando a palavra cresce (hoaf → hòa, depois hoafn → hoàn).
 * Posição do tom: estilo tradicional (hòa, khỏe, thủy), o mais usado no dia a dia.
 */
object Telex {
    private const val NONE = ' '     // sem marca
    private const val CIRC = '^'     // â ê ô
    private const val BREVE = '('    // ă
    private const val HORN = '+'     // ơ ư
    private const val STROKE = '-'   // đ

    private const val VOW = "aeiouy"

    private class Ch(var b: Char, var up: Boolean, var mark: Char = NONE, var fromW: Boolean = false)

    private fun toneOf(k: Char): Int = when (k) { 's' -> 1; 'f' -> 2; 'r' -> 3; 'x' -> 4; 'j' -> 5; else -> 0 }
    private fun toneMark(t: Int): Char = when (t) { 1 -> '\u0301'; 2 -> '\u0300'; 3 -> '\u0309'; 4 -> '\u0303'; else -> '\u0323' }
    private fun markChar(m: Char): String = when (m) { CIRC -> "\u0302"; BREVE -> "\u0306"; HORN -> "\u031B"; else -> "" }
    private fun isVowel(c: Ch) = VOW.indexOf(c.b) >= 0

    fun compose(raw: CharSequence): String {
        val cs = ArrayList<Ch>()
        var tone = 0
        for (k in raw) {
            val kl = k.lowercaseChar()
            val up = k.isUpperCase()
            val last = cs.lastOrNull()

            // dd → đ
            if (kl == 'd' && last != null && last.b == 'd') {
                if (last.mark == NONE) { last.mark = STROKE; continue }
                if (last.mark == STROKE) { last.mark = NONE; cs.add(Ch('d', up)); continue }
            }
            // aa, ee, oo → â, ê, ô
            if ((kl == 'a' || kl == 'e' || kl == 'o') && last != null && last.b == kl) {
                if (last.mark == NONE) { last.mark = CIRC; continue }
                if (last.mark == CIRC) { last.mark = NONE; cs.add(Ch(kl, up)); continue }
            }
            // w: ă, ơ, ư (e "uow" → ươ)
            if (kl == 'w') {
                var v = -1
                for (i in cs.indices.reversed()) if (isVowel(cs[i])) { v = i; break }
                if (v < 0) { cs.add(Ch('u', up, HORN, true)); continue }      // w sozinho → ư
                val x = cs[v]
                if (x.fromW && v == cs.size - 1) { cs[v] = Ch('w', x.up); continue }   // ww → w
                if (v > 0 && isVowel(cs[v - 1]) && cs[v - 1].b == 'u' && x.b == 'o' && !(v - 1 > 0 && cs[v - 2].b == 'q')) {
                    val u = cs[v - 1]
                    if (u.mark == HORN && x.mark == HORN) { u.mark = NONE; x.mark = NONE; cs.add(Ch('w', up)) }
                    else { u.mark = HORN; x.mark = HORN }
                    continue
                }
                when (x.b) {
                    'a' -> if (x.mark == BREVE) { x.mark = NONE; cs.add(Ch('w', up)) } else x.mark = BREVE
                    'o', 'u' -> if (x.mark == HORN) { x.mark = NONE; cs.add(Ch('w', up)) } else x.mark = HORN
                    else -> cs.add(Ch('w', up))
                }
                continue
            }
            // tons
            if ((toneOf(kl) > 0 || kl == 'z') && cs.any { isVowel(it) }) {
                val t = if (kl == 'z') 0 else toneOf(kl)
                if (tone == t) { tone = 0; cs.add(Ch(kl, up)) } else tone = t
                continue
            }
            cs.add(Ch(if (k.isLetter()) kl else k, up))
        }
        return render(cs, tone)
    }

    /** Vogais do núcleo da sílaba (o "u" de qu e o "i" de gi antes de vogal são consoantes). */
    private fun nucleus(cs: List<Ch>): List<Int> {
        val n = cs.size
        fun isV(j: Int): Boolean {
            val c = cs[j]
            if (!isVowel(c)) return false
            if (c.b == 'u' && j > 0 && cs[j - 1].b == 'q') return false
            if (c.b == 'i' && j > 0 && cs[j - 1].b == 'g' && j + 1 < n && VOW.indexOf(cs[j + 1].b) >= 0) return false
            return true
        }
        var i = 0
        while (i < n && !isV(i)) i++
        var j = i
        while (j < n && isV(j)) j++
        return (i until j).toList()
    }

    private fun toneIndex(cs: List<Ch>): Int {
        val nuc = nucleus(cs)
        if (nuc.isEmpty()) return -1
        if (nuc.size == 1) return nuc[0]
        val mod = nuc.filter { cs[it].mark == CIRC || cs[it].mark == BREVE || cs[it].mark == HORN }
        if (mod.isNotEmpty()) return mod.last()                 // ê ô â ă ơ ư levam o tom (em ươ, na ơ)
        if (nuc.size >= 3) return nuc[1]
        val hasFinal = nuc.last() < cs.size - 1
        return if (hasFinal) nuc[1] else nuc[0]                 // toán, hoàn · mái, hòa, thủy
    }

    private fun render(cs: List<Ch>, tone: Int): String {
        val ti = if (tone > 0) toneIndex(cs) else -1
        val sb = StringBuilder()
        for ((i, c) in cs.withIndex()) {
            val piece = if (c.b == 'd' && c.mark == STROKE) "đ" else {
                val t = StringBuilder().append(c.b).append(markChar(c.mark))
                if (i == ti) t.append(toneMark(tone))
                t.toString()
            }
            sb.append(if (c.up) piece.uppercase() else piece)
        }
        return Normalizer.normalize(sb.toString(), Normalizer.Form.NFC)
    }

    /** O contrário: de uma palavra já acentuada, as teclas do Telex que a produzem (usado ao apagar uma letra). */
    fun toRaw(display: String): String {
        val d = Normalizer.normalize(Normalizer.normalize(display, Normalizer.Form.NFC), Normalizer.Form.NFD)
        val raw = StringBuilder()
        var tone = ' '
        for (ch in d) {
            when (ch.code) {
                0x0111 -> raw.append("dd")
                0x0110 -> raw.append("Dd")
                0x0302 -> if (raw.isNotEmpty()) raw.append(raw.last().lowercaseChar())
                0x0306, 0x031B -> raw.append('w')
                0x0301 -> tone = 's'
                0x0300 -> tone = 'f'
                0x0309 -> tone = 'r'
                0x0303 -> tone = 'x'
                0x0323 -> tone = 'j'
                else -> raw.append(ch)
            }
        }
        if (tone != ' ') raw.append(tone)
        return raw.toString()
    }
}

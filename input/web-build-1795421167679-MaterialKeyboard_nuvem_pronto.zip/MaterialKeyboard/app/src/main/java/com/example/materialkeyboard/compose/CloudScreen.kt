package com.example.materialkeyboard.compose

import androidx.compose.runtime.Composable
import com.example.materialkeyboard.L
import com.example.materialkeyboard.Prefs
import com.example.materialkeyboard.cloud.CloudController
import com.example.materialkeyboard.tr
import java.text.DateFormat
import java.util.Date

/** Página "Conta e nuvem": login com Google e backup/restauração das configurações. Só usa componentes que já existem em SettingsPages. */
@Composable
fun CloudScreen(prefs: Prefs, c: CloudController) = PageHost(prefs) {
    val ui = c.ui
    val user = ui.user
    MkCard("Conta".tr()) {
        if (!c.configured) {
            MkNote("A nuvem não está configurada neste APK.".tr())
        } else if (user == null) {
            MkNote("Entre com a sua conta Google para guardar um backup das suas configurações e restaurá-lo em outro aparelho. O teclado continua funcionando normalmente sem login e sem internet.".tr())
            MkAction(if (ui.busy) "Entrando…".tr() else "Entrar com o Google".tr()) { c.signIn() }
        } else {
            MkNote(listOf(user.name, user.email).filter { it.isNotBlank() }.joinToString("\n"))
            MkAction("Sair da conta".tr()) { c.signOut() }
        }
    }
    if (c.configured && user != null) {
        MkCard("Backup".tr()) {
            val last = if (ui.lastBackup > 0L)
                L.f("Último backup deste aparelho: %s", DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT).format(Date(ui.lastBackup)))
            else "Nenhum backup feito neste aparelho ainda.".tr()
            MkNote(last)
            MkSwitch("Backup automático".tr(), "Envia as configurações ao sair daqui, só se mudaram e com internet.".tr(), ui.auto) { c.setAuto(it) }
            MkAction("Fazer backup agora".tr()) { c.backup() }
            MkAction("Restaurar do backup".tr()) { c.restore() }
            MkAction("Apagar backup da nuvem".tr(), true) { c.deleteBackup() }
        }
    }
    if (ui.message.isNotEmpty()) MkCard { MkNote(ui.message) }
    MkNote("O backup inclui as configurações e preferências do teclado. Não inclui o histórico da área de transferência, palavras aprendidas, imagem ou vídeo de fundo, sons importados, temas do Keys Café nem a chave do ditado por voz.".tr())
}

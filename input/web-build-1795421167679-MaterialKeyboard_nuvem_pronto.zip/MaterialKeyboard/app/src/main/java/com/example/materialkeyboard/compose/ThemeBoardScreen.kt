package com.example.materialkeyboard.compose

import android.graphics.BitmapFactory
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.materialkeyboard.L
import com.example.materialkeyboard.Prefs
import com.example.materialkeyboard.keyscafe.BoardResult
import com.example.materialkeyboard.keyscafe.BoardTheme
import com.example.materialkeyboard.keyscafe.PackageBuild
import com.example.materialkeyboard.keyscafe.ReportCategory
import com.example.materialkeyboard.keyscafe.ThemeBoardApi
import com.example.materialkeyboard.keyscafe.ThemeLibrary
import com.example.materialkeyboard.tr
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * true depois que o ThemeBoard carregou a lista ao menos uma vez nesta sessão do teclado. A primeira
 * chamada ao servidor é bem mais lenta (cold start: 20-30s); as seguintes são rápidas (~5s), então
 * o carregamento cheio com aviso de demora só aparece uma vez — depois é só um spinner pequeno.
 */
private var themeBoardWarmedUp = false

/**
 * ThemeBoard: explorar, baixar, publicar e denunciar temas da comunidade (Supabase).
 * Ver só precisa de internet; publicar, denunciar e "meus temas" pedem conta (e-mail e senha).
 * Tudo que é baixado passa por [ThemeBoardApi.download] (hash + validação rígida) antes de entrar na biblioteca.
 */
@Composable
fun ThemeBoardDialog(prefs: Prefs, onClose: () -> Unit, onChanged: () -> Unit, onCreate: () -> Unit = {}) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val cs = MaterialTheme.colorScheme

    var tab by remember { mutableIntStateOf(0) }                 // 0 explorar, 1 meus
    var sort by remember { mutableIntStateOf(0) }                // 0 populares, 1 novos, 2 melhores
    var queryText by remember { mutableStateOf("") }
    var query by remember { mutableStateOf("") }
    var reload by remember { mutableIntStateOf(0) }
    val items = remember { mutableStateListOf<BoardTheme>() }
    var page by remember { mutableIntStateOf(0) }
    var hasMore by remember { mutableStateOf(false) }
    var loading by remember { mutableStateOf(false) }
    var coldLoading by remember { mutableStateOf(false) }   // primeiro carregamento desta sessão: tela cheia com aviso de demora
    var busy by remember { mutableStateOf<String?>(null) }
    var note by remember { mutableStateOf<String?>(null) }
    var reporting by remember { mutableStateOf<BoardTheme?>(null) }
    var publishing by remember { mutableStateOf<String?>(null) }
    var loginFor by remember { mutableStateOf<(() -> Unit)?>(null) }   // diálogo de login; o lambda roda após entrar
    var account by remember { mutableStateOf(ThemeBoardApi.accountEmail(ctx)) }
    // moderador? Quem decide é o servidor; aqui só escondemos/mostramos o botão
    val moderator by produceState(false, account) { value = account != null && withContext(Dispatchers.IO) { ThemeBoardApi.isModerator(ctx) } }
    var moderating by remember { mutableStateOf(false) }

    fun failText(reason: String): String = if (reason == ThemeBoardApi.NEED_LOGIN) "Entre na sua conta para continuar.".tr() else reason.tr()

    suspend fun load(p: Int) {
        loading = true
        val firstEver = p == 0 && !themeBoardWarmedUp
        coldLoading = firstEver && items.isEmpty()
        val r = withContext(Dispatchers.IO) {
            if (tab == 0) ThemeBoardApi.list(p, when (sort) { 0 -> ThemeBoardApi.Sort.POPULAR; 1 -> ThemeBoardApi.Sort.NEWEST; else -> ThemeBoardApi.Sort.BEST }, query)
            else if (p == 0) ThemeBoardApi.mine(ctx) else BoardResult.Ok(emptyList())
        }
        when (r) {
            is BoardResult.Fail -> { if (p == 0) items.clear(); hasMore = false; note = failText(r.reason) }
            is BoardResult.Ok -> {
                if (p == 0) items.clear()
                items.addAll(r.value)
                page = p
                hasMore = tab == 0 && r.value.size >= 20
                note = if (items.isEmpty()) (if (tab == 0) "Nenhum tema encontrado." else "Você ainda não publicou temas.").tr() else null
            }
        }
        if (firstEver) themeBoardWarmedUp = true
        loading = false
        coldLoading = false
    }

    LaunchedEffect(tab, sort, query, reload, account) { load(0) }

    /** Roda [action] se há conta; senão abre o login e roda depois de entrar. */
    fun needAccount(action: () -> Unit) { if (ThemeBoardApi.signedIn(ctx)) action() else loginFor = action }

    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxSize(), color = cs.surface) {
            Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("ThemeBoard", color = cs.primary, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge,
                        modifier = Modifier.weight(1f))
                    if (moderator) TextButton(onClick = { moderating = true }) { Text("Moderar".tr()) }
                    TextButton(onClick = onCreate) { Text("Criar tema".tr()) }
                    TextButton(onClick = onClose) { Text("Fechar".tr()) }
                }
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text(account ?: "Sem conta".tr(), Modifier.weight(1f), style = MaterialTheme.typography.bodySmall,
                        color = cs.onSurface.copy(alpha = 0.7f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                    if (account != null) TextButton(onClick = { ThemeBoardApi.signOut(ctx); account = null; tab = 0 }) { Text("Sair".tr()) }
                    else TextButton(onClick = { loginFor = { } }) { Text("Entrar".tr()) }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(tab == 0, { tab = 0 }, { Text("Explorar".tr()) })
                    FilterChip(tab == 1, { needAccount { tab = 1 } }, { Text("Meus temas".tr()) })
                }
                if (tab == 0) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(sort == 0, { sort = 0 }, { Text("Populares".tr()) })
                        FilterChip(sort == 1, { sort = 1 }, { Text("Novos".tr()) })
                        FilterChip(sort == 2, { sort = 2 }, { Text("Melhores".tr()) })
                    }
                    OutlinedTextField(queryText, { if (it.length <= 40) queryText = it }, singleLine = true, shape = CircleShape,
                        modifier = Modifier.fillMaxWidth(), placeholder = { Text("Buscar tema".tr()) },
                        keyboardActions = KeyboardActions(onSearch = { query = queryText.trim() }),
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search))
                }
                if (coldLoading) {
                    // Primeira vez nesta sessão: o servidor ainda está "frio" e pode levar até 30s.
                    // Em vez do antigo "Carregando…" discreto, uma tela cheia explica a demora.
                    Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(14.dp)) {
                            MkLoadingIndicator(size = 56.dp)
                            Text(
                                "Carregando os temas da comunidade…".tr(),
                                color = cs.onSurface, fontWeight = FontWeight.SemiBold,
                                textAlign = TextAlign.Center, style = MaterialTheme.typography.bodyLarge
                            )
                            Text(
                                "Pode levar até 30 segundos na primeira vez. Nas próximas, é rápido (uns 5 segundos).".tr(),
                                color = cs.onSurface.copy(alpha = 0.65f), textAlign = TextAlign.Center,
                                style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(horizontal = 28.dp)
                            )
                        }
                    }
                } else {
                    note?.let { Text(it, color = cs.onSurface.copy(alpha = 0.7f), style = MaterialTheme.typography.bodyMedium) }

                    LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    if (tab == 1) item {
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text("Publicar um tema meu".tr(), fontWeight = FontWeight.SemiBold)
                            val mine = ThemeLibrary.list().filter { it.id.startsWith("meu-") }
                            if (mine.isEmpty()) Text("Salve seu visual como tema (aba Keys Café) para poder publicar.".tr(),
                                color = cs.onSurface.copy(alpha = 0.7f), style = MaterialTheme.typography.bodySmall)
                            mine.forEach { s ->
                                val already = ThemeBoardApi.isPublished(ctx, s.id)
                                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                    Text(s.name, Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    OutlinedButton(onClick = { publishing = s.id }, enabled = !already && busy == null) {
                                        Text((if (already) "Publicado" else "Publicar").tr())
                                    }
                                }
                            }
                            Text("Todo tema publicado passa por revisão antes de aparecer para os outros.".tr(),
                                color = cs.onSurface.copy(alpha = 0.6f), style = MaterialTheme.typography.bodySmall)
                        }
                    }
                    items(items, key = { it.id }) { t ->
                        val specId = ThemeBoardApi.installedSpecId(ctx, t.id)
                        BoardRow(t, mineTab = tab == 1, installed = specId != null, busy = busy == t.id,
                            onGet = {
                                busy = t.id
                                scope.launch {
                                    val r = withContext(Dispatchers.IO) { ThemeBoardApi.download(ctx, t) }
                                    busy = null
                                    note = when (r) {
                                        is BoardResult.Fail -> failText(r.reason)
                                        is BoardResult.Ok -> { onChanged(); L.f("Tema instalado: %s", r.value.name) }
                                    }
                                    reload++
                                }
                            },
                            onApply = { if (specId != null && ThemeLibrary.apply(prefs, specId)) { onChanged(); note = L.f("Aplicado: %s", t.title) } },
                            onReport = { needAccount { reporting = t } })
                    }
                    if (hasMore && !loading) item {
                        OutlinedButton(onClick = { scope.launch { load(page + 1) } }, modifier = Modifier.fillMaxWidth()) { Text("Carregar mais".tr()) }
                    }
                    // Carregamentos rápidos (recarregar, trocar de aba/ordem, página seguinte): giro pequeno, sem
                    // atrapalhar a lista — a tela cheia com aviso de demora é só para a primeira vez (acima).
                    if (loading) item {
                        Row(Modifier.fillMaxWidth().padding(vertical = 10.dp), horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically) {
                            MkLoadingIndicator(size = 22.dp)
                            Spacer(Modifier.width(8.dp))
                            Text("Carregando…".tr(), color = cs.onSurface.copy(alpha = 0.6f), style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
                }
            }
        }
    }

    if (moderating) ModerationDialog(onClose = { moderating = false; reload++ })

    loginFor?.let { after ->
        LoginDialog(onDismiss = { loginFor = null }, onDone = { loginFor = null; account = ThemeBoardApi.accountEmail(ctx); after() })
    }

    reporting?.let { t ->
        var reason by remember(t.id) { mutableStateOf("") }
        var cat by remember(t.id) { mutableStateOf(ReportCategory.INAPPROPRIATE) }
        AlertDialog(
            onDismissRequest = { reporting = null },
            title = { Text("Denunciar este tema?".tr()) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(t.title)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        ReportCategory.values().take(2).forEach { c -> FilterChip(cat == c, { cat = c }, { Text(c.label.tr()) }) }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        ReportCategory.values().drop(2).forEach { c -> FilterChip(cat == c, { cat = c }, { Text(c.label.tr()) }) }
                    }
                    OutlinedTextField(reason, { if (it.length <= 500) reason = it }, placeholder = { Text("O que há de errado? (mín. 5 letras)".tr()) })
                }
            },
            confirmButton = {
                TextButton(enabled = reason.trim().length >= 5, onClick = {
                    reporting = null
                    scope.launch {
                        val r = withContext(Dispatchers.IO) { ThemeBoardApi.report(ctx, t, cat, reason) }
                        note = if (r is BoardResult.Fail) failText(r.reason) else "Denúncia enviada. Obrigado!".tr()
                    }
                }) { Text("Denunciar".tr()) }
            },
            dismissButton = { TextButton(onClick = { reporting = null }) { Text("Cancelar".tr()) } }
        )
    }

    publishing?.let { id ->
        val spec = ThemeLibrary.get(id)
        var desc by remember(id) { mutableStateOf(spec?.description.orEmpty()) }
        AlertDialog(
            onDismissRequest = { publishing = null },
            title = { Text("Publicar no ThemeBoard".tr()) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(spec?.name.orEmpty(), fontWeight = FontWeight.SemiBold)
                    OutlinedTextField(desc, { if (it.length <= 300) desc = it }, placeholder = { Text("Descrição (opcional)".tr()) })
                    Text("O tema fica visível para todos depois de aprovado. Não envie nada que não seja seu nem conteúdo ofensivo ou +18.".tr(),
                        style = MaterialTheme.typography.bodySmall)
                }
            },
            confirmButton = {
                TextButton(enabled = spec != null, onClick = {
                    publishing = null
                    busy = id
                    scope.launch {
                        val r = withContext(Dispatchers.IO) {
                            when (val b = ThemeLibrary.export(id, null, desc.trim())) {
                                is PackageBuild.Fail -> BoardResult.Fail(b.reason)
                                is PackageBuild.Ok -> ThemeBoardApi.publish(ctx, spec!!.copy(description = desc.trim()), b, ThemeLibrary.previewFile(id)?.readBytes())
                            }
                        }
                        busy = null
                        note = if (r is BoardResult.Fail) failText(r.reason) else "Enviado! Ele aparece para todos depois da revisão.".tr()
                        reload++
                    }
                }) { Text("Publicar".tr()) }
            },
            dismissButton = { TextButton(onClick = { publishing = null }) { Text("Cancelar".tr()) } }
        )
    }
}

@Composable
private fun LoginDialog(onDismiss: () -> Unit, onDone: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var create by remember { mutableStateOf(false) }
    var email by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }
    var name by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf<String?>(null) }
    var working by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = { if (!working) onDismiss() },
        title = { Text((if (create) "Criar conta" else "Entrar").tr()) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (create) OutlinedTextField(name, { if (it.length <= 40) name = it }, singleLine = true, placeholder = { Text("Seu nome ou apelido".tr()) })
                OutlinedTextField(email, { email = it.trim() }, singleLine = true, placeholder = { Text("E-mail".tr()) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email))
                OutlinedTextField(pass, { pass = it }, singleLine = true, placeholder = { Text("Senha (8+ caracteres)".tr()) },
                    visualTransformation = PasswordVisualTransformation(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password))
                msg?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
                TextButton(onClick = { create = !create; msg = null }) { Text((if (create) "Já tenho conta" else "Criar uma conta").tr()) }
            }
        },
        confirmButton = {
            TextButton(enabled = !working && email.contains("@") && pass.length >= 8 && (!create || name.isNotBlank()), onClick = {
                working = true; msg = null
                scope.launch {
                    val r = withContext(Dispatchers.IO) {
                        if (create) when (val s = ThemeBoardApi.signUp(ctx, email, pass, name)) {
                            is BoardResult.Fail -> s
                            is BoardResult.Ok -> if (s.value) BoardResult.Ok(Unit) else BoardResult.Fail("Conta criada! Confirme seu e-mail e depois toque em Entrar.")
                        } else ThemeBoardApi.signIn(ctx, email, pass)
                    }
                    working = false
                    when (r) { is BoardResult.Fail -> { msg = r.reason.tr(); if (r.reason.startsWith("Conta criada")) create = false }; is BoardResult.Ok -> onDone() }
                }
            }) { Text((if (working) "Aguarde…" else if (create) "Criar" else "Entrar").tr()) }
        },
        dismissButton = { TextButton(onClick = { if (!working) onDismiss() }) { Text("Cancelar".tr()) } }
    )
}

@Composable
private fun BoardRow(
    t: BoardTheme, mineTab: Boolean, installed: Boolean, busy: Boolean,
    onGet: () -> Unit, onApply: () -> Unit, onReport: () -> Unit
) {
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    val thumb by produceState<androidx.compose.ui.graphics.ImageBitmap?>(null, t.id) {
        value = withContext(Dispatchers.IO) {
            ThemeBoardApi.previewBytes(ctx, t)?.let { b ->
                try { BitmapFactory.decodeByteArray(b, 0, b.size)?.asImageBitmap() } catch (_: Exception) { null }
            }
        }
    }
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(cs.surfaceVariant.copy(alpha = 0.5f)).padding(10.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(72.dp).clip(RoundedCornerShape(12.dp)).background(cs.primary.copy(alpha = 0.15f))) {
            thumb?.let { Image(it, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop) }
        }
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(t.title, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            val rating = if (t.ratingCount > 0) L.f(" · ★ %.1f", t.ratingAvg) else ""
            Text(L.f("por %s · %d downloads", t.authorName.ifBlank { "—" }, t.downloads) + rating, style = MaterialTheme.typography.bodySmall,
                color = cs.onSurface.copy(alpha = 0.65f), maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (t.description.isNotBlank()) Text(t.description, style = MaterialTheme.typography.bodySmall, maxLines = 2, overflow = TextOverflow.Ellipsis)
            if (mineTab) Text(
                when {
                    t.version == 0 -> "Incompleto (publique de novo)"
                    t.status == "approved" -> "Aprovado"
                    t.status == "rejected" -> "Recusado"
                    t.status == "hidden" || t.status == "removed" -> "Removido"
                    else -> "Aguardando revisão"
                }.tr(), style = MaterialTheme.typography.labelMedium, color = cs.primary)
        }
        Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(2.dp)) {
            if (installed) Button(onClick = onApply, enabled = !busy) { Text("Aplicar".tr()) }
            else if (t.status == "approved" && t.versionStatus == "approved") Button(onClick = onGet, enabled = !busy) { Text((if (busy) "Baixando…" else "Baixar").tr()) }
            if (!mineTab) TextButton(onClick = onReport) { Text("Denunciar".tr()) }
        }
    }
}

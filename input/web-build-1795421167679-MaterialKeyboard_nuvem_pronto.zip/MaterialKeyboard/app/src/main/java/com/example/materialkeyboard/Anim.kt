package com.example.materialkeyboard

import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import androidx.dynamicanimation.animation.DynamicAnimation
import androidx.dynamicanimation.animation.SpringAnimation
import androidx.dynamicanimation.animation.SpringForce
import java.util.WeakHashMap

/** Ajustes globais de animação (preenchidos por Prefs): velocidade, elasticidade e acentos. */
object AnimCfg {
    @Volatile var speed = 1f            // 0.5..2 (1 = padrão)
    @Volatile var bounce = 50           // 0..100 (50 = padrão)
    @Volatile var altSpeed = 1f         // velocidade extra da animação dos acentos
    @Volatile var longPressMs = 500L    // tempo para abrir os acentos
    @Volatile var repeatSpeed = 1f      // repetição ao segurar (setas e apagar)
}

private val running = WeakHashMap<View, HashMap<DynamicAnimation.ViewProperty, SpringAnimation>>()

/**
 * Anima uma propriedade da view com uma mola (movimento "Material You").
 * Se já houver uma mola na mesma propriedade, ela é reaproveitada a partir da posição/velocidade atual
 * (cancelar e recomeçar mantém a posição, só perde a velocidade — suficiente e leve).
 * damping 1f = sem ricochete; valores menores = mais "elástico".
 */
fun View.springTo(
    prop: DynamicAnimation.ViewProperty,
    target: Float,
    stiffness: Float = 420f,
    damping: Float = 0.78f,
    onEnd: (() -> Unit)? = null
) {
    val map = running.getOrPut(this) { HashMap() }
    map[prop]?.cancel()
    val a = SpringAnimation(this, prop)
    val sp = AnimCfg.speed
    val dmp = if (damping < 1f) (damping + (50 - AnimCfg.bounce) / 100f * 0.6f).coerceIn(0.25f, 1f) else damping
    a.setSpring(SpringForce(target).setStiffness(stiffness * sp * sp).setDampingRatio(dmp))
    if (prop == DynamicAnimation.ALPHA) { a.setMinValue(0f); a.setMaxValue(1f) }
    if (onEnd != null) a.addEndListener { _, canceled, _, _ -> if (!canceled) onEnd() }
    map[prop] = a
    a.start()
}

/** Pop de entrada: sobe, aumenta e aparece, tudo com mola. */
fun View.springIn(fromY: Float = 24f, fromScale: Float = 0.92f, delay: Long = 0L, stiffness: Float = 380f, damping: Float = 0.74f) {
    alpha = 0f
    translationY = fromY * resources.displayMetrics.density
    scaleX = fromScale; scaleY = fromScale
    val go = Runnable {
        springTo(DynamicAnimation.ALPHA, 1f, 500f, 1f)
        springTo(DynamicAnimation.TRANSLATION_Y, 0f, stiffness, damping)
        springTo(DynamicAnimation.SCALE_X, 1f, stiffness, damping)
        springTo(DynamicAnimation.SCALE_Y, 1f, stiffness, damping)
    }
    if (delay > 0) postDelayed(go, delay) else go.run()
}

/** Entrada só com fade (sem mover nem escalar): não desloca a área de toque das teclas. */
fun View.springFadeIn(delay: Long = 0L, stiffness: Float = 420f) {
    alpha = 0f
    val go = Runnable { springTo(DynamicAnimation.ALPHA, 1f, stiffness, 1f) }
    if (delay > 0) postDelayed(go, delay) else go.run()
}

/** Cancela molas/animações e deixa a view no estado final (nunca fica transparente ou deslocada). */
fun View.settle() {
    animate().cancel()
    alpha = 1f; translationX = 0f; translationY = 0f; scaleX = 1f; scaleY = 1f
}

/** Pop elástico: começa menor e volta ao tamanho com mola e ricochete (ícones, chips, selos). */
fun View.pop(from: Float = 0.8f, delay: Long = 0L, stiffness: Float = 650f, damping: Float = 0.42f) {
    scaleX = from; scaleY = from
    val go = Runnable {
        springTo(DynamicAnimation.SCALE_X, 1f, stiffness, damping)
        springTo(DynamicAnimation.SCALE_Y, 1f, stiffness, damping)
    }
    if (delay > 0) postDelayed(go, delay) else go.run()
}

/** Cascata: os filhos entram um depois do outro (sobem, crescem e aparecem); os selos dos itens dão um pop extra. */
fun ViewGroup.cascade(fromY: Float = 24f, step: Long = 32L, maxDelayed: Int = 14) {
    for (i in 0 until childCount) {
        val c = getChildAt(i)
        val d = minOf(i, maxDelayed) * step
        c.springIn(fromY = fromY, fromScale = 0.95f, delay = d, stiffness = 360f, damping = 0.72f)
        if (c is LinearLayout && c.childCount >= 2 && c.getChildAt(0) is FrameLayout)
            c.getChildAt(0).pop(0.3f, d + 110L, 600f, 0.4f)
    }
}

/** Empurrão elástico: a view é deslocada e volta ao lugar com mola (apagar, enter, espaço). */
fun View.kick(dxDp: Float = -5f, dyDp: Float = 0f, stiffness: Float = 700f, damping: Float = 0.35f) {
    val d = resources.displayMetrics.density
    translationX = dxDp * d; translationY = dyDp * d
    springTo(DynamicAnimation.TRANSLATION_X, 0f, stiffness, damping)
    springTo(DynamicAnimation.TRANSLATION_Y, 0f, stiffness, damping)
}

/** Balanço: gira um pouco para um lado e volta ao lugar com mola (cliques em botões de ícone e selos). */
fun View.wiggle(deg: Float = 14f) {
    rotation = deg
    springTo(DynamicAnimation.ROTATION, 0f, 480f, 0.3f)
}

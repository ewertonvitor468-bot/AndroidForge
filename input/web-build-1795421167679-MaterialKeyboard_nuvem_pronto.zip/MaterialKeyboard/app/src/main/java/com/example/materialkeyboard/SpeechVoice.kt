package com.example.materialkeyboard

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.util.Log
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL

/**
 * Ditado por voz com o reconhecimento do próprio Android (SpeechRecognizer).
 * PADRÃO: tenta o reconhecimento NO APARELHO (Android 12+, a maioria dos aparelhos com Google
 * instalado) — nada para baixar, funciona sem internet e sem limite de uso, e começa a ouvir na hora.
 * Se o aparelho não tiver reconhecimento no aparelho, cai sozinho no reconhecimento normal do Google
 * (precisa de internet). Se nenhum dos dois existir, avisa que o ditado não está disponível.
 * OPCIONAL: com uma chave nas configurações, usa a nuvem em vez do Android. "gsk_..." = Groq
 * (whisper-large-v3), "sk-..." = OpenAI (gpt-4o-transcribe) — mais precisão, mas precisa de internet.
 * Mesma API de antes: 1º toque grava (para sozinho no silêncio), 2º toque encerra na hora,
 * toque ao processar cancela.
 */
class SpeechVoice(private val context: Context, private val cb: Callbacks) {

    enum class State { IDLE, STARTING, RECORDING, TRANSCRIBING }

    interface Callbacks {
        fun onState(state: State)
        fun onText(text: String)
        /** Texto parcial enquanto a pessoa ainda fala (aparece no campo na hora). */
        fun onPartial(text: String) {}
        fun onError(message: String)
        /** Aviso que não é erro (ex.: trocou de motor de reconhecimento). */
        fun onInfo(message: String) {}
    }

    @Volatile var state = State.IDLE
        private set

    @Volatile private var generation = 0
    @Volatile private var lastPartial = ""
    private val main = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null

    // Usados só no modo nuvem (chave configurada): grava o áudio na mão e manda pela internet.
    @Volatile private var stopRequested = false
    private var worker: Thread? = null

    fun isAvailable(): Boolean =
        SpeechRecognizer.isRecognitionAvailable(context) || onDeviceAvailable()

    private fun onDeviceAvailable(): Boolean =
        Build.VERSION.SDK_INT >= 31 && SpeechRecognizer.isOnDeviceRecognitionAvailable(context)

    fun start(): Boolean {
        if (state != State.IDLE) return false
        if (context.checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            cb.onError("Permissão do microfone negada"); return false
        }
        val prefs = Prefs.get(context)
        val key = prefs.voiceKeyNow()          // vazio = reconhecimento do Android
        val gen = ++generation
        lastPartial = ""
        setState(State.STARTING)       // v75.1: só vira RECORDING quando o reconhecedor está de fato ouvindo
        if (key.isBlank()) {
            startSystemRecognizer(gen, prefs.language)
        } else {
            stopRequested = false
            val t = Thread { work(gen, prefs.language, key) }
            t.isDaemon = true
            worker = t
            t.start()
        }
        return true
    }

    fun stop() {
        if (state != State.RECORDING && state != State.STARTING) return
        if (recognizer != null) main.post { recognizer?.stopListening() } else stopRequested = true
    }

    fun cancel() {
        if (state == State.IDLE) return
        generation++
        main.post { destroyRecognizer() }
        setState(State.IDLE)
    }

    fun onKeyboardHidden() = cancel()

    fun release() {
        generation++
        state = State.IDLE
        main.post { destroyRecognizer() }
    }

    // ---------- Reconhecimento do sistema (padrão, sem chave) ----------

    private fun startSystemRecognizer(gen: Int, lang: String) {
        if (!isAvailable()) {
            fail(gen, "Reconhecimento de voz indisponível neste aparelho"); return
        }
        main.post {
            if (!alive(gen)) return@post
            try {
                // v75.2: o reconhecedor normal do Google (online, bem mais preciso) vem primeiro; o do aparelho
                // (offline, às vezes "inventa" palavras) só é usado se o normal não existir.
                val onDevice = !SpeechRecognizer.isRecognitionAvailable(context) && onDeviceAvailable()
                val r = if (onDevice) SpeechRecognizer.createOnDeviceSpeechRecognizer(context)
                        else SpeechRecognizer.createSpeechRecognizer(context)
                recognizer = r
                r.setRecognitionListener(listener(gen))
                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, localeTag(lang))
                    putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)     // v75.1: o texto aparece enquanto fala
                    putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
                    putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, false)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, localeTag(lang))
                    putExtra(RecognizerIntent.EXTRA_ONLY_RETURN_LANGUAGE_PREFERENCE, localeTag(lang))
                    putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, context.packageName)
                    // v75.1: espera um pouco mais de silêncio antes de encerrar (antes cortava rápido demais)
                    putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 2200)
                    putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 2000)
                }
                r.startListening(intent)
            } catch (e: Throwable) {
                Log.w(TAG, e)
                destroyRecognizer()
                fail(gen, "Erro ao iniciar o reconhecimento de voz")
            }
        }
    }

    private fun listener(gen: Int) = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) { if (alive(gen) && state == State.STARTING) setState(State.RECORDING) }
        override fun onBeginningOfSpeech() { if (alive(gen) && state == State.STARTING) setState(State.RECORDING) }
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onPartialResults(partialResults: Bundle?) {
            if (!alive(gen)) return
            val t = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.trim().orEmpty()
            if (t.isNotEmpty()) { lastPartial = t; cb.onPartial(t) }
        }
        override fun onEvent(eventType: Int, params: Bundle?) {}

        override fun onEndOfSpeech() { if (alive(gen)) setState(State.TRANSCRIBING) }

        override fun onError(error: Int) {
            if (!alive(gen)) return
            destroyRecognizer()
            // Ninguém falou: não é bem um erro, é só o toque sem fala.
            if (error == SpeechRecognizer.ERROR_NO_MATCH || error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT) {
                val keep = lastPartial; lastPartial = ""
                // v75.1: aproveita o que já foi ouvido (o texto é entregue ANTES de voltar ao estado parado)
                if (keep.trim().length >= 3) { cb.onText(keep); setState(State.IDLE) } else { setState(State.IDLE); cb.onError("Não entendi, tente de novo") }
                return
            }
            val msg = when (error) {
                SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Sem internet para transcrever a voz"
                SpeechRecognizer.ERROR_AUDIO -> "Erro ao gravar o áudio"
                SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Reconhecimento de voz ocupado, tente de novo"
                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Permissão do microfone negada"
                SpeechRecognizer.ERROR_CLIENT -> return   // cancelado pela própria pessoa (2º toque): sem toast
                else -> "Erro no ditado de voz"
            }
            fail(gen, msg)
        }

        override fun onResults(results: Bundle?) {
            if (!alive(gen)) return
            destroyRecognizer()
            // v75.2: entre as alternativas, fica a de maior confiança (quando o motor informa)
            val alts = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
            val conf = results?.getFloatArray(SpeechRecognizer.CONFIDENCE_SCORES)
            var bi = 0
            if (alts != null && conf != null && conf.size == alts.size) for (i in conf.indices) if (conf[i] > conf[bi]) bi = i
            val text = (alts?.getOrNull(bi)?.trim()).let { if (it.isNullOrBlank()) lastPartial else it }
            lastPartial = ""
            if (text.isNullOrBlank()) { setState(State.IDLE); cb.onError("Não entendi, tente de novo") }
            else { cb.onText(text); setState(State.IDLE) }
        }
    }

    private fun destroyRecognizer() {
        val r = recognizer ?: return
        recognizer = null
        try { r.cancel() } catch (_: Exception) {}
        try { r.destroy() } catch (_: Exception) {}
    }

    private fun localeTag(lang: String) = when (lang) {
        Prefs.LANG_EN -> "en-US"; Prefs.LANG_RU -> "ru-RU"; Prefs.LANG_ES -> "es-ES"
        Prefs.LANG_AR -> "ar-SA"; Prefs.LANG_FR -> "fr-FR"; Prefs.LANG_TR -> "tr-TR"
        Prefs.LANG_VI -> "vi-VN"; else -> "pt-BR"
    }

    // ---------- Internos ----------

    private fun alive(gen: Int) = gen == generation

    private fun setState(s: State) { state = s; cb.onState(s) }

    private fun fail(gen: Int, msg: String) {
        if (!alive(gen)) return
        setState(State.IDLE); cb.onError(msg)
    }

    // ---------- Nuvem (chave opcional nas configurações) ----------

    private fun work(gen: Int, lang: String, key: String) {
        var rec: AudioRecord? = null
        try {
            val minBuf = AudioRecord.getMinBufferSize(RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
            val r = AudioRecord(MediaRecorder.AudioSource.VOICE_RECOGNITION, RATE,
                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(minBuf, 8192))
            rec = r
            if (r.state != AudioRecord.STATE_INITIALIZED) { fail(gen, "Microfone indisponível"); return }
            r.startRecording()
            if (!alive(gen)) return
            setState(State.RECORDING)

            val pcm = ByteArrayOutputStream()
            val buf = ByteArray(CHUNK_BYTES)                 // 100 ms por leitura
            val t0 = System.currentTimeMillis()
            var noise = 0.0
            var chunks = 0
            var heard = false
            var loudChunks = 0
            var lastLoud = t0
            while (alive(gen) && !stopRequested) {
                val now = System.currentTimeMillis()
                if (now - t0 > MAX_MS) break
                val n = r.read(buf, 0, buf.size)
                if (n < 0) { fail(gen, "Erro ao gravar o áudio"); return }
                if (n == 0) continue
                pcm.write(buf, 0, n)
                val level = rms(buf, n)
                chunks++
                if (chunks <= 3) noise = maxOf(noise, minOf(level, 1500.0))   // ruído de fundo nos primeiros 300 ms
                val thr = (noise * 2.5).coerceIn(600.0, 2500.0)
                if (level > thr) {
                    loudChunks++
                    lastLoud = now
                    if (loudChunks >= 2) heard = true
                }
                if (heard && now - lastLoud >= SILENCE_MS) break           // parou de falar
                if (!heard && now - t0 > NO_SPEECH_MS) break               // ninguém falou
            }
            try { r.stop() } catch (_: Exception) { }
            if (!alive(gen)) return
            if (!heard) { setState(State.IDLE); cb.onError("Não entendi, tente de novo"); return }

            setState(State.TRANSCRIBING)
            val text = transcribe(wav(pcm.toByteArray()), lang, key, gen) ?: return
            if (!alive(gen)) return
            setState(State.IDLE)
            if (text.isBlank()) cb.onError("Não entendi, tente de novo") else cb.onText(text)
        } catch (e: Throwable) {
            Log.w(TAG, e)
            fail(gen, "Erro no ditado (${e.javaClass.simpleName})")
        } finally {
            try { rec?.stop() } catch (_: Exception) { }
            try { rec?.release() } catch (_: Exception) { }
        }
    }

    private fun rms(b: ByteArray, n: Int): Double {
        var sum = 0.0
        var i = 0
        var count = 0
        while (i + 1 < n) {
            val v = (b[i].toInt() and 0xFF) or (b[i + 1].toInt() shl 8)    // 16 bits com sinal, little-endian
            sum += v.toDouble() * v
            count++
            i += 2
        }
        return if (count == 0) 0.0 else Math.sqrt(sum / count)
    }

    /** PCM 16 kHz mono -> arquivo WAV na memória. */
    private fun wav(pcm: ByteArray): ByteArray {
        val out = ByteArrayOutputStream(pcm.size + 44)
        fun i32(v: Int) { out.write(v and 0xFF); out.write((v shr 8) and 0xFF); out.write((v shr 16) and 0xFF); out.write((v shr 24) and 0xFF) }
        fun i16(v: Int) { out.write(v and 0xFF); out.write((v shr 8) and 0xFF) }
        out.write("RIFF".toByteArray()); i32(36 + pcm.size); out.write("WAVE".toByteArray())
        out.write("fmt ".toByteArray()); i32(16); i16(1); i16(1); i32(RATE); i32(RATE * 2); i16(2); i16(16)
        out.write("data".toByteArray()); i32(pcm.size); out.write(pcm)
        return out.toByteArray()
    }

    /** Envia o WAV e devolve o texto. null = deu erro (já avisado ao usuário). */
    private fun transcribe(wav: ByteArray, lang: String, key: String, gen: Int): String? {
        val groq = key.startsWith("gsk_")
        val url = if (groq) "https://api.groq.com/openai/v1/audio/transcriptions"
                  else "https://api.openai.com/v1/audio/transcriptions"
        val model = if (groq) "whisper-large-v3" else "gpt-4o-transcribe"
        val boundary = "----mk" + System.currentTimeMillis()
        val body = ByteArrayOutputStream()
        fun field(name: String, value: String) {
            body.write(("--$boundary\r\nContent-Disposition: form-data; name=\"$name\"\r\n\r\n$value\r\n").toByteArray())
        }
        field("model", model); field("language", lang); field("response_format", "json"); field("temperature", "0")
        body.write(("--$boundary\r\nContent-Disposition: form-data; name=\"file\"; filename=\"audio.wav\"\r\nContent-Type: audio/wav\r\n\r\n").toByteArray())
        body.write(wav)
        body.write("\r\n--$boundary--\r\n".toByteArray())
        val payload = body.toByteArray()

        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"
            c.doOutput = true
            c.connectTimeout = 15000; c.readTimeout = 60000
            c.setRequestProperty("Authorization", "Bearer $key")
            c.setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")
            c.setFixedLengthStreamingMode(payload.size)
            c.outputStream.use { it.write(payload) }
            val code = c.responseCode
            if (code != 200) {
                val err = try { c.errorStream?.bufferedReader()?.readText() ?: "" } catch (_: Exception) { "" }
                Log.w(TAG, "HTTP $code $err")
                val msg = when (code) {
                    401, 403 -> "Chave do ditado inválida ou sem permissão"
                    429 -> "Limite de uso da chave atingido, tente em instantes"
                    else -> "Erro na transcrição (HTTP $code)"
                }
                fail(gen, msg)
                return null
            }
            val resp = c.inputStream.bufferedReader().readText()
            return JSONObject(resp).optString("text").trim()
        } catch (e: Exception) {
            Log.w(TAG, e)
            val offline = e is java.net.UnknownHostException || e is java.net.SocketTimeoutException || e is java.net.ConnectException
            fail(gen, if (offline) "Sem internet para transcrever a voz" else "Erro na transcrição (${e.javaClass.simpleName})")
            return null
        } finally {
            c.disconnect()
        }
    }

    private companion object {
        const val TAG = "SpeechVoice"
        const val RATE = 16000
        const val CHUNK_BYTES = 3200          // 100 ms de áudio
        const val MAX_MS = 60_000L
        const val NO_SPEECH_MS = 8_000L
        const val SILENCE_MS = 1_400L         // silêncio depois de falar: termina
    }
}

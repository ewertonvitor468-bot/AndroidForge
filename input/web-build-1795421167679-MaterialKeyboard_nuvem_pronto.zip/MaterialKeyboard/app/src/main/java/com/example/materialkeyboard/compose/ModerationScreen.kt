package com.example.materialkeyboard.compose

import android.graphics.BitmapFactory
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.materialkeyboard.L
import com.example.materialkeyboard.keyscafe.BoardReport
import com.example.materialkeyboard.keyscafe.BoardResult
import com.example.materialkeyboard.keyscafe.BoardTheme
import com.example.materialkeyboard.keyscafe.ReportCategory
import com.example.materialkeyboard.keyscafe.ReviewData
import com.example.materialkeyboard.keyscafe.ThemeBoardApi
import com.example.materialkeyboard.tr
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Fila de moderação do ThemeBoard (só aparece para contas moderadoras). Duas abas:
 *  - Temas: pendentes de revisão. "Revisar" baixa o pacote SEM instalar, mostra a prévia real e, se houver, a
 *    imagem de fundo, para conferir conteúdo impróprio/+18 antes de Aprovar ou Recusar (com motivo).
 *  - Denúncias: abertas. Descartar ou Ocultar o tema.
 * Quem decide é o servidor: uma conta comum que chamasse isso receberia erro de permissão.
 */
@Composable
fun ModerationDialog(onClose: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val cs = MaterialTheme.colorScheme

    var tab by remember { mutableIntStateOf(0) }
    var reload by remember { mutableIntStateOf(0) }
    val themes = remember { mutableStateListOf<BoardTheme>() }
    val reports = remember { mutableStateListOf<BoardReport>() }
    var loading by remember { mutableStateOf(true) }
    var working by remember { mutableStateOf(false) }
    var note by remember { mutableStateOf<String?>(null) }
    var reviewing by remember { mutableStateOf<BoardTheme?>(null) }
    var hiding by remember { mutableStateOf<BoardReport?>(null) }

    LaunchedEffect(reload) {
        loading = true
        val rt = withContext(Dispatchers.IO) { ThemeBoardApi.pendingThemes(ctx) }
        val rr = withContext(Dispatchers.IO) { ThemeBoardApi.openReports(ctx) }
        themes.clear()
        reports.clear()
        var err: String? = null
        when (rt) {
            is BoardResult.Ok -> themes.addAll(rt.value)
            is BoardResult.Fail -> err = rt.reason
        }
        when (rr) {
            is BoardResult.Ok -> reports.addAll(rr.value)
            is BoardResult.Fail -> if (err == null) err = rr.reason
        }
        if (err != null) note = err.tr()
        loading = false
    }

    fun resolveReport(r: BoardReport, hide: Boolean) {
        working = true
        scope.launch {
            val res = withContext(Dispatchers.IO) { ThemeBoardApi.moderateReport(ctx, r.id, hide, null) }
            working = false
            note = if (res is BoardResult.Fail) res.reason.tr()
            else (if (hide) "Tema ocultado." else "Denúncia descartada.").tr()
            reload++
        }
    }

    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxSize(), color = cs.surface) {
            Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("Moderação".tr(), color = cs.primary, fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
                    TextButton(onClick = { reload++ }, enabled = !loading) { Text("Atualizar".tr()) }
                    TextButton(onClick = onClose) { Text("Fechar".tr()) }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(tab == 0, { tab = 0 }, { Text(L.f("Temas (%d)", themes.size)) })
                    FilterChip(tab == 1, { tab = 1 }, { Text(L.f("Denúncias (%d)", reports.size)) })
                }
                note?.let { Text(it, color = cs.onSurface.copy(alpha = 0.8f), style = MaterialTheme.typography.bodyMedium) }
                if (loading) {
                    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                        MkLoadingIndicator(size = 22.dp)
                        Spacer(Modifier.width(8.dp))
                        Text("Carregando…".tr(), color = cs.onSurface.copy(alpha = 0.6f), style = MaterialTheme.typography.bodySmall)
                    }
                }
                LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    if (tab == 0) {
                        if (!loading && themes.isEmpty()) item {
                            Text("Nenhum tema esperando revisão.".tr(), color = cs.onSurface.copy(alpha = 0.7f))
                        }
                        items(themes, key = { it.id }) { t -> ThemeQueueRow(t) { reviewing = t } }
                    } else {
                        if (!loading && reports.isEmpty()) item {
                            Text("Nenhuma denúncia aberta.".tr(), color = cs.onSurface.copy(alpha = 0.7f))
                        }
                        items(reports, key = { it.id }) { r ->
                            ReportRow(r, enabled = !working, onDismiss = { resolveReport(r, false) }, onHide = { hiding = r })
                        }
                    }
                }
            }
        }
    }

    reviewing?.let { t ->
        ReviewDialog(t) { msg ->
            reviewing = null
            if (msg != null) { note = msg; reload++ }
        }
    }

    hiding?.let { r ->
        AlertDialog(
            onDismissRequest = { hiding = null },
            title = { Text("Ocultar este tema?".tr()) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(r.themeTitle, fontWeight = FontWeight.SemiBold)
                    Text("Ele sai do ThemeBoard e todas as denúncias abertas dele são resolvidas.".tr(),
                        style = MaterialTheme.typography.bodySmall)
                }
            },
            confirmButton = { TextButton(onClick = { hiding = null; resolveReport(r, true) }) { Text("Ocultar tema".tr()) } },
            dismissButton = { TextButton(onClick = { hiding = null }) { Text("Cancelar".tr()) } }
        )
    }
}

@Composable
private fun ThemeQueueRow(t: BoardTheme, onReview: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(cs.surfaceVariant.copy(alpha = 0.5f)).padding(12.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(t.title, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(L.f("por %s", t.authorName.ifBlank { "—" }), style = MaterialTheme.typography.bodySmall,
                color = cs.onSurface.copy(alpha = 0.65f), maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (t.description.isNotBlank()) Text(t.description, style = MaterialTheme.typography.bodySmall,
                maxLines = 2, overflow = TextOverflow.Ellipsis)
        }
        Spacer(Modifier.width(8.dp))
        Button(onClick = onReview) { Text("Revisar".tr()) }
    }
}

@Composable
private fun ReportRow(r: BoardReport, enabled: Boolean, onDismiss: () -> Unit, onHide: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val cat = ReportCategory.values().firstOrNull { it.key == r.category }?.label ?: r.category
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(cs.surfaceVariant.copy(alpha = 0.5f)).padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(r.themeTitle, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text(L.f("Motivo: %s", cat.tr()), style = MaterialTheme.typography.labelMedium, color = cs.primary)
        Text(r.reason, style = MaterialTheme.typography.bodyMedium)
        if (r.themeStatus != "approved") Text("Este tema não está mais público.".tr(),
            style = MaterialTheme.typography.bodySmall, color = cs.onSurface.copy(alpha = 0.6f))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = onDismiss, enabled = enabled) { Text("Descartar".tr()) }
            Button(onClick = onHide, enabled = enabled) { Text("Ocultar tema".tr()) }
        }
    }
}

/** Revisão de um tema pendente. [onDone]: mensagem para a fila (ação feita) ou null (só fechou). */
@Composable
private fun ReviewDialog(t: BoardTheme, onDone: (String?) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val cs = MaterialTheme.colorScheme
    val data by produceState<BoardResult<ReviewData>?>(null, t.id) {
        value = withContext(Dispatchers.IO) { ThemeBoardApi.reviewPackage(ctx, t) }
    }
    var rejecting by remember { mutableStateOf(false) }
    var reason by remember { mutableStateOf("") }
    var working by remember { mutableStateOf(false) }
    var err by remember { mutableStateOf<String?>(null) }

    val loaded = (data as? BoardResult.Ok<*>)?.value as? ReviewData
    val canApprove = loaded != null && loaded.shaOk && !working

    fun decide(approve: Boolean) {
        working = true; err = null
        scope.launch {
            val r = withContext(Dispatchers.IO) { ThemeBoardApi.moderateTheme(ctx, t.id, approve, if (approve) null else reason) }
            working = false
            when (r) {
                is BoardResult.Fail -> err = r.reason.tr()
                is BoardResult.Ok -> onDone(L.f(if (approve) "Tema aprovado: %s" else "Tema recusado: %s", t.title))
            }
        }
    }

    Dialog(onDismissRequest = { if (!working) onDone(null) }, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxSize(), color = cs.surface) {
            Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("Revisar tema".tr(), color = cs.primary, fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
                    TextButton(onClick = { if (!working) onDone(null) }) { Text("Fechar".tr()) }
                }
                Column(Modifier.weight(1f).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(t.title, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                    Text(L.f("por %s", t.authorName.ifBlank { "—" }), color = cs.onSurface.copy(alpha = 0.7f),
                        style = MaterialTheme.typography.bodySmall)
                    if (t.description.isNotBlank()) Text(t.description)

                    when (val d = data) {
                        null -> Row(verticalAlignment = Alignment.CenterVertically) {
                            MkLoadingIndicator(size = 22.dp)
                            Spacer(Modifier.width(8.dp))
                            Text("Baixando o pacote para conferir…".tr(), style = MaterialTheme.typography.bodySmall)
                        }
                        is BoardResult.Fail -> Text(d.reason.tr(), color = cs.error)
                        is BoardResult.Ok -> {
                            val rv = d.value
                            if (!rv.shaOk) Text("O arquivo NÃO confere com o registro (SHA-256). Não aprove.".tr(),
                                color = cs.error, fontWeight = FontWeight.SemiBold)
                            if (rv.spec.name != t.title) Text(L.f("Nome dentro do pacote: %s", rv.spec.name),
                                style = MaterialTheme.typography.bodySmall)
                            if (rv.spec.inspiredBy.isNotBlank()) Text(L.f("Inspirado em: %s", rv.spec.inspiredBy),
                                style = MaterialTheme.typography.bodySmall)
                            val prev = remember(rv) { rv.previewWebp?.let { b -> decode(b, 1024) } }
                            prev?.let {
                                Text("Como o teclado fica:".tr(), style = MaterialTheme.typography.labelMedium, color = cs.primary)
                                Image(it, null, Modifier.fillMaxWidth().aspectRatio(2f).clip(RoundedCornerShape(14.dp)), contentScale = ContentScale.Crop)
                            }
                            val img = remember(rv) { rv.image?.let { b -> decode(b, 1024) } }
                            if (rv.image != null) {
                                Text("Imagem de fundo do tema (confira se há conteúdo impróprio ou +18):".tr(),
                                    style = MaterialTheme.typography.labelMedium, color = cs.primary)
                                if (img != null) Image(img, null, Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)), contentScale = ContentScale.FillWidth)
                                else Text("Não foi possível abrir a imagem. Recuse o tema.".tr(), color = cs.error)
                            }
                            rv.warnings.forEach { Text("• " + it.tr(), style = MaterialTheme.typography.bodySmall,
                                color = cs.onSurface.copy(alpha = 0.7f)) }
                        }
                    }
                    err?.let { Text(it, color = cs.error) }
                }
                if (rejecting) {
                    OutlinedTextField(reason, { if (it.length <= 300) reason = it }, modifier = Modifier.fillMaxWidth(),
                        placeholder = { Text("Motivo da recusa (aparece para o autor)".tr()) })
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        TextButton(onClick = { rejecting = false }, enabled = !working) { Text("Voltar".tr()) }
                        Button(onClick = { decide(false) }, enabled = !working && reason.trim().length >= 3) {
                            Text((if (working) "Aguarde…" else "Confirmar recusa").tr())
                        }
                    }
                } else {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { rejecting = true }, enabled = !working && data != null) { Text("Recusar".tr()) }
                        Button(onClick = { decide(true) }, enabled = canApprove) { Text((if (working) "Aguarde…" else "Aprovar").tr()) }
                    }
                }
            }
        }
    }
}

/** Decodifica reduzindo a imagem (nunca carrega uma foto enorme inteira só para conferir). */
private fun decode(b: ByteArray, max: Int): ImageBitmap? = try {
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeByteArray(b, 0, b.size, bounds)
    var sample = 1
    while (bounds.outWidth / sample > max || bounds.outHeight / sample > max) sample *= 2
    BitmapFactory.decodeByteArray(b, 0, b.size, BitmapFactory.Options().apply { inSampleSize = sample })?.asImageBitmap()
} catch (_: Throwable) { null }

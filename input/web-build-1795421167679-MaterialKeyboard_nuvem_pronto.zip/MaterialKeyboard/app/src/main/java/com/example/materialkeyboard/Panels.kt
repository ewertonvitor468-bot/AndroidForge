package com.example.materialkeyboard

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.text.TextUtils
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.core.graphics.ColorUtils
import androidx.dynamicanimation.animation.DynamicAnimation

fun Context.dpi(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

/** Botão de ícone (vetor tingido) com ripple circular; usado na barra de ferramentas e nos painéis. */
fun iconButton(ctx: Context, res: Int, tint: Int, desc: String, sizeDp: Int = 40, onClick: () -> Unit): ImageView =
    ImageView(ctx).apply {
        setImageDrawable(ContextCompat.getDrawable(ctx, res)?.mutate())
        setColorFilter(tint)
        contentDescription = desc
        scaleType = ImageView.ScaleType.CENTER_INSIDE
        val pad = ctx.dpi(sizeDp / 5)
        setPadding(pad, pad, pad, pad)
        layoutParams = LinearLayout.LayoutParams(ctx.dpi(sizeDp), ctx.dpi(sizeDp))
        val mask = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0xFFFFFFFF.toInt()) }
        background = RippleDrawable(ColorStateList.valueOf(ColorUtils.setAlphaComponent(tint, 70)), null, mask)
        setOnClickListener { onClick() }
        setOnTouchListener { v, e ->
            if (Prefs.get(ctx).fluid) when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { v.springTo(DynamicAnimation.SCALE_X, 0.80f, 900f, 0.6f); v.springTo(DynamicAnimation.SCALE_Y, 0.80f, 900f, 0.6f) }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { v.springTo(DynamicAnimation.SCALE_X, 1f, 500f, 0.38f); v.springTo(DynamicAnimation.SCALE_Y, 1f, 500f, 0.38f) }
            }
            false
        }
    }

internal fun roundedBg(color: Int, radiusPx: Float, rippleColor: Int): RippleDrawable {
    val shape = GradientDrawable().apply { cornerRadius = radiusPx; setColor(color) }
    return RippleDrawable(ColorStateList.valueOf(ColorUtils.setAlphaComponent(rippleColor, 60)), shape, null)
}

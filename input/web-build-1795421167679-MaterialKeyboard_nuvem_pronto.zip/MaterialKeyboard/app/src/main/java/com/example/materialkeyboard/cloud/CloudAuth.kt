package com.example.materialkeyboard.cloud

import android.app.Activity
import android.content.Context
import android.os.CancellationSignal
import androidx.core.content.ContextCompat
import androidx.credentials.ClearCredentialStateRequest
import androidx.credentials.Credential
import androidx.credentials.CredentialManager
import androidx.credentials.CredentialManagerCallback
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.GetCredentialResponse
import androidx.credentials.exceptions.ClearCredentialException
import androidx.credentials.exceptions.GetCredentialCancellationException
import androidx.credentials.exceptions.GetCredentialException
import androidx.credentials.exceptions.NoCredentialException
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.android.libraries.identity.googleid.GoogleIdTokenParsingException
import com.google.firebase.FirebaseApp
import com.google.firebase.FirebaseOptions
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.GoogleAuthProvider

class CloudUser(val uid: String, val email: String, val name: String)

/**
 * Login exclusivo com o Google (Firebase Authentication). O Firebase só é iniciado quando alguém abre a página
 * "Conta e nuvem" (ou quando o backup automático está ligado): o teclado e o resto do app nunca tocam nele,
 * então tudo continua funcionando offline e sem conta.
 */
object CloudAuth {
    enum class Fail { NOT_CONFIGURED, CANCELLED, NO_ACCOUNT, FAILED }
    class Outcome(val user: CloudUser?, val fail: Fail?, val detail: String = "")

    /** Inicia o Firebase com as opções de [CloudConfig] (uma vez). false se a nuvem não está configurada ou o início falhou. */
    @Synchronized
    fun ensure(ctx: Context): Boolean {
        if (!CloudConfig.configured) return false
        return try {
            if (FirebaseApp.getApps(ctx.applicationContext).isEmpty()) {
                val o = FirebaseOptions.Builder()
                    .setApiKey(CloudConfig.API_KEY)
                    .setApplicationId(CloudConfig.APP_ID)
                    .setProjectId(CloudConfig.PROJECT_ID)
                    .build()
                FirebaseApp.initializeApp(ctx.applicationContext, o)
            }
            true
        } catch (_: Exception) { false }
    }

    fun user(): CloudUser? = try {
        FirebaseAuth.getInstance().currentUser?.let { CloudUser(it.uid, it.email ?: "", it.displayName ?: "") }
    } catch (_: Exception) { null }

    fun uid(): String? = try { FirebaseAuth.getInstance().currentUser?.uid } catch (_: Exception) { null }

    /** Abre a folha de contas do Google e entra no Firebase. O retorno vem na thread principal. Precisa de uma Activity. */
    fun signIn(act: Activity, cb: (Outcome) -> Unit) {
        if (!ensure(act)) { cb(Outcome(null, Fail.NOT_CONFIGURED)); return }
        val request = GetCredentialRequest.Builder()
            .addCredentialOption(GetSignInWithGoogleOption.Builder(CloudConfig.WEB_CLIENT_ID).build())
            .build()
        try {
            CredentialManager.create(act).getCredentialAsync(
                act, request, CancellationSignal(), ContextCompat.getMainExecutor(act),
                object : CredentialManagerCallback<GetCredentialResponse, GetCredentialException> {
                    override fun onResult(result: GetCredentialResponse) { withFirebase(result.credential, cb) }
                    override fun onError(e: GetCredentialException) {
                        val f = when (e) {
                            is GetCredentialCancellationException -> Fail.CANCELLED
                            is NoCredentialException -> Fail.NO_ACCOUNT
                            else -> Fail.FAILED
                        }
                        cb(Outcome(null, f, e.javaClass.simpleName))
                    }
                })
        } catch (e: Exception) { cb(Outcome(null, Fail.FAILED, e.javaClass.simpleName)) }
    }

    private fun withFirebase(c: Credential, cb: (Outcome) -> Unit) {
        if (c !is CustomCredential || c.type != GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
            cb(Outcome(null, Fail.FAILED, "credential")); return
        }
        try {
            val token = GoogleIdTokenCredential.createFrom(c.data).idToken
            FirebaseAuth.getInstance().signInWithCredential(GoogleAuthProvider.getCredential(token, null))
                .addOnCompleteListener { t ->
                    if (t.isSuccessful) cb(Outcome(user(), null))
                    else cb(Outcome(null, Fail.FAILED, t.exception?.javaClass?.simpleName ?: ""))
                }
        } catch (e: GoogleIdTokenParsingException) {
            cb(Outcome(null, Fail.FAILED, "token"))
        } catch (e: Exception) {
            cb(Outcome(null, Fail.FAILED, e.javaClass.simpleName))
        }
    }

    /** Sai do Firebase e esquece a conta escolhida (para a próxima entrada mostrar a lista de contas de novo). */
    fun signOut(act: Activity) {
        try { FirebaseAuth.getInstance().signOut() } catch (_: Exception) { }
        try {
            CredentialManager.create(act).clearCredentialStateAsync(
                ClearCredentialStateRequest(), CancellationSignal(), ContextCompat.getMainExecutor(act),
                object : CredentialManagerCallback<Void?, ClearCredentialException> {
                    override fun onResult(result: Void?) {}
                    override fun onError(e: ClearCredentialException) {}
                })
        } catch (_: Exception) { }
    }
}

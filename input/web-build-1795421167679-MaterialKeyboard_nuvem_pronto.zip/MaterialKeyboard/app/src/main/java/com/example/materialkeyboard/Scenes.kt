package com.example.materialkeyboard

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.Rect
import android.graphics.Shader
import android.graphics.drawable.Drawable
import android.view.Choreographer
import android.view.View
import kotlin.math.sin
import kotlin.random.Random

/**
 * Cenário animado: SÓ as partículas (1 = Outono, folhas vermelhas; 2 = Inverno, flocos de neve; 3 = Tempestade, chuva).
 * Transparente: o fundo é o que a pessoa escolheu (tema, cor ou imagem). Usado como foreground do teclado,
 * sem alocar nada a cada quadro.
 * A animação só roda enquanto o teclado está visível: para sozinha ao esconder ou sair da janela.
 */
class SceneDrawable(
    private val kind: Int, private val topR: Float, private val dens: Float,
    /** true = tem o próprio relógio de quadros (miniaturas); false = quem manda é o [FxOverlay], via [tick]. */
    private val selfDriven: Boolean = true
) : Drawable() {

    private val rnd = Random(kind * 977 + 13)
    private val n = when (kind) { AUTUMN -> 16; WINTER -> 34; else -> 48 }
    private val px = FloatArray(n) { rnd.nextFloat() }                 // posição 0..1
    private val py = FloatArray(n) { rnd.nextFloat() }
    private val sz = FloatArray(n) { 0.6f + rnd.nextFloat() * 0.8f }   // fator de tamanho
    private val spd = FloatArray(n) { 0.7f + rnd.nextFloat() * 0.8f }  // fator de velocidade
    private val ph = FloatArray(n) { rnd.nextFloat() * 6.2832f }
    private val rot = FloatArray(n) { rnd.nextFloat() * 360f }
    private val col = IntArray(n) { LEAF[rnd.nextInt(LEAF.size)] }

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val clip = Path()
    private val leaf = Path().apply {
        moveTo(0f, -1f); quadTo(1f, -0.25f, 0f, 1f); quadTo(-1f, -0.25f, 0f, -1f); close()
    }
    private var bw = 0f
    private var bh = 0f
    private var running = false
    private var last = 0L
    private var t = 0f
    private var flash = 0f
    private var nextFlash = 4f

    private val frame = object : Choreographer.FrameCallback {
        override fun doFrame(now: Long) {
            if (!running) return
            val cb = callback
            if (cb == null || (cb is View && !cb.isAttachedToWindow)) { running = false; return }   // view saiu da tela
            val dt = if (last == 0L) 0.016f else ((now - last) / 1_000_000_000f).coerceIn(0f, 0.05f)
            last = now
            step(dt)
            invalidateSelf()
            Choreographer.getInstance().postFrameCallback(this)
        }
    }

    /** Avança a animação em [dt] segundos (usado pelo overlay do teclado, que controla o relógio). */
    fun tick(dt: Float) { if (kind > 0) step(dt) }

    private fun start() {
        if (!selfDriven || running || kind <= 0) return
        running = true; last = 0L
        Choreographer.getInstance().postFrameCallback(frame)
    }

    private fun stop() {
        running = false
        Choreographer.getInstance().removeFrameCallback(frame)
    }

    override fun setVisible(visible: Boolean, restart: Boolean): Boolean {
        val changed = super.setVisible(visible, restart)
        if (visible) start() else stop()
        return changed
    }

    override fun onBoundsChange(b: Rect) {
        bw = b.width().toFloat(); bh = b.height().toFloat()
        if (bw <= 0f || bh <= 0f) return
        clip.rewind()
        clip.addRoundRect(RectF(0f, 0f, bw, bh), floatArrayOf(topR, topR, topR, topR, 0f, 0f, 0f, 0f), Path.Direction.CW)
    }

    private fun step(dt: Float) {
        t += dt
        val slant = if (bw > 0f) bh / bw else 1f
        for (i in 0 until n) {
            when (kind) {
                AUTUMN -> {
                    py[i] += 0.12f * spd[i] * dt
                    px[i] += sin(t * 1.1f + ph[i]) * 0.06f * dt + 0.008f * dt
                    rot[i] += (if (i % 2 == 0) 55f else -55f) * spd[i] * dt
                    if (py[i] > 1.08f) { py[i] = -0.08f; px[i] = rnd.nextFloat() }
                }
                WINTER -> {
                    py[i] += 0.06f * spd[i] * dt
                    px[i] += sin(t * 0.7f + ph[i]) * 0.035f * dt
                    rot[i] += 20f * dt
                    if (py[i] > 1.05f) { py[i] = -0.05f; px[i] = rnd.nextFloat() }
                }
                else -> {
                    py[i] += 1.15f * spd[i] * dt
                    px[i] -= 0.2f * 1.15f * spd[i] * dt * slant
                    if (py[i] > 1.05f) { py[i] = -0.1f; px[i] = rnd.nextFloat() * 1.3f }
                }
            }
            if (px[i] > 1.06f) px[i] = -0.06f else if (px[i] < -0.3f && kind != STORM) px[i] = 1.06f
        }
        if (kind == STORM) {
            nextFlash -= dt
            if (nextFlash <= 0f) { flash = 0.2f; nextFlash = 5f + rnd.nextFloat() * 6f }
            if (flash > 0f) flash = (flash - dt * 1.1f).coerceAtLeast(0f)
        }
    }

    override fun draw(c: Canvas) {
        if (bw <= 0f || bh <= 0f) return
        c.save()
        c.translate(bounds.left.toFloat(), bounds.top.toFloat())
        c.clipRect(0f, 0f, bw, bh)          // clipPath a cada quadro é caro; os cantos são tratados em corner()
        paint.shader = null
        when (kind) {
            AUTUMN -> for (i in 0 until n) {
                if (corner(px[i] * bw, py[i] * bh)) continue
                c.save()
                c.translate(px[i] * bw, py[i] * bh)
                c.rotate(rot[i])
                val s = 8f * dens * sz[i]
                c.scale(s * 0.62f, s)
                paint.style = Paint.Style.FILL; paint.color = col[i]
                c.drawPath(leaf, paint)
                paint.style = Paint.Style.STROKE; paint.strokeWidth = 0.09f
                paint.color = Color.argb(110, 60, 0, 0)
                c.drawLine(0f, -0.9f, 0f, 0.95f, paint)
                c.restore()
            }
            WINTER -> for (i in 0 until n) {
                val r = 1.7f * dens * sz[i]
                val x = px[i] * bw; val y = py[i] * bh
                if (corner(x, y)) continue
                paint.color = Color.argb(if (sz[i] > 1.1f) 235 else 175, 255, 255, 255)
                if (sz[i] > 1.1f) {                                   // flocos grandes: estrela de 6 pontas
                    paint.style = Paint.Style.STROKE; paint.strokeWidth = dens * 0.9f
                    paint.strokeCap = Paint.Cap.ROUND
                    c.save(); c.translate(x, y); c.rotate(rot[i])
                    for (k in 0 until 3) { c.drawLine(-r * 1.9f, 0f, r * 1.9f, 0f, paint); c.rotate(60f) }
                    c.restore()
                } else {
                    paint.style = Paint.Style.FILL
                    c.drawCircle(x, y, r, paint)
                    paint.style = Paint.Style.STROKE; paint.strokeWidth = dens * 0.6f      // contorno fino: aparece também em fundo claro
                    paint.color = Color.argb(90, 110, 140, 190)
                    c.drawCircle(x, y, r, paint)
                }
            }
            else -> {
                paint.style = Paint.Style.STROKE; paint.strokeWidth = dens * 1.1f; paint.strokeCap = Paint.Cap.ROUND
                paint.color = Color.argb(125, 190, 215, 255)
                for (i in 0 until n) {
                    val len = dens * (9f + 9f * sz[i])
                    val x = px[i] * bw; val y = py[i] * bh
                    if (corner(x, y)) continue
                    c.drawLine(x, y, x - 0.2f * len, y + len, paint)
                }
                if (flash > 0f) {
                    paint.style = Paint.Style.FILL
                    paint.color = Color.argb((flash * 255).toInt().coerceIn(0, 255), 235, 242, 255)
                    c.drawPath(clip, paint)         // respeita os cantos arredondados
                }
            }
        }
        paint.strokeCap = Paint.Cap.BUTT
        c.restore()
    }

    /** Dentro da zona dos cantos de cima (arredondados): não desenha, para não vazar para fora do teclado. */
    private fun corner(x: Float, y: Float) = topR > 0f && y < topR && (x < topR || x > bw - topR)

    override fun setAlpha(alpha: Int) {}
    override fun setColorFilter(cf: ColorFilter?) {}
    @Suppress("OVERRIDE_DEPRECATION")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT

    companion object {
        const val AUTUMN = 1
        const val WINTER = 2
        const val STORM = 3
        private val LEAF = intArrayOf(0xFFC62828.toInt(), 0xFFB71C1C.toInt(), 0xFFD84315.toInt(), 0xFFE53935.toInt(), 0xFF8E1B14.toInt())
    }
}

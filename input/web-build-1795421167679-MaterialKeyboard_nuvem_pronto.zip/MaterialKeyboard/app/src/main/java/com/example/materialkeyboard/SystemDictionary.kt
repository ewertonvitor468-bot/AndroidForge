package com.example.materialkeyboard

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.view.textservice.SentenceSuggestionsInfo
import android.view.textservice.SpellCheckerSession
import android.view.textservice.SuggestionsInfo
import android.view.textservice.TextInfo
import android.view.textservice.TextServicesManager
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap

/**
 * Ponte com o corretor ortográfico do próprio Android (TextServicesManager / SpellCheckerSession,
 * parte aberta do AOSP, presente em todo aparelho). Ele já traz um dicionário bem maior que o
 * pequeno dicionário embutido no app, no idioma que o usuário escolheu em "Idioma do teclado".
 *
 * Usado só para REFORÇAR a autocorreção ("Melhorar precisão do corretor"), nunca para travar a
 * digitação: a consulta é sempre assíncrona. Se a resposta demorar ou não vier, o chamador recebe
 * uma lista vazia; quem decide se ainda vale aplicar a sugestão (palavra ainda intacta, cursor no
 * mesmo lugar) é o KeyboardService, do mesmo jeito que já fazia para a correção local.
 */
class SystemDictionary(ctx: Context) {

    private val appCtx = ctx.applicationContext
    private val main = Handler(Looper.getMainLooper())
    private val callbacks = ConcurrentHashMap<Int, (List<String>) -> Unit>()
    private var cookieSeq = 0

    @Volatile private var session: SpellCheckerSession? = null
    @Volatile private var sessionLang = ""
    @Volatile private var triedAndFailed = false   // aparelho sem corretor instalado: não tenta de novo

    private val listener = object : SpellCheckerSession.SpellCheckerSessionListener {
        override fun onGetSuggestions(results: Array<out SuggestionsInfo>?) {
            val info = results?.firstOrNull() ?: return
            finish(info.cookie, info)
        }
        override fun onGetSentenceSuggestions(results: Array<out SentenceSuggestionsInfo>?) { }
    }

    private fun finish(cookie: Int, info: SuggestionsInfo) {
        val cb = callbacks.remove(cookie) ?: return
        try {
            val n = info.suggestionsCount.coerceAtLeast(0)
            cb((0 until n).map { info.getSuggestionAt(it) })
        } catch (_: Exception) { cb(emptyList()) }
    }

    private fun localeFor(langCode: String): Locale = when (langCode) {
        Prefs.LANG_EN -> Locale.ENGLISH
        Prefs.LANG_RU -> Locale("ru")
        Prefs.LANG_ES -> Locale("es")
        Prefs.LANG_AR -> Locale("ar")
        Prefs.LANG_FR -> Locale("fr")
        Prefs.LANG_TR -> Locale("tr")
        Prefs.LANG_VI -> Locale("vi")
        else -> Locale("pt", "BR")
    }

    /** Deve ser chamado sempre na thread principal (é onde o Android entrega as respostas). */
    private fun ensureSession(langCode: String): SpellCheckerSession? {
        if (session != null && sessionLang == langCode) return session
        if (triedAndFailed && sessionLang == langCode) return null
        return try {
            session?.close()
            session = null
            val tsm = appCtx.getSystemService(Context.TEXT_SERVICES_MANAGER_SERVICE) as? TextServicesManager
            val s = tsm?.newSpellCheckerSession(null, localeFor(langCode), listener, true)
            session = s
            sessionLang = langCode
            triedAndFailed = s == null
            s
        } catch (_: Exception) {
            triedAndFailed = true
            null
        }
    }

    /**
     * Pede sugestões para [word] no idioma [langCode]. [callback] é chamado mais tarde, sempre na
     * thread principal (lista vazia se o corretor do sistema não existir ou não responder a tempo).
     */
    fun suggest(word: String, langCode: String, callback: (List<String>) -> Unit) {
        main.post {
            val s = ensureSession(langCode)
            if (s == null) { callback(emptyList()); return@post }
            val cookie = ++cookieSeq
            callbacks[cookie] = callback
            try {
                s.getSuggestions(TextInfo(word, cookie, 0), 3)
            } catch (_: Exception) {
                callbacks.remove(cookie)
                callback(emptyList())
                return@post
            }
            // evita vazar o callback para sempre se a resposta nunca chegar
            main.postDelayed({ callbacks.remove(cookie)?.invoke(emptyList()) }, 1200)
        }
    }

    fun close() {
        main.post { try { session?.close() } catch (_: Exception) { }; session = null; callbacks.clear() }
    }
}

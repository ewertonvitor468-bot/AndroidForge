package com.example.materialkeyboard

import android.content.Context
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.common.model.RemoteModelManager
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.TranslateRemoteModel
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions

/** Idiomas oferecidos (todos suportados pelo ML Kit Translation). */
object TLangs {
    class Lang(val code: String, val name: String, val short: String)

    /** Os nomes dos idiomas novos ficam na própria língua (العربية, हिन्दी, 中文...): servem em qualquer idioma da interface. */
    private val extra = listOf(
        "ar" to "العربية", "fa" to "فارسی", "hi" to "हिन्दी", "bn" to "বাংলা", "ur" to "اردو",
        "zh" to "中文", "ja" to "日本語", "ko" to "한국어", "id" to "Bahasa Indonesia", "ms" to "Bahasa Melayu",
        "th" to "ไทย", "tl" to "Filipino", "de" to "Deutsch", "it" to "Italiano", "nl" to "Nederlands",
        "pl" to "Polski", "uk" to "Українська", "el" to "Ελληνικά", "he" to "עברית", "ro" to "Română",
        "cs" to "Čeština", "sv" to "Svenska", "da" to "Dansk", "fi" to "Suomi", "no" to "Norsk",
        "hu" to "Magyar", "bg" to "Български", "hr" to "Hrvatski", "sk" to "Slovenčina", "sl" to "Slovenščina",
        "ca" to "Català", "sw" to "Kiswahili", "ta" to "தமிழ்", "te" to "తెలుగు", "mr" to "मराठी",
        "gu" to "ગુજરાતી", "kn" to "ಕನ್ನಡ", "af" to "Afrikaans", "lt" to "Lietuvių", "lv" to "Latviešu", "et" to "Eesti"
    ).map { (c, n) -> Lang(c, n, c.uppercase()) }

    val all: List<Lang> = listOf(
        Lang(TranslateLanguage.PORTUGUESE, "Português", "PT"),
        Lang(TranslateLanguage.ENGLISH, "Inglês", "EN"),
        Lang(TranslateLanguage.ARABIC, "Árabe", "AR"),
        Lang(TranslateLanguage.RUSSIAN, "Russo", "RU"),
        Lang(TranslateLanguage.SPANISH, "Espanhol", "ES"),
        Lang(TranslateLanguage.FRENCH, "Francês", "FR"),
        Lang(TranslateLanguage.TURKISH, "Turco", "TR"),
        Lang(TranslateLanguage.VIETNAMESE, "Vietnamita", "VI")
    ) + extra.filter { it.code != TranslateLanguage.ARABIC }

    fun indexOf(code: String): Int = all.indexOfFirst { it.code == code }.coerceAtLeast(0)
    fun of(code: String): Lang = all[indexOf(code)]
}

/**
 * Preferências do tradutor em arquivo PRÓPRIO. Motivo: qualquer mudança em [Prefs] recria o teclado
 * inteiro; trocar idioma pela barra do teclado não pode causar isso.
 */
class TranslatorPrefs private constructor(ctx: Context) {
    private val sp = ctx.applicationContext.getSharedPreferences("translator_prefs", Context.MODE_PRIVATE)

    private fun lang(key: String, def: String): String {
        val v = sp.getString(key, def) ?: def
        return if (TLangs.all.any { it.code == v }) v else def
    }

    var source: String
        get() = lang("source", TranslateLanguage.PORTUGUESE)
        set(v) { sp.edit().putString("source", v).apply() }
    var target: String
        get() = lang("target", TranslateLanguage.ENGLISH)
        set(v) { sp.edit().putString("target", v).apply() }
    /** Pausa (ms) sem digitar antes de atualizar a tradução. */
    var delayMs: Int
        get() = sp.getInt("delayMs", 600).coerceIn(200, 2000)
        set(v) { sp.edit().putInt("delayMs", v).apply() }
    var wifiOnly: Boolean
        get() = sp.getBoolean("wifiOnly", false)
        set(v) { sp.edit().putBoolean("wifiOnly", v).apply() }

    fun clear() { sp.edit().clear().apply() }

    companion object {
        @Volatile private var inst: TranslatorPrefs? = null
        fun get(ctx: Context): TranslatorPrefs =
            inst ?: synchronized(this) { inst ?: TranslatorPrefs(ctx).also { inst = it } }
    }
}

class TranslateError(msg: String) : Exception(msg)

/**
 * Tradução no aparelho com o Google ML Kit. Os modelos NÃO ficam no APK: o par de idiomas só é baixado
 * (uma vez) quando há algo para traduzir. Usar só na thread principal (os callbacks do ML Kit já voltam nela).
 */
class TranslationEngine {
    private var translator: Translator? = null
    private var pairKey: String? = null
    private val ready = HashSet<String>()
    private var seq = 0

    /** Descarta qualquer resultado pendente. */
    fun cancel() { seq++ }

    fun release() {
        seq++
        translator?.close(); translator = null; pairKey = null
        ready.clear()
    }

    private fun clientFor(src: String, dst: String): Translator {
        val key = "$src>$dst"
        if (pairKey != key) {
            translator?.close()
            translator = Translation.getClient(
                TranslatorOptions.Builder().setSourceLanguage(src).setTargetLanguage(dst).build())
            pairKey = key
        }
        return translator!!
    }

    fun translate(
        text: String, src: String, dst: String, wifiOnly: Boolean,
        onDownloading: () -> Unit, onResult: (Result<String>) -> Unit
    ) {
        val my = ++seq
        execute(my, text, src, dst, wifiOnly, true, onDownloading, onResult)
    }

    private fun execute(
        my: Int, text: String, src: String, dst: String, wifiOnly: Boolean, retry: Boolean,
        onDownloading: () -> Unit, onResult: (Result<String>) -> Unit
    ) {
        val key = "$src>$dst"
        val t = clientFor(src, dst)
        fun doTranslate() {
            t.translate(text)
                .addOnSuccessListener { if (my == seq) onResult(Result.success(it)) }
                .addOnFailureListener {
                    if (my != seq) return@addOnFailureListener
                    if (key in ready && retry) {            // modelo pode ter sido excluído: baixa de novo
                        ready.remove(key)
                        execute(my, text, src, dst, wifiOnly, false, onDownloading, onResult)
                    } else onResult(Result.failure(TranslateError("Não foi possível traduzir.".tr())))
                }
        }
        if (key in ready) { doTranslate(); return }
        onDownloading()
        val cond = DownloadConditions.Builder().apply { if (wifiOnly) requireWifi() }.build()
        t.downloadModelIfNeeded(cond)
            .addOnSuccessListener { ready.add(key); if (my == seq) doTranslate() }
            .addOnFailureListener {
                if (my == seq) onResult(Result.failure(TranslateError(
                    if (wifiOnly) "Não foi possível baixar o modelo. Conecte-se ao Wi-Fi.".tr()
                    else "Não foi possível baixar o modelo. Verifique a conexão.".tr())))
            }
    }

    companion object {
        /** Códigos dos modelos de tradução já baixados no aparelho. */
        fun downloadedLanguages(cb: (Set<String>) -> Unit) {
            RemoteModelManager.getInstance().getDownloadedModels(TranslateRemoteModel::class.java)
                .addOnSuccessListener { cb(it.map { m -> m.language }.toSet()) }
                .addOnFailureListener { cb(emptySet()) }
        }

        /** Exclui os modelos dos idiomas oferecidos (liberam espaço; voltam a baixar quando precisar). */
        fun deleteModels(done: () -> Unit) {
            downloadedLanguages { have ->
                val mgr = RemoteModelManager.getInstance()
                val todo = TLangs.all.map { it.code }.filter { it in have }
                if (todo.isEmpty()) { done(); return@downloadedLanguages }
                var left = todo.size
                todo.forEach { c ->
                    mgr.deleteDownloadedModel(TranslateRemoteModel.Builder(c).build())
                        .addOnCompleteListener { if (--left == 0) done() }
                }
            }
        }
    }
}

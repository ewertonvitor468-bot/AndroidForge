package com.example.materialkeyboard.cloud

import android.content.Context
import android.os.Build
import android.os.Handler
import android.os.Looper
import com.example.materialkeyboard.Prefs
import com.example.materialkeyboard.TranslatorPrefs
import com.google.android.gms.tasks.Tasks
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.FirebaseFirestoreSettings
import com.google.firebase.firestore.MemoryCacheSettings
import com.google.firebase.firestore.Source
import java.security.MessageDigest
import java.util.concurrent.ExecutionException
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.TimeoutException

/**
 * Backup e restauração das configurações no Cloud Firestore, num ÚNICO documento por conta: users/{uid}/backup/settings
 * (alguns KB; plano gratuito Spark). Backup = 1 escrita; restaurar = 1 leitura. Nada roda sozinho, exceto o backup automático
 * opcional, que só envia ao sair das configurações, só se algo mudou e no máximo a cada poucos minutos.
 * Restaurar é sempre manual e pede confirmação: nenhum aparelho sobrescreve o outro sem você mandar.
 */
object CloudSync {
    const val SCHEMA = 1
    private const val SP = "mk_cloud"                       // estado local da nuvem (NÃO vai no backup e não é apagado por "Restaurar padrões")
    private const val TIMEOUT_S = 20L
    private const val MIN_AUTO_GAP_MS = 3L * 60 * 1000

    enum class Err { NO_LOGIN, NOT_CONFIGURED, OFFLINE, DENIED, NO_BACKUP, TOO_NEW, BAD_DATA, OTHER }
    class Out<T>(val value: T?, val err: Err?, val detail: String = "")
    class Remote(val at: Long, val device: String, val version: String, val prefs: Map<String, Any?>, val translator: Map<String, Any?>)
    private class Stop(val err: Err, val detail: String = "") : Exception()

    private val io = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())

    private fun sp(ctx: Context) = ctx.applicationContext.getSharedPreferences(SP, Context.MODE_PRIVATE)
    fun autoBackup(ctx: Context): Boolean = sp(ctx).getBoolean("auto", false)
    fun setAutoBackup(ctx: Context, v: Boolean) { sp(ctx).edit().putBoolean("auto", v).apply() }
    fun lastBackupAt(ctx: Context): Long = sp(ctx).getLong("lastBackupAt", 0L)

    // ---------- Firestore ----------

    @Volatile private var dbInst: FirebaseFirestore? = null
    private fun db(): FirebaseFirestore = dbInst ?: synchronized(this) {
        dbInst ?: FirebaseFirestore.getInstance().also {
            // Cache só em memória: nada de banco local em disco; leituras do backup usam Source.SERVER (nunca um backup velho do cache).
            try { it.firestoreSettings = FirebaseFirestoreSettings.Builder().setLocalCacheSettings(MemoryCacheSettings.newBuilder().build()).build() }
            catch (_: Exception) { }
            dbInst = it
        }
    }
    private fun docPath(uid: String) = "users/$uid/backup/settings"

    private fun uidOrStop(app: Context): String {
        if (!CloudConfig.configured) throw Stop(Err.NOT_CONFIGURED)
        if (!CloudAuth.ensure(app)) throw Stop(Err.OTHER, "init")
        return CloudAuth.uid() ?: throw Stop(Err.NO_LOGIN)
    }

    private fun <T> run(cb: (Out<T>) -> Unit, work: () -> T) {
        io.execute {
            val r: Out<T> = try { Out(work(), null) } catch (e: Stop) { Out(null, e.err, e.detail) } catch (e: Exception) { fail(e) }
            main.post { cb(r) }
        }
    }

    private fun <T> fail(e: Exception): Out<T> {
        val c: Throwable = (e as? ExecutionException)?.cause ?: e
        if (e is TimeoutException) return Out(null, Err.OFFLINE)
        if (c is FirebaseFirestoreException) return when (c.code) {
            FirebaseFirestoreException.Code.UNAVAILABLE, FirebaseFirestoreException.Code.DEADLINE_EXCEEDED -> Out(null, Err.OFFLINE)
            FirebaseFirestoreException.Code.PERMISSION_DENIED, FirebaseFirestoreException.Code.UNAUTHENTICATED -> Out(null, Err.DENIED)
            else -> Out(null, Err.OTHER, c.code.name)
        }
        return Out(null, Err.OTHER, c.javaClass.simpleName)
    }

    // ---------- O que vai no backup ----------

    private fun payload(app: Context): Pair<Map<String, Any>, Map<String, Any>> {
        val tp = TranslatorPrefs.get(app)
        val tr = linkedMapOf<String, Any>("source" to tp.source, "target" to tp.target, "delayMs" to tp.delayMs, "wifiOnly" to tp.wifiOnly)
        return Prefs.get(app).exportForCloud() to tr
    }

    private fun hash(p: Map<String, Any>, t: Map<String, Any>): String =
        MessageDigest.getInstance("SHA-256").digest("$p|$t".toByteArray()).joinToString("") { "%02x".format(it) }

    private fun versionName(app: Context): String = try { app.packageManager.getPackageInfo(app.packageName, 0).versionName ?: "" } catch (_: Exception) { "" }

    // ---------- Operações (retorno sempre na thread principal) ----------

    /** Envia as configurações deste aparelho (substitui o backup da conta). Devolve a hora do backup. */
    fun backup(ctx: Context, cb: (Out<Long>) -> Unit) {
        val app = ctx.applicationContext
        run(cb) { upload(app) }
    }

    private fun upload(app: Context): Long {
        val uid = uidOrStop(app)
        val (p, t) = payload(app)
        val doc = hashMapOf<String, Any>(
            "schema" to SCHEMA,
            "appVersion" to versionName(app).take(30),
            "device" to Build.MODEL.take(60),
            "updatedAt" to FieldValue.serverTimestamp(),
            "prefs" to p,
            "translator" to t)
        Tasks.await(db().document(docPath(uid)).set(doc), TIMEOUT_S, TimeUnit.SECONDS)
        val now = System.currentTimeMillis()
        sp(app).edit().putLong("lastBackupAt", now).putString("lastHash", hash(p, t)).apply()
        return now
    }

    /** Lê o backup da conta (sempre do servidor) sem aplicar nada. */
    fun fetch(ctx: Context, cb: (Out<Remote>) -> Unit) {
        val app = ctx.applicationContext
        run(cb) {
            val uid = uidOrStop(app)
            val snap = Tasks.await(db().document(docPath(uid)).get(Source.SERVER), TIMEOUT_S, TimeUnit.SECONDS)
            if (!snap.exists()) throw Stop(Err.NO_BACKUP)
            val schema = snap.getLong("schema") ?: 0L
            if (schema > SCHEMA) throw Stop(Err.TOO_NEW)
            if (schema < 1L) throw Stop(Err.BAD_DATA)
            @Suppress("UNCHECKED_CAST")
            val p = snap.get("prefs") as? Map<String, Any?> ?: throw Stop(Err.BAD_DATA)
            @Suppress("UNCHECKED_CAST")
            val t = snap.get("translator") as? Map<String, Any?> ?: emptyMap()
            Remote(snap.getTimestamp("updatedAt")?.toDate()?.time ?: 0L, snap.getString("device") ?: "", snap.getString("appVersion") ?: "", p, t)
        }
    }

    /** Aplica um backup lido por [fetch] neste aparelho. Devolve quantas preferências foram aplicadas. */
    fun applyRemote(ctx: Context, r: Remote): Int {
        val app = ctx.applicationContext
        val n = Prefs.get(app).importFromCloud(r.prefs)
        val tp = TranslatorPrefs.get(app)
        (r.translator["source"] as? String)?.takeIf { it.length in 2..12 }?.let { tp.source = it }
        (r.translator["target"] as? String)?.takeIf { it.length in 2..12 }?.let { tp.target = it }
        (r.translator["delayMs"] as? Number)?.toInt()?.takeIf { it in 200..2000 }?.let { tp.delayMs = it }
        (r.translator["wifiOnly"] as? Boolean)?.let { tp.wifiOnly = it }
        val (p, t) = payload(app)
        sp(app).edit().putString("lastHash", hash(p, t)).apply()   // o que acabou de chegar não precisa voltar para a nuvem
        return n
    }

    /** Apaga o backup da conta na nuvem (as configurações deste aparelho não mudam). */
    fun deleteBackup(ctx: Context, cb: (Out<Boolean>) -> Unit) {
        val app = ctx.applicationContext
        run(cb) {
            val uid = uidOrStop(app)
            Tasks.await(db().document(docPath(uid)).delete(), TIMEOUT_S, TimeUnit.SECONDS)
            sp(app).edit().remove("lastBackupAt").remove("lastHash").apply()
            true
        }
    }

    /**
     * Backup automático (opcional): chamado ao sair das configurações. Não faz nada se estiver desligado, sem conta, sem mudanças
     * desde o último envio ou se a última tentativa foi há pouco tempo. Falhas (ex.: sem internet) são silenciosas; tenta de novo depois.
     */
    fun autoBackupIfNeeded(ctx: Context) {
        if (!CloudConfig.configured || !autoBackup(ctx)) return
        val app = ctx.applicationContext
        if (System.currentTimeMillis() - sp(app).getLong("lastTry", 0L) < MIN_AUTO_GAP_MS) return
        io.execute {
            try {
                if (!CloudAuth.ensure(app) || CloudAuth.uid() == null) return@execute
                val (p, t) = payload(app)
                if (hash(p, t) == sp(app).getString("lastHash", "")) return@execute
                sp(app).edit().putLong("lastTry", System.currentTimeMillis()).apply()
                upload(app)
            } catch (_: Exception) { }
        }
    }
}

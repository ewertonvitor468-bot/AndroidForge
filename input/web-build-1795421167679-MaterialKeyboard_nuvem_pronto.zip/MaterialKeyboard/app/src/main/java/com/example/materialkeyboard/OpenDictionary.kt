package com.example.materialkeyboard

import android.content.Context
import java.util.concurrent.ConcurrentHashMap

/**
 * Carrega uma lista de palavras de código aberto (arquivo em assets/dict/<idioma>.txt) para somar ao
 * dicionário pequeno embutido em [Suggestions]. O arquivo NÃO vem no projeto: rode tools/baixar_dicionarios.sh
 * (ver assets/dict/LEIA-ME.txt). Se o arquivo não existir, o app continua só com o dicionário embutido.
 *
 * Formato aceito: uma palavra por linha, opcionalmente seguida de espaço/tab e a frequência
 * ("de 123456"). A ordem do arquivo vale como ordem de frequência (mais comum primeiro).
 */
object OpenDictionary {
    private const val MAX_WORDS = 40_000
    private val cache = ConcurrentHashMap<String, List<String>>()

    fun forget(lang: String) { cache.remove(lang) }

    /** Solta as listas de outros idiomas já carregados (só a do idioma atual fica na memória). */
    fun keepOnly(lang: String) { cache.keys.retainAll(setOf(lang)) }

    private fun fileFor(lang: String): String? = when (lang) {
        Prefs.LANG_PT -> "dict/pt.txt"
        Prefs.LANG_EN -> "dict/en.txt"
        Prefs.LANG_RU -> "dict/ru.txt"
        Prefs.LANG_ES -> "dict/es.txt"
        Prefs.LANG_AR -> "dict/ar.txt"
        Prefs.LANG_FR -> "dict/fr.txt"
        Prefs.LANG_TR -> "dict/tr.txt"
        Prefs.LANG_VI -> "dict/vi.txt"
        else -> null
    }

    /** Lê o arquivo (fora da thread principal!). Lista vazia se não houver arquivo ou der erro. */
    fun load(ctx: Context, lang: String): List<String> {
        val name = fileFor(lang) ?: return emptyList()
        cache[lang]?.let { return it }
        val out = LinkedHashSet<String>()
        try {
            val local = DictionaryDownloader.file(ctx, lang)            // baixado pelo app tem prioridade
            val ins = if (DictionaryDownloader.has(ctx, lang)) local.inputStream() else ctx.applicationContext.assets.open(name)
            ins.bufferedReader(Charsets.UTF_8).useLines { lines ->
                for (line in lines) {
                    if (out.size >= MAX_WORDS) break
                    val w = line.trim().substringBefore(' ').substringBefore('\t').lowercase().let { java.text.Normalizer.normalize(it, java.text.Normalizer.Form.NFC) }  // NFC: o vietnamita vem decomposto em algumas listas
                    if (w.length < 2 || w.length > 24) continue
                    if (!w.all { it.isLetter() || it == '-' || it == '\'' }) continue
                    out.add(w)
                }
            }
        } catch (_: Exception) { return emptyList() }       // arquivo ausente: normal
        val list = out.toList()
        cache.keys.retainAll(setOf(lang))          // só o idioma atual fica em memória
        cache[lang] = list
        return list
    }
}

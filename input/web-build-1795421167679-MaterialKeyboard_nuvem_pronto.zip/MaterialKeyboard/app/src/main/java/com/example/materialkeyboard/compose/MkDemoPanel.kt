package com.example.materialkeyboard.compose

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import com.example.materialkeyboard.R
import com.example.materialkeyboard.tr

/**
 * Demonstração visual dos componentes Expressive, dentro do teclado (painel "Demo" da barra extra).
 * Três páginas com transição em mola: Botões · Expandir · Menu.
 * Cabe na altura da área das teclas: o conteúdo da página rola.
 */
@Composable
fun MkDemoPanel(onBack: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val motion = Mk.motion
    var page by remember { mutableIntStateOf(0) }
    val tabs = listOf("Botões".tr(), "Expandir".tr(), "Menu".tr(), "Formas".tr())

    Column(Modifier.fillMaxSize().padding(horizontal = 4.dp, vertical = 2.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            MkIconButton(onClick = onBack) { MkBackArrow() }
            MkGap()
            MkButtonGroup(tabs, page, { page = it }, Modifier.weight(1f))
        }
        Spacer(Modifier.height(6.dp))
        AnimatedContent(
            targetState = page,
            modifier = Modifier.weight(1f).fillMaxWidth(),
            transitionSpec = {
                val dir = if (targetState > initialState) 1 else -1
                (slideInHorizontally(motion.spatial<IntOffset>()) { it / 5 * dir } + fadeIn(motion.effects()))
                    .togetherWith(slideOutHorizontally(motion.spatial<IntOffset>()) { -it / 5 * dir } + fadeOut(motion.effects()))
            },
            label = "mkDemoPage"
        ) { p ->
            Column(
                Modifier.fillMaxSize().verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                when (p) {
                    0 -> ButtonsPage()
                    1 -> ExpandPage()
                    2 -> MenuPage()
                    else -> ShapesPage()
                }
            }
        }
    }
}

@Composable
private fun ButtonsPage() {
    val cs = MaterialTheme.colorScheme
    var taps by remember { mutableIntStateOf(0) }
    var bold by remember { mutableStateOf(true) }
    var italic by remember { mutableStateOf(false) }
    var under by remember { mutableStateOf(false) }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        MkButton("Preenchido".tr(), { taps++ }, Modifier.weight(1f))
        MkButton("Tonal".tr(), { taps++ }, Modifier.weight(1f), MkButtonStyle.Tonal)
        MkButton("Contorno".tr(), { taps++ }, Modifier.weight(1f), MkButtonStyle.Outlined)
    }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        MkToggleButton("Negrito".tr(), bold, { bold = it }, Modifier.weight(1f))
        MkToggleButton("Itálico".tr(), italic, { italic = it }, Modifier.weight(1f))
        MkToggleButton("Sublinhado".tr(), under, { under = it }, Modifier.weight(1f))
    }
    Text("${"Toques".tr()}: $taps", color = cs.onSurfaceVariant, style = MaterialTheme.typography.labelMedium,
        modifier = Modifier.padding(start = 8.dp))
}

@Composable
private fun ExpandPage() {
    val cs = MaterialTheme.colorScheme
    MkExpandableSection("Mola espacial (forma e tamanho)".tr(), initiallyExpanded = true) {
        Text("Formas e tamanhos usam mola com leve quique, como no Material 3 Expressive.".tr(),
            color = cs.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
    }
    MkExpandableSection("Mola de efeitos (cor e opacidade)".tr()) {
        Text("Cor e opacidade usam mola sem quique, para mudanças limpas.".tr(),
            color = cs.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
private fun MenuPage() {
    var sel by remember { mutableIntStateOf(0) }
    val items = listOf("Material You".tr(), "Expressive".tr(), "Escuro".tr(), "Claro".tr())
    MkMenu {
        items.forEachIndexed { i, label -> MkMenuItem(i, label, sel == i, { sel = i }) }
    }
}

@Composable
private fun ShapesPage() {
    val cs = MaterialTheme.colorScheme
    var emojiOn by remember { mutableStateOf(false) }
    var clipOn by remember { mutableStateOf(true) }
    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        MkIconButton({ emojiOn = !emojiOn }, selected = emojiOn, size = 56.dp) { MkIcon(R.drawable.ic_emoji, "Emojis".tr(), size = 26.dp) }
        MkIconButton({ clipOn = !clipOn }, selected = clipOn, size = 56.dp) { MkIcon(R.drawable.ic_clipboard, "Área de transferência".tr(), size = 26.dp) }
        MkIconButton({}, size = 56.dp) { MkIcon(R.drawable.ic_settings, "Configurações".tr(), size = 26.dp) }
        MkLoadingIndicator(Modifier.padding(start = 6.dp), size = 44.dp)
    }
    Text(
        "Morfing de formas de verdade: círculo, quadrado arredondado e cookie. Toque e segure para ver a mudança.".tr(),
        color = cs.onSurfaceVariant, style = MaterialTheme.typography.bodySmall,
        modifier = Modifier.padding(horizontal = 4.dp)
    )
}

package com.example.materialkeyboard.keyscafe

/**
 * Endereço do ThemeBoard (Supabase). Fica em código (e não em BuildConfig/local.properties) para compilar também
 * em ambientes simples, como o PocketCode no celular.
 *
 * A chave abaixo é a "anon" (pública por desenho: quem protege os dados são as regras de acesso do servidor).
 * NUNCA coloque aqui a chave "service_role". Para desligar a parte online, deixe os dois valores vazios.
 */
object ThemeBoardConfig {
    const val URL = "https://rdfkxquoitxdntcprigh.supabase.co"
    const val ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InJkZmt4cXVvaXR4ZG50Y3ByaWdoIiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTQ2OTQ3ODQsImV4cCI6MjExMDI3MDc4NH0.sM2n1-mgQE7oGUYpWR53fi5l6yYT_3rwDuuCuBzxj0Q"
}

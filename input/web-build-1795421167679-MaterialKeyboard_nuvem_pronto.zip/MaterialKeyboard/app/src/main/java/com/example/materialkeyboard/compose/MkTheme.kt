package com.example.materialkeyboard.compose

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.remember
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.materialkeyboard.Palette

/**
 * Tema Compose do teclado: Material 3 + linguagem Expressive (formas grandes, tipografia enfática,
 * molas via [MkMotionScheme]). Ponto ÚNICO de estilo: se um dia o projeto subir para Material3 1.5+
 * (AGP 9.2+, compileSdk 37), basta trocar MaterialTheme por MaterialExpressiveTheme aqui.
 *
 * [colors]: normalmente [paletteColorScheme] — o MESMO Palette do teclado (cores dinâmicas/Material You
 * ou tema escolhido), para painéis Compose e Views ficarem idênticos. Nulo = esquema dinâmico do sistema.
 */
@Composable
fun MkTheme(
    colors: ColorScheme? = null,
    motionEnabled: Boolean = true,
    content: @Composable () -> Unit
) {
    val ctx = LocalContext.current
    val dark = isSystemInDarkTheme()
    val scheme = colors ?: when {
        Build.VERSION.SDK_INT >= Build.VERSION_CODES.S ->
            if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
        dark -> darkColorScheme()
        else -> lightColorScheme()
    }
    val motion = remember(motionEnabled) { MkMotionScheme(motionEnabled) }
    CompositionLocalProvider(LocalMkMotion provides motion) {
        MaterialTheme(colorScheme = scheme, shapes = MkShapes, typography = MkTypography, content = content)
    }
}

/** Converte o [Palette] do teclado (já dinâmico) em ColorScheme M3. */
fun paletteColorScheme(p: Palette): ColorScheme {
    val base = if (p.isDark) darkColorScheme() else lightColorScheme()
    val surface = Color(p.surface)
    val onSurface = Color(p.onSurface)
    return base.copy(
        primary = Color(p.keyAccent), onPrimary = Color(p.onAccent),
        primaryContainer = Color(p.keyAccent), onPrimaryContainer = Color(p.onAccent),
        secondaryContainer = Color(p.keySpecial), onSecondaryContainer = Color(p.onSpecial),
        surface = surface, onSurface = onSurface,
        background = surface, onBackground = onSurface,
        surfaceVariant = Color(p.keyNormal), onSurfaceVariant = Color(p.onNormal),
        surfaceContainer = Color(p.keyNormal), surfaceContainerHigh = Color(p.keyNormal),
        outline = onSurface.copy(alpha = 0.38f)
    )
}

/** Formas bem arredondadas (Expressive). */
val MkShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(20.dp),
    large = RoundedCornerShape(28.dp),
    extraLarge = RoundedCornerShape(36.dp)
)

/** Tipografia enfática: títulos e rótulos mais pesados, como no Expressive. */
private val baseTypography = Typography()
val MkTypography = baseTypography.copy(
    titleMedium = baseTypography.titleMedium.copy(fontWeight = FontWeight.Bold),
    titleSmall = baseTypography.titleSmall.copy(fontWeight = FontWeight.Bold),
    labelLarge = baseTypography.labelLarge.copy(fontWeight = FontWeight.SemiBold),
    labelMedium = baseTypography.labelMedium.copy(fontWeight = FontWeight.SemiBold)
)

package com.example.materialkeyboard.compose

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.layout.layout
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.runtime.rememberCoroutineScope
import kotlinx.coroutines.launch
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.materialkeyboard.ClipboardStore
import com.example.materialkeyboard.DictionaryDownloader
import com.example.materialkeyboard.Palette
import com.example.materialkeyboard.Prefs
import com.example.materialkeyboard.R
import com.example.materialkeyboard.tr
import kotlinx.coroutines.delay
import kotlin.math.roundToInt

private val pop = spring<Float>(Spring.DampingRatioMediumBouncy, Spring.StiffnessMedium)

/** Contexto de uma página: prefs, paleta do teclado e um "refresh" que recompõe tudo com as cores novas. */
class PageCtx(val prefs: Prefs, val pal: Palette, val refresh: () -> Unit) {
    val card: Color get() = Color(pal.keyNormal).copy(alpha = 0.55f)
}

@Composable
fun PageHost(prefs: Prefs, content: @Composable PageCtx.() -> Unit) {
    val ctx = LocalContext.current
    var rev by remember { mutableIntStateOf(0) }
    val pal = remember(rev) { Palette.build(ctx, prefs) }
    MkTheme(colors = paletteColorScheme(pal)) {
        Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(20.dp)) {
            PageCtx(prefs, pal) { rev++ }.content()
        }
    }
}

/** Entrada escalonada: o item sobe e aparece com mola. */
@Composable
fun Enter(index: Int, content: @Composable () -> Unit) {
    val a = remember { Animatable(0f) }
    LaunchedEffect(Unit) { delay(index * 50L); a.animateTo(1f, spring(Spring.DampingRatioLowBouncy, Spring.StiffnessLow)) }
    Box(Modifier.graphicsLayer { alpha = a.value.coerceIn(0f, 1f); translationY = (1f - a.value) * 70f }) { content() }
}

/** Linha fina de separação no pé da linha (estilo lista agrupada do iOS). A do último item é cortada pelo [MkCard]. */
internal fun Modifier.rowLine(color: Color): Modifier = drawBehind {
    val h = 1.dp.toPx()
    drawRect(color, Offset(0f, size.height - h), Size(size.width, h))
}

@Composable
internal fun lineColor(): Color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.10f)

/**
 * Grupo de ajustes no estilo "Ajustes do iOS" com Material You: título pequeno em cima, bloco
 * arredondado sólido e linhas com separador fino. O último separador fica fora do bloco (cortado).
 */
@Composable
fun PageCtx.MkCard(title: String? = null, content: @Composable ColumnScope.() -> Unit) = Enter(0) {
    val shape = RoundedCornerShape(26.dp)
    Column(Modifier.fillMaxWidth()) {
        if (title != null) Text(title.uppercase(), color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f), fontWeight = FontWeight.SemiBold,
            style = MaterialTheme.typography.labelMedium, letterSpacing = 0.6.sp, modifier = Modifier.padding(start = 16.dp, top = 6.dp, bottom = 8.dp))
        Column(Modifier.fillMaxWidth().animateContentSize(spring(stiffness = Spring.StiffnessMediumLow)).clip(shape).background(card)) {
            Column(
                Modifier.layout { m, c ->
                    val pl = m.measure(c)
                    val cut = 1.dp.roundToPx()
                    layout(pl.width, (pl.height - cut).coerceAtLeast(0)) { pl.place(0, 0) }
                }.padding(horizontal = 18.dp),
                content = content
            )
        }
    }
}

@Composable
fun PageCtx.MkSwitch(title: String, sub: String?, checked: Boolean, onChange: (Boolean) -> Unit) {
    val cs = MaterialTheme.colorScheme
    var acc by remember { mutableFloatStateOf(0f) }
    Row(
        Modifier.fillMaxWidth().rowLine(lineColor())
            .pointerInput(checked) {   // gesto: deslizar para a direita liga, para a esquerda desliga
                detectHorizontalDragGestures(onDragEnd = {
                    if (acc > 60f && !checked) onChange(true) else if (acc < -60f && checked) onChange(false)
                    acc = 0f
                }) { _, d -> acc += d }
            }
            .clickable { onChange(!checked) }.heightIn(min = 68.dp).padding(vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f).padding(end = 14.dp)) {
            Text(title, color = cs.onSurface, fontSize = 17.sp, fontWeight = FontWeight.Medium)
            if (sub != null) Text(sub, color = cs.onSurface.copy(alpha = 0.62f), fontSize = 13.sp, lineHeight = 17.sp, modifier = Modifier.padding(top = 2.dp))
        }
        Switch(checked, null, Modifier.scale(1.1f))
    }
}

@Composable
fun PageCtx.MkSlider(title: String, value: Int, min: Int, max: Int, unit: String, onSave: (Int) -> Unit) {
    val cs = MaterialTheme.colorScheme
    var v by remember(value) { mutableFloatStateOf(value.toFloat()) }
    Column(Modifier.fillMaxWidth().rowLine(lineColor()).padding(top = 14.dp, bottom = 8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(title, color = cs.onSurface, fontSize = 17.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f).padding(end = 10.dp))
            Box(Modifier.clip(CircleShape).background(cs.primary.copy(alpha = 0.14f)).padding(horizontal = 12.dp, vertical = 4.dp)) {
                Text("${v.roundToInt()}$unit", color = cs.primary, fontSize = 14.sp, fontWeight = FontWeight.Bold)
            }
        }
        Slider(v, { v = it; onSave(it.roundToInt()) }, valueRange = min.toFloat()..max.toFloat(), modifier = Modifier.padding(top = 2.dp))
    }
}

@Composable
fun PageCtx.MkNote(text: String) {
    Text(text, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.62f), fontSize = 13.sp, lineHeight = 18.sp,
        modifier = Modifier.padding(vertical = 12.dp))
}

@Composable
fun PageCtx.MkAction(text: String, danger: Boolean = false, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    FilledTonalButton(onClick, Modifier.fillMaxWidth().heightIn(min = 56.dp).padding(vertical = 4.dp), shape = RoundedCornerShape(18.dp),
        colors = if (danger) ButtonDefaults.filledTonalButtonColors(containerColor = cs.errorContainer, contentColor = cs.onErrorContainer)
        else ButtonDefaults.filledTonalButtonColors()) { Text(text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold) }
}

/** Ícone em quadrado arredondado colorido (como os ícones dos Ajustes do iOS), na cor de destaque do tema. */
@Composable
internal fun IconTile(icon: Int, size: androidx.compose.ui.unit.Dp = 40.dp) {
    val cs = MaterialTheme.colorScheme
    Box(Modifier.size(size).clip(RoundedCornerShape(size * 0.3f)).background(cs.primary), contentAlignment = Alignment.Center) {
        Icon(painterResource(icon), null, tint = cs.onPrimary, modifier = Modifier.size(size * 0.55f))
    }
}

@Composable
fun PageCtx.MkNav(icon: Int, title: String, sub: String, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Row(Modifier.fillMaxWidth().rowLine(lineColor()).clickable(onClick = onClick).heightIn(min = 68.dp).padding(vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically) {
        IconTile(icon)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = cs.onSurface, fontSize = 17.sp, fontWeight = FontWeight.Medium)
            Text(sub, color = cs.onSurface.copy(alpha = 0.62f), fontSize = 13.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
        }
        Icon(painterResource(R.drawable.ic_chevron), null, tint = cs.onSurface.copy(alpha = 0.45f))
    }
}

class NavItem(val icon: Int, val title: String, val sub: String, val target: String)

/** Cartão quadrado de um item do menu (ícone, título e resumo), usado nas páginas deslizáveis da tela inicial. */
@Composable
fun PageCtx.MkTile(item: NavItem, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val sc by animateFloatAsState(if (pressed) 0.94f else 1f, pop, label = "tile")
    Column(
        modifier.scale(sc).clip(RoundedCornerShape(24.dp)).background(card)
            .clickable(interactionSource = src, indication = null, onClick = onClick).padding(14.dp)
    ) {
        Box(Modifier.size(42.dp).clip(CircleShape).background(cs.primary.copy(alpha = 0.15f)), contentAlignment = Alignment.Center) {
            Icon(painterResource(item.icon), null, tint = cs.primary, modifier = Modifier.size(22.dp))
        }
        Spacer(Modifier.height(10.dp))
        Text(item.title, color = cs.onSurface, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text(item.sub, color = cs.onSurface.copy(alpha = 0.62f), style = MaterialTheme.typography.bodySmall,
            maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 2.dp))
    }
}

@Composable
fun SizeScreen(prefs: Prefs) = PageHost(prefs) {
    MkCard("Tamanho geral".tr()) {
        MkSlider("Tamanho do teclado".tr(), prefs.keyboardScale, 70, 130, "%") { prefs.putInt("keyboardScale", it) }
        MkSlider("Tamanho do teclado flutuante".tr(), prefs.floatScale, 60, 110, "%") { prefs.putInt("floatScale", it) }
        Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Pequeno".tr() to 85, "Ideal".tr() to 100, "Grande".tr() to 115).forEach { (t, v) ->
                FilledTonalButton({ prefs.putInt("keyboardScale", v); refresh() }, Modifier.weight(1f)) { Text(t) }
            }
        }
        MkNote("Ajusta tudo de uma vez: teclas, barra de ferramentas e sugestões. 100% é o tamanho padrão; use menos se estiver grande e mais se estiver pequeno.".tr())
        MkNote("No teclado flutuante, toque em − ou + na alça de cima para diminuir ou aumentar na hora.".tr())
    }
    MkCard("Ajuste fino".tr()) {
        MkSlider("Altura das teclas".tr(), prefs.keyHeight, 40, 72, "dp") { prefs.putInt("keyHeight", it) }
        MkSlider("Tamanho do texto das teclas".tr(), prefs.textScale, 80, 130, "%") { prefs.putInt("textScale", it) }
        MkSwitch("Linha de números".tr(), "Mostra 1 2 3… acima das letras".tr(), prefs.numberRow) { prefs.putBool("numberRow", it); refresh() }
    }
}

@Composable
fun AnimScreen(prefs: Prefs, onFluid: (Boolean) -> Unit) = PageHost(prefs) {
    MkCard {
        MkSwitch("Animações fluidas".tr(), "Teclas, painéis e menus com mola, no estilo Material You".tr(), prefs.fluid) {
            prefs.putBool("fluid", it); onFluid(it); refresh()
        }
    }
    MkCard("Velocidade e estilo".tr()) {
        MkSlider("Velocidade das animações".tr(), prefs.animSpeed, 50, 200, "%") { prefs.putInt("animSpeed", it) }
        MkSlider("Elasticidade (ricochete)".tr(), prefs.animBounce, 0, 100, "%") { prefs.putInt("animBounce", it) }
    }
    MkCard("Acentos (segurar a tecla)".tr()) {
        MkSlider("Velocidade da animação dos acentos".tr(), prefs.altSpeed, 50, 200, "%") { prefs.putInt("altSpeed", it) }
        MkSlider("Tempo para abrir os acentos".tr(), prefs.longPressMs, 200, 800, "ms") { prefs.putInt("longPressMs", it) }
    }
    MkCard("Segurar para repetir".tr()) {
        MkSlider("Velocidade das setas ◀ ▶ e do apagar".tr(), prefs.repeatSpeed, 50, 300, "%") { prefs.putInt("repeatSpeed", it) }
    }
}

@Composable
fun TypingScreen(prefs: Prefs) = PageHost(prefs) {
    MkCard("Correção".tr()) {
        MkSwitch("Autocorreção".tr(), "Corrige palavras ao digitar espaço ou pontuação".tr(), prefs.autoCorrect) { prefs.putBool("autoCorrectV2", it); refresh() }
        MkSwitch("Melhorar precisão do corretor".tr(), "Modo bruto: acentos, erros pesados de digitação e sem-vogais (hj → hoje). Use com a Autocorreção ligada".tr(),
            prefs.preciseCorrect) { prefs.putBool("preciseCorrect", it); refresh() }
    }
    MkCard("Dicionário".tr()) {
        val ctx = LocalContext.current
        var busy by remember { mutableStateOf(false) }
        var msg by remember { mutableStateOf<String?>(null) }
        val lang = prefs.language
        val have = DictionaryDownloader.has(ctx, lang)
        MkNote((if (have) "Dicionário aberto instalado (50 mil palavras mais usadas). Vale na próxima vez que o teclado abrir."
        else "Só o dicionário pequeno embutido está ativo. Baixe o dicionário aberto (~0,7 MB) para sugestões e correção bem melhores.").tr())
        MkAction((if (busy) "Baixando…" else if (have) "Baixar de novo" else "Baixar dicionário aberto").tr()) {
            if (!busy) {
                busy = true; msg = null
                Thread {
                    val ok = DictionaryDownloader.download(ctx, lang)
                    msg = (if (ok) "Dicionário instalado ✓" else "Não consegui baixar. Verifique a internet e tente de novo.").tr()
                    busy = false
                }.start()
            }
        }
        msg?.let { MkNote(it) }
        MkNote("Lista de frequência FrequencyWords (hermitdave), licença CC-BY-SA 4.0.".tr())
    }
    MkCard("Sugestões".tr()) {
        MkSwitch("Sugestões de palavras".tr(), "Completa a palavra que você está digitando".tr(), prefs.suggestions) { prefs.putBool("suggestions", it); refresh() }
        MkSwitch("Próxima palavra".tr(), "Sugere a palavra seguinte".tr(), prefs.nextWord) { prefs.putBool("nextWord", it); refresh() }
    }
    MkCard("Entrada".tr()) {
        MkSwitch("Maiúsculas automáticas".tr(), "Início de frases e campos".tr(), prefs.autoCaps) { prefs.putBool("autoCaps", it); refresh() }
        MkSwitch("Toque inteligente".tr(), "Tocar entre as teclas digita a tecla mais próxima".tr(), prefs.smartTouch) { prefs.putBool("smartTouch", it); refresh() }
        MkSwitch("Digitação por deslize".tr(), "Arraste o dedo pelas letras e solte: o teclado escolhe a palavra. Opções aparecem na barra.".tr(), prefs.glide) { prefs.putBool("glide", it); refresh() }
        MkSwitch("Preenchimento automático".tr(), "Mostra senhas, endereços e cartões do seu serviço de autofill na barra (Android 11+).".tr(), prefs.autofill) { prefs.putBool("autofill", it); refresh() }
    }
}

@Composable
fun ClipScreen(prefs: Prefs, onClear: () -> Unit) = PageHost(prefs) {
    MkCard {
        MkSwitch("Guardar histórico".tr(), "Guarda tudo que for copiado, até ${ClipboardStore.MAX_ITEMS}; passou do limite, o mais antigo sai. Fica até você excluir".tr(),
            prefs.clipboardEnabled) { prefs.putBool("clipboardEnabled", it); refresh() }
        MkAction("Apagar histórico".tr(), true, onClear)
    }
}

@Composable
fun MoreScreen(prefs: Prefs, onWizard: () -> Unit, onReset: () -> Unit) = PageHost(prefs) {
    MkCard {
        MkSwitch("Mostrar botão Demo".tr(), "Mostra o botão Demo na linha extra do teclado".tr(), prefs.showDemo) { prefs.putBool("showDemo", it); refresh() }
    }
    MkCard {
        MkAction("Rever o assistente de boas-vindas".tr(), false, onWizard)
        MkAction("Restaurar configurações padrão".tr(), true, onReset)
    }
}

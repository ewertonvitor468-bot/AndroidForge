package com.example.materialkeyboard.keyscafe

/**
 * ThemeSpec v1: o contrato entre o Keys Café (editor/aplicação local) e o ThemeBoard (comunidade).
 * É SÓ DADOS. Nunca contém código. Campos desconhecidos no JSON são ignorados, então versões
 * novas do formato continuam abrindo nas antigas (o que elas não entendem, descartam).
 *
 * Cores são ARGB em Long, no mesmo formato de [com.example.materialkeyboard.Patch].
 * Os índices (formas, estilos, fontes) são os mesmos que o teclado já usa em Prefs.
 */
object SpecLimits {
    const val SPEC_VERSION = 1

    // Tamanhos de texto
    const val NAME_MAX = 40
    const val AUTHOR_MAX = 40
    const val DESC_MAX = 300
    const val INSPIRED_MAX = 80
    const val TAG_MAX = 24
    const val TAGS_MAX = 10
    const val JSON_MAX_CHARS = 64 * 1024

    // Faixas numéricas (valores fora da faixa são ajustados e geram aviso)
    val KEY_STYLE = 0..4          // Material You, iOS, One UI, Vidro, Mecânico
    val KEY_SHAPE = 0..9          // KeyShapes.NAMES
    val ACCENT_SHAPE = 0..10      // 0 = igual às demais
    val KEY_RADIUS = 0..40        // dp
    val BOARD_RADIUS = 0..48      // dp
    val KEY_GAP = 0..12           // dp
    val KEY_ALPHA = 20..100       // %
    val BLUR = 0..100
    val FONT_STYLE = 0..5         // padrão, black, serif, mono, casual, fina
    val TEXT_SCALE = 80..130      // %
    val BUBBLE_SHAPE = 0..6
    val BUBBLE_SIZE = 60..160     // %
    val BUBBLE_COLOR = 0..3
    val BUBBLE_HUE = 0..360
    val ANIM_SPEED = 50..200      // %
    val ANIM_BOUNCE = 0..100
    val KEY_BORDER = 0..6         // dp (v54.2)
    val KEY_DEPTH = 0..8          // dp (v54.2)
    val BAR_BUTTON_SHAPE = 0..5   // BarShapes.NAMES (v54.2)
    val BAR_STYLE = 0..2          // pílula, reta, retangular (v54.2)
    val SCENE = 0..3              // desligado, outono, inverno, tempestade
    val IMAGE_DIM = 0..80         // %
    val IMAGE_POS = 0..100        // %
    const val GRADIENTS_MAX = 4
    val GRADIENT_COLORS = 2..4

    /** id: minúsculas, números, _ e -, de 3 a 40 caracteres. */
    val ID_REGEX = Regex("^[a-z0-9][a-z0-9_-]{2,39}$")
}

/** Cores principais do tema, no claro ou no escuro (um tema = um modo). */
data class SpecPalette(
    val dark: Boolean,
    val surface: Long, val normal: Long, val special: Long, val accent: Long,
    val onNormal: Long, val onSpecial: Long, val onAccent: Long
)

/** Gradiente. Reservado na v1: é lido, validado e guardado, mas o teclado ainda não o desenha. */
data class SpecGradient(
    val target: String,          // "surface" | "key" | "accent"
    val angle: Int,              // 0..359
    val colors: List<Long>       // 2 a 4 cores, distribuídas por igual
) {
    companion object { val TARGETS = setOf("surface", "key", "accent") }
}

data class SpecKeys(
    val keyStyle: Int = 0, val keyShape: Int = 0, val accentShape: Int = 0,
    val keyRadius: Int = 12, val boardRadius: Int = 26, val keyGap: Int = 3,
    val keyAlpha: Int = 60, val blurAmount: Int = 85, val pressGlow: Boolean = true,
    /** v54.2 */
    val keyBorder: Int = 0, val keyDepth: Int = 0, val expressive: Boolean = true
)

/** v54.2: botões e faixa da barra superior (microfone, seta, estilo da faixa de ícones). */
data class SpecBar(
    val micShape: Int = 0, val toolShape: Int = 0, val barStyle: Int = 0
)

data class SpecText(
    val fontStyle: Int = 0,
    val textScale: Int = 108,
    val fontColor: Long? = null      // null = cor do tema
)

data class SpecBubble(
    val shape: Int = 0, val size: Int = 100, val color: Int = 0, val hue: Int = 260, val anim: Boolean = true
)

data class SpecAnimation(
    val speed: Int = 100, val bounce: Int = 50, val scene: Int = 0
)

/** Imagem de fundo. [asset] é o caminho dentro do pacote, por exemplo "assets/bg.webp". */
data class SpecImage(
    val asset: String, val dim: Int = 25, val pos: Int = 50
)

data class ThemeSpec(
    val specVersion: Int = SpecLimits.SPEC_VERSION,
    val minAppVersion: Int = 0,                  // versionCode mínimo do app; 0 = qualquer
    val id: String,
    val name: String,
    val author: String = "",
    val description: String = "",
    val inspiredBy: String = "",                 // jogo, anime, filme ou criador (só texto, sem logos)
    val tags: List<String> = emptyList(),
    val palette: SpecPalette,
    val gradients: List<SpecGradient> = emptyList(),
    val keys: SpecKeys = SpecKeys(),
    val text: SpecText = SpecText(),
    val bubble: SpecBubble = SpecBubble(),
    val animation: SpecAnimation = SpecAnimation(),
    val bar: SpecBar = SpecBar(),
    val image: SpecImage? = null
)

package com.example.materialkeyboard.compose

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.graphics.drawable.toBitmap
import com.example.materialkeyboard.Prefs
import com.example.materialkeyboard.R
import com.example.materialkeyboard.tr

private val tap = spring<Float>(Spring.DampingRatioMediumBouncy, Spring.StiffnessMedium)

@Composable
private fun appIcon(): ImageBitmap {
    val ctx = LocalContext.current
    return remember { ctx.packageManager.getApplicationIcon(ctx.packageName).toBitmap(256, 256).asImageBitmap() }
}

/** Um grupo da lista: título pequeno (opcional) e os itens. */
class NavSection(val title: String?, val items: List<NavItem>)

/** Grupo de itens no estilo Ajustes do iOS: bloco arredondado, ícone em quadrado colorido, separador que começa depois do ícone. */
@Composable
private fun PageCtx.NavGroup(sec: NavSection, startIndex: Int, go: (String) -> Unit) {
    val cs = MaterialTheme.colorScheme
    val line = lineColor()
    Column(Modifier.fillMaxWidth()) {
        if (sec.title != null) Text(sec.title.uppercase(), color = cs.onSurface.copy(alpha = 0.6f), fontWeight = FontWeight.SemiBold,
            style = MaterialTheme.typography.labelMedium, letterSpacing = 0.6.sp, modifier = Modifier.padding(start = 16.dp, top = 2.dp, bottom = 8.dp))
        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(26.dp)).background(card)) {
            sec.items.forEachIndexed { i, item ->
                val last = i == sec.items.lastIndex
                Enter(startIndex + i) {
                    Row(
                        Modifier.fillMaxWidth()
                            .drawBehind {
                                if (!last) {
                                    val h = 1.dp.toPx(); val x = 72.dp.toPx()
                                    drawRect(line, Offset(x, size.height - h), Size(size.width - x, h))
                                }
                            }
                            .clickable { go(item.target) }
                            .heightIn(min = 72.dp).padding(horizontal = 18.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconTile(item.icon, 42.dp)
                        Spacer(Modifier.width(16.dp))
                        Column(Modifier.weight(1f)) {
                            Text(item.title, color = cs.onSurface, fontSize = 17.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(item.sub, color = cs.onSurface.copy(alpha = 0.62f), fontSize = 13.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        }
                        Icon(painterResource(R.drawable.ic_chevron), null, tint = cs.onSurface.copy(alpha = 0.45f))
                    }
                }
            }
        }
    }
}

/** Tela inicial: cabeçalho com ícone/versão, cartão de ativar o teclado e os grupos de ajustes organizados por assunto. */
@Composable
fun HomeScreen(
    prefs: Prefs, ready: Boolean, version: String, sections: List<NavSection>,
    onToggle: () -> Unit, onGear: () -> Unit, go: (String) -> Unit
) = PageHost(prefs) {
    val cs = MaterialTheme.colorScheme
    val icon = appIcon()
    Enter(0) {
        Row(Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 0.dp), verticalAlignment = Alignment.CenterVertically) {
            Image(icon, null, Modifier.size(72.dp).clip(RoundedCornerShape(22.dp)))
            Spacer(Modifier.width(16.dp))
            Column(Modifier.weight(1f)) {
                Text("Material Keyboard", color = cs.onSurface, fontSize = 28.sp, lineHeight = 32.sp, fontWeight = FontWeight.SemiBold)
                Text("v$version", color = cs.onSurface.copy(alpha = 0.6f), fontSize = 16.sp)
            }
            Box(Modifier.size(52.dp).clip(CircleShape).background(cs.primary.copy(alpha = 0.14f)).clickable(onClick = onGear), contentAlignment = Alignment.Center) {
                Icon(painterResource(R.drawable.ic_settings), null, tint = cs.primary, modifier = Modifier.size(28.dp))
            }
        }
    }
    Enter(1) {
        val bg by animateColorAsState(if (ready) cs.primary.copy(alpha = 0.16f) else cs.primary.copy(alpha = 0.30f), label = "enable")
        Row(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp)).background(bg).clickable(onClick = onToggle).padding(horizontal = 20.dp, vertical = 22.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(painterResource(R.drawable.ic_keyboard), null, tint = cs.primary, modifier = Modifier.size(34.dp))
            Spacer(Modifier.width(18.dp))
            Column(Modifier.weight(1f).padding(end = 8.dp)) {
                Text("Ativar o teclado".tr(), color = cs.onSurface, fontSize = 20.sp, fontWeight = FontWeight.Medium)
                Text((if (ready) "Use o Material Keyboard" else "Toque para ativar o Material Keyboard").tr(),
                    color = cs.onSurface.copy(alpha = 0.7f), fontSize = 14.sp)
            }
            Switch(ready, null, Modifier.scale(1.1f))
        }
    }
    var n = 2
    sections.forEach { sec -> NavGroup(sec, n, go); n += sec.items.size }
}

/** Página com grupos (abas Teclado e Temas e o submenu de ajustes). [preview] = teclado ao vivo opcional no topo. */
@Composable
fun SectionsScreen(prefs: Prefs, title: String?, preview: android.view.View?, sections: List<NavSection>, go: (String) -> Unit) = PageHost(prefs) {
    val cs = MaterialTheme.colorScheme
    if (title != null) Text(title, color = cs.onSurface, fontSize = 34.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 4.dp, top = 12.dp))
    if (preview != null) Enter(0) {
        AndroidView(factory = {
            (preview.parent as? android.view.ViewGroup)?.removeView(preview); preview
        }, modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp)).border(1.dp, cs.onSurface.copy(alpha = 0.07f), RoundedCornerShape(28.dp)))
    }
    var n = 1
    sections.forEach { sec -> NavGroup(sec, n, go); n += sec.items.size }
}

/** Atalho: uma lista simples (um único grupo). */
@Composable
fun ListScreen(prefs: Prefs, title: String?, preview: android.view.View?, items: List<NavItem>, go: (String) -> Unit) =
    SectionsScreen(prefs, title, preview, listOf(NavSection(null, items)), go)

/** Barra inferior com as 3 abas. Os ids ("home", "kb", "themes") são os mesmos de SettingsActivity. */
@Composable
fun BottomTabs(prefs: Prefs, selected: String, onSelect: (String) -> Unit) = PageHost(prefs) {
    val cs = MaterialTheme.colorScheme
    Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
        listOf(
            Triple("home", R.drawable.ic_settings, "Configurações"),
            Triple("kb", R.drawable.ic_keyboard, "Teclado"),
            Triple("themes", R.drawable.ic_palette, "Temas")
        ).forEach { (id, ic, label) ->
            val sel = id == selected
            val bg by animateColorAsState(if (sel) cs.primary.copy(alpha = 0.20f) else Color.Transparent, label = "tab")
            val fg = if (sel) cs.primary else cs.onSurface.copy(alpha = 0.7f)
            Box(Modifier.weight(1f), contentAlignment = Alignment.Center) {
                Column(
                    Modifier.clip(RoundedCornerShape(24.dp)).background(bg).clickable { onSelect(id) }.padding(horizontal = 22.dp, vertical = 10.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(painterResource(ic), null, tint = fg, modifier = Modifier.size(26.dp))
                    Text(label.tr(), color = fg, fontSize = 13.sp, fontWeight = FontWeight.Medium, maxLines = 1)
                }
            }
        }
    }
}

@Composable
fun AboutScreen(prefs: Prefs, version: String, onUpdates: () -> Unit, onWizard: () -> Unit) = PageHost(prefs) {
    val cs = MaterialTheme.colorScheme
    val icon = appIcon()
    MkCard {
        Column(Modifier.fillMaxWidth().padding(vertical = 14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Image(icon, null, Modifier.size(84.dp).clip(RoundedCornerShape(24.dp)))
            Text("Material Keyboard", color = cs.onSurface, fontSize = 22.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 12.dp))
            Text("${"Versão".tr()} $version", color = cs.onSurface.copy(alpha = 0.62f), fontSize = 14.sp)
        }
        MkNote("Teclado com Material You, temas, tradução e muito mais.".tr())
    }
    MkCard {
        MkAction("Verificar atualizações".tr(), false, onUpdates)
        MkAction("Rever o assistente de boas-vindas".tr(), false, onWizard)
    }
}

@Composable
fun EmojiScreen(prefs: Prefs, onBar: () -> Unit) = PageHost(prefs) {
    MkCard {
        MkSwitch("Emoji ao lado do espaço".tr(), "Troca a tecla de idioma pela tecla de emoji".tr(), prefs.langKey == Prefs.LANG_KEY_EMOJI) {
            prefs.putInt("langKey", if (it) Prefs.LANG_KEY_EMOJI else 0); refresh()
        }
        MkNote("Os emojis recentes ficam no topo do painel de emojis.".tr())
    }
    MkCard { MkAction("Barra de ícones".tr(), false, onBar) }
}

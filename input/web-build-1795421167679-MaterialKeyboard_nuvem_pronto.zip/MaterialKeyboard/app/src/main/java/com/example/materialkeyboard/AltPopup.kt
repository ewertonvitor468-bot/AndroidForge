package com.example.materialkeyboard

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.PopupWindow
import androidx.core.graphics.ColorUtils
import androidx.dynamicanimation.animation.DynamicAnimation

/**
 * Bolha de uma variação (ã á ç § ¶ ...). Cada variação é a sua própria bolha, desenhada com um dos
 * formatos de [PopupShapes] (cookie, flor, selo, círculo, quadrado, pílula...), sem barra de fundo.
 * Também é usada pelo painel "Adicionar idioma", então tudo fica no mesmo estilo.
 */
class AltBubble(ctx: Context) : View(ctx) {
    var text = ""
    var shapeId = 4
    var textPx = 40f
    private var fill = 0
    private var ink = 0
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER; typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    }
    private val path = Path()
    private val rc = RectF()

    fun paint(fillColor: Int, inkColor: Int) {
        fill = ColorUtils.setAlphaComponent(fillColor, 255); ink = inkColor; invalidate()
    }

    override fun onDraw(c: Canvas) {
        val d = resources.displayMetrics.density
        val st = 1.2f * d
        rc.set(st, st, width - st, height - st)
        path.rewind(); PopupShapes.build(path, rc, d, shapeId)
        p.style = Paint.Style.FILL; p.color = fill; c.drawPath(path, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = st; p.color = ColorUtils.setAlphaComponent(ink, 50); c.drawPath(path, p)
        tp.color = ink; tp.textSize = textPx
        val tw = tp.measureText(text); val maxW = width * 0.74f
        if (tw > maxW && tw > 0f) tp.textSize = textPx * maxW / tw       // "EN", "＋" etc. sempre cabem na bolha
        c.drawText(text, width / 2f, height / 2f - (tp.ascent() + tp.descent()) / 2f, tp)
    }
}

/**
 * Variações de uma tecla (segurar 0,5 s): ç č ć ã á...
 *
 * Em vez de uma barra genérica, cada variação é uma bolha em cookie (ou outro formato escolhido em
 * Configurações → Popup) flutuando acima da tecla. A bolha escolhida cresce e ganha a cor de destaque;
 * as outras ficam menores e na cor "especial".
 *
 * É uma janela flutuante separada (PopupWindow): aparece ACIMA do teclado mesmo para a fileira de cima.
 * Ela não recebe toque: o dedo continua "preso" à tecla e o [KeyView] repassa a posição horizontal em
 * [move]. Ao soltar, [finish] devolve a variação escolhida.
 *
 * Animação (modo fluido): as bolhas brotam da tecla com mola, entram em cascata e a seleção "pula"
 * de uma bolha para a outra com mola.
 */
class AltPopup(
    private val ctx: Context,
    private val pal: Palette,
    @Suppress("unused") private val keyRadiusPx: Float,
    private val fluid: Boolean,
    private val shapeOf: () -> Int = { 4 }          // formato lido na hora de abrir: trocar nas configurações vale já
) {
    private var pw: PopupWindow? = null
    private var card: FrameLayout? = null
    private var views: List<AltBubble> = emptyList()
    private var shown: List<String> = emptyList()
    private var left = 0          // x (tela) da borda esquerda da janela
    private var pad = 0           // folga lateral (a bolha escolhida cresce e não pode ser cortada)
    private var step = 0          // distância entre os centros das bolhas
    private var lift = 0f         // quanto a bolha escolhida sobe
    private var lift3d = 0f
    private var sel = 0
    private var reversed = false  // true: a 1ª variação (a mais usada) é a bolha da DIREITA, sempre perto do dedo

    val isShowing: Boolean get() = pw != null

    /** @return true se o painel abriu. */
    fun show(anchor: View, list: List<String>, rawX: Float, compact: Boolean = false): Boolean {
        cancel()
        if (list.isEmpty() || !anchor.isAttachedToWindow) return false
        return try {
            val d = ctx.resources.displayMetrics.density
            val screenW = ctx.resources.displayMetrics.widthPixels
            val margin = (4 * d).toInt()
            val bs = if (compact) (38 * d).toInt() else (anchor.height * 0.9f).coerceIn(42 * d, 54 * d).toInt()
            val gap = (3 * d).toInt()
            step = bs + gap
            val grow = bs * (SEL_SCALE - 1f)
            lift = bs * 0.10f
            lift3d = 3 * d
            pad = (grow / 2f + 2 * d).toInt()
            val topPad = (grow / 2f + lift + 2 * d).toInt()
            val botPad = (grow / 2f + 2 * d).toInt()
            // cabe na tela: se a lista for larga demais, limita a quantidade de bolhas
            val maxItems = ((screenW - 2 * margin - 2 * pad) / step).coerceAtLeast(1)
            val items = list.take(maxItems)
            val cardW = items.size * step + 2 * pad
            val cardH = topPad + bs + botPad

            val loc = IntArray(2)
            anchor.getLocationOnScreen(loc)
            val keyCenter = loc[0] + anchor.width / 2
            val maxLeft = screenW - cardW - margin
            // Normal: a 1ª variação (a mais usada) fica centralizada sobre a tecla e as outras seguem para a direita.
            val wantedNormal = keyCenter - step / 2 - pad
            if (wantedNormal <= maxLeft) {
                reversed = false
                left = wantedNormal.coerceIn(margin, maxOf(margin, maxLeft))
            } else {
                // Não cabe para a direita (teclas do lado direito): inverte a ordem e a 1ª variação fica
                // na bolha da direita, centralizada sobre a tecla (antes ia para a ponta da tela, longe do dedo).
                reversed = true
                val wantedRev = keyCenter + step / 2 + pad - cardW
                left = wantedRev.coerceIn(margin, maxOf(margin, maxLeft))
            }
            shown = if (reversed) items.reversed() else items

            val sid = shapeOf()
            val c = FrameLayout(ctx)
            c.clipChildren = false; c.clipToPadding = false
            val textPx = ((anchor as? KeyView)?.textSizePx ?: (20 * d))
                .let { if (compact) minOf(it, 17 * d) else it }.coerceAtMost(bs * 0.52f)
            val bubbles = ArrayList<AltBubble>()
            shown.forEachIndexed { i, s ->
                val b = AltBubble(ctx).apply {
                    text = s; shapeId = sid; this.textPx = textPx
                    layoutParams = FrameLayout.LayoutParams(bs, bs).apply {
                        leftMargin = pad + i * step + gap / 2; topMargin = topPad
                    }
                }
                bubbles.add(b); c.addView(b)
            }
            card = c; views = bubbles

            sel = indexAt(rawX)
            paintAll()
            views.getOrNull(sel)?.let { v ->                           // estado inicial da bolha escolhida
                v.translationY = -lift; v.translationZ = lift3d
                if (!fluid) { v.scaleX = SEL_SCALE; v.scaleY = SEL_SCALE }
            }

            val w = PopupWindow(c, cardW, cardH, false)
            w.isFocusable = false
            w.isTouchable = false                    // o toque continua com a tecla
            w.isOutsideTouchable = false
            w.isClippingEnabled = false
            w.inputMethodMode = PopupWindow.INPUT_METHOD_NOT_NEEDED
            w.setWindowLayoutType(WindowManager.LayoutParams.TYPE_APPLICATION_PANEL)
            // posição: base das bolhas logo acima da tecla, janela alinhada a [left]
            val xOff = left - loc[0]
            val yOff = -(anchor.height + cardH - botPad + (2 * d).toInt())
            w.showAsDropDown(anchor, xOff, yOff, android.view.Gravity.TOP or android.view.Gravity.START)
            pw = w

            if (fluid) {
                c.pivotX = (keyCenter - left).toFloat()
                c.pivotY = (cardH - botPad).toFloat()
                c.alpha = 0f; c.scaleX = 0.45f; c.scaleY = 0.45f
                c.aSpring(DynamicAnimation.ALPHA, 1f, 900f, 1f)
                c.aSpring(DynamicAnimation.SCALE_X, 1f, 520f, 0.62f)
                c.aSpring(DynamicAnimation.SCALE_Y, 1f, 520f, 0.62f)
                bubbles.forEachIndexed { i, b ->
                    b.alpha = 0f; b.scaleX = 0.6f; b.scaleY = 0.6f
                    val go = Runnable {
                        val t = if (i == sel) SEL_SCALE else 1f        // lê a seleção na hora: o dedo pode ter andado
                        b.aSpring(DynamicAnimation.ALPHA, 1f, 800f, 1f)
                        b.aSpring(DynamicAnimation.SCALE_X, t, 600f, 0.6f)
                        b.aSpring(DynamicAnimation.SCALE_Y, t, 600f, 0.6f)
                    }
                    b.postDelayed(go, 14L * i)
                }
            }
            true
        } catch (_: Exception) {
            cancel()
            false
        }
    }

    /**
     * Bolha sob o dedo. A 1ª variação (a mais usada) tem uma zona 20% maior: não precisa acertar o centro
     * da tecla para pegar ã, é, ç... Para escolher outra, é só deslizar.
     */
    private fun indexAt(rawX: Float): Int {
        val pos = (rawX - left - pad) / step
        val raw = if (reversed) Math.floor((pos + 0.2f).toDouble()) else Math.floor((pos - 0.2f).toDouble())
        return raw.toInt().coerceIn(0, (shown.size - 1).coerceAtLeast(0))
    }

    /** Chamado a cada movimento do dedo (coordenada X na tela). */
    fun move(rawX: Float) {
        if (pw == null) return
        val i = indexAt(rawX)
        if (i == sel) return
        val old = sel
        sel = i
        paintAll()
        applySel(old, false)
        applySel(i, true)
    }

    private fun applySel(i: Int, on: Boolean) {
        val v = views.getOrNull(i) ?: return
        val s = if (on) SEL_SCALE else 1f
        val ty = if (on) -lift else 0f
        val tz = if (on) lift3d else 0f
        if (fluid) {
            v.aSpring(DynamicAnimation.SCALE_X, s, 700f, 0.55f)
            v.aSpring(DynamicAnimation.SCALE_Y, s, 700f, 0.55f)
            v.aSpring(DynamicAnimation.TRANSLATION_Y, ty, 700f, 0.6f)
            v.aSpring(DynamicAnimation.TRANSLATION_Z, tz, 700f, 0.6f)
        } else {
            v.scaleX = s; v.scaleY = s; v.translationY = ty; v.translationZ = tz
        }
    }

    private fun paintAll() {
        views.forEachIndexed { i, b ->
            if (i == sel) b.paint(pal.keyAccent, pal.onAccent) else b.paint(pal.keySpecial, pal.onSpecial)
        }
    }

    /** Dedo levantado: fecha e devolve a variação escolhida. */
    fun finish(): String? {
        if (pw == null) return null        // já foi fechado/substituído por outro popup: não devolve variação velha
        val pick = shown.getOrNull(sel)
        dismiss(true)
        return pick
    }

    /** Fecha sem escolher nada. */
    fun cancel() = dismiss(false)

    private fun dismiss(animate: Boolean) {
        val w = pw ?: return
        val c = card
        pw = null; card = null; views = emptyList()
        if (animate && fluid && c != null) {
            c.aSpring(DynamicAnimation.ALPHA, 0f, 1200f, 1f)
            c.aSpring(DynamicAnimation.SCALE_X, 0.9f, 1200f, 1f)
            c.aSpring(DynamicAnimation.SCALE_Y, 0.9f, 1200f, 1f)
            c.postDelayed({ try { w.dismiss() } catch (_: Exception) { } }, 120)
        } else {
            try { w.dismiss() } catch (_: Exception) { }
        }
    }

    private companion object {
        const val SEL_SCALE = 1.3f     // a bolha escolhida fica 30% maior
    }
}


private fun android.view.View.aSpring(prop: DynamicAnimation.ViewProperty, target: Float, stiffness: Float, damping: Float) =
    springTo(prop, target, stiffness * AnimCfg.altSpeed * AnimCfg.altSpeed, damping)

package com.example.materialkeyboard

import android.content.Context
import android.os.Handler
import android.os.Looper
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions
import org.json.JSONObject
import java.io.File

/**
 * v65.5: idioma do APLICATIVO (menus e textos) em dezenas de línguas além das 8 do teclado.
 * O texto em inglês de [L] é traduzido NO APARELHO (ML Kit, o mesmo do Tradutor) uma única vez por idioma
 * e guardado em arquivo (filesDir/uitr_<codigo>.json). Não mexe no layout do teclado nem no Tradutor.
 * O que ainda não foi traduzido aparece em inglês.
 */
object UiTr {
    /** Idiomas com tabela própria dentro de [L]; os demais passam por aqui. */
    val BUILT_IN = setOf(Prefs.LANG_PT, Prefs.LANG_EN, Prefs.LANG_ES, Prefs.LANG_AR, Prefs.LANG_RU, Prefs.LANG_FR, Prefs.LANG_TR, Prefs.LANG_VI)

    private var appCtx: Context? = null
    private val cache = HashMap<String, Map<String, String>>()
    private val main = Handler(Looper.getMainLooper())

    /** Estado do trabalho atual (a tela de idioma lê para mostrar o andamento). */
    @Volatile var workingCode: String? = null
    @Volatile var done = 0
    @Volatile var total = 0
    @Volatile var failed = false

    fun init(ctx: Context) { appCtx = ctx.applicationContext }

    private fun file(code: String): File? = appCtx?.let { File(it.filesDir, "uitr_$code.json") }

    fun isReady(code: String): Boolean = file(code)?.exists() == true

    /** Tradução já guardada (ou null). Chamada a cada texto: lê o arquivo só uma vez por idioma. */
    fun get(code: String, pt: String): String? {
        val m = cache[code] ?: synchronized(this) {
            cache[code] ?: load(code).also { cache[code] = it }
        }
        return m[pt]
    }

    private fun load(code: String): Map<String, String> {
        val f = file(code) ?: return emptyMap()
        if (!f.exists()) return emptyMap()
        return try {
            val o = JSONObject(f.readText())
            val out = HashMap<String, String>(o.length())
            o.keys().forEach { k -> out[k] = o.getString(k) }
            out
        } catch (_: Exception) { emptyMap() }
    }

    fun delete(code: String) { cache.remove(code); file(code)?.delete() }

    private fun placeholders(s: String): Int = Regex("%(\\d+\\$)?[sd]|%%").findAll(s).count()

    /**
     * Baixa o modelo (uma vez) e traduz todos os textos do inglês para [code].
     * [onDone] roda na thread principal (true = deu certo). Se já estiver pronto, chama na hora.
     */
    fun ensure(code: String, onDone: (Boolean) -> Unit) {
        if (code in BUILT_IN || isReady(code)) { onDone(true); return }
        if (workingCode != null) { onDone(false); return }
        val entries = L.englishEntries()
        workingCode = code; done = 0; total = entries.size; failed = false
        val tr = Translation.getClient(
            TranslatorOptions.Builder()
                .setSourceLanguage(TranslateLanguage.ENGLISH)
                .setTargetLanguage(code)
                .build()
        )
        fun finish(ok: Boolean) {
            tr.close(); workingCode = null; failed = !ok
            main.post { onDone(ok) }
        }
        tr.downloadModelIfNeeded(DownloadConditions.Builder().build())
            .addOnFailureListener { finish(false) }
            .addOnSuccessListener {
                val out = JSONObject()
                fun step(i: Int) {
                    if (i >= entries.size) {
                        try { file(code)?.writeText(out.toString()) } catch (_: Exception) { finish(false); return }
                        cache.remove(code)
                        finish(true); return
                    }
                    val (pt, en) = entries[i]
                    tr.translate(en)
                        .addOnSuccessListener { r ->
                            // se o tradutor estragou um %s/%d, fica o inglês
                            if (r.isNotBlank() && placeholders(r) == placeholders(en)) out.put(pt, r)
                            done = i + 1; step(i + 1)
                        }
                        .addOnFailureListener { done = i + 1; step(i + 1) }   // um texto falho não derruba o resto
                }
                step(0)
            }
    }
}

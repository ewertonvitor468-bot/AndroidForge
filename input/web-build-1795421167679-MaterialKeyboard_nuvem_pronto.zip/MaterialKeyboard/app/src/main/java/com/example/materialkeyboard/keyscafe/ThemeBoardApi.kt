package com.example.materialkeyboard.keyscafe

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.UUID

/** Um tema da lista do ThemeBoard, já com a versão mais recente aprovada (ou a mais recente sua, em "meus temas"). */
data class BoardTheme(
    val id: String, val ownerId: String, val title: String, val description: String, val tags: List<String>,
    val previewPath: String?, val status: String, val authorName: String,
    val version: Int, val versionStatus: String, val packagePath: String?, val sha256: String?, val sizeBytes: Long,
    val minAppVersion: Int?, val downloads: Int, val ratingAvg: Double, val ratingCount: Int
)

/** Uma denúncia aberta, como a fila de moderação a mostra. */
data class BoardReport(
    val id: String, val themeId: String, val themeTitle: String, val themeStatus: String,
    val category: String, val reason: String
)

/** O que o moderador vê de um tema pendente: o pacote lido SEM instalar (nada entra na biblioteca). */
class ReviewData(
    val spec: ThemeSpec, val previewWebp: ByteArray?, val image: ByteArray?,
    val warnings: List<String>, val shaOk: Boolean
)

sealed class BoardResult<out T> {
    data class Ok<T>(val value: T) : BoardResult<T>()
    data class Fail(val reason: String) : BoardResult<Nothing>()
}

/** Categorias de denúncia aceitas pelo servidor. */
enum class ReportCategory(val key: String, val label: String) {
    INAPPROPRIATE("inappropriate", "Ofensivo ou +18"), COPYRIGHT("copyright", "Direitos autorais"),
    SPAM("spam", "Spam"), OTHER("other", "Outro")
}

/**
 * Cliente do ThemeBoard (Supabase) SEM dependências novas: HttpURLConnection + org.json.
 * Esquema do servidor: ver docs/supabase/README.md (themes, theme_versions, theme_stats, reports, profiles; buckets
 * privados `theme-packages` e `theme-previews`, lidos pelas regras de acesso, nunca por URL pública).
 *
 * Segurança no app:
 *  - só HTTPS e só a chave pública (anon); quem protege os dados é o RLS do servidor;
 *  - nada baixado é confiado: tamanho limitado, SHA-256 conferido contra o registro da versão e o pacote passa por
 *    [ThemeLibrary.readPackage] (validação rígida) antes de instalar; um tema baixado nunca sobrescreve um tema local
 *    que não veio do mesmo registro do ThemeBoard.
 *
 * TODAS as funções são bloqueantes: chame fora da thread principal.
 */
object ThemeBoardApi {
    const val NEED_LOGIN = "NEED_LOGIN"
    /** Categoria deste app no servidor (a outra plataforma usa "themeboard"). */
    private const val CATEGORY = "keys_cafe"
    private const val PKG_BUCKET = "theme-packages"
    private const val PREV_BUCKET = "theme-previews"
    private const val PAGE = 20
    private const val TIMEOUT_MS = 15_000
    private const val SESS = "themeboard_session"
    private const val LOCAL = "themeboard_local"

    private val baseUrl: String get() = ThemeBoardConfig.URL.trimEnd('/')
    private val anonKey: String get() = ThemeBoardConfig.ANON_KEY

    /** false = o app foi compilado sem URL/chave (ThemeBoardConfig); a parte online fica escondida. */
    val configured: Boolean get() = baseUrl.startsWith("https://") && anonKey.length > 20

    // ------------------------------------------------------------------ conta

    private class Session(val token: String, val refresh: String, val expiresAt: Long, val userId: String, val email: String)
    @Volatile private var session: Session? = null

    private fun sp(ctx: Context) = ctx.applicationContext.getSharedPreferences(SESS, Context.MODE_PRIVATE)

    private fun loadSession(ctx: Context): Session? {
        session?.let { return it }
        val p = sp(ctx)
        val t = p.getString("token", null) ?: return null
        return Session(t, p.getString("refresh", "") ?: "", p.getLong("exp", 0L), p.getString("uid", "") ?: "", p.getString("email", "") ?: "")
            .also { session = it }
    }

    private fun saveSession(ctx: Context, j: JSONObject): Session? {
        val token = j.optString("access_token"); if (token.isEmpty()) return null
        val u = j.optJSONObject("user")
        val exp = j.optLong("expires_at", System.currentTimeMillis() / 1000 + j.optLong("expires_in", 3600))
        val s = Session(token, j.optString("refresh_token"), exp, u?.optString("id").orEmpty(), u?.optString("email").orEmpty())
        session = s
        sp(ctx).edit().putString("token", s.token).putString("refresh", s.refresh).putLong("exp", s.expiresAt)
            .putString("uid", s.userId).putString("email", s.email).apply()
        return s
    }

    /** E-mail da conta conectada, ou null se não há login. */
    fun accountEmail(ctx: Context): String? = loadSession(ctx)?.email?.takeIf { it.isNotEmpty() }
    fun signedIn(ctx: Context): Boolean = loadSession(ctx) != null
    fun userId(ctx: Context): String = loadSession(ctx)?.userId.orEmpty()

    fun signOut(ctx: Context) { session = null; modCache = null; sp(ctx).edit().clear().apply() }

    /** Token válido (renova se preciso) ou null se não há login / a sessão expirou de vez. */
    private fun token(ctx: Context): Session? {
        val cur = loadSession(ctx) ?: return null
        if (cur.expiresAt - 60 > System.currentTimeMillis() / 1000) return cur
        if (cur.refresh.isNotEmpty()) {
            val r = http("POST", "/auth/v1/token?grant_type=refresh_token", null,
                JSONObject().put("refresh_token", cur.refresh).toString().toByteArray(), "application/json")
            if (r.code in 200..299) try { return saveSession(ctx, JSONObject(r.text())) } catch (_: Exception) { }
        }
        signOut(ctx); return null
    }

    private fun authError(r: Resp): String {
        val msg = try { JSONObject(r.text()).let { it.optString("msg", it.optString("error_description", it.optString("message"))) } } catch (_: Exception) { "" }
        return when {
            msg.contains("Invalid login", true) -> "E-mail ou senha incorretos."
            msg.contains("not confirmed", true) -> "Confirme seu e-mail (veja sua caixa de entrada) e entre de novo."
            msg.contains("already", true) -> "Esse e-mail já tem conta. Use Entrar."
            msg.contains("password", true) -> "Senha fraca ou inválida (use 8+ caracteres)."
            r.code == 429 -> "Muitas tentativas. Espere um pouco."
            else -> "Não foi possível entrar (${r.code})."
        }
    }

    fun signIn(ctx: Context, email: String, password: String): BoardResult<Unit> = guarded {
        val r = http("POST", "/auth/v1/token?grant_type=password", null,
            JSONObject().put("email", email.trim()).put("password", password).toString().toByteArray(), "application/json")
        if (r.code !in 200..299) return@guarded BoardResult.Fail(authError(r))
        if (saveSession(ctx, JSONObject(r.text())) == null) BoardResult.Fail("Resposta inesperada do servidor.") else BoardResult.Ok(Unit)
    }

    /** Cria a conta. Se o servidor exige confirmação por e-mail, devolve Ok(false); se já entrou, Ok(true). */
    fun signUp(ctx: Context, email: String, password: String, displayName: String): BoardResult<Boolean> = guarded {
        val body = JSONObject().put("email", email.trim()).put("password", password)
            .put("data", JSONObject().put("display_name", displayName.trim().take(40)))
        val r = http("POST", "/auth/v1/signup", null, body.toString().toByteArray(), "application/json")
        if (r.code !in 200..299) return@guarded BoardResult.Fail(authError(r))
        BoardResult.Ok(saveSession(ctx, JSONObject(r.text())) != null)
    }

    // ------------------------------------------------------------------ HTTP

    private class Resp(val code: Int, val body: ByteArray) { fun text() = String(body, Charsets.UTF_8) }

    private fun http(
        method: String, path: String, token: String?, body: ByteArray? = null, contentType: String? = null,
        extra: Map<String, String> = emptyMap(), maxBytes: Int = 2 * 1024 * 1024
    ): Resp {
        val c = (URL(baseUrl + path).openConnection() as HttpURLConnection)
        try {
            c.requestMethod = method
            c.connectTimeout = TIMEOUT_MS; c.readTimeout = TIMEOUT_MS * 2
            c.instanceFollowRedirects = false
            c.setRequestProperty("apikey", anonKey)
            c.setRequestProperty("Authorization", "Bearer " + (token ?: anonKey))
            if (contentType != null) c.setRequestProperty("Content-Type", contentType)
            extra.forEach { (k, v) -> c.setRequestProperty(k, v) }
            if (body != null) { c.doOutput = true; c.setFixedLengthStreamingMode(body.size); c.outputStream.use { it.write(body) } }
            val code = c.responseCode
            val stream: InputStream? = if (code in 200..299) c.inputStream else c.errorStream
            val out = ByteArrayOutputStream()
            if (stream != null) stream.use { s ->
                val buf = ByteArray(16 * 1024)
                while (true) {
                    val n = s.read(buf); if (n < 0) break
                    out.write(buf, 0, n)
                    if (out.size() > maxBytes) return Resp(-2, ByteArray(0))   // grande demais
                }
            }
            return Resp(code, out.toByteArray())
        } finally { c.disconnect() }
    }

    private fun <T> guarded(block: () -> BoardResult<T>): BoardResult<T> = try {
        if (!configured) BoardResult.Fail("O ThemeBoard não está configurado neste app.") else block()
    } catch (e: java.net.UnknownHostException) { BoardResult.Fail("Sem internet.") }
    catch (e: java.net.SocketTimeoutException) { BoardResult.Fail("A conexão demorou demais.") }
    catch (e: java.io.IOException) { BoardResult.Fail("Falha de rede.") }
    catch (e: Exception) { BoardResult.Fail("Resposta inesperada do servidor.") }

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")
    private fun objPath(bucket: String, path: String) = "/storage/v1/object/$bucket/" + path.split("/").joinToString("/") { enc(it) }

    // ------------------------------------------------------------------ listar

    enum class Sort { POPULAR, NEWEST, BEST }

    private const val SELECT = "id,owner_id,title,description,tags,preview_path,status," +
        "theme_stats(download_count,rating_avg,rating_count)," +
        "theme_versions!inner(version,status,package_path,sha256,size_bytes,min_app_version)"
    private const val SELECT_MINE = "id,owner_id,title,description,tags,preview_path,status," +
        "theme_stats(download_count,rating_avg,rating_count)," +
        "theme_versions(version,status,package_path,sha256,size_bytes,min_app_version)"

    private fun parseTheme(o: JSONObject, authors: Map<String, String>): BoardTheme? = try {
        val tags = o.optJSONArray("tags")?.let { a -> (0 until a.length()).map { a.getString(it) } } ?: emptyList()
        val st = o.optJSONObject("theme_stats")
        val vs = o.optJSONArray("theme_versions")
        var best: JSONObject? = null
        if (vs != null) for (i in 0 until vs.length()) { val v = vs.getJSONObject(i); if (best == null || v.getInt("version") > best.getInt("version")) best = v }
        val owner = o.getString("owner_id")
        BoardTheme(
            o.getString("id"), owner, o.getString("title"), o.optString("description"), tags,
            if (o.isNull("preview_path")) null else o.getString("preview_path"), o.optString("status", "pending"),
            authors[owner].orEmpty(),
            best?.getInt("version") ?: 0, best?.optString("status").orEmpty(), best?.optString("package_path"), best?.optString("sha256"),
            best?.optLong("size_bytes") ?: 0L, if (best == null || best.isNull("min_app_version")) null else best.getInt("min_app_version"),
            st?.optInt("download_count") ?: 0, st?.optDouble("rating_avg", 0.0) ?: 0.0, st?.optInt("rating_count") ?: 0
        )
    } catch (_: Exception) { null }

    private fun authorsOf(arr: JSONArray): Map<String, String> {
        val ids = (0 until arr.length()).mapNotNull { arr.optJSONObject(it)?.optString("owner_id") }.filter { it.length == 36 }.distinct()
        if (ids.isEmpty()) return emptyMap()
        val r = http("GET", "/rest/v1/profiles?select=id,display_name&id=in.(${ids.joinToString(",")})", null)
        if (r.code !in 200..299) return emptyMap()
        val a = JSONArray(r.text())
        return (0 until a.length()).associate { a.getJSONObject(it).getString("id") to a.getJSONObject(it).optString("display_name") }
    }

    /** Temas aprovados com versão aprovada. [page] começa em 0. [query] procura no título. */
    fun list(page: Int, sort: Sort, query: String = ""): BoardResult<List<BoardTheme>> = guarded {
        val q = query.replace(Regex("[*,()%\\\\]"), " ").trim().take(40)
        val filter = if (q.isEmpty()) "" else "&title=ilike.${enc("*$q*")}"
        val order = when (sort) {
            Sort.POPULAR -> "theme_stats(download_count).desc"; Sort.BEST -> "theme_stats(rating_avg).desc"; Sort.NEWEST -> "created_at.desc" }
        val r = http("GET", "/rest/v1/themes?select=${enc(SELECT)}&category=eq.$CATEGORY&status=eq.approved" +
            "&theme_versions.status=eq.approved&theme_versions.order=version.desc&theme_versions.limit=1" +
            "$filter&order=${enc(order)}&limit=$PAGE&offset=${page * PAGE}", null)
        if (r.code !in 200..299) return@guarded BoardResult.Fail("Não foi possível carregar os temas (${r.code}).")
        val arr = JSONArray(r.text()); val authors = authorsOf(arr)
        BoardResult.Ok((0 until arr.length()).mapNotNull { parseTheme(arr.getJSONObject(it), authors) })
    }

    /** Temas desta conta (aprovados ou não, completos ou não). */
    fun mine(ctx: Context): BoardResult<List<BoardTheme>> = guarded {
        val s = token(ctx) ?: return@guarded BoardResult.Fail(NEED_LOGIN)
        val r = http("GET", "/rest/v1/themes?select=${enc(SELECT_MINE)}&owner_id=eq.${s.userId}&category=eq.$CATEGORY" +
            "&theme_versions.order=version.desc&theme_versions.limit=1&order=created_at.desc&limit=50", s.token)
        if (r.code !in 200..299) return@guarded BoardResult.Fail("Não foi possível carregar seus temas (${r.code}).")
        val arr = JSONArray(r.text())
        BoardResult.Ok((0 until arr.length()).mapNotNull { parseTheme(arr.getJSONObject(it), emptyMap()) })
    }

    /** Bytes da miniatura (bucket privado; a regra do servidor só deixa ler a de tema aprovado ou a sua). */
    fun previewBytes(ctx: Context, t: BoardTheme): ByteArray? = try {
        val p = t.previewPath ?: return null
        val r = http("GET", objPath(PREV_BUCKET, p), token(ctx)?.token, maxBytes = 512 * 1024)
        if (r.code in 200..299 && r.body.isNotEmpty()) r.body else null
    } catch (_: Exception) { null }

    // ------------------------------------------------------------------ baixar e instalar

    private fun local(ctx: Context) = ctx.applicationContext.getSharedPreferences(LOCAL, Context.MODE_PRIVATE)

    /** Id local (do ThemeSpec) do tema do ThemeBoard [boardId] se ele já foi instalado aqui, senão null. */
    fun installedSpecId(ctx: Context, boardId: String): String? =
        local(ctx).all.entries.firstOrNull { it.value == boardId }?.key?.takeIf { ThemeLibrary.get(it) != null }

    /** true se este tema local (id do ThemeSpec) já foi publicado por este app. */
    fun isPublished(ctx: Context, specId: String): Boolean = local(ctx).contains(specId)

    private fun clientKey(ctx: Context): String {
        val p = local(ctx)
        return p.getString("\$client", null) ?: UUID.randomUUID().toString().also { p.edit().putString("\$client", it).apply() }
    }

    /** Baixa, confere e instala. Nada é instalado se qualquer conferência falhar. */
    fun download(ctx: Context, t: BoardTheme): BoardResult<ThemeSpec> = guarded {
        val path = t.packagePath; val sha = t.sha256
        if (path == null || sha == null || t.version < 1 || t.versionStatus != "approved") return@guarded BoardResult.Fail("Este tema ainda não tem versão aprovada.")
        if (t.minAppVersion != null && t.minAppVersion > ThemeLibrary.appVersionCode) return@guarded BoardResult.Fail("Este tema precisa de uma versão mais nova do app.")
        if (t.sizeBytes > ThemePackage.MAX_PACKAGE_BYTES) return@guarded BoardResult.Fail("O pacote é grande demais.")
        val r = http("GET", objPath(PKG_BUCKET, path), token(ctx)?.token, maxBytes = ThemePackage.MAX_PACKAGE_BYTES)
        if (r.code == -2) return@guarded BoardResult.Fail("O pacote é grande demais.")
        if (r.code !in 200..299 || r.body.isEmpty()) return@guarded BoardResult.Fail("Não foi possível baixar o tema (${r.code}).")
        if (!ThemePackage.sha256(r.body).equals(sha, ignoreCase = true))
            return@guarded BoardResult.Fail("O arquivo não confere com o registro do ThemeBoard. Nada foi instalado.")
        when (val p = ThemeLibrary.readPackage(r.body.inputStream())) {
            is PackageRead.Fail -> BoardResult.Fail(p.reason)
            is PackageRead.Ok -> {
                val specId = p.spec.id
                val owner = local(ctx).getString(specId, null)
                if (ThemeLibrary.get(specId) != null && owner != t.id)
                    return@guarded BoardResult.Fail("Você já tem um tema local com o id \"$specId\". Apague-o antes de baixar este.")
                when (val i = ThemeLibrary.install(p, "themeboard:${t.id}:${t.version}")) {
                    is InstallResult.Fail -> BoardResult.Fail(i.reason)
                    is InstallResult.Ok -> {
                        local(ctx).edit().putString(i.spec.id, t.id).apply()
                        try { http("POST", "/rest/v1/rpc/register_download", null, JSONObject()
                            .put("p_theme_id", t.id).put("p_version", t.version).put("p_client", clientKey(ctx)).toString().toByteArray(),
                            "application/json") } catch (_: Exception) { }
                        BoardResult.Ok(i.spec)
                    }
                }
            }
        }
    }

    // ------------------------------------------------------------------ publicar

    /**
     * Publica um tema local como versão 1 (fica "pending" até um moderador aprovar):
     * 1) linha em `themes`; 2) pacote no bucket; 3) miniatura (opcional); 4) linha em `theme_versions`.
     * Se algo falha no meio, apaga os arquivos enviados; a linha em `themes` fica pendente e vazia ("Incompleto").
     */
    fun publish(ctx: Context, spec: ThemeSpec, pkg: PackageBuild.Ok, preview: ByteArray?): BoardResult<Unit> = guarded {
        val s = token(ctx) ?: return@guarded BoardResult.Fail(NEED_LOGIN)
        val row = JSONObject().put("owner_id", s.userId).put("title", spec.name.take(80)).put("description", spec.description.take(2000))
            .put("category", CATEGORY).put("tags", JSONArray(spec.tags.take(10))).put("status", "pending").put("spec_version", 1)
        val r1 = http("POST", "/rest/v1/themes", s.token, row.toString().toByteArray(), "application/json", mapOf("Prefer" to "return=representation"))
        if (r1.code !in 200..299) return@guarded BoardResult.Fail(
            if (r1.code == 401 || r1.code == 403) "Sua conta não pode publicar agora. Entre de novo." else "O servidor recusou o tema (${r1.code}).")
        val themeId = JSONArray(r1.text()).getJSONObject(0).getString("id")

        val pkgPath = "${s.userId}/$themeId/1/${spec.id}.mkt"
        val prevPath = if (preview != null) "${s.userId}/$themeId/preview.webp" else null
        fun upload(bucket: String, path: String, bytes: ByteArray, type: String) =
            http("POST", objPath(bucket, path), s.token, bytes, type, mapOf("x-upsert" to "false")).code
        fun cleanup() {
            try { http("DELETE", objPath(PKG_BUCKET, pkgPath), s.token) } catch (_: Exception) { }
            if (prevPath != null) try { http("DELETE", objPath(PREV_BUCKET, prevPath), s.token) } catch (_: Exception) { }
        }
        if (upload(PKG_BUCKET, pkgPath, pkg.bytes, "application/octet-stream") !in 200..299) return@guarded BoardResult.Fail("Não foi possível enviar o pacote.")
        if (preview != null) {
            if (upload(PREV_BUCKET, prevPath!!, preview, "image/webp") !in 200..299) { cleanup(); return@guarded BoardResult.Fail("Não foi possível enviar a miniatura.") }
            http("PATCH", "/rest/v1/themes?id=eq.${enc(themeId)}", s.token, JSONObject().put("preview_path", prevPath).toString().toByteArray(), "application/json")
        }
        val ver = JSONObject().put("theme_id", themeId).put("version", 1).put("package_path", pkgPath).put("sha256", pkg.sha256)
            .put("size_bytes", pkg.bytes.size).put("spec_version", 1).put("status", "pending")
        val r2 = http("POST", "/rest/v1/theme_versions", s.token, ver.toString().toByteArray(), "application/json", mapOf("Prefer" to "return=minimal"))
        if (r2.code !in 200..299) { cleanup(); return@guarded BoardResult.Fail("O servidor recusou a versão do tema (${r2.code}).") }
        local(ctx).edit().putString(spec.id, themeId).apply()      // lembra que este tema local já foi publicado
        BoardResult.Ok(Unit)
    }

    // ------------------------------------------------------------------ denunciar

    /** Denuncia um tema aprovado. [reason] precisa ter de 5 a 500 caracteres. */
    fun report(ctx: Context, t: BoardTheme, category: ReportCategory, reason: String): BoardResult<Unit> = guarded {
        val s = token(ctx) ?: return@guarded BoardResult.Fail(NEED_LOGIN)
        val txt = reason.trim()
        if (txt.length < 5) return@guarded BoardResult.Fail("Explique o motivo em pelo menos 5 letras.")
        val body = JSONObject().put("theme_id", t.id).put("reporter_id", s.userId).put("target_type", "theme")
            .put("category", category.key).put("reason", txt.take(500)).toString().toByteArray()
        val r = http("POST", "/rest/v1/reports", s.token, body, "application/json", mapOf("Prefer" to "return=minimal"))
        when {
            r.code in 200..299 || r.code == 409 -> BoardResult.Ok(Unit)
            else -> BoardResult.Fail("Não foi possível enviar a denúncia (${r.code}).")
        }
    }

    // ------------------------------------------------------------------ moderação
    // Só funciona para contas em `user_roles` (moderator/admin). Quem decide é o SERVIDOR (RLS + funções
    // moderate_theme/moderate_report): o app só mostra os botões; uma conta comum que tentasse receberia erro.

    @Volatile private var modCache: Pair<String, Boolean>? = null

    /** true se a conta conectada é moderadora. Guarda a resposta enquanto a conta for a mesma. */
    fun isModerator(ctx: Context): Boolean = try {
        val s = token(ctx) ?: return false
        modCache?.let { if (it.first == s.userId) return it.second }
        val r = http("GET", "/rest/v1/user_roles?select=role&user_id=eq.${enc(s.userId)}", s.token)
        val ok = r.code in 200..299 && JSONArray(r.text()).length() > 0
        if (r.code in 200..299) modCache = s.userId to ok
        ok
    } catch (_: Exception) { false }

    /** Temas esperando revisão (com versão pendente), do mais antigo para o mais novo. */
    fun pendingThemes(ctx: Context): BoardResult<List<BoardTheme>> = guarded {
        val s = token(ctx) ?: return@guarded BoardResult.Fail(NEED_LOGIN)
        val r = http("GET", "/rest/v1/themes?select=${enc(SELECT)}&category=eq.$CATEGORY&status=eq.pending" +
            "&theme_versions.status=eq.pending&theme_versions.order=version.desc&theme_versions.limit=1" +
            "&order=created_at.asc&limit=50", s.token)
        if (r.code !in 200..299) return@guarded BoardResult.Fail("Não foi possível carregar a fila (${r.code}).")
        val arr = JSONArray(r.text()); val authors = authorsOf(arr)
        BoardResult.Ok((0 until arr.length()).mapNotNull { parseTheme(arr.getJSONObject(it), authors) })
    }

    /**
     * Baixa o pacote de um tema pendente para o moderador CONFERIR (o servidor só deixa moderador/dono ler).
     * Não instala nada. Confere o SHA-256 e valida o pacote com as mesmas regras de uma instalação.
     */
    fun reviewPackage(ctx: Context, t: BoardTheme): BoardResult<ReviewData> = guarded {
        val s = token(ctx) ?: return@guarded BoardResult.Fail(NEED_LOGIN)
        val path = t.packagePath; val sha = t.sha256
        if (path == null || sha == null) return@guarded BoardResult.Fail("Este tema não tem pacote para conferir.")
        if (t.sizeBytes > ThemePackage.MAX_PACKAGE_BYTES) return@guarded BoardResult.Fail("O pacote é grande demais.")
        val r = http("GET", objPath(PKG_BUCKET, path), s.token, maxBytes = ThemePackage.MAX_PACKAGE_BYTES)
        if (r.code == -2) return@guarded BoardResult.Fail("O pacote é grande demais.")
        if (r.code !in 200..299 || r.body.isEmpty()) return@guarded BoardResult.Fail("Não foi possível baixar o pacote (${r.code}).")
        val shaOk = ThemePackage.sha256(r.body).equals(sha, ignoreCase = true)
        when (val p = ThemeLibrary.readPackage(r.body.inputStream())) {
            is PackageRead.Fail -> BoardResult.Fail("Pacote inválido: " + p.reason)
            is PackageRead.Ok -> BoardResult.Ok(ReviewData(p.spec, ThemePreviewRenderer.render(p.spec),
                p.spec.image?.let { im -> p.assets[im.asset] }, p.warnings, shaOk))
        }
    }

    private fun rpcError(r: Resp): String {
        val m = try { JSONObject(r.text()).optString("message") } catch (_: Exception) { "" }
        return when {
            m.contains("not_allowed") || r.code == 401 || r.code == 403 -> "Sua conta não é de moderador."
            m.contains("not_pending") || m.contains("no_version") || m.contains("not_open") ->
                "Outra pessoa já resolveu este item. Atualize a fila."
            m.contains("reason_required") -> "Explique o motivo (mínimo 3 letras)."
            else -> "O servidor recusou a ação (${r.code})."
        }
    }

    private fun rpc(ctx: Context, fn: String, body: JSONObject): BoardResult<Unit> {
        val s = token(ctx) ?: return BoardResult.Fail(NEED_LOGIN)
        val r = http("POST", "/rest/v1/rpc/$fn", s.token, body.toString().toByteArray(), "application/json")
        return if (r.code in 200..299) BoardResult.Ok(Unit) else BoardResult.Fail(rpcError(r))
    }

    /** Aprova ([approve] = true) ou recusa um tema pendente (tema + versão, numa transação só). Recusar exige [reason]. */
    fun moderateTheme(ctx: Context, themeId: String, approve: Boolean, reason: String?): BoardResult<Unit> = guarded {
        rpc(ctx, "moderate_theme", JSONObject().put("p_theme_id", themeId).put("p_approve", approve)
            .put("p_reason", reason?.trim()?.take(300) ?: JSONObject.NULL))
    }

    /** Denúncias abertas, da mais antiga para a mais nova. */
    fun openReports(ctx: Context): BoardResult<List<BoardReport>> = guarded {
        val s = token(ctx) ?: return@guarded BoardResult.Fail(NEED_LOGIN)
        val r = http("GET", "/rest/v1/reports?select=${enc("id,theme_id,category,reason,themes(title,status)")}" +
            "&status=eq.open&order=created_at.asc&limit=50", s.token)
        if (r.code !in 200..299) return@guarded BoardResult.Fail("Não foi possível carregar as denúncias (${r.code}).")
        val arr = JSONArray(r.text())
        BoardResult.Ok((0 until arr.length()).mapNotNull { i ->
            try {
                val o = arr.getJSONObject(i); val th = o.optJSONObject("themes")
                BoardReport(o.getString("id"), o.getString("theme_id"), th?.optString("title").orEmpty().ifBlank { "—" },
                    th?.optString("status").orEmpty(), o.optString("category"), o.optString("reason"))
            } catch (_: Exception) { null }
        })
    }

    /** Resolve uma denúncia: [hideTheme] = false descarta; true oculta o tema e resolve todas as denúncias abertas dele. */
    fun moderateReport(ctx: Context, reportId: String, hideTheme: Boolean, note: String?): BoardResult<Unit> = guarded {
        rpc(ctx, "moderate_report", JSONObject().put("p_report_id", reportId).put("p_hide_theme", hideTheme)
            .put("p_note", note?.trim()?.take(500) ?: JSONObject.NULL))
    }
}

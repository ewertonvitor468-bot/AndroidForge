package com.example.materialkeyboard.updates

/**
 * Configuração do sistema de atualizações: o app consulta o ÚLTIMO RELEASE do GitHub (API pública, sem chave).
 * Para lançar uma versão: crie um release com a tag igual ao versionName do APK (ex.: v54.8) e anexe o .apk.
 * O repositório precisa ser público.
 */
object UpdatesConfig {
    const val GITHUB_OWNER = "ewertonvitor468-bot"
    const val GITHUB_REPO = "materialkeyboard"

    /** Intervalo mínimo entre verificações automáticas (ao abrir as configurações). */
    const val AUTO_CHECK_MS = 6L * 60 * 60 * 1000
    /** Limite de segurança para o tamanho do APK baixado. */
    const val MAX_APK_BYTES = 250L * 1024 * 1024

    val configured: Boolean get() = GITHUB_OWNER.isNotBlank() && GITHUB_REPO.isNotBlank()
}

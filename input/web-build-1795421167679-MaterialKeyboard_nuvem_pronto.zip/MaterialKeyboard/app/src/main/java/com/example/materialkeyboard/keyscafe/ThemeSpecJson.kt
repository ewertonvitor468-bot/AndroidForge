package com.example.materialkeyboard.keyscafe

import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject

sealed class SpecParse {
    /** [warnings]: coisas ajustadas (valor fora da faixa, texto cortado...). O tema continua válido. */
    data class Ok(val spec: ThemeSpec, val warnings: List<String>) : SpecParse()
    /** [reason]: motivo legível, pronto para mostrar à pessoa. */
    data class Fail(val reason: String) : SpecParse()
}

/**
 * Leitura e escrita do theme.json.
 * Regra de ouro: o JSON vem de terceiros (ThemeBoard ou arquivo), então NADA é aplicado sem passar por aqui.
 * Tipo errado = recusa. Número fora da faixa = ajustado para a faixa segura, com aviso.
 */
object ThemeSpecJson {

    private class SpecError(msg: String) : Exception(msg)

    /** [appVersion]: versionCode do app, para recusar temas que pedem um app mais novo. */
    fun parse(text: String, appVersion: Int = Int.MAX_VALUE): SpecParse {
        if (text.length > SpecLimits.JSON_MAX_CHARS) return SpecParse.Fail("O arquivo do tema é grande demais.")
        return try {
            val warnings = ArrayList<String>()
            val root = JSONObject(text)
            SpecParse.Ok(read(root, warnings, appVersion), warnings)
        } catch (e: SpecError) {
            SpecParse.Fail(e.message ?: "Tema inválido.")
        } catch (e: JSONException) {
            SpecParse.Fail("O arquivo do tema não é um JSON válido.")
        }
    }

    // ---------------------------------------------------------------- leitura

    private fun read(root: JSONObject, w: MutableList<String>, appVersion: Int): ThemeSpec {
        val ver = int(root, "spec_version", 1..Int.MAX_VALUE, 1, "", w)
        if (ver > SpecLimits.SPEC_VERSION) {
            throw SpecError("Este tema usa um formato mais novo (v$ver). Atualize o app para usá-lo.")
        }
        val minApp = int(root, "min_app_version", 0..Int.MAX_VALUE, 0, "", w)
        if (minApp > appVersion) throw SpecError("Este tema precisa de uma versão mais nova do app.")

        val id = str(root, "id", 40, "", w, required = true)
        if (!SpecLimits.ID_REGEX.matches(id)) {
            throw SpecError("id inválido: use 3 a 40 caracteres entre a-z, 0-9, _ e -.")
        }
        val name = str(root, "name", SpecLimits.NAME_MAX, "", w, required = true)
        val author = str(root, "author", SpecLimits.AUTHOR_MAX, "", w)
        val desc = str(root, "description", SpecLimits.DESC_MAX, "", w)
        val inspired = str(root, "inspired_by", SpecLimits.INSPIRED_MAX, "", w)
        val tags = readTags(root, w)

        val po = root.optJSONObject("palette") ?: throw SpecError("palette é obrigatório.")
        if (!po.has("dark") || po.opt("dark") !is Boolean) throw SpecError("palette.dark deve ser true ou false.")
        val palette = SpecPalette(
            dark = po.getBoolean("dark"),
            surface = color(po, "surface", "palette."), normal = color(po, "normal", "palette."),
            special = color(po, "special", "palette."), accent = color(po, "accent", "palette."),
            onNormal = color(po, "on_normal", "palette."), onSpecial = color(po, "on_special", "palette."),
            onAccent = color(po, "on_accent", "palette.")
        )

        val gradients = readGradients(root, w)

        val kd = SpecKeys()
        val ko = root.optJSONObject("keys") ?: JSONObject()
        val keys = SpecKeys(
            keyStyle = int(ko, "key_style", SpecLimits.KEY_STYLE, kd.keyStyle, "keys.", w),
            keyShape = int(ko, "key_shape", SpecLimits.KEY_SHAPE, kd.keyShape, "keys.", w),
            accentShape = int(ko, "accent_shape", SpecLimits.ACCENT_SHAPE, kd.accentShape, "keys.", w),
            keyRadius = int(ko, "key_radius", SpecLimits.KEY_RADIUS, kd.keyRadius, "keys.", w),
            boardRadius = int(ko, "board_radius", SpecLimits.BOARD_RADIUS, kd.boardRadius, "keys.", w),
            keyGap = int(ko, "key_gap", SpecLimits.KEY_GAP, kd.keyGap, "keys.", w),
            keyAlpha = int(ko, "key_alpha", SpecLimits.KEY_ALPHA, kd.keyAlpha, "keys.", w),
            blurAmount = int(ko, "blur", SpecLimits.BLUR, kd.blurAmount, "keys.", w),
            pressGlow = bool(ko, "press_glow", kd.pressGlow, "keys."),
            keyBorder = int(ko, "key_border", SpecLimits.KEY_BORDER, kd.keyBorder, "keys.", w),
            keyDepth = int(ko, "key_depth", SpecLimits.KEY_DEPTH, kd.keyDepth, "keys.", w),
            expressive = bool(ko, "expressive", kd.expressive, "keys.")
        )

        val td = SpecText()
        val txo = root.optJSONObject("text") ?: JSONObject()
        val text = SpecText(
            fontStyle = int(txo, "font_style", SpecLimits.FONT_STYLE, td.fontStyle, "text.", w),
            textScale = int(txo, "text_scale", SpecLimits.TEXT_SCALE, td.textScale, "text.", w),
            fontColor = if (txo.has("font_color") && !txo.isNull("font_color")) color(txo, "font_color", "text.") else null
        )

        val bd = SpecBubble()
        val bo = root.optJSONObject("bubble") ?: JSONObject()
        val bubble = SpecBubble(
            shape = int(bo, "shape", SpecLimits.BUBBLE_SHAPE, bd.shape, "bubble.", w),
            size = int(bo, "size", SpecLimits.BUBBLE_SIZE, bd.size, "bubble.", w),
            color = int(bo, "color", SpecLimits.BUBBLE_COLOR, bd.color, "bubble.", w),
            hue = int(bo, "hue", SpecLimits.BUBBLE_HUE, bd.hue, "bubble.", w),
            anim = bool(bo, "anim", bd.anim, "bubble.")
        )

        val ad = SpecAnimation()
        val ao = root.optJSONObject("animation") ?: JSONObject()
        val animation = SpecAnimation(
            speed = int(ao, "speed", SpecLimits.ANIM_SPEED, ad.speed, "animation.", w),
            bounce = int(ao, "bounce", SpecLimits.ANIM_BOUNCE, ad.bounce, "animation.", w),
            scene = int(ao, "scene", SpecLimits.SCENE, ad.scene, "animation.", w)
        )

        val brd = SpecBar()
        val bro = root.optJSONObject("bar") ?: JSONObject()
        val bar = SpecBar(
            micShape = int(bro, "mic_shape", SpecLimits.BAR_BUTTON_SHAPE, brd.micShape, "bar.", w),
            toolShape = int(bro, "tool_shape", SpecLimits.BAR_BUTTON_SHAPE, brd.toolShape, "bar.", w),
            barStyle = int(bro, "bar_style", SpecLimits.BAR_STYLE, brd.barStyle, "bar.", w)
        )

        val image = root.optJSONObject("image")?.let { io ->
            val asset = str(io, "asset", 80, "image.", w, required = true)
            if (!ASSET_PATH.matches(asset)) throw SpecError("image.asset inválido.")
            val id0 = SpecImage(asset)
            SpecImage(
                asset = asset,
                dim = int(io, "dim", SpecLimits.IMAGE_DIM, id0.dim, "image.", w),
                pos = int(io, "pos", SpecLimits.IMAGE_POS, id0.pos, "image.", w)
            )
        }

        return ThemeSpec(
            specVersion = ver, minAppVersion = minApp, id = id, name = name, author = author,
            description = desc, inspiredBy = inspired, tags = tags, palette = palette,
            gradients = gradients, keys = keys, text = text, bubble = bubble,
            animation = animation, bar = bar, image = image
        )
    }

    private val ASSET_PATH = Regex("^assets/[A-Za-z0-9._-]{1,64}$")

    private fun readTags(root: JSONObject, w: MutableList<String>): List<String> {
        val arr = root.optJSONArray("tags") ?: return emptyList()
        val out = LinkedHashSet<String>()
        for (i in 0 until arr.length()) {
            val v = arr.opt(i) as? String ?: throw SpecError("tags deve ser uma lista de textos.")
            val t = clean(v).lowercase().take(SpecLimits.TAG_MAX)
            if (t.isNotEmpty()) out.add(t)
        }
        if (out.size > SpecLimits.TAGS_MAX) w.add("tags: só as ${SpecLimits.TAGS_MAX} primeiras foram mantidas")
        return out.take(SpecLimits.TAGS_MAX)
    }

    private fun readGradients(root: JSONObject, w: MutableList<String>): List<SpecGradient> {
        val arr = root.optJSONArray("gradients") ?: return emptyList()
        if (arr.length() > SpecLimits.GRADIENTS_MAX) w.add("gradients: só os ${SpecLimits.GRADIENTS_MAX} primeiros foram mantidos")
        val out = ArrayList<SpecGradient>()
        for (i in 0 until minOf(arr.length(), SpecLimits.GRADIENTS_MAX)) {
            val g = arr.optJSONObject(i) ?: throw SpecError("gradients[$i] inválido.")
            val path = "gradients[$i]."
            val target = g.opt("target") as? String ?: throw SpecError("${path}target é obrigatório.")
            if (target !in SpecGradient.TARGETS) throw SpecError("${path}target deve ser surface, key ou accent.")
            val angle = int(g, "angle", 0..359, 0, path, w)
            val ca = g.optJSONArray("colors") ?: throw SpecError("${path}colors é obrigatório.")
            if (ca.length() !in SpecLimits.GRADIENT_COLORS) throw SpecError("${path}colors deve ter de 2 a 4 cores.")
            val cols = ArrayList<Long>()
            for (k in 0 until ca.length()) {
                val s = ca.opt(k) as? String ?: throw SpecError("${path}colors[$k] deve ser #RRGGBB.")
                cols.add(parseColor(s, "${path}colors[$k]", opaque = false))
            }
            out.add(SpecGradient(target, angle, cols))
        }
        return out
    }

    // ---------------------------------------------------------------- campos

    private fun number(o: JSONObject, key: String, path: String): Double? {
        if (!o.has(key) || o.isNull(key)) return null
        val v = o.get(key)
        if (v !is Number) throw SpecError("$path$key deve ser um número.")
        val d = v.toDouble()
        if (d.isNaN() || d.isInfinite()) throw SpecError("$path$key é inválido.")
        return d
    }

    private fun int(o: JSONObject, key: String, range: IntRange, def: Int, path: String, w: MutableList<String>): Int {
        val d = number(o, key, path) ?: return def
        val n = d.toLong().coerceIn(Int.MIN_VALUE.toLong(), Int.MAX_VALUE.toLong()).toInt()
        if (n in range) return n
        w.add("$path$key fora da faixa (${range.first} a ${range.last}); ajustado")
        return n.coerceIn(range.first, range.last)
    }

    private fun bool(o: JSONObject, key: String, def: Boolean, path: String): Boolean {
        if (!o.has(key) || o.isNull(key)) return def
        val v = o.get(key)
        if (v !is Boolean) throw SpecError("$path$key deve ser true ou false.")
        return v
    }

    private fun str(o: JSONObject, key: String, max: Int, path: String, w: MutableList<String>, required: Boolean = false): String {
        if (!o.has(key) || o.isNull(key)) {
            if (required) throw SpecError("$path$key é obrigatório.")
            return ""
        }
        val v = o.get(key)
        if (v !is String) throw SpecError("$path$key deve ser um texto.")
        val c = clean(v)
        if (required && c.isEmpty()) throw SpecError("$path$key não pode ficar vazio.")
        if (c.length > max) { w.add("$path$key cortado em $max caracteres"); return c.take(max) }
        return c
    }

    /** Tira caracteres de controle e os que invertem a direção do texto (usados para enganar o olho). */
    private fun clean(s: String): String = s.filter {
        !it.isISOControl() && it.code !in 0x202A..0x202E && it.code !in 0x2066..0x2069
    }.trim()

    private fun color(o: JSONObject, key: String, path: String): Long {
        val s = o.opt(key) as? String ?: throw SpecError("$path$key deve ser uma cor #RRGGBB.")
        return parseColor(s, "$path$key", opaque = true)
    }

    /** "#RRGGBB" ou "#AARRGGBB". [opaque] força o alfa em 255 (cores do tema nunca ficam transparentes). */
    private fun parseColor(s: String, path: String, opaque: Boolean): Long {
        val t = s.trim()
        if (!t.startsWith("#") || (t.length != 7 && t.length != 9)) throw SpecError("$path: cor inválida.")
        val body = t.substring(1)
        if (!body.all { it in '0'..'9' || it in 'a'..'f' || it in 'A'..'F' }) throw SpecError("$path: cor inválida.")
        var c = body.toLong(16)
        if (t.length == 7 || opaque) c = c or 0xFF000000L
        return c
    }

    // ---------------------------------------------------------------- escrita

    fun toJson(s: ThemeSpec): String {
        val o = JSONObject()
        o.put("spec_version", s.specVersion)
        if (s.minAppVersion > 0) o.put("min_app_version", s.minAppVersion)
        o.put("id", s.id)
        o.put("name", s.name)
        if (s.author.isNotEmpty()) o.put("author", s.author)
        if (s.description.isNotEmpty()) o.put("description", s.description)
        if (s.inspiredBy.isNotEmpty()) o.put("inspired_by", s.inspiredBy)
        if (s.tags.isNotEmpty()) o.put("tags", JSONArray(s.tags))

        o.put("palette", JSONObject().apply {
            put("dark", s.palette.dark)
            put("surface", hex(s.palette.surface)); put("normal", hex(s.palette.normal))
            put("special", hex(s.palette.special)); put("accent", hex(s.palette.accent))
            put("on_normal", hex(s.palette.onNormal)); put("on_special", hex(s.palette.onSpecial))
            put("on_accent", hex(s.palette.onAccent))
        })

        if (s.gradients.isNotEmpty()) {
            val ga = JSONArray()
            s.gradients.forEach { g ->
                ga.put(JSONObject().apply {
                    put("target", g.target); put("angle", g.angle)
                    put("colors", JSONArray(g.colors.map { hex(it) }))
                })
            }
            o.put("gradients", ga)
        }

        o.put("keys", JSONObject().apply {
            put("key_style", s.keys.keyStyle); put("key_shape", s.keys.keyShape)
            put("accent_shape", s.keys.accentShape); put("key_radius", s.keys.keyRadius)
            put("board_radius", s.keys.boardRadius); put("key_gap", s.keys.keyGap)
            put("key_alpha", s.keys.keyAlpha); put("blur", s.keys.blurAmount)
            put("press_glow", s.keys.pressGlow)
            put("key_border", s.keys.keyBorder); put("key_depth", s.keys.keyDepth)
            put("expressive", s.keys.expressive)
        })
        o.put("text", JSONObject().apply {
            put("font_style", s.text.fontStyle); put("text_scale", s.text.textScale)
            s.text.fontColor?.let { put("font_color", hex(it)) }
        })
        o.put("bubble", JSONObject().apply {
            put("shape", s.bubble.shape); put("size", s.bubble.size); put("color", s.bubble.color)
            put("hue", s.bubble.hue); put("anim", s.bubble.anim)
        })
        o.put("animation", JSONObject().apply {
            put("speed", s.animation.speed); put("bounce", s.animation.bounce); put("scene", s.animation.scene)
        })
        o.put("bar", JSONObject().apply {
            put("mic_shape", s.bar.micShape); put("tool_shape", s.bar.toolShape); put("bar_style", s.bar.barStyle)
        })
        s.image?.let { im ->
            o.put("image", JSONObject().apply { put("asset", im.asset); put("dim", im.dim); put("pos", im.pos) })
        }
        return o.toString(2)
    }

    private fun hex(c: Long): String =
        if (((c shr 24) and 0xFF) == 0xFFL) "#%06X".format(c and 0xFFFFFFL)
        else "#%08X".format(c and 0xFFFFFFFFL)
}

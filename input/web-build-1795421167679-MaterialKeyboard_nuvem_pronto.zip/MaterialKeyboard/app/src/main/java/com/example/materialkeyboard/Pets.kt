package com.example.materialkeyboard

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.os.SystemClock
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.view.Choreographer
import android.view.MotionEvent
import android.view.View
import androidx.core.graphics.ColorUtils
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

/**
 * Camada de efeitos por cima do teclado: partículas do cenário animado + bichinhos (cachorro, gato e coelho).
 *
 * - Tem UM relógio de quadros próprio, que para quando a janela some e volta sozinho quando ela aparece
 *   ([resume] é seguro de chamar a qualquer momento). Antes as partículas eram o "foreground" do teclado inteiro.
 * - Só reage ao toque quando o dedo cai em cima de um bichinho ou balão E a pessoa não está digitando
 *   (nenhum outro toque nos últimos [TYPING_MS] ms). Em qualquer outro caso o toque passa direto para as teclas.
 */
class FxOverlay(
    ctx: Context,
    private val scene: Int,
    topR: Float,
    private val prefs: Prefs,
    private val pal: Palette,
    /** false = há outro painel aberto (emojis, clipboard...): bichinhos escondidos e sem toque. */
    private val petsVisible: () -> Boolean
) : View(ctx) {

    private val dens = resources.displayMetrics.density
    private val rnd = Random(System.nanoTime())
    private val sceneDrawable: SceneDrawable? = if (scene > 0) SceneDrawable(scene, topR, dens, false) else null

    // ---------- bichinhos ----------

    private class Bubble(
        val sound: StaticLayout, val trans: StaticLayout,
        val soundW: Float, val transW: Float, var until: Long
    ) {
        var showTrans = false
        val rect = RectF()
    }

    private class Pet(val kind: Int) {
        var placed = false
        var x = 0f; var y = 0f; var tx = 0f; var ty = 0f
        var dir = 1f
        var moving = false
        var idle = 1f
        var phase = 0f; var wag = 0f
        var blink = 0f; var nextBlink = 2f
        var hop = 0f; var speak = 0f
        var tapCount = 0; var lastTap = 0L
        var nameUntil = 0L
        var lastLine = -1
        var bubble: Bubble? = null
    }

    private val pets = ArrayList<Pet>()
    private var petPx = 34f * dens
    private var sortTick = 0

    // pincéis reaproveitados (nada é alocado por quadro)
    private val fp = Paint(Paint.ANTI_ALIAS_FLAG)
    private val sp = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 1.6f; strokeJoin = Paint.Join.ROUND }
    private val lp = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND }
    private val bubblePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tpSound = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 12f * dens; isFakeBoldText = true }
    private val tpTrans = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 11f * dens }
    private val tpName = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 10f * dens; isFakeBoldText = true; textAlign = Paint.Align.CENTER }
    private val r = RectF()
    private val path = Path()
    private var outline = Color.BLACK

    init {
        for (k in 0 until 3) if (prefs.petOn[k]) pets.add(Pet(k))
        isClickable = false
        isFocusable = false
        importantForAccessibility = IMPORTANT_FOR_ACCESSIBILITY_NO
    }

    // ---------- relógio de quadros (à prova de "travar") ----------

    private var running = false
    private var last = 0L
    private var acc = 0f

    private val frame = object : Choreographer.FrameCallback {
        override fun doFrame(now: Long) {
            if (!running) return
            if (!isAttachedToWindow) { running = false; return }
            val dt = if (last == 0L) 0.016f else ((now - last) / 1_000_000_000f).coerceIn(0f, 0.05f)
            last = now
            acc += dt
            if (acc >= 0.0145f) {            // no máximo ~60 quadros por segundo, mesmo em telas de 90/120 Hz
                val d = acc; acc = 0f
                step(d)
                invalidate()
            }
            Choreographer.getInstance().postFrameCallback(this)
        }
    }

    /** (Re)inicia a animação. Pode ser chamado quantas vezes quiser: sempre deixa exatamente UM callback ativo. */
    fun resume() {
        Choreographer.getInstance().removeFrameCallback(frame)
        running = false
        if (!isAttachedToWindow || (sceneDrawable == null && pets.isEmpty())) return
        running = true; last = 0L; acc = 0f
        Choreographer.getInstance().postFrameCallback(frame)
    }

    fun pause() {
        running = false
        Choreographer.getInstance().removeFrameCallback(frame)
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); resume() }
    override fun onDetachedFromWindow() { pause(); super.onDetachedFromWindow() }
    override fun onWindowVisibilityChanged(visibility: Int) {
        super.onWindowVisibilityChanged(visibility)
        if (visibility == VISIBLE) resume() else pause()
    }
    override fun onVisibilityAggregated(isVisible: Boolean) {
        super.onVisibilityAggregated(isVisible)
        if (isVisible) resume() else pause()
    }

    /**
     * Esta camada NUNCA pode aumentar a janela do teclado: na primeira medição (altura "no máximo") ela devolve 0;
     * só quando o pai já sabe a altura do teclado (medida exata) ela ocupa exatamente essa área.
     * (Sem isso a janela virava tela cheia: partículas pelo app todo e fundo borrado embaixo.)
     */
    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val w = MeasureSpec.getSize(widthMeasureSpec)
        val h = if (MeasureSpec.getMode(heightMeasureSpec) == MeasureSpec.EXACTLY) MeasureSpec.getSize(heightMeasureSpec) else 0
        setMeasuredDimension(w, h)
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        sceneDrawable?.setBounds(0, 0, w, h)
        petPx = min(prefs.petSize * dens, h * 0.4f).coerceAtLeast(16f * dens)
        for (p in pets) {
            if (!p.placed && w > 0 && h > 0) {
                p.placed = true
                p.x = petPx + rnd.nextFloat() * max(1f, w - 2 * petPx)
                p.y = petPx * 1.1f + rnd.nextFloat() * max(1f, h - petPx * 1.2f)
                p.dir = if (rnd.nextBoolean()) 1f else -1f
                p.idle = 0.4f + rnd.nextFloat() * 1.5f
            }
        }
    }

    // ---------- simulação ----------

    private fun step(dt: Float) {
        sceneDrawable?.tick(dt)
        if (pets.isEmpty()) return
        val now = SystemClock.uptimeMillis()
        for (p in pets) updatePet(p, dt, now)
        if (++sortTick % 20 == 0) pets.sortBy { it.y }       // quem está mais embaixo é desenhado por cima
    }

    private fun pickTarget(p: Pet) {
        val w = width.toFloat(); val h = height.toFloat()
        val half = petPx * 0.6f
        p.tx = half + rnd.nextFloat() * max(1f, w - 2 * half)
        p.ty = petPx * 1.1f + rnd.nextFloat() * max(1f, h - petPx * 1.1f - 6f * dens)
        p.moving = true
    }

    private fun updatePet(p: Pet, dt: Float, now: Long) {
        if (!p.placed) return
        p.nextBlink -= dt
        if (p.nextBlink <= 0f) { p.blink = 0.14f; p.nextBlink = 2f + rnd.nextFloat() * 3.5f }
        if (p.blink > 0f) p.blink -= dt
        if (p.hop > 0f) p.hop = max(0f, p.hop - dt * 2.2f)
        if (p.speak > 0f) p.speak -= dt
        p.wag += dt * (if (p.moving) 13f else 6f)

        if (p.moving) {
            val dx = p.tx - p.x; val dy = p.ty - p.y
            val d = hypot(dx, dy)
            if (d < 3f * dens) {
                p.moving = false; p.idle = 1.5f + rnd.nextFloat() * 3.5f
            } else {
                var speed = (if (p.kind == PetLines.CAT) 30f else 38f) * dens
                if (p.kind == PetLines.RABBIT) {
                    p.phase += dt * 2.8f
                    speed *= 1.9f * abs(sin(PI_F * p.phase))      // só avança no ar, entre um pulo e outro
                } else {
                    p.phase += dt * (if (p.kind == PetLines.CAT) 7f else 9f)
                }
                p.x += dx / d * speed * dt
                p.y += dy / d * speed * dt
                if (abs(dx) > 2f * dens) p.dir = if (dx > 0f) 1f else -1f
            }
        } else {
            p.idle -= dt
            if (p.idle <= 0f && p.hop <= 0f && p.bubble == null) pickTarget(p)
            else if (p.idle <= 0f) p.idle = 0.8f
        }
        val half = petPx * 0.6f
        p.x = p.x.coerceIn(half, max(half, width - half))
        p.y = p.y.coerceIn(petPx * 1.05f, max(petPx * 1.05f, height - 3f * dens))
        val b = p.bubble
        if (b != null && now > b.until) p.bubble = null
    }

    // ---------- desenho ----------

    override fun onDraw(c: Canvas) {
        sceneDrawable?.draw(c)
        if (pets.isEmpty() || !petsVisible()) return
        outline = Color.argb(200, 30, 20, 20)
        val now = SystemClock.uptimeMillis()
        for (p in pets) if (p.placed) drawPet(c, p)
        for (p in pets) if (p.placed) drawLabel(c, p, now)
    }

    private fun oval(c: Canvas, cx: Float, cy: Float, rx: Float, ry: Float, fill: Int, stroke: Boolean = true) {
        r.set(cx - rx, cy - ry, cx + rx, cy + ry)
        fp.color = fill; c.drawOval(r, fp)
        if (stroke) { sp.color = outline; c.drawOval(r, sp) }
    }

    private fun line(c: Canvas, x1: Float, y1: Float, x2: Float, y2: Float, w: Float, color: Int, edge: Boolean = true) {
        lp.strokeCap = Paint.Cap.ROUND
        if (edge) { lp.strokeWidth = w + 3f; lp.color = outline; c.drawLine(x1, y1, x2, y2, lp) }
        lp.strokeWidth = w; lp.color = color; c.drawLine(x1, y1, x2, y2, lp)
    }

    private fun strokePath(c: Canvas, w: Float, color: Int) {
        lp.strokeCap = Paint.Cap.ROUND
        lp.strokeWidth = w + 3f; lp.color = outline; c.drawPath(path, lp)
        lp.strokeWidth = w; lp.color = color; c.drawPath(path, lp)
    }

    private fun fillPath(c: Canvas, fill: Int, stroke: Boolean = true) {
        fp.color = fill; c.drawPath(path, fp)
        if (stroke) { sp.color = outline; c.drawPath(path, sp) }
    }

    private fun eye(c: Canvas, p: Pet, x: Float, y: Float) {
        if (p.blink > 0f) { line(c, x - 3f, y, x + 3f, y, 1.8f, 0xFF222222.toInt(), false); return }
        oval(c, x, y, 2.7f, 3f, 0xFF222222.toInt(), false)
        oval(c, x + 0.9f, y - 1f, 0.9f, 0.9f, Color.WHITE, false)
    }

    private fun mouth(c: Canvas, p: Pet, x: Float, y: Float) {
        if (p.speak > 0f) {
            val open = 2.2f + 2f * (0.5f + 0.5f * sin(p.speak * 22f))
            oval(c, x, y, 4.2f, open, 0xFF7A2230.toInt(), false)
        } else line(c, x - 3f, y, x + 3f, y, 1.3f, 0xFF3A2020.toInt(), false)
    }

    private fun drawPet(c: Canvas, p: Pet) {
        val s = petPx / 100f
        val body = prefs.petBody[p.kind]; val detail = prefs.petDetail[p.kind]
        val dark = ColorUtils.blendARGB(body, Color.BLACK, 0.28f)
        val light = ColorUtils.blendARGB(body, Color.WHITE, 0.42f)
        val hopUnits = if (p.kind == PetLines.RABBIT && p.moving) abs(sin(PI_F * p.phase)) * 20f else 0f
        val jump = if (p.hop > 0f) sin(p.hop * PI_F) * 18f else 0f

        c.save()
        c.translate(p.x, p.y)
        c.scale(s * p.dir, s)
        // sombra no chão
        fp.color = Color.argb(55, 0, 0, 0)
        r.set(-34f, -3f, 34f, 3f); c.drawOval(r, fp)
        c.translate(0f, -(hopUnits + jump))
        when (p.kind) {
            PetLines.DOG -> drawDog(c, p, body, detail, dark, light)
            PetLines.CAT -> drawCat(c, p, body, detail, dark)
            else -> drawRabbit(c, p, body, detail, dark, light)
        }
        c.restore()
    }

    private fun drawDog(c: Canvas, p: Pet, body: Int, detail: Int, dark: Int, light: Int) {
        val sw = if (p.moving) sin(p.phase) * 9f else 0f
        val wag = sin(p.wag) * 8f
        line(c, -16f, -34f, -16f - sw, -3f, 9f, dark)         // pernas de trás
        line(c, 26f, -34f, 26f + sw, -3f, 9f, dark)
        path.rewind(); path.moveTo(-34f, -54f); path.quadTo(-48f, -58f, -45f + wag * 0.5f, -78f)
        strokePath(c, 8f, body)                                // rabo
        oval(c, -4f, -48f, 34f, 17f, body)                     // corpo
        oval(c, -14f, -52f, 10f, 7f, detail, false)            // mancha
        line(c, -26f, -34f, -26f + sw, -3f, 9f, body)          // pernas da frente
        line(c, 18f, -34f, 18f - sw, -3f, 9f, body)
        oval(c, 32f, -70f, 16f, 15f, body)                     // cabeça
        oval(c, 46f, -65f, 11f, 8f, light)                     // focinho
        c.save(); c.translate(24f, -78f); c.rotate(18f + (if (p.moving) sin(p.wag * 0.5f) * 5f else 0f))
        oval(c, 0f, 6f, 6.5f, 13f, detail); c.restore()        // orelha caída
        eye(c, p, 38f, -73f)
        oval(c, 55f, -68f, 3.8f, 3f, 0xFF222222.toInt(), false) // nariz
        mouth(c, p, 49f, -59f)
    }

    private fun drawCat(c: Canvas, p: Pet, body: Int, detail: Int, dark: Int) {
        val sw = if (p.moving) sin(p.phase) * 8f else 0f
        val sway = sin(p.wag * 0.6f) * 5f
        line(c, -16f, -32f, -16f - sw, -3f, 7f, dark)
        line(c, 24f, -32f, 24f + sw, -3f, 7f, dark)
        path.rewind(); path.moveTo(-34f, -46f); path.cubicTo(-58f + sway, -50f, -58f, -84f, -42f + sway, -90f)
        strokePath(c, 7f, body)                                // rabo comprido
        oval(c, -42f + sway, -90f, 4.3f, 4.3f, detail)         // ponta do rabo
        oval(c, -4f, -46f, 33f, 14f, body)
        for (x in intArrayOf(-18, -8, 2)) line(c, x.toFloat(), -58f, x + 2f, -49f, 2.4f, dark, false)
        line(c, -26f, -32f, -26f + sw, -3f, 7f, body)
        line(c, 18f, -32f, 18f - sw, -3f, 7f, body)
        // orelhas
        path.rewind(); path.moveTo(19f, -72f); path.lineTo(21f, -95f); path.lineTo(33f, -76f); path.close(); fillPath(c, body)
        path.rewind(); path.moveTo(29f, -77f); path.lineTo(40f, -94f); path.lineTo(44f, -71f); path.close(); fillPath(c, body)
        path.rewind(); path.moveTo(23f, -76f); path.lineTo(23.5f, -88f); path.lineTo(30f, -77f); path.close(); fillPath(c, detail, false)
        path.rewind(); path.moveTo(33f, -79f); path.lineTo(40f, -89f); path.lineTo(41f, -75f); path.close(); fillPath(c, detail, false)
        oval(c, 31f, -64f, 15f, 13.5f, body)                   // cabeça
        if (p.blink > 0f) line(c, 33f, -67f, 40f, -67f, 1.8f, 0xFF222222.toInt(), false)
        else { oval(c, 37f, -67f, 3.3f, 3.9f, 0xFF7ED957.toInt(), false); oval(c, 37f, -67f, 1.1f, 3.3f, 0xFF222222.toInt(), false) }
        path.rewind(); path.moveTo(44f, -64f); path.lineTo(48.5f, -64f); path.lineTo(46f, -60.5f); path.close(); fillPath(c, detail, false)
        lp.strokeWidth = 1.1f; lp.color = Color.argb(160, 40, 30, 30); lp.strokeCap = Paint.Cap.ROUND
        c.drawLine(45f, -61f, 59f, -64f, lp); c.drawLine(45f, -60f, 60f, -60f, lp); c.drawLine(45f, -59f, 58f, -56f, lp)
        mouth(c, p, 46f, -56f)
    }

    private fun drawRabbit(c: Canvas, p: Pet, body: Int, detail: Int, dark: Int, light: Int) {
        val twitch = sin(p.wag * 0.8f) * (if (p.moving) 2f else 5f)
        val back = if (p.moving) -9f else 0f
        oval(c, -34f, -30f, 9f, 9f, ColorUtils.blendARGB(body, Color.WHITE, 0.75f))   // rabo de algodão
        oval(c, -14f, -4f, 15f, 5.2f, body)                    // pata de trás
        oval(c, -6f, -30f, 28f, 24f, body)                     // corpo
        oval(c, 9f, -27f, 10f, 14f, light, false)              // barriguinha
        oval(c, 17f, -4f, 7f, 4.2f, body)                      // patinha da frente
        c.save(); c.translate(15f, -68f); c.rotate(-12f + back + twitch)
        oval(c, 0f, -15f, 5.6f, 17f, dark); oval(c, 0f, -15f, 2.8f, 12f, detail, false); c.restore()   // orelha de trás
        oval(c, 22f, -58f, 15f, 14f, body)                     // cabeça
        c.save(); c.translate(26f, -69f); c.rotate(8f + back - twitch)
        oval(c, 0f, -15f, 5.6f, 17f, body); oval(c, 0f, -15f, 2.8f, 12f, detail, false); c.restore()   // orelha da frente
        eye(c, p, 29f, -61f)
        oval(c, 36f, -56f, 2.8f, 2.2f, ColorUtils.blendARGB(detail, Color.BLACK, 0.3f), false)
        lp.strokeWidth = 1f; lp.color = Color.argb(150, 40, 30, 30); lp.strokeCap = Paint.Cap.ROUND
        c.drawLine(34f, -54f, 46f, -57f, lp); c.drawLine(34f, -53f, 47f, -52f, lp)
        mouth(c, p, 35f, -50f)
    }

    // ---------- balão de fala e nome ----------

    private fun layoutOf(text: String, paint: TextPaint, maxW: Int): StaticLayout =
        StaticLayout.Builder.obtain(text, 0, text.length, paint, maxW)
            .setAlignment(Layout.Alignment.ALIGN_CENTER).setIncludePad(false).build()

    private fun widest(l: StaticLayout): Float {
        var m = 0f
        for (i in 0 until l.lineCount) m = max(m, l.getLineWidth(i))
        return m
    }

    private fun speak(p: Pet) {
        if (width <= 0) return
        val lines = PetLines.of(p.kind)
        var i = rnd.nextInt(lines.size)
        if (i == p.lastLine) i = (i + 1) % lines.size
        p.lastLine = i
        val maxW = min(width * 0.6f, 180f * dens).toInt()
        tpSound.color = pal.onNormal; tpTrans.color = pal.onNormal
        val sl = layoutOf(lines[i].first, tpSound, maxW)
        val tl = layoutOf(lines[i].second, tpTrans, maxW)
        p.bubble = Bubble(sl, tl, widest(sl), widest(tl), SystemClock.uptimeMillis() + 3800L)
        p.speak = 1.5f
        p.moving = false; p.idle = 4f
    }

    private fun drawLabel(c: Canvas, p: Pet, now: Long) {
        val hopOff = (if (p.hop > 0f) sin(p.hop * PI_F) * 18f * petPx / 100f else 0f)
        val headY = p.y - petPx * 1.08f - hopOff
        val b = p.bubble
        if (b == null) {
            if (now < p.nameUntil) {
                val name = prefs.petName[p.kind]
                tpName.color = pal.onNormal
                val tw = tpName.measureText(name)
                val padX = 6f * dens; val h = 16f * dens
                val l = (p.x - tw / 2 - padX).coerceIn(2f * dens, max(2f * dens, width - tw - 2 * padX - 2f * dens))
                r.set(l, headY - h, l + tw + 2 * padX, headY)
                bubblePaint.style = Paint.Style.FILL; bubblePaint.color = ColorUtils.setAlphaComponent(pal.keyNormal, 235)
                c.drawRoundRect(r, h / 2, h / 2, bubblePaint)
                c.drawText(name, r.centerX(), r.centerY() + tpName.textSize * 0.35f, tpName)
            }
            return
        }
        val remain = b.until - now
        val a = if (remain < 350) (remain.coerceAtLeast(0) / 350f) else 1f
        val alpha = (a * 255).toInt()
        val pad = 7f * dens
        val cw = max(b.soundW, if (b.showTrans) b.transW else 0f)
        val gap = 4f * dens
        val ch: Float = b.sound.height + (if (b.showTrans) gap + b.trans.height else 0f)
        val bw = cw + 2 * pad; val bh = ch + 2 * pad
        val left = (p.x - bw / 2).coerceIn(3f * dens, max(3f * dens, width - bw - 3f * dens))
        val top = max(3f * dens, headY - bh - 6f * dens)
        b.rect.set(left, top, left + bw, top + bh)
        val corner = 10f * dens
        // corpo do balão
        bubblePaint.style = Paint.Style.FILL; bubblePaint.color = ColorUtils.setAlphaComponent(pal.keyNormal, (245 * a).toInt())
        c.drawRoundRect(b.rect, corner, corner, bubblePaint)
        // perninha apontando para o bichinho
        val tx = p.x.coerceIn(left + corner, left + bw - corner)
        path.rewind(); path.moveTo(tx - 5f * dens, top + bh - 1f); path.lineTo(tx, top + bh + 6f * dens); path.lineTo(tx + 5f * dens, top + bh - 1f); path.close()
        c.drawPath(path, bubblePaint)
        bubblePaint.style = Paint.Style.STROKE; bubblePaint.strokeWidth = 1.2f * dens
        bubblePaint.color = ColorUtils.setAlphaComponent(pal.keyAccent, alpha)
        c.drawRoundRect(b.rect, corner, corner, bubblePaint)
        // textos
        tpSound.alpha = alpha; tpTrans.alpha = alpha
        c.save(); c.translate(left + pad + (cw - b.soundW) / 2 - (b.sound.width - b.soundW) / 2, top + pad)
        b.sound.draw(c)
        c.restore()
        if (b.showTrans) {
            c.save(); c.translate(left + pad + (cw - b.transW) / 2 - (b.trans.width - b.transW) / 2, top + pad + b.sound.height + gap)
            b.trans.draw(c); c.restore()
        } else {
            // "?" = toque para ver a tradução
            bubblePaint.style = Paint.Style.FILL; bubblePaint.color = ColorUtils.setAlphaComponent(pal.keyAccent, alpha)
            c.drawCircle(left + bw, top, 7f * dens, bubblePaint)
            tpName.color = ColorUtils.setAlphaComponent(pal.onAccent, alpha)
            c.drawText("?", left + bw, top + tpName.textSize * 0.36f, tpName)
        }
    }

    // ---------- toque ----------

    private var lastKeyDown = 0L
    private var grabPet: Pet? = null
    private var grabBubble = false
    private var downX = 0f
    private var downY = 0f

    private fun hitPet(p: Pet, x: Float, y: Float): Boolean {
        val m = 5f * dens
        return p.placed && x >= p.x - petPx * 0.62f - m && x <= p.x + petPx * 0.62f + m &&
            y >= p.y - petPx * 1.08f - m && y <= p.y + 4f * dens + m
    }

    override fun dispatchTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                val now = SystemClock.uptimeMillis()
                grabPet = null; grabBubble = false
                if (prefs.petsTouch && pets.isNotEmpty() && petsVisible() && now - lastKeyDown > TYPING_MS) {
                    val m = 6f * dens
                    for (i in pets.indices.reversed()) {
                        val p = pets[i]; val b = p.bubble ?: continue
                        if (e.x >= b.rect.left - m && e.x <= b.rect.right + m && e.y >= b.rect.top - m && e.y <= b.rect.bottom + m) {
                            grabPet = p; grabBubble = true; downX = e.x; downY = e.y; return true
                        }
                    }
                    for (i in pets.indices.reversed()) {
                        val p = pets[i]
                        if (hitPet(p, e.x, e.y)) { grabPet = p; downX = e.x; downY = e.y; return true }
                    }
                }
                lastKeyDown = now        // toque nas teclas: a pessoa está digitando, bichinhos ficam "transparentes"
                return false
            }
            MotionEvent.ACTION_UP -> {
                val p = grabPet ?: return false
                grabPet = null
                if (hypot(e.x - downX, e.y - downY) < 24f * dens) onTap(p, grabBubble)
                return true
            }
            MotionEvent.ACTION_CANCEL -> { grabPet = null; return false }
            else -> return grabPet != null
        }
    }

    private fun onTap(p: Pet, bubble: Boolean) {
        val now = SystemClock.uptimeMillis()
        if (bubble) {
            val b = p.bubble ?: return
            b.showTrans = true
            b.until = max(b.until, now + 5200L)       // tempo para ler a tradução
            return
        }
        if (now - p.lastTap > 700L) p.tapCount = 0
        p.tapCount++; p.lastTap = now
        p.hop = 1f; p.nameUntil = now + 2000L
        p.moving = false; p.idle = 2.5f
        if (p.tapCount >= 3) { p.tapCount = 0; speak(p) }
    }

    companion object {
        private const val PI_F = 3.1415927f
        /** Depois de um toque numa tecla, os bichinhos não "seguram" toques por este tempo (ms). */
        private const val TYPING_MS = 1400L
    }
}

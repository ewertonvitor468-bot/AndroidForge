package com.example.materialkeyboard

/**
 * Patch = tema completo (paleta + acabamento). Fica separado de [Palette.PRESETS].
 * Cores em Long ARGB, como em [Preset]. Os textos (nome de marca genérica e descrição) passam por tr().
 */
data class Patch(
    val id: String, val name: String, val category: Int, val desc: String, val dark: Boolean,
    val surface: Long, val normal: Long, val special: Long, val accent: Long,
    val onNormal: Long, val onSpecial: Long, val onAccent: Long,
    val keyStyle: Int, val keyShape: Int, val pressGlow: Boolean, val keyAlpha: Int,
    val radius: Int, val gap: Int, val fontStyle: Int, val blur: Int = 85,
    /** Passo 3 (Keys Café): chaves extras de [Prefs.EXTRA_KEYS] que o tema também define. Vazio nos temas embutidos. */
    val extras: Map<String, Int> = emptyMap()
)

object Patches {
    const val GAMES = 0
    const val MATERIAL = 1
    const val BRANDS = 2
    const val GLASS = 3
    const val AMOLED = 4
    const val COMMUNITY = 5   // temas instalados pela biblioteca do Keys Café (ThemeBoard, arquivo ou criados no aparelho)
    const val CLASSIC = 6     // v54.2: aba "Clássicos" (CLASSIC_LIST); não aparece na lista geral de patches

    /** Nomes das categorias, na ordem dos índices acima (passam por tr()). */
    val CATEGORY_NAMES = listOf("Jogos", "Material You", "Marcas", "Liquid Glass", "AMOLED", "Comunidade", "Clássicos")

    // keyStyle: 0 Material You, 1 iOS, 2 One UI, 3 Vidro | fontStyle: 0 padrão, 1 black, 2 serif, 3 mono, 4 casual, 5 fina
    val ALL: List<Patch> = listOf(
        // ---- Jogos (inspirado em estéticas, sem nomes oficiais) ----
        Patch("game_neon", "Neon Cidade 2099", GAMES, "Inspirado em cidades cyberpunk: neon magenta, cantos chanfrados e fonte mono.", true,
            0xFF0B0614, 0xFF1A1030, 0xFF2A1450, 0xFFFF2BD6, 0xFF7FF3FF, 0xFFE8D9FF, 0xFF1A0016,
            2, 3, true, 70, 8, 3, 3),
        Patch("game_pixel", "Pixel Retrô", GAMES, "Inspirado em jogos de 8 bits: teclas quadradas, cores de fliperama e fonte mono.", true,
            0xFF1B1B2F, 0xFF2F3057, 0xFF43457A, 0xFFFFD23F, 0xFFF1F1F8, 0xFFFFFFFF, 0xFF2B2000,
            0, 0, false, 80, 2, 4, 3),
        Patch("game_medieval", "Reino Medieval", GAMES, "Inspirado em fantasia medieval: couro, ouro velho e letras serifadas.", true,
            0xFF241A12, 0xFF3A2A1C, 0xFF54402A, 0xFFC9A227, 0xFFF2E6CF, 0xFFF7EBD2, 0xFF2A1F00,
            1, 0, true, 80, 10, 3, 2),

        // ---- Material You ----
        Patch("my_autumn", "Outono Tonal", MATERIAL, "Tons quentes de folhas secas em estilo Material You claro.", false,
            0xFFFFF1E6, 0xFFFFFFFF, 0xFFFFD9BF, 0xFFB5541C, 0xFF2B170B, 0xFF3B1E0B, 0xFFFFFFFF,
            0, 0, true, 60, 22, 4, 0),
        Patch("my_lilac", "Pastel Lilás", MATERIAL, "Pastel suave de lavanda com teclas em pílula.", false,
            0xFFF3EDFF, 0xFFFFFFFF, 0xFFE2D6FF, 0xFF7B5BD6, 0xFF1F1636, 0xFF2A1F4A, 0xFFFFFFFF,
            0, 1, true, 60, 28, 4, 0),
        Patch("my_forest", "Floresta Noturna", MATERIAL, "Verdes profundos e naturais em estilo Material You escuro.", true,
            0xFF10190F, 0xFF1D2A1C, 0xFF2D4230, 0xFF8FD694, 0xFFE3EEE1, 0xFFE3EEE1, 0xFF0A2B10,
            0, 5, true, 60, 22, 3, 0),

        // ---- Marcas de celular (só inspiração de cor e forma) ----
        Patch("brand_clean", "Estilo Sul-coreano Claro", BRANDS, "Inspirado em interfaces sul-coreanas: limpo, claro e com azul vivo.", false,
            0xFFF2F3F7, 0xFFFFFFFF, 0xFFE4E7EF, 0xFF3E7BFA, 0xFF14161C, 0xFF1B1E27, 0xFFFFFFFF,
            2, 2, true, 60, 20, 4, 0),
        Patch("brand_dark", "Estilo Minimalista Escuro", BRANDS, "Inspirado em interfaces escuras e minimalistas, com laranja discreto.", true,
            0xFF0E0E10, 0xFF1C1C1F, 0xFF2A2A2E, 0xFFFF6A3D, 0xFFEDEDF0, 0xFFF5F5F7, 0xFF2B0E00,
            1, 0, false, 60, 9, 3, 5),

        // ---- Liquid Glass ----
        Patch("glass_liquid", "Liquid Glass", GLASS, "Teclas de vidro translúcido com desfoque, borda iluminada e reflexo suave.", true,
            0xFF1A2233, 0xFF3A4A6B, 0xFF54648C, 0xFF7FD4FF, 0xFFFFFFFF, 0xFFFFFFFF, 0xFF04222F,
            3, 0, true, 55, 24, 4, 0, 85),

        Patch("glass_vidro", "Vidro", GLASS, "Vidro líquido escuro: translúcido, com desfoque, reflexos, borda luminosa e profundidade.", true,
            0xFF141B2B, 0xFF3D4F73, 0xFF566A94, 0xFF8FD8FF, 0xFFFFFFFF, 0xFFFFFFFF, 0xFF04222F,
            3, 0, true, 50, 26, 4, 0, 90,
            extras = mapOf("keyDepth" to 2, "boardRadius" to 30, "animBounce" to 75, "animSpeed" to 110, "micShape" to 2, "toolShape" to 2, "previewShape" to 3)),
        Patch("glass_vidro_light", "Vidro Claro", GLASS, "Vidro líquido claro e leitoso: translúcido, com desfoque, reflexos, borda luminosa e profundidade.", false,
            0xFFE3EDF9, 0xFFFFFFFF, 0xFFCFE0F3, 0xFF2F8FD8, 0xFF0D2233, 0xFF0D2233, 0xFFFFFFFF,
            3, 0, true, 45, 26, 4, 0, 90,
            extras = mapOf("keyDepth" to 2, "boardRadius" to 30, "animBounce" to 75, "animSpeed" to 110, "micShape" to 2, "toolShape" to 2, "previewShape" to 3)),

        // ---- AMOLED: fundo #000000 ----
        Patch("amoled_matrix", "AMOLED Verde", AMOLED, "Fundo preto puro e acento verde neon.", true,
            0xFF000000, 0xFF0A0F0A, 0xFF142014, 0xFF22C55E, 0xFFD9F5DF, 0xFFE6FFEB, 0xFF002B0F,
            0, 0, true, 60, 18, 3, 0),
        Patch("amoled_cyan", "AMOLED Ciano", AMOLED, "Fundo preto puro e acento ciano neon.", true,
            0xFF000000, 0xFF0A1012, 0xFF11202A, 0xFF00E5FF, 0xFFDDF7FB, 0xFFE6FBFF, 0xFF00262B,
            2, 2, true, 60, 18, 3, 0),
        Patch("amoled_magenta", "AMOLED Magenta", AMOLED, "Fundo preto puro e acento magenta neon.", true,
            0xFF000000, 0xFF120A12, 0xFF241126, 0xFFFF4FD8, 0xFFF9DDF4, 0xFFFFE6FA, 0xFF2B0024,
            0, 1, true, 60, 24, 3, 0),
        Patch("amoled_white", "AMOLED Sóbrio", AMOLED, "Fundo preto puro e acento branco, discreto.", true,
            0xFF000000, 0xFF121212, 0xFF1E1E1E, 0xFFE8E8E8, 0xFFEDEDED, 0xFFF5F5F5, 0xFF111111,
            1, 0, false, 60, 12, 3, 5),

        // ---- v41: +16 temas ----
        Patch("game_space", "Galáxia Profunda", GAMES, "Inspirado em ficção espacial: azul-noite, roxo estelar e brilho no toque.", true,
            0xFF070A1F, 0xFF121A3D, 0xFF1D2A5E, 0xFF8B7CFF, 0xFFDDE4FF, 0xFFE8ECFF, 0xFF110A3A,
            0, 5, true, 70, 14, 3, 0),
        Patch("game_racing", "Corrida Noturna", GAMES, "Inspirado em corridas de rua: asfalto escuro, amarelo faixa e fonte forte.", true,
            0xFF121212, 0xFF202020, 0xFF2E2E2E, 0xFFFFC400, 0xFFF2F2F2, 0xFFFFFFFF, 0xFF241A00,
            1, 0, true, 75, 8, 3, 1),
        Patch("game_lava", "Vulcão Arcade", GAMES, "Inspirado em fases de lava: preto vulcânico e acento laranja incandescente.", true,
            0xFF1A0B08, 0xFF2B140E, 0xFF40201A, 0xFFFF5A1F, 0xFFFFE3D6, 0xFFFFE9DE, 0xFF2B0A00,
            0, 3, true, 70, 10, 3, 1),
        Patch("game_wild", "Terra Selvagem", GAMES, "Inspirado em aventuras na selva: verde musgo, madeira e folhas.", true,
            0xFF14210F, 0xFF223319, 0xFF35502A, 0xFFB7E34A, 0xFFE9F3D8, 0xFFEFF7DE, 0xFF1C2B00,
            0, 6, true, 75, 12, 3, 4),
        Patch("my_ocean", "Oceano Tonal", MATERIAL, "Azuis claros e calmos em estilo Material You.", false,
            0xFFEAF4FB, 0xFFFFFFFF, 0xFFCFE6F5, 0xFF1F78B4, 0xFF0B1F2E, 0xFF0F2B40, 0xFFFFFFFF,
            0, 0, true, 60, 12, 3, 0),
        Patch("my_rose", "Rosa Quartzo", MATERIAL, "Rosa suave e delicado com teclas arredondadas.", false,
            0xFFFFEEF3, 0xFFFFFFFF, 0xFFFFD6E2, 0xFFC2335F, 0xFF33101C, 0xFF40111F, 0xFFFFFFFF,
            0, 0, true, 60, 14, 3, 0),
        Patch("my_mint", "Menta Fresca", MATERIAL, "Verde-menta leve e arejado em estilo Material You claro.", false,
            0xFFE9F8F1, 0xFFFFFFFF, 0xFFC9EDDD, 0xFF1F9D6B, 0xFF0B2A1D, 0xFF0F3324, 0xFFFFFFFF,
            0, 0, true, 60, 12, 3, 0),
        Patch("my_sunset", "Pôr do Sol", MATERIAL, "Roxo e coral em estilo Material You escuro.", true,
            0xFF1E1226, 0xFF2D1D38, 0xFF442A52, 0xFFFF8A65, 0xFFF3E6F7, 0xFFF3E6F7, 0xFF3A1200,
            0, 1, true, 60, 22, 3, 0),
        Patch("brand_search", "Estilo Busca Claro", BRANDS, "Inspirado em teclados de buscadores: claro, azul-acinzentado e teclas retas.", false,
            0xFFE8EAEF, 0xFFFFFFFF, 0xFFD3D8E2, 0xFF1A73E8, 0xFF1F2328, 0xFF1F2328, 0xFFFFFFFF,
            0, 0, false, 60, 10, 3, 0),
        Patch("brand_graphite", "Grafite Suave", BRANDS, "Cinza grafite confortável para a noite, com acento azul-gelo.", true,
            0xFF1F2226, 0xFF30343A, 0xFF3F444B, 0xFF8AB4F8, 0xFFE8EAED, 0xFFE8EAED, 0xFF062449,
            0, 0, false, 60, 10, 3, 0),
        Patch("glass_aurora", "Vidro Aurora", GLASS, "Vidro translúcido escuro com acento verde-aurora.", true,
            0xFF0F1F2B, 0xFF2E4A5E, 0xFF456479, 0xFF6BFFC2, 0xFFFFFFFF, 0xFFFFFFFF, 0xFF00291B,
            3, 0, true, 55, 22, 4, 0, 90),
        Patch("glass_rose", "Vidro Rosé", GLASS, "Vidro claro e leitoso com acento rosé.", false,
            0xFFF6E9EF, 0xFFFFFFFF, 0xFFEBD3DE, 0xFFE0568A, 0xFF2A1520, 0xFF2A1520, 0xFFFFFFFF,
            3, 0, true, 50, 22, 4, 0, 70),
        Patch("amoled_red", "AMOLED Vermelho", AMOLED, "Fundo preto puro e acento vermelho vivo.", true,
            0xFF000000, 0xFF120A0A, 0xFF241111, 0xFFFF3B3B, 0xFFF9DDDD, 0xFFFFE6E6, 0xFF2B0000,
            0, 0, true, 60, 12, 3, 0),
        Patch("amoled_gold", "AMOLED Dourado", AMOLED, "Fundo preto puro e acento dourado elegante.", true,
            0xFF000000, 0xFF14110A, 0xFF241E10, 0xFFFFC53D, 0xFFF7EBCB, 0xFFFFF1D1, 0xFF2B2000,
            1, 0, false, 60, 12, 3, 2),
        Patch("amoled_purple", "AMOLED Roxo", AMOLED, "Fundo preto puro e acento roxo elétrico.", true,
            0xFF000000, 0xFF0F0A14, 0xFF1D1126, 0xFFB26BFF, 0xFFEBDDF9, 0xFFF1E6FF, 0xFF1F0033,
            0, 1, true, 60, 20, 3, 0),

        // ---- v54.2: +5 temas (usam borda, formatos do microfone e estilo da barra) ----
        Patch("game_arcade", "Fliperama Neon", GAMES, "Inspirado em fliperamas: contorno de neon ciano, teclas quadradas e fonte mono.", true,
            0xFF0A0A1A, 0xFF14143A, 0xFF1F1F55, 0xFF00FFC6, 0xFFE6F0FF, 0xFFE6F0FF, 0xFF002B22,
            0, 0, true, 70, 6, 4, 3,
            extras = mapOf("keyBorder" to 2, "micShape" to 4, "toolShape" to 4, "barStyle" to 2, "previewShape" to 2, "boardRadius" to 10)),
        Patch("my_lemon", "Limão Tonal", MATERIAL, "Amarelo-limão suave, com Enter em cookie e botões em flor, no estilo Material You.", false,
            0xFFFAFAE0, 0xFFFFFFFF, 0xFFEDEFB4, 0xFF6B7A00, 0xFF1B1D00, 0xFF262900, 0xFFFFFFFF,
            0, 0, true, 60, 20, 4, 0,
            extras = mapOf("expressive" to 0, "accentShape" to 6, "micShape" to 1, "toolShape" to 0, "previewShape" to 5, "boardRadius" to 30)),
        Patch("brand_messenger", "Estilo Mensageiro Verde", BRANDS, "Inspirado em mensageiros: fundo bege, teclas brancas com sombra fina e verde de destaque.", false,
            0xFFECE5DD, 0xFFFFFFFF, 0xFFD9D2C9, 0xFF128C4A, 0xFF1C1B19, 0xFF1C1B19, 0xFFFFFFFF,
            1, 0, false, 60, 8, 3, 0,
            extras = mapOf("micShape" to 2, "toolShape" to 2, "barStyle" to 1, "boardRadius" to 0)),
        Patch("glass_ice", "Vidro Gelo", GLASS, "Vidro claro cor de gelo, com borda iluminada e letras finas.", false,
            0xFFDCEBF7, 0xFFFFFFFF, 0xFFBFD9EE, 0xFF2F8FD8, 0xFF0D2233, 0xFF0D2233, 0xFFFFFFFF,
            3, 0, true, 50, 22, 4, 5, 80,
            extras = mapOf("micShape" to 2, "toolShape" to 2, "previewShape" to 3)),
        Patch("amoled_blue", "AMOLED Azul", AMOLED, "Fundo preto puro, contorno fino e acento azul elétrico.", true,
            0xFF000000, 0xFF0A0F1A, 0xFF111B2E, 0xFF3D8BFF, 0xFFDCE8FF, 0xFFE6EEFF, 0xFF001A3D,
            0, 0, true, 60, 14, 3, 0,
            extras = mapOf("keyBorder" to 1, "micShape" to 2, "toolShape" to 2))
    )

    /**
     * v54.2 · aba "Clássicos": 5 visuais de referência. Ficam fora de [ALL] (a lista geral de patches), mas [byId] os acha.
     * Cada um também define os botões da barra e o estilo da faixa; tudo continua editável depois (Personalização ilimitada).
     */
    val CLASSIC_LIST: List<Patch> = listOf(
        // Teclado de 2017: Material Design 1, teclas retas com sombra fina, faixa reta, botões redondos
        Patch("classic_2017", "Padrão 2017", CLASSIC, "O teclado de 2017: teclas retas com sombra fina, azul de destaque, faixa reta e botões redondos.", false,
            0xFFECEFF1, 0xFFFFFFFF, 0xFFCFD8DC, 0xFF4285F4, 0xFF37474F, 0xFF37474F, 0xFFFFFFFF,
            1, 0, false, 60, 4, 3, 0,
            extras = mapOf("boardRadius" to 0, "previewShape" to 2, "animBounce" to 15, "animSpeed" to 120,
                "micShape" to 2, "toolShape" to 2, "barStyle" to 1, "expressive" to 1, "textScale" to 104)),
        // Mecânico: keycaps 3D com lateral escura, face clara no topo, borda fina e botões quadrados
        Patch("classic_mech", "Mecânico", CLASSIC, "Teclado mecânico: keycaps 3D com lateral e face do topo, laranja no Enter e botões quadrados.", true,
            0xFF16181C, 0xFF2A2D33, 0xFF3A3E46, 0xFFFF6B1A, 0xFFE8EAED, 0xFFE8EAED, 0xFF1A0A00,
            4, 0, false, 60, 7, 4, 1,
            extras = mapOf("boardRadius" to 6, "previewShape" to 2, "animBounce" to 10, "animSpeed" to 140,
                "micShape" to 4, "toolShape" to 4, "barStyle" to 2, "keyBorder" to 1, "keyDepth" to 4, "expressive" to 1, "textScale" to 104)),
        // Material: Enter em cookie, balão em flor, microfone em flor e seta em cookie
        Patch("classic_material", "Material", CLASSIC, "Material You com formas expressivas: Enter em cookie, balão e microfone em flor, seta em cookie.", false,
            0xFFF7F2FA, 0xFFFFFFFF, 0xFFE8DEF8, 0xFF6750A4, 0xFF1D1B20, 0xFF1D192B, 0xFFFFFFFF,
            0, 0, true, 60, 18, 4, 0,
            extras = mapOf("boardRadius" to 28, "accentShape" to 6, "previewShape" to 5, "previewSize" to 110, "animBounce" to 70,
                "micShape" to 1, "toolShape" to 0, "barStyle" to 0, "expressive" to 0)),
        // Gboard claro: teclas arredondadas, azul claro nas especiais, faixa reta
        Patch("classic_gboard", "Padrão Gboard", CLASSIC, "No estilo do teclado do Google: teclas arredondadas, especiais em azul claro e faixa reta.", false,
            0xFFE9EEF6, 0xFFFFFFFF, 0xFFD3E3FD, 0xFF0B57D0, 0xFF1F1F1F, 0xFF041E49, 0xFFFFFFFF,
            0, 0, false, 60, 14, 3, 0,
            extras = mapOf("boardRadius" to 0, "previewShape" to 0, "animBounce" to 40,
                "micShape" to 2, "toolShape" to 2, "barStyle" to 1, "expressive" to 1)),
        // Gboard escuro
        Patch("classic_gboard_dark", "Gboard Escuro", CLASSIC, "A versão escura do estilo Google: teclas cinza-azuladas, especiais em azul-aço e acento azul claro.", true,
            0xFF1A1C20, 0xFF2E3136, 0xFF2F3D54, 0xFFA8C7FA, 0xFFE3E3E3, 0xFFD3E3FD, 0xFF062E6F,
            0, 0, false, 60, 14, 3, 0,
            extras = mapOf("boardRadius" to 0, "previewShape" to 0, "animBounce" to 40,
                "micShape" to 2, "toolShape" to 2, "barStyle" to 1, "expressive" to 1))
    )

    fun byId(id: String): Patch? =
        ALL.firstOrNull { it.id == id } ?: CLASSIC_LIST.firstOrNull { it.id == id }
            ?: com.example.materialkeyboard.keyscafe.ThemeLibrary.patchById(id)

    /** Patch ativo. Com imagem de fundo ativa, só o acabamento vale (as cores ficam com a imagem). */
    fun of(p: Prefs): Patch? = if (p.themeImage || p.patch.isEmpty()) null else byId(p.patch)

    /** Grava paleta + acabamento de uma vez (um único edit/apply), guardando o estado anterior. */
    fun apply(prefs: Prefs, p: Patch) = prefs.setPatch(
        p.id,
        mapOf(
            "preset" to 0, "customColor" to p.accent.toInt(),
            "keyStyle" to p.keyStyle, "keyShape" to p.keyShape, "keyAlpha" to p.keyAlpha,
            "keyRadius" to p.radius, "keyGap" to p.gap, "fontStyle" to p.fontStyle, "blurAmount" to p.blur
        ),
        mapOf("pressGlow" to p.pressGlow, "useCustomColor" to true),
        p.extras
    )
}

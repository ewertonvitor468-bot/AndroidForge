package com.example.materialkeyboard.compose

import android.view.View
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner

/**
 * Um InputMethodService não é uma Activity: não tem ciclo de vida nem estado salvo para o Compose.
 * Sem isto, ComposeView falha com "ViewTreeLifecycleOwner not found".
 *
 * O ciclo fica em RESUMED desde [onCreate] até [destroy]. NÃO pausamos quando a janela some: com o ciclo
 * abaixo de STARTED o Compose congela o relógio de quadros e a UI fica desenhada, mas sem reagir a toque
 * nem animar (foi o bug da v30). Sem animações contínuas, manter ativo não gasta bateria.
 */
class ImeComposeOwner : LifecycleOwner, SavedStateRegistryOwner {

    private val registry = LifecycleRegistry(this)
    private val savedState = SavedStateRegistryController.create(this)

    override val lifecycle: Lifecycle get() = registry
    override val savedStateRegistry: SavedStateRegistry get() = savedState.savedStateRegistry

    fun onCreate() {
        if (registry.currentState != Lifecycle.State.INITIALIZED) return
        savedState.performAttach()
        savedState.performRestore(null)
        registry.currentState = Lifecycle.State.CREATED
        registry.currentState = Lifecycle.State.RESUMED
    }

    fun resume() {
        if (registry.currentState == Lifecycle.State.DESTROYED) return
        registry.currentState = Lifecycle.State.RESUMED
    }

    fun destroy() {
        registry.currentState = Lifecycle.State.DESTROYED
    }

    /** Instala os donos na própria view (e, por herança, em toda a sub-árvore). */
    fun attachTo(view: View) {
        view.setViewTreeLifecycleOwner(this)
        view.setViewTreeSavedStateRegistryOwner(this)
    }
}

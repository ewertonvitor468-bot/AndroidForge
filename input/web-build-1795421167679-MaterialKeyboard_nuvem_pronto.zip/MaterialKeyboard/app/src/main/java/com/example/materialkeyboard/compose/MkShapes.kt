package com.example.materialkeyboard.compose

import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.LayoutDirection
import androidx.graphics.shapes.CornerRounding
import androidx.graphics.shapes.Morph
import androidx.graphics.shapes.RoundedPolygon
import androidx.graphics.shapes.circle
import androidx.graphics.shapes.rectangle
import androidx.graphics.shapes.star

/**
 * Formas do Material 3 Expressive com morfing REAL (biblioteca androidx.graphics.shapes, a mesma
 * que o Material 3 Expressive usa), em vez de cantos arredondados desenhados à mão.
 * Todos os polígonos ficam em [-1, 1] x [-1, 1]; [MorphShape] escala para o tamanho do componente.
 */
object MkPolygons {
    /** Círculo / pílula (a forma "em repouso" dos botões de ícone). */
    val circle: RoundedPolygon by lazy { RoundedPolygon.circle(numVertices = 10) }

    /** Quadrado arredondado: a forma "pressionada". */
    val squircle: RoundedPolygon by lazy {
        RoundedPolygon.rectangle(width = 2f, height = 2f, rounding = CornerRounding(0.34f), centerX = 0f, centerY = 0f)
    }

    /** "Cookie" de 9 lados: a forma "selecionada" (assinatura do Expressive). */
    val cookie: RoundedPolygon by lazy {
        RoundedPolygon.star(
            numVerticesPerRadius = 9, radius = 1f, innerRadius = 0.86f,
            rounding = CornerRounding(0.5f), innerRounding = CornerRounding(0.5f),
            centerX = 0f, centerY = 0f
        )
    }

    /** Flor de 6 pétalas, para destaques (indicador de carregamento, estado vazio). */
    val flower: RoundedPolygon by lazy {
        RoundedPolygon.star(
            numVerticesPerRadius = 6, radius = 1f, innerRadius = 0.72f,
            rounding = CornerRounding(0.6f), innerRounding = CornerRounding(0.6f),
            centerX = 0f, centerY = 0f
        )
    }

    /** Losango arredondado. */
    val diamond: RoundedPolygon by lazy {
        RoundedPolygon.star(
            numVerticesPerRadius = 4, radius = 1f, innerRadius = 0.62f,
            rounding = CornerRounding(0.3f), innerRounding = CornerRounding(0.3f),
            centerX = 0f, centerY = 0f
        )
    }
}

/**
 * [Shape] que desenha o contorno interpolado de um [Morph] em [progress] (0 = início, 1 = fim).
 * O progresso é lido na fase de layout/desenho (via lambda no Modifier), então a animação não recompõe.
 */
class MorphShape(private val morph: Morph, private val progress: Float) : Shape {
    private val path = Path()

    override fun createOutline(size: Size, layoutDirection: LayoutDirection, density: Density): Outline {
        path.rewind()
        val hw = size.width / 2f
        val hh = size.height / 2f
        var first = true
        morph.forEachCubic(progress.coerceIn(0f, 1f)) { c ->
            if (first) {
                path.moveTo((c.anchor0X + 1f) * hw, (c.anchor0Y + 1f) * hh)
                first = false
            }
            path.cubicTo(
                (c.control0X + 1f) * hw, (c.control0Y + 1f) * hh,
                (c.control1X + 1f) * hw, (c.control1Y + 1f) * hh,
                (c.anchor1X + 1f) * hw, (c.anchor1Y + 1f) * hh
            )
        }
        path.close()
        return Outline.Generic(path)
    }
}

/** Morphs prontos (criados uma vez; Morph é imutável e barato de reaproveitar). */
object MkMorphs {
    val circleToSquircle: Morph by lazy { Morph(MkPolygons.circle, MkPolygons.squircle) }
    val circleToCookie: Morph by lazy { Morph(MkPolygons.circle, MkPolygons.cookie) }
    val squircleToCookie: Morph by lazy { Morph(MkPolygons.squircle, MkPolygons.cookie) }
    val cookieToFlower: Morph by lazy { Morph(MkPolygons.cookie, MkPolygons.flower) }
    val flowerToDiamond: Morph by lazy { Morph(MkPolygons.flower, MkPolygons.diamond) }
}

package com.example.materialkeyboard.compose

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.materialkeyboard.L
import com.example.materialkeyboard.Prefs
import com.example.materialkeyboard.R
import com.example.materialkeyboard.tr
import com.example.materialkeyboard.updates.ApkInstaller
import com.example.materialkeyboard.updates.AppUpdate
import com.example.materialkeyboard.updates.UpdateChecker
import com.example.materialkeyboard.updates.UpdateException
import com.example.materialkeyboard.updates.UpdateResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.time.OffsetDateTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.time.format.FormatStyle

private sealed interface UpState {
    object Loading : UpState
    object NotConfigured : UpState
    object UpToDate : UpState
    class Failed(val msg: String) : UpState
    class Available(val u: AppUpdate) : UpState
}

private sealed interface Dl {
    object Idle : Dl
    class Busy(val p: Float) : Dl
    class Ready(val f: File) : Dl
}

/** Aba Atualizações: versão atual × nova, novidades, data de publicação e botão para baixar/instalar o APK. */
@Composable
fun UpdatesScreen(prefs: Prefs) = PageHost(prefs) {
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    val scope = rememberCoroutineScope()
    val curName = remember { UpdateChecker.currentName(ctx) }
    var state by remember { mutableStateOf<UpState>(UpState.Loading) }
    var tick by remember { mutableIntStateOf(0) }
    var dl by remember { mutableStateOf<Dl>(Dl.Idle) }
    var msg by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(tick) {
        state = UpState.Loading
        state = when (val r = withContext(Dispatchers.IO) { UpdateChecker.check(ctx) }) {
            is UpdateResult.NotConfigured -> UpState.NotConfigured
            is UpdateResult.Fail -> UpState.Failed(r.reason)
            is UpdateResult.Ok -> r.update?.takeIf { UpdateChecker.isNewer(ctx, it) }
                ?.let { UpState.Available(it) } ?: UpState.UpToDate
        }
    }

    fun install(f: File) {
        msg = if (ApkInstaller.install(ctx, f)) null
        else "Permita instalar apps desconhecidos para o Material Keyboard e toque em Instalar de novo.".tr()
    }

    fun download(u: AppUpdate) = scope.launch {
        msg = null; dl = Dl.Busy(0f)
        try {
            val f = withContext(Dispatchers.IO) { ApkInstaller.download(ctx, u) { dl = Dl.Busy(it) } }
            dl = Dl.Ready(f); install(f)
        } catch (e: UpdateException) { dl = Dl.Idle; msg = (e.message ?: "").tr() }
        catch (_: Exception) { dl = Dl.Idle; msg = "Não foi possível baixar a atualização.".tr() }
    }

    val s = state
    val available = s is UpState.Available
    val fg = if (available) cs.onPrimary else cs.onSurface

    // ---- cabeçalho ----
    Enter(0) {
        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp)).background(if (available) cs.primary else card).padding(20.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(48.dp).clip(CircleShape).background(fg.copy(alpha = 0.16f)), contentAlignment = Alignment.Center) {
                    if (s is UpState.Loading) CircularProgressIndicator(Modifier.size(24.dp), color = fg, strokeWidth = 2.5.dp)
                    else Icon(painterResource(R.drawable.ic_update), null, tint = fg)
                }
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        when (s) {
                            is UpState.Loading -> "Verificando atualizações…"
                            is UpState.NotConfigured -> "Atualizações indisponíveis"
                            is UpState.Failed -> "Não foi possível verificar agora."
                            is UpState.UpToDate -> "Você está atualizado"
                            is UpState.Available -> "Nova versão disponível"
                        }.tr(), color = fg, fontSize = 20.sp, fontWeight = FontWeight.SemiBold
                    )
                    val sub = when (s) {
                        is UpState.NotConfigured -> "As atualizações ainda não estão configuradas neste app.".tr()
                        is UpState.Failed -> s.msg.tr()
                        is UpState.UpToDate -> "Você já usa a versão mais recente do Material Keyboard.".tr()
                        is UpState.Available -> if (s.u.mandatory) "Atualização importante".tr() else ""
                        else -> ""
                    }
                    if (sub.isNotEmpty()) Text(sub, color = fg.copy(alpha = 0.8f), style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 2.dp))
                }
            }
            if (s is UpState.Available) {
                Spacer(Modifier.height(18.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    VersionChip("Versão atual".tr(), "v$curName", fg, Modifier.weight(1f))
                    Icon(painterResource(R.drawable.ic_chevron), null, tint = fg.copy(alpha = 0.7f))
                    VersionChip("Nova versão".tr(), "v${s.u.versionName}", fg, Modifier.weight(1f))
                }
            }
        }
    }

    if (s is UpState.Available) {
        val u = s.u
        // ---- detalhes ----
        Enter(1) {
            MkCard("Detalhes".tr()) {
                InfoRow("Data de publicação".tr(), dateLabel(u.publishedAt))
                if (u.sizeBytes > 0) InfoRow("Tamanho".tr(), "%.1f MB".format(u.sizeBytes / 1048576.0))
            }
        }
        // ---- novidades ----
        val lines = u.notes.lines().map { it.trim().removePrefix("-").removePrefix("•").removePrefix("*").trim() }.filter { it.isNotEmpty() }
        if (lines.isNotEmpty()) Enter(2) {
            MkCard("Novidades".tr()) {
                Column(Modifier.padding(vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    lines.forEach { line ->
                        Row {
                            Text("•", color = cs.primary, fontWeight = FontWeight.Bold, modifier = Modifier.width(18.dp))
                            Text(line, color = cs.onSurface, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
                        }
                    }
                }
            }
        }
        // ---- baixar / instalar ----
        Enter(3) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                val d = dl
                if (d is Dl.Busy) {
                    LinearProgressIndicator(progress = { d.p }, modifier = Modifier.fillMaxWidth().height(10.dp).clip(CircleShape))
                    Text(L.f("Baixando… %d%%", (d.p * 100).toInt()), color = cs.onSurface.copy(alpha = 0.7f), style = MaterialTheme.typography.bodySmall)
                } else {
                    Button(
                        onClick = { if (d is Dl.Ready) install(d.f) else download(u) },
                        modifier = Modifier.fillMaxWidth().height(56.dp), shape = CircleShape
                    ) {
                        Icon(painterResource(R.drawable.ic_update), null, Modifier.size(20.dp))
                        Spacer(Modifier.width(10.dp))
                        Text((if (d is Dl.Ready) "Instalar agora" else "Baixar atualização").tr(), fontWeight = FontWeight.SemiBold)
                    }
                }
                msg?.let { Text(it, color = cs.error, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(horizontal = 6.dp)) }
            }
        }
    }

    if (s !is UpState.Loading && s !is UpState.NotConfigured && dl !is Dl.Busy)
        Enter(4) { MkAction("Verificar agora".tr()) { dl = Dl.Idle; msg = null; tick++ } }
}

@Composable
private fun VersionChip(label: String, value: String, fg: Color, modifier: Modifier) {
    Column(modifier.clip(RoundedCornerShape(18.dp)).background(fg.copy(alpha = 0.14f)).padding(horizontal = 14.dp, vertical = 10.dp)) {
        Text(label, color = fg.copy(alpha = 0.75f), style = MaterialTheme.typography.labelSmall)
        Text(value, color = fg, fontSize = 20.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun InfoRow(label: String, value: String) {
    val cs = MaterialTheme.colorScheme
    Row(Modifier.fillMaxWidth().padding(vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = cs.onSurface.copy(alpha = 0.7f), modifier = Modifier.weight(1f))
        Text(value, color = cs.onSurface, fontWeight = FontWeight.Medium)
    }
}

/** Data de publicação no formato do idioma/fuso do aparelho; se não der para ler, mostra o texto original. */
private fun dateLabel(iso: String): String = try {
    OffsetDateTime.parse(iso).atZoneSameInstant(ZoneId.systemDefault()).format(DateTimeFormatter.ofLocalizedDate(FormatStyle.MEDIUM))
} catch (_: Exception) { iso.take(10) }

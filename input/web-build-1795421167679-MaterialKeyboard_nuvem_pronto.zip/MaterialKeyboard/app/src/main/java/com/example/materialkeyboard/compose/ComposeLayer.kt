package com.example.materialkeyboard.compose

import android.content.Context
import android.util.Log
import android.view.MotionEvent
import android.view.View
import androidx.compose.material3.ColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.platform.AbstractComposeView
import androidx.compose.ui.platform.ViewCompositionStrategy

/**
 * Fábrica de camadas Compose para a arquitetura de Views do teclado.
 *
 * Dois modos:
 *  - passThrough = true  (padrão): camada só visual; NUNCA recebe toque, tudo passa para as teclas.
 *    Usada pelo overlay que cobre o teclado (efeitos visuais futuros).
 *  - passThrough = false: área interativa (painéis, como o de clipboard/emoji). Só intercepta toques
 *    enquanto o painel está visível, pois o serviço o oculta (GONE) ao voltar às teclas.
 *
 * Todo conteúdo já vem dentro de [MkTheme].
 */
object ComposeLayer {

    private const val TAG = "MKCompose"

    fun create(
        context: Context,
        owner: ImeComposeOwner,
        colors: ColorScheme? = null,
        motionEnabled: Boolean = true,
        passThrough: Boolean = true,
        content: @Composable () -> Unit
    ): View = MkComposeView(context, colors, motionEnabled, passThrough, content).apply {
        owner.attachTo(this)
        setViewCompositionStrategy(ViewCompositionStrategy.DisposeOnDetachedFromWindow)
        if (passThrough) importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO_HIDE_DESCENDANTS
    }

    /** Overlay do teclado: área real (tamanho total), sem toque. Hoje só valida a composição. */
    fun createOverlay(context: Context, owner: ImeComposeOwner, colors: ColorScheme?, motionEnabled: Boolean): View =
        create(context, owner, colors, motionEnabled, passThrough = true) { MkOverlay() }

    @Composable
    internal fun logActive() {
        LaunchedEffect(Unit) { Log.i(TAG, "Compose ativo dentro do InputMethodService") }
    }
}

/** AbstractComposeView (ComposeView é final), com opção de deixar o toque passar. */
private class MkComposeView(
    context: Context,
    private val colors: ColorScheme?,
    private val motionEnabled: Boolean,
    private val passThrough: Boolean,
    private val body: @Composable () -> Unit
) : AbstractComposeView(context) {

    @Composable
    override fun Content() {
        MkTheme(colors = colors, motionEnabled = motionEnabled, content = body)
    }

    override fun dispatchTouchEvent(ev: MotionEvent?): Boolean =
        if (passThrough) false else super.dispatchTouchEvent(ev)

    override fun onInterceptTouchEvent(ev: MotionEvent?): Boolean =
        if (passThrough) false else super.onInterceptTouchEvent(ev)
}

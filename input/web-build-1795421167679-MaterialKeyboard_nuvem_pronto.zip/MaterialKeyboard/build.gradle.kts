plugins {
    id("com.android.application") version "8.5.2" apply false
    id("org.jetbrains.kotlin.android") version "2.0.0" apply false
    // Compose Compiler Gradle plugin: a versão TEM de ser igual à do Kotlin (2.0.0).
    id("org.jetbrains.kotlin.plugin.compose") version "2.0.0" apply false
}

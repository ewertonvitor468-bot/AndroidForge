#!/usr/bin/env bash
# Baixa listas de frequência abertas (projeto FrequencyWords, de hermitdave) para assets/dict/.
# NÃO TESTADO (sem internet onde foi escrito). Confira a licença do conjunto de dados antes de publicar o app
# (o repositório indica CC-BY-SA 4.0 para o conteúdo; isso exige atribuição).
set -euo pipefail
cd "$(dirname "$0")/../app/src/main/assets/dict"
base="https://raw.githubusercontent.com/hermitdave/FrequencyWords/master/content/2018"
curl -fL "$base/pt_br/pt_br_50k.txt" -o pt.txt
curl -fL "$base/en/en_50k.txt"       -o en.txt
curl -fL "$base/ru/ru_50k.txt"       -o ru.txt
wc -l pt.txt en.txt ru.txt

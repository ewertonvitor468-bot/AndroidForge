# Third-party notices / Avisos de terceiros

Material Keyboard uses the following third-party components. Each keeps its own license.

| Component | Use | License |
|---|---|---|
| AndroidX, Jetpack Compose, Material Components (Google) | App framework and interface | Apache License 2.0 |
| Kotlin and Kotlin libraries (JetBrains) | Programming language and libraries | Apache License 2.0 |
| Google ML Kit Translate | On-device translation (Translator and app language) | Google ML Kit terms of service |
| FrequencyWords by hermitdave (downloaded by the app, not bundled) | Word lists for the spell corrector | CC BY-SA 4.0 |

Conferir as versões exatas e os textos completos das licenças nos sites de cada projeto.

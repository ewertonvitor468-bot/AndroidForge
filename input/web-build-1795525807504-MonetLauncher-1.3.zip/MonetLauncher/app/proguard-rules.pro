# As regras do Compose/AndroidX já vêm nos consumer rules das bibliotecas.

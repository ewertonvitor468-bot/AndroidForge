package com.monet.launcher.data

import android.app.ActivityOptions
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.LauncherApps
import android.content.pm.PackageManager
import android.graphics.Rect
import android.net.Uri
import android.os.Process
import android.provider.MediaStore
import android.view.View
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class AppRepository(private val ctx: Context) {

    private val pm = ctx.packageManager
    private val launcherApps = ctx.getSystemService(LauncherApps::class.java)

    suspend fun loadApps(): List<RawApp> = withContext(Dispatchers.IO) {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        pm.queryIntentActivities(intent, 0)
            .filter { it.activityInfo.packageName != ctx.packageName }
            .map { ri ->
                RawApp(
                    label = ri.loadLabel(pm).toString(),
                    pkg = ri.activityInfo.packageName,
                    component = ComponentName(ri.activityInfo.packageName, ri.activityInfo.name),
                    bitmap = ri.loadIcon(pm).toBitmap(160, 160),
                )
            }
            .distinctBy { it.pkg }
            .sortedBy { it.label.lowercase() }
    }

    /** Telefone, mensagens, câmera e navegador padrão do aparelho. */
    fun defaultDock(): List<String> = listOf(
        Intent(Intent.ACTION_DIAL),
        Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_MESSAGING),
        Intent(MediaStore.ACTION_IMAGE_CAPTURE),
        Intent(Intent.ACTION_VIEW, Uri.parse("https://")),
    ).mapNotNull { pm.resolveActivity(it, PackageManager.MATCH_DEFAULT_ONLY)?.activityInfo?.packageName }
        .distinct()

    /** Abre o app com animação de zoom saindo do ícone. */
    fun launch(app: AppInfo, view: View?, b: androidx.compose.ui.geometry.Rect?) {
        runCatching {
            val opts = if (view != null && b != null)
                ActivityOptions.makeScaleUpAnimation(
                    view, b.left.toInt(), b.top.toInt(), b.width.toInt(), b.height.toInt()
                ).toBundle() else null
            val src = b?.let { Rect(it.left.toInt(), it.top.toInt(), it.right.toInt(), it.bottom.toInt()) }
            launcherApps.startMainActivity(app.component, Process.myUserHandle(), src, opts)
        }
    }
}

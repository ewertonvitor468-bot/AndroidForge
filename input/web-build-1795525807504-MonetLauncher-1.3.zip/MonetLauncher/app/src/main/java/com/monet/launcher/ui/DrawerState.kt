package com.monet.launcher.ui

import androidx.compose.animation.core.animate
import androidx.compose.animation.core.spring
import androidx.compose.runtime.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

/**
 * progress: 0 = fechada, 1 = aberta. O valor é lido SÓ em graphicsLayer {}, então
 * o arrasto/animação não causa recomposição (só mexe em propriedades da camada).
 */
@Stable
class DrawerState(private val scope: CoroutineScope) {
    var progress by mutableFloatStateOf(0f)
        private set
    var travel by mutableFloatStateOf(1f)

    val isShown: Boolean by derivedStateOf { progress > 0.001f }

    private var job: Job? = null

    fun dragBy(dy: Float) {
        job?.cancel()
        progress = (progress - dy / travel).coerceIn(0f, 1f)
    }

    /** Solta o dedo: decide abrir/fechar pela velocidade (px/s) ou pela posição. */
    fun settle(velocityY: Float) {
        val target = when {
            velocityY < -700f -> 1f
            velocityY > 700f -> 0f
            progress > 0.5f -> 1f
            else -> 0f
        }
        animateTo(target, velocityY)
    }

    fun animateTo(target: Float, velocityY: Float = 0f) {
        job?.cancel()
        job = scope.launch {
            animate(
                initialValue = progress,
                targetValue = target,
                initialVelocity = -velocityY / travel,
                animationSpec = spring<Float>(dampingRatio = 0.92f, stiffness = 700f),
            ) { v, _ -> progress = v.coerceIn(0f, 1f) }
        }
    }

    fun open() = animateTo(1f)
    fun close() = animateTo(0f)
}

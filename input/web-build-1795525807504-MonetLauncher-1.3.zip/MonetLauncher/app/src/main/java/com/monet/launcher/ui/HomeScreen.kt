package com.monet.launcher.ui

import android.content.Context
import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.monet.launcher.LauncherViewModel
import com.monet.launcher.data.AppInfo
import com.monet.launcher.widgets.WidgetController
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale

private data class HomeTarget(val app: AppInfo, val dock: Boolean)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    vm: LauncherViewModel,
    widgets: WidgetController,
    drawer: DrawerState,
    onOpenSettings: () -> Unit,
    onPickWidget: () -> Unit,
) {
    val s by vm.settings.collectAsState()
    val apps by vm.apps.collectAsState()
    val ctx = LocalContext.current
    val view = LocalView.current
    val byPkg = remember(apps) { apps.associateBy { it.pkg } }
    var menu by remember { mutableStateOf(false) }
    var target by remember { mutableStateOf<HomeTarget?>(null) }
    val pull = remember { floatArrayOf(0f) }

    val perPage = (s.homeColumns * s.homeRows).coerceAtLeast(1)
    val pages = remember(byPkg, s.homeApps, perPage) { s.homeApps.mapNotNull { byPkg[it] }.chunked(perPage) }
    val pageCount = maxOf(1, pages.size)
    val pagerState = rememberPagerState(pageCount = { pageCount })
    val dock = remember(byPkg, s.dockApps) { s.dockApps.ifEmpty { vm.defaultDock }.mapNotNull { byPkg[it] }.take(5) }

    val launch: (AppInfo, androidx.compose.ui.geometry.Rect?) -> Unit = { app, r -> vm.launch(app, view, r) }

    Box(
        Modifier
            .fillMaxSize()
            .pointerInput(Unit) { detectTapGestures(onLongPress = { menu = true }) }
            .draggable(
                orientation = Orientation.Vertical,
                state = rememberDraggableState { dy ->
                    // gaveta fechada + puxar para baixo = notificações; senão a gaveta segue o dedo
                    if (drawer.progress == 0f && dy > 0f) pull[0] += dy else drawer.dragBy(dy)
                },
                onDragStarted = { pull[0] = 0f },
                onDragStopped = { v ->
                    if (pull[0] > 120f && s.shadeGesture && drawer.progress == 0f) expandShade(ctx)
                    else drawer.settle(v)
                    pull[0] = 0f
                },
            )
    ) {
        Column(
            Modifier
                .fillMaxSize()
                // a home some e encolhe um pouco enquanto a gaveta sobe (lido só na fase de desenho)
                .graphicsLayer {
                    val p = drawer.progress
                    alpha = 1f - p
                    scaleX = 1f - 0.06f * p
                    scaleY = scaleX
                }
                .windowInsetsPadding(WindowInsets.systemBars)
                .padding(horizontal = 16.dp)
        ) {
            if (s.showGlance) Glance()

            HorizontalPager(state = pagerState, modifier = Modifier.weight(1f).fillMaxWidth()) { page ->
                Column(Modifier.fillMaxSize()) {
                    if (page == 0) {
                        s.widgetIds.filter { widgets.exists(it) }.forEach { id ->
                            val h = widgets.heightDp(id)
                            AndroidView(
                                factory = { c ->
                                    widgets.createView(id)?.also { it.updateAppWidgetSize(null, 250, h, 400, h) }
                                        ?: android.view.View(c)
                                },
                                modifier = Modifier.fillMaxWidth().height(h.dp).padding(vertical = 6.dp),
                            )
                        }
                    }
                    pages.getOrNull(page).orEmpty().chunked(s.homeColumns).forEach { row ->
                        Row(Modifier.fillMaxWidth()) {
                            row.forEach { app ->
                                AppIcon(
                                    app, s.iconSize, s.labelSize, s.showLabels, Modifier.weight(1f),
                                    onLongClick = { target = HomeTarget(it, false) },
                                    onClick = launch,
                                )
                            }
                            repeat(s.homeColumns - row.size) { Spacer(Modifier.weight(1f)) }
                        }
                    }
                }
            }

            if (pageCount > 1) PageDots(pageCount, pagerState.currentPage)

            Box(
                Modifier
                    .align(Alignment.CenterHorizontally)
                    .clickable { drawer.open() }
                    .padding(horizontal = 24.dp, vertical = 8.dp)
            ) {
                Box(
                    Modifier.size(36.dp, 4.dp)
                        .background(Color.White.copy(alpha = 0.7f), RoundedCornerShape(2.dp))
                )
            }

            Surface(
                shape = RoundedCornerShape(32.dp),
                color = if (s.dockBackground) Color.White.copy(alpha = 0.18f) else Color.Transparent,
                modifier = Modifier.fillMaxWidth(),
            ) {
                Row(
                    Modifier.padding(horizontal = 8.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                ) {
                    dock.forEach { app ->
                        AppIcon(
                            app, s.iconSize, s.labelSize, false, Modifier.weight(1f),
                            onLongClick = { target = HomeTarget(it, true) },
                            onClick = launch,
                        )
                    }
                }
            }

            if (s.showSearchBar) {
                Spacer(Modifier.height(10.dp))
                SearchPill(ctx)
            }
            Spacer(Modifier.height(8.dp))
        }
    }

    target?.let { t ->
        val remove: Pair<String, () -> Unit> =
            if (t.dock) "Remover do dock" to {
                vm.update { it.copy(dockApps = it.dockApps.ifEmpty { vm.defaultDock } - t.app.pkg) }
            } else "Remover da tela inicial" to {
                vm.update { it.copy(homeApps = it.homeApps - t.app.pkg) }
            }
        ActionsSheet(
            t.app.label,
            listOf(remove, "Informações do app" to { openAppInfo(ctx, t.app.pkg) }),
            onDismiss = { target = null },
        )
    }

    if (menu) {
        ModalBottomSheet(onDismissRequest = { menu = false }) {
            ListItem(
                headlineContent = { Text("Widgets") },
                modifier = Modifier.clickable { menu = false; onPickWidget() },
            )
            ListItem(
                headlineContent = { Text("Configurações do MonetLauncher") },
                modifier = Modifier.clickable { menu = false; onOpenSettings() },
            )
            Spacer(Modifier.height(24.dp))
        }
    }
}

/** "At a Glance" estilo Motorola: data + saudação. */
@Composable
private fun Glance() {
    val now = remember { LocalDateTime.now() }
    val greeting = when (now.hour) {
        in 5..11 -> "Bom dia"
        in 12..17 -> "Boa tarde"
        else -> "Boa noite"
    }
    Column(Modifier.padding(start = 8.dp, top = 20.dp, bottom = 12.dp)) {
        Text(
            now.format(DateTimeFormatter.ofPattern("EEE, d MMM", Locale.getDefault())),
            color = Color.White, fontSize = 32.sp, fontWeight = FontWeight.Light, style = TextShadow,
        )
        Text(greeting, color = Color.White, fontSize = 16.sp, style = TextShadow)
    }
}

@Composable
private fun PageDots(count: Int, current: Int) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), horizontalArrangement = Arrangement.Center) {
        repeat(count) { i ->
            Box(
                Modifier
                    .padding(horizontal = 3.dp)
                    .size(if (i == current) 8.dp else 6.dp)
                    .clip(CircleShape)
                    .background(Color.White.copy(alpha = if (i == current) 1f else 0.45f))
            )
        }
    }
}

@Composable
private fun SearchPill(ctx: Context) {
    Surface(
        shape = RoundedCornerShape(28.dp),
        color = Color.White.copy(alpha = 0.92f),
        modifier = Modifier
            .fillMaxWidth()
            .height(52.dp)
            .clip(RoundedCornerShape(28.dp))
            .clickable {
                runCatching {
                    ctx.startActivity(Intent(Intent.ACTION_WEB_SEARCH).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                }
            },
    ) {
        Row(Modifier.padding(horizontal = 20.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Search, null, tint = Color(0xFF444444))
            Spacer(Modifier.width(12.dp))
            Text("Pesquisar", color = Color(0xFF444444), fontSize = 16.sp)
        }
    }
}

/** Puxa a barra de notificações (precisa da permissão EXPAND_STATUS_BAR). */
private fun expandShade(ctx: Context) {
    runCatching {
        val sb = ctx.getSystemService("statusbar")
        Class.forName("android.app.StatusBarManager")
            .getMethod("expandNotificationsPanel")
            .invoke(sb)
    }
}

package com.monet.launcher.data

import android.graphics.*

/** Aplica o formato (arredondamento) UMA vez, fora da UI. Assim a lista não precisa de clip por item. */
object IconShaper {
    fun shape(src: Bitmap, percent: Int): Bitmap {
        val out = Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = BitmapShader(src, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
        }
        val r = minOf(src.width, src.height) * percent / 100f
        Canvas(out).drawRoundRect(0f, 0f, src.width.toFloat(), src.height.toFloat(), r, r, paint)
        return out
    }
}

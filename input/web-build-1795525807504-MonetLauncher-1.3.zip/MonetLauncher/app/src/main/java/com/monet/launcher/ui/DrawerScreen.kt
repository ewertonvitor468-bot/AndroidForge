package com.monet.launcher.ui

import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Velocity
import androidx.compose.ui.unit.dp
import android.content.Intent
import android.net.Uri
import com.monet.launcher.LauncherViewModel
import com.monet.launcher.data.AppInfo

@Composable
fun DrawerScreen(vm: LauncherViewModel, drawer: DrawerState) {
    val s by vm.settings.collectAsState()
    val apps by vm.apps.collectAsState()
    val ctx = LocalContext.current
    val view = LocalView.current
    val focus = LocalFocusManager.current
    var query by remember { mutableStateOf("") }
    var target by remember { mutableStateOf<AppInfo?>(null) }

    val byPkg = remember(apps) { apps.associateBy { it.pkg } }
    val recents = remember(byPkg, s.recentApps) { s.recentApps.mapNotNull { byPkg[it] } }
    val shown = remember(apps, query) {
        if (query.isBlank()) apps else apps.filter { it.label.contains(query.trim(), ignoreCase = true) }
    }

    // ao fechar: limpa a busca e o teclado
    LaunchedEffect(drawer) {
        snapshotFlow { drawer.isShown }.collect { if (!it) { query = ""; focus.clearFocus() } }
    }

    // arrastar a grade para baixo (quando está no topo) fecha a gaveta seguindo o dedo
    val connection = remember(drawer) {
        object : NestedScrollConnection {
            override fun onPreScroll(available: Offset, source: NestedScrollSource): Offset {
                if (available.y < 0f && drawer.progress < 1f) { drawer.dragBy(available.y); return Offset(0f, available.y) }
                return Offset.Zero
            }
            override fun onPostScroll(consumed: Offset, available: Offset, source: NestedScrollSource): Offset {
                if (available.y > 0f) { drawer.dragBy(available.y); return Offset(0f, available.y) }
                return Offset.Zero
            }
            override suspend fun onPreFling(available: Velocity): Velocity {
                if (drawer.progress > 0.001f && drawer.progress < 0.999f) { drawer.settle(available.y); return available }
                return Velocity.Zero
            }
            override suspend fun onPostFling(consumed: Velocity, available: Velocity): Velocity {
                if (available.y > 0f) { drawer.settle(available.y); return available }
                return Velocity.Zero
            }
        }
    }

    val launch: (AppInfo, androidx.compose.ui.geometry.Rect?) -> Unit = { app, r ->
        vm.launch(app, view, r)
        drawer.close()
    }

    Surface(
        Modifier
            .fillMaxSize()
            .graphicsLayer {
                translationY = (1f - drawer.progress) * drawer.travel
                alpha = (drawer.progress * 2f).coerceIn(0f, 1f)
            },
        color = MaterialTheme.colorScheme.surface.copy(alpha = 0.96f),
    ) {
        Column(Modifier.statusBarsPadding().padding(horizontal = 12.dp)) {
            TextField(
                value = query,
                onValueChange = { query = it },
                placeholder = { Text("Pesquisar apps") },
                leadingIcon = { Icon(Icons.Default.Search, null) },
                singleLine = true,
                shape = RoundedCornerShape(28.dp),
                colors = TextFieldDefaults.colors(
                    focusedIndicatorColor = Color.Transparent,
                    unfocusedIndicatorColor = Color.Transparent,
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp)
                    .draggable(
                        orientation = Orientation.Vertical,
                        state = rememberDraggableState { drawer.dragBy(it) },
                        onDragStopped = { drawer.settle(it) },
                    ),
            )
            LazyVerticalGrid(
                columns = GridCells.Fixed(s.drawerColumns),
                contentPadding = PaddingValues(bottom = 24.dp),
                modifier = Modifier.nestedScroll(connection).navigationBarsPadding(),
            ) {
                if (query.isBlank() && recents.isNotEmpty()) {
                    item(span = { GridItemSpan(maxLineSpan) }, contentType = "recents") {
                        Surface(
                            shape = RoundedCornerShape(24.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                            modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
                        ) {
                            Column(Modifier.padding(12.dp)) {
                                Text(
                                    "Recentes",
                                    color = MaterialTheme.colorScheme.primary,
                                    fontWeight = FontWeight.Medium,
                                    modifier = Modifier.padding(start = 4.dp, bottom = 4.dp),
                                )
                                Row(Modifier.fillMaxWidth()) {
                                    recents.forEach { r ->
                                        AppIcon(
                                            r, s.iconSize, s.labelSize, false, Modifier.weight(1f),
                                            onClick = launch,
                                        )
                                    }
                                    repeat(5 - recents.size) { Spacer(Modifier.weight(1f)) }
                                }
                            }
                        }
                    }
                }
                items(shown, key = { it.pkg }, contentType = { "app" }) { app ->
                    AppIcon(
                        app, s.iconSize, s.labelSize, s.showLabels,
                        labelColor = MaterialTheme.colorScheme.onSurface,
                        shadow = false,
                        onLongClick = { target = it },
                        onClick = launch,
                    )
                }
            }
        }
    }

    target?.let { app ->
        ActionsSheet(
            app.label,
            listOf(
                "Adicionar à tela inicial" to {
                    vm.update { it.copy(homeApps = (it.homeApps + app.pkg).distinct()) }
                },
                "Adicionar ao dock" to {
                    vm.update {
                        val cur = it.dockApps.ifEmpty { vm.defaultDock }
                        if (cur.size < 5) it.copy(dockApps = (cur + app.pkg).distinct()) else it
                    }
                },
                "Informações do app" to { openAppInfo(ctx, app.pkg) },
                "Desinstalar" to {
                    ctx.startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:${app.pkg}")))
                },
            ),
            onDismiss = { target = null },
        )
    }
}

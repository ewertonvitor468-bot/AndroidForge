package com.monet.launcher.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.*
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.onSizeChanged
import com.monet.launcher.LauncherViewModel
import com.monet.launcher.widgets.WidgetController

enum class Screen { HOME, SETTINGS, WIDGETS }

@Composable
fun LauncherApp(vm: LauncherViewModel, widgets: WidgetController) {
    var screen by rememberSaveable { mutableStateOf(Screen.HOME) }
    val scope = rememberCoroutineScope()
    val drawer = remember { DrawerState(scope) }

    BackHandler(enabled = drawer.isShown) { drawer.close() }

    // botão Home: fecha tudo
    LaunchedEffect(Unit) { vm.homeEvents.collect { drawer.close(); screen = Screen.HOME } }

    // widget adicionado -> salva o id
    DisposableEffect(Unit) {
        widgets.onAdded = { id -> vm.update { it.copy(widgetIds = it.widgetIds + id) } }
        onDispose { widgets.onAdded = null }
    }

    val slide = tween<androidx.compose.ui.unit.IntOffset>(240, easing = FastOutSlowInEasing)

    Box(Modifier.fillMaxSize().onSizeChanged { drawer.travel = it.height.toFloat() }) {
        HomeScreen(
            vm, widgets, drawer,
            onOpenSettings = { screen = Screen.SETTINGS },
            onPickWidget = { screen = Screen.WIDGETS },
        )

        // sempre composta: abrir é só mover uma camada (sem custo de composição no gesto)
        DrawerScreen(vm, drawer)

        AnimatedVisibility(
            visible = screen != Screen.HOME,
            enter = slideInHorizontally(slide) { it },
            exit = slideOutHorizontally(slide) { it },
        ) {
            when (screen) {
                Screen.SETTINGS -> SettingsScreen(vm, widgets,
                    onPickWidget = { screen = Screen.WIDGETS },
                    onBack = { screen = Screen.HOME })
                Screen.WIDGETS -> WidgetPickerScreen(widgets, onBack = { screen = Screen.HOME })
                Screen.HOME -> Unit
            }
        }
    }
}

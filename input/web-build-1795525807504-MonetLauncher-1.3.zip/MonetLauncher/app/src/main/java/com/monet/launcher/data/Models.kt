package com.monet.launcher.data

import android.content.ComponentName
import androidx.compose.runtime.Immutable
import android.graphics.Bitmap
import androidx.compose.ui.graphics.ImageBitmap

@Immutable
data class AppInfo(
    val label: String,
    val pkg: String,
    val component: ComponentName,
    val icon: ImageBitmap,
)

/** Ícone bruto (sem máscara). O ícone com o formato escolhido é gerado em background. */
class RawApp(val label: String, val pkg: String, val component: ComponentName, val bitmap: Bitmap)

enum class ThemeMode { SYSTEM, LIGHT, DARK }

@Immutable
data class LauncherSettings(
    // Ícones
    val iconSize: Int = 56,        // dp
    val iconCorner: Int = 36,      // % (50 = círculo, 0 = quadrado). ~36 lembra o squircle da One UI 3.1
    val labelSize: Int = 12,       // sp
    val showLabels: Boolean = true,
    // Grades
    val homeColumns: Int = 4,
    val homeRows: Int = 5,
    val drawerColumns: Int = 4,
    // Tema
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val dynamicColor: Boolean = true,
    // Conteúdo
    val homeApps: List<String> = emptyList(),
    val dockApps: List<String> = emptyList(),
    val widgetIds: List<Int> = emptyList(),
    val recentApps: List<String> = emptyList(),
    // Estilo Motorola
    val showGlance: Boolean = true,       // data + saudação no topo
    val showSearchBar: Boolean = true,    // barra de pesquisa embaixo do dock
    val dockBackground: Boolean = true,   // dock translúcido (One UI)
    val shadeGesture: Boolean = true,     // deslizar p/ baixo abre notificações
)

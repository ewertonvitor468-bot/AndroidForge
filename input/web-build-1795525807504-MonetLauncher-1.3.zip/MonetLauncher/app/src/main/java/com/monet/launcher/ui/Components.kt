package com.monet.launcher.ui

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.LayoutCoordinates
import androidx.compose.ui.layout.boundsInWindow
import androidx.compose.ui.layout.onPlaced
import androidx.compose.ui.semantics.onClick
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.monet.launcher.data.AppInfo

val TextShadow = TextStyle(shadow = Shadow(Color.Black.copy(alpha = 0.45f), Offset(0f, 2f), 4f))

/**
 * Leve de propósito: o formato do ícone já vem aplicado no bitmap (sem clip), só recebe
 * valores primitivos (pula recomposição) e o "apertar" é um graphicsLayer lido na fase de desenho.
 */
@Composable
fun AppIcon(
    app: AppInfo,
    iconSize: Int,
    labelSize: Int,
    showLabel: Boolean,
    modifier: Modifier = Modifier,
    labelColor: Color = Color.White,
    shadow: Boolean = true,
    onLongClick: ((AppInfo) -> Unit)? = null,
    onClick: (AppInfo, Rect?) -> Unit,
) {
    var pressed by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(
        targetValue = if (pressed) 0.86f else 1f,
        animationSpec = spring(dampingRatio = 0.55f, stiffness = Spring.StiffnessMedium),
        label = "press",
    )
    val coords = remember { arrayOfNulls<LayoutCoordinates>(1) }
    val click by rememberUpdatedState(onClick)
    val longClick by rememberUpdatedState(onLongClick)

    Column(
        modifier
            .fillMaxWidth()
            .onPlaced { coords[0] = it }
            .graphicsLayer { scaleX = scale; scaleY = scale }
            .pointerInput(app) {
                detectTapGestures(
                    onPress = { pressed = true; tryAwaitRelease(); pressed = false },
                    onTap = { click(app, coords[0]?.takeIf { it.isAttached }?.boundsInWindow()) },
                    onLongPress = { longClick?.invoke(app) },
                )
            }
            .semantics { onClick(label = app.label) { click(app, null); true } }
            .padding(vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Image(bitmap = app.icon, contentDescription = null, modifier = Modifier.size(iconSize.dp))
        if (showLabel) {
            Text(
                app.label,
                color = labelColor,
                fontSize = labelSize.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                style = if (shadow) TextShadow else TextStyle.Default,
                modifier = Modifier.padding(top = 4.dp, start = 2.dp, end = 2.dp),
            )
        }
    }
}

/** Menu de ações (toque longo). Um só por tela em vez de um DropdownMenu por ícone. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ActionsSheet(title: String, actions: List<Pair<String, () -> Unit>>, onDismiss: () -> Unit) {
    ModalBottomSheet(onDismissRequest = onDismiss) {
        Text(
            title, fontWeight = FontWeight.Medium, fontSize = 18.sp,
            modifier = Modifier.padding(horizontal = 24.dp, vertical = 8.dp),
        )
        actions.forEach { (label, action) ->
            ListItem(
                headlineContent = { Text(label) },
                modifier = Modifier.clickable { onDismiss(); action() },
            )
        }
        Spacer(Modifier.height(24.dp))
    }
}

fun openAppInfo(ctx: Context, pkg: String) {
    ctx.startActivity(
        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", pkg, null))
    )
}

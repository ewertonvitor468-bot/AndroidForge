package com.monet.launcher

import android.app.role.RoleManager
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.monet.launcher.data.LauncherSettings
import com.monet.launcher.ui.LogoMark
import com.monet.launcher.ui.MonetTheme

/** Tela do ícone do app: mostra o status e pede para virar o launcher padrão. */
class SetupActivity : ComponentActivity() {

    private var isDefault by mutableStateOf(false)

    private val roleLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { refresh() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        refresh()
        setContent {
            MonetTheme(LauncherSettings()) {
                SetupScreen(
                    isDefault = isDefault,
                    onSetDefault = ::requestDefault,
                    onOpen = { startActivity(Intent(this, MainActivity::class.java)) },
                )
            }
        }
    }

    override fun onResume() { super.onResume(); refresh() }

    private fun refresh() {
        val rm = getSystemService(RoleManager::class.java)
        isDefault = rm?.isRoleHeld(RoleManager.ROLE_HOME) == true
    }

    private fun requestDefault() {
        val rm = getSystemService(RoleManager::class.java)
        val ok = runCatching {
            if (rm != null && rm.isRoleAvailable(RoleManager.ROLE_HOME) && !rm.isRoleHeld(RoleManager.ROLE_HOME)) {
                roleLauncher.launch(rm.createRequestRoleIntent(RoleManager.ROLE_HOME))
                true
            } else false
        }.getOrDefault(false)
        if (!ok) {
            // Já é o padrão (trocar) ou o sistema não mostrou o diálogo: abre os ajustes
            runCatching { startActivity(Intent(Settings.ACTION_HOME_SETTINGS)) }
                .onFailure { startActivity(Intent(Settings.ACTION_SETTINGS)) }
        }
    }
}

@Composable
private fun SetupScreen(isDefault: Boolean, onSetDefault: () -> Unit, onOpen: () -> Unit) {
    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.surface) {
        Column(
            Modifier
                .verticalScroll(rememberScrollState())
                .systemBarsPadding()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Spacer(Modifier.height(40.dp))
            LogoMark(120.dp)
            Spacer(Modifier.height(20.dp))
            Text("MonetLauncher", fontSize = 32.sp, fontWeight = FontWeight.Medium)
            Text("Versão 1.3 • Material You", color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(32.dp))

            Surface(
                shape = RoundedCornerShape(24.dp),
                color = if (isDefault) MaterialTheme.colorScheme.primaryContainer
                else MaterialTheme.colorScheme.surfaceVariant,
                modifier = Modifier.fillMaxWidth(),
            ) {
                Row(Modifier.padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(if (isDefault) Icons.Default.Check else Icons.Default.Warning, null)
                    Spacer(Modifier.width(16.dp))
                    Column {
                        Text(
                            if (isDefault) "Launcher padrão ativo" else "Ainda não é o launcher padrão",
                            fontWeight = FontWeight.Medium,
                        )
                        Text(
                            if (isDefault) "O botão Home já abre o MonetLauncher."
                            else "Toque no botão abaixo e escolha MonetLauncher.",
                            style = MaterialTheme.typography.bodySmall,
                        )
                    }
                }
            }

            Spacer(Modifier.height(24.dp))
            Button(onClick = onSetDefault, modifier = Modifier.fillMaxWidth().height(52.dp)) {
                Text(if (isDefault) "Trocar launcher padrão" else "Definir como launcher padrão")
            }
            Spacer(Modifier.height(12.dp))
            OutlinedButton(onClick = onOpen, modifier = Modifier.fillMaxWidth().height(52.dp)) {
                Text("Abrir MonetLauncher")
            }
            Spacer(Modifier.height(24.dp))
            Text(
                "Dica: depois de definir, aperte o botão Home. Para voltar ao launcher antigo, use Configurações > Apps > Apps padrão > Tela inicial.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center,
            )
        }
    }
}

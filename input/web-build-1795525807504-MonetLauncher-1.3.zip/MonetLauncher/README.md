# MonetLauncher 1.3

Kotlin + Jetpack Compose. Material You (Monet), visual One UI, home estilo Motorola.

## 1.3: desempenho + animações
- Ícones com o formato aplicado em background (sem clip por item no scroll)
- Itens da lista pulam recomposição; um único menu por tela (antes: um DropdownMenu por ícone)
- Gaveta segue o dedo (arrastar abre/fecha, com velocidade e mola); home encolhe e some enquanto sobe
- Fechar arrastando a grade para baixo quando está no topo
- Ícone "afunda" ao tocar; app abre com zoom saindo do ícone
- Build Release otimizado (R8) + profileinstaller

## IMPORTANTE para ficar fluido
Instale o build **release** (Build > assembleRelease). Compose em debug trava muito.

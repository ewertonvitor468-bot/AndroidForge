# MonetLauncher 1.1

Launcher Android em Kotlin + Jetpack Compose, Material You (Monet), estilo One UI 3.1.

## Como abrir
Android Studio (Koala+) > Open > pasta MonetLauncher > Run no Android 12+ (minSdk 31).
Depois, Configurações > Apps > Apps padrão > Tela inicial > MonetLauncher.

## Recursos 1.1
- Cores dinâmicas (Monet) + tema claro/escuro/sistema
- Tela inicial: relógio, widgets, grade de apps, dock (até 5)
- Gaveta de apps com busca; deslizar para cima abre, para baixo fecha
- Toque longo no app: adicionar à home/dock, info, desinstalar
- Toque longo na home: menu (widgets, configurações)
- Configurações: tamanho/arredondamento/texto dos ícones, nomes, colunas e linhas, widgets
- Suporte a widgets (AppWidgetHost): bind, tela de configuração, remoção

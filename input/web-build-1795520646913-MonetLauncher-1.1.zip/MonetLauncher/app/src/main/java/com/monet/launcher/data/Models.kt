package com.monet.launcher.data

import android.content.ComponentName
import androidx.compose.runtime.Immutable
import androidx.compose.ui.graphics.ImageBitmap

@Immutable
data class AppInfo(
    val label: String,
    val pkg: String,
    val component: ComponentName,
    val icon: ImageBitmap,
)

enum class ThemeMode { SYSTEM, LIGHT, DARK }

data class LauncherSettings(
    // Ícones
    val iconSize: Int = 56,        // dp
    val iconCorner: Int = 36,      // % (50 = círculo, 0 = quadrado). ~36 lembra o squircle da One UI 3.1
    val labelSize: Int = 12,       // sp
    val showLabels: Boolean = true,
    // Grades
    val homeColumns: Int = 4,
    val homeRows: Int = 5,
    val drawerColumns: Int = 4,
    // Tema
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val dynamicColor: Boolean = true,
    // Conteúdo
    val homeApps: List<String> = emptyList(),
    val dockApps: List<String> = emptyList(),
    val widgetIds: List<Int> = emptyList(),
)

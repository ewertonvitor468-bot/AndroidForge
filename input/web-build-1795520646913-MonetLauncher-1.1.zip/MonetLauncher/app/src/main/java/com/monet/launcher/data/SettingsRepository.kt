package com.monet.launcher.data

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.store by preferencesDataStore("monet_launcher_settings")

class SettingsRepository(private val ctx: Context) {

    private object K {
        val iconSize = intPreferencesKey("icon_size")
        val iconCorner = intPreferencesKey("icon_corner")
        val labelSize = intPreferencesKey("label_size")
        val showLabels = booleanPreferencesKey("show_labels")
        val homeCols = intPreferencesKey("home_cols")
        val homeRows = intPreferencesKey("home_rows")
        val drawerCols = intPreferencesKey("drawer_cols")
        val theme = stringPreferencesKey("theme")
        val dynamic = booleanPreferencesKey("dynamic")
        val home = stringPreferencesKey("home_apps")
        val dock = stringPreferencesKey("dock_apps")
        val widgets = stringPreferencesKey("widgets")
    }

    val flow: Flow<LauncherSettings> = ctx.store.data.map(::read)

    suspend fun update(transform: (LauncherSettings) -> LauncherSettings) {
        ctx.store.edit { p -> write(p, transform(read(p))) }
    }

    private fun String?.pipeList() = this?.split("|")?.filter { it.isNotEmpty() }.orEmpty()

    private fun read(p: Preferences): LauncherSettings {
        val d = LauncherSettings()
        return LauncherSettings(
            iconSize = p[K.iconSize] ?: d.iconSize,
            iconCorner = p[K.iconCorner] ?: d.iconCorner,
            labelSize = p[K.labelSize] ?: d.labelSize,
            showLabels = p[K.showLabels] ?: d.showLabels,
            homeColumns = p[K.homeCols] ?: d.homeColumns,
            homeRows = p[K.homeRows] ?: d.homeRows,
            drawerColumns = p[K.drawerCols] ?: d.drawerColumns,
            themeMode = p[K.theme]?.let { runCatching { ThemeMode.valueOf(it) }.getOrNull() } ?: d.themeMode,
            dynamicColor = p[K.dynamic] ?: d.dynamicColor,
            homeApps = p[K.home].pipeList(),
            dockApps = p[K.dock].pipeList(),
            widgetIds = p[K.widgets]?.split(",")?.mapNotNull { it.toIntOrNull() }.orEmpty(),
        )
    }

    private fun write(p: MutablePreferences, s: LauncherSettings) {
        p[K.iconSize] = s.iconSize
        p[K.iconCorner] = s.iconCorner
        p[K.labelSize] = s.labelSize
        p[K.showLabels] = s.showLabels
        p[K.homeCols] = s.homeColumns
        p[K.homeRows] = s.homeRows
        p[K.drawerCols] = s.drawerColumns
        p[K.theme] = s.themeMode.name
        p[K.dynamic] = s.dynamicColor
        p[K.home] = s.homeApps.joinToString("|")
        p[K.dock] = s.dockApps.joinToString("|")
        p[K.widgets] = s.widgetIds.joinToString(",")
    }
}

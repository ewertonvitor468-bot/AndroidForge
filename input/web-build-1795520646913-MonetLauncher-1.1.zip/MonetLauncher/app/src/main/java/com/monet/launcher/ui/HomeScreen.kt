package com.monet.launcher.ui

import android.text.format.DateFormat
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.monet.launcher.LauncherViewModel
import com.monet.launcher.widgets.WidgetController
import kotlinx.coroutines.delay
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.time.format.FormatStyle

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    vm: LauncherViewModel,
    widgets: WidgetController,
    onOpenDrawer: () -> Unit,
    onOpenSettings: () -> Unit,
    onPickWidget: () -> Unit,
) {
    val s by vm.settings.collectAsState()
    val apps by vm.apps.collectAsState()
    val byPkg = remember(apps) { apps.associateBy { it.pkg } }
    var menu by remember { mutableStateOf(false) }

    val homeApps = s.homeApps.mapNotNull { byPkg[it] }.take(s.homeColumns * s.homeRows)
    val dock = s.dockApps.ifEmpty { vm.defaultDock }.mapNotNull { byPkg[it] }.take(5)

    Box(
        Modifier
            .fillMaxSize()
            .pointerInput(Unit) { detectTapGestures(onLongPress = { menu = true }) }
            .pointerInput(Unit) {
                var total = 0f
                detectVerticalDragGestures(
                    onDragStart = { total = 0f },
                    onDragEnd = { if (total < -120f) onOpenDrawer() },
                    onVerticalDrag = { _, dy -> total += dy },
                )
            }
    ) {
        Column(
            Modifier
                .fillMaxSize()
                .windowInsetsPadding(WindowInsets.systemBars)
                .padding(horizontal = 16.dp)
        ) {
            ClockHeader()

            s.widgetIds.filter { widgets.exists(it) }.forEach { id ->
                val h = widgets.heightDp(id)
                AndroidView(
                    factory = { ctx -> widgets.createView(id) ?: android.view.View(ctx) },
                    update = { v ->
                        (v as? android.appwidget.AppWidgetHostView)
                            ?.updateAppWidgetSize(null, 250, h, 400, h)
                    },
                    modifier = Modifier.fillMaxWidth().height(h.dp).padding(vertical = 6.dp),
                )
            }

            Spacer(Modifier.height(8.dp))
            homeApps.chunked(s.homeColumns).forEach { row ->
                Row(Modifier.fillMaxWidth()) {
                    row.forEach { app ->
                        AppIcon(
                            app, s, Modifier.weight(1f),
                            actions = listOf("Remover da tela inicial" to {
                                vm.update { it.copy(homeApps = it.homeApps - app.pkg) }
                            }),
                            onClick = { vm.launch(app) },
                        )
                    }
                    repeat(s.homeColumns - row.size) { Spacer(Modifier.weight(1f)) }
                }
            }

            Spacer(Modifier.weight(1f))

            // alça para abrir a gaveta (além do gesto de deslizar para cima)
            Box(
                Modifier
                    .align(Alignment.CenterHorizontally)
                    .clickable(onClick = onOpenDrawer)
                    .padding(horizontal = 24.dp, vertical = 10.dp)
            ) {
                Box(
                    Modifier.size(36.dp, 4.dp)
                        .background(Color.White.copy(alpha = 0.7f), RoundedCornerShape(2.dp))
                )
            }

            Surface(
                shape = RoundedCornerShape(32.dp),
                color = Color.White.copy(alpha = 0.18f),
                modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
            ) {
                Row(
                    Modifier.padding(horizontal = 8.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                ) {
                    dock.forEach { app ->
                        AppIcon(
                            app, s, Modifier.weight(1f), showLabel = false,
                            actions = listOf("Remover do dock" to {
                                vm.update { it.copy(dockApps = it.dockApps.ifEmpty { vm.defaultDock } - app.pkg) }
                            }),
                            onClick = { vm.launch(app) },
                        )
                    }
                }
            }
        }
    }

    if (menu) {
        ModalBottomSheet(onDismissRequest = { menu = false }) {
            ListItem(
                headlineContent = { Text("Widgets") },
                modifier = Modifier.clickable { menu = false; onPickWidget() },
            )
            ListItem(
                headlineContent = { Text("Configurações do MonetLauncher") },
                modifier = Modifier.clickable { menu = false; onOpenSettings() },
            )
            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun ClockHeader() {
    val ctx = LocalContext.current
    val now by produceState(LocalDateTime.now()) {
        while (true) {
            value = LocalDateTime.now()
            delay((60 - value.second) * 1000L)
        }
    }
    val pattern = if (DateFormat.is24HourFormat(ctx)) "HH:mm" else "h:mm"
    Column(Modifier.padding(start = 8.dp, top = 24.dp, bottom = 12.dp)) {
        Text(
            now.format(DateTimeFormatter.ofPattern(pattern)),
            color = Color.White, fontSize = 72.sp, fontWeight = FontWeight.Light, style = TextShadow,
        )
        Text(
            now.format(DateTimeFormatter.ofLocalizedDate(FormatStyle.FULL)),
            color = Color.White, fontSize = 16.sp, style = TextShadow,
        )
    }
}

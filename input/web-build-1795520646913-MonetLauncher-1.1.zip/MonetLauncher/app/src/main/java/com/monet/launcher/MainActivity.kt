package com.monet.launcher

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.runtime.getValue
import androidx.compose.runtime.collectAsState
import com.monet.launcher.ui.LauncherApp
import com.monet.launcher.ui.MonetTheme
import com.monet.launcher.widgets.WidgetController

class MainActivity : ComponentActivity() {

    private val vm: LauncherViewModel by viewModels()
    private val widgets = WidgetController(this) // precisa ser criado antes do STARTED

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val s by vm.settings.collectAsState()
            MonetTheme(s) { LauncherApp(vm, widgets) }
        }
    }

    override fun onStart() { super.onStart(); widgets.start() }
    override fun onStop() { super.onStop(); widgets.stop() }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (intent.action == Intent.ACTION_MAIN) vm.homePressed()
    }

    @Deprecated("Usado pelo AppWidgetHost para a tela de configuração do widget")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == WidgetController.REQ_CONFIG) widgets.onConfigResult(resultCode)
        else super.onActivityResult(requestCode, resultCode, data)
    }
}

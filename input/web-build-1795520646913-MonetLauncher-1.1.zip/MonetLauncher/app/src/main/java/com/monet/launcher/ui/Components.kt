package com.monet.launcher.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.monet.launcher.data.AppInfo
import com.monet.launcher.data.LauncherSettings

val TextShadow = TextStyle(shadow = Shadow(Color.Black.copy(alpha = 0.45f), Offset(0f, 2f), 4f))

@Composable
fun AppIcon(
    app: AppInfo,
    s: LauncherSettings,
    modifier: Modifier = Modifier,
    showLabel: Boolean = s.showLabels,
    labelColor: Color = Color.White,
    shadow: Boolean = true,
    actions: List<Pair<String, () -> Unit>> = emptyList(),
    onClick: () -> Unit,
) {
    var menu by remember { mutableStateOf(false) }
    Box(modifier) {
        Column(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .combinedClickable(onClick = onClick, onLongClick = { if (actions.isNotEmpty()) menu = true })
                .padding(vertical = 6.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Image(
                bitmap = app.icon,
                contentDescription = app.label,
                modifier = Modifier
                    .size(s.iconSize.dp)
                    .clip(RoundedCornerShape(percent = s.iconCorner)),
            )
            if (showLabel) {
                Text(
                    app.label,
                    color = labelColor,
                    fontSize = s.labelSize.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    style = if (shadow) TextShadow else TextStyle.Default,
                    modifier = Modifier.padding(top = 4.dp, start = 2.dp, end = 2.dp),
                )
            }
        }
        DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
            actions.forEach { (title, action) ->
                DropdownMenuItem(text = { Text(title) }, onClick = { menu = false; action() })
            }
        }
    }
}

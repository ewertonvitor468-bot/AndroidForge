package com.monet.launcher.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.monet.launcher.LauncherViewModel
import com.monet.launcher.data.ThemeMode
import com.monet.launcher.widgets.WidgetController
import kotlin.math.roundToInt

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SettingsScreen(
    vm: LauncherViewModel,
    widgets: WidgetController,
    onPickWidget: () -> Unit,
    onBack: () -> Unit,
) {
    BackHandler(onBack = onBack)
    val s by vm.settings.collectAsState()

    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.surface) {
        Column(
            Modifier
                .verticalScroll(rememberScrollState())
                .systemBarsPadding()
                .padding(horizontal = 16.dp)
        ) {
            // Cabeçalho grande, no estilo One UI 3.1
            Box(Modifier.fillMaxWidth().height(140.dp), contentAlignment = Alignment.BottomStart) {
                Text("Configurações", fontSize = 34.sp, fontWeight = FontWeight.Medium,
                    modifier = Modifier.padding(start = 8.dp, bottom = 16.dp))
            }

            Section("Aparência") {
                Text("Tema", style = MaterialTheme.typography.bodyMedium)
                Spacer(Modifier.height(8.dp))
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(ThemeMode.SYSTEM to "Sistema", ThemeMode.LIGHT to "Claro", ThemeMode.DARK to "Escuro")
                        .forEach { (mode, name) ->
                            FilterChip(
                                selected = s.themeMode == mode,
                                onClick = { vm.update { it.copy(themeMode = mode) } },
                                label = { Text(name) },
                            )
                        }
                }
                SwitchRow("Cores dinâmicas (Monet)", s.dynamicColor) { v -> vm.update { it.copy(dynamicColor = v) } }
            }

            Section("Ícones") {
                Box(
                    Modifier.align(Alignment.CenterHorizontally)
                        .size(s.iconSize.dp)
                        .background(MaterialTheme.colorScheme.primary, RoundedCornerShape(percent = s.iconCorner))
                )
                Spacer(Modifier.height(8.dp))
                SliderRow("Tamanho do ícone", s.iconSize, 40..80, "dp") { v -> vm.update { it.copy(iconSize = v) } }
                SliderRow("Arredondamento", s.iconCorner, 0..50, "%") { v -> vm.update { it.copy(iconCorner = v) } }
                SliderRow("Tamanho do texto", s.labelSize, 9..16, "sp") { v -> vm.update { it.copy(labelSize = v) } }
                SwitchRow("Mostrar nomes dos apps", s.showLabels) { v -> vm.update { it.copy(showLabels = v) } }
            }

            Section("Tela inicial") {
                SliderRow("Colunas", s.homeColumns, 3..6, "") { v -> vm.update { it.copy(homeColumns = v) } }
                SliderRow("Linhas", s.homeRows, 3..8, "") { v -> vm.update { it.copy(homeRows = v) } }
            }

            Section("Gaveta de apps") {
                SliderRow("Colunas", s.drawerColumns, 3..6, "") { v -> vm.update { it.copy(drawerColumns = v) } }
            }

            Section("Widgets") {
                s.widgetIds.forEach { id ->
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Text(widgets.label(id), Modifier.weight(1f))
                        IconButton(onClick = {
                            widgets.remove(id)
                            vm.update { it.copy(widgetIds = it.widgetIds - id) }
                        }) { Icon(Icons.Default.Delete, "Remover widget") }
                    }
                }
                FilledTonalButton(onClick = onPickWidget) {
                    Icon(Icons.Default.Add, null)
                    Spacer(Modifier.width(8.dp))
                    Text("Adicionar widget")
                }
            }

            Section("Sobre") {
                Text("MonetLauncher 1.1", fontWeight = FontWeight.Medium)
                Text("Material You • Compose • Widgets", style = MaterialTheme.typography.bodySmall)
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun Section(title: String, content: @Composable ColumnScope.() -> Unit) {
    Text(title, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Medium,
        modifier = Modifier.padding(start = 8.dp, top = 16.dp, bottom = 8.dp))
    Surface(shape = RoundedCornerShape(24.dp), color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)) {
        Column(Modifier.fillMaxWidth().padding(16.dp), content = content)
    }
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun SliderRow(label: String, value: Int, range: IntRange, unit: String, onDone: (Int) -> Unit) {
    var v by remember(value) { mutableFloatStateOf(value.toFloat()) }
    Column(Modifier.padding(top = 4.dp)) {
        Row {
            Text(label, Modifier.weight(1f))
            Text("${v.roundToInt()}$unit", color = MaterialTheme.colorScheme.primary)
        }
        Slider(
            value = v,
            onValueChange = { v = it },
            onValueChangeFinished = { onDone(v.roundToInt()) },
            valueRange = range.first.toFloat()..range.last.toFloat(),
            steps = range.last - range.first - 1,
        )
    }
}

package com.example.materialkeyboard

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RadialGradient
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.drawable.Drawable
import androidx.core.graphics.ColorUtils

/**
 * Fundo próprio do Liquid Glass: a cor do tema com manchas suaves de luz, geradas a partir do destaque.
 * O teclado não enxerga o app atrás dele; é este fundo que as teclas ampliam para imitar a lente do vidro.
 * Não usa imagens. Os gradientes só são recriados quando o tamanho muda.
 */
class LiquidBackdrop(private val surface: Int, accent: Int, private val topR: Float) : Drawable() {
    private val colors = intArrayOf(accent, rotate(accent, 70f), rotate(accent, -80f), rotate(accent, 150f))
    // x, y e raio de cada mancha, em fração da largura/altura/largura
    private val spots = floatArrayOf(
        0.08f, 0.22f, 0.48f,
        0.88f, 0.12f, 0.44f,
        0.60f, 0.68f, 0.50f,
        0.16f, 0.82f, 0.34f)
    private val base = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = surface }
    private val paints = Array(4) { Paint(Paint.ANTI_ALIAS_FLAG or Paint.DITHER_FLAG) }
    private val clip = Path()
    private var a = 255

    private fun rotate(c: Int, deg: Float): Int {
        val hsl = FloatArray(3)
        ColorUtils.colorToHSL(c, hsl)
        hsl[0] = (hsl[0] + deg + 360f) % 360f
        hsl[1] = hsl[1].coerceAtLeast(0.55f)
        return ColorUtils.HSLToColor(hsl)
    }

    override fun onBoundsChange(b: Rect) {
        val w = b.width().toFloat(); val h = b.height().toFloat()
        if (w <= 0f || h <= 0f) return
        for (i in paints.indices) {
            paints[i].shader = RadialGradient(w * spots[i * 3], h * spots[i * 3 + 1], w * spots[i * 3 + 2],
                intArrayOf(ColorUtils.setAlphaComponent(colors[i], 190), ColorUtils.setAlphaComponent(colors[i], 110),
                    ColorUtils.setAlphaComponent(colors[i], 0)),
                floatArrayOf(0f, 0.45f, 1f), Shader.TileMode.CLAMP)
        }
        clip.rewind()
        clip.addRoundRect(RectF(0f, 0f, w, h), floatArrayOf(topR, topR, topR, topR, 0f, 0f, 0f, 0f), Path.Direction.CW)
    }

    override fun draw(canvas: Canvas) {
        canvas.save()
        canvas.translate(bounds.left.toFloat(), bounds.top.toFloat())
        canvas.clipPath(clip)
        paint(canvas)
        canvas.restore()
    }

    /** Desenha o fundo em coordenadas próprias (0,0 = canto do teclado); as teclas usam para a lente. */
    fun paint(canvas: Canvas) {
        val w = bounds.width().toFloat(); val h = bounds.height().toFloat()
        base.alpha = Color.alpha(surface) * a / 255
        canvas.drawRect(0f, 0f, w, h, base)
        for (p in paints) { p.alpha = a; canvas.drawRect(0f, 0f, w, h, p) }
    }

    override fun setAlpha(alpha: Int) { if (a != alpha) { a = alpha; invalidateSelf() } }
    override fun getAlpha(): Int = a
    override fun setColorFilter(colorFilter: ColorFilter?) { base.colorFilter = colorFilter; paints.forEach { it.colorFilter = colorFilter } }
    @Deprecated("Deprecated in Java")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}

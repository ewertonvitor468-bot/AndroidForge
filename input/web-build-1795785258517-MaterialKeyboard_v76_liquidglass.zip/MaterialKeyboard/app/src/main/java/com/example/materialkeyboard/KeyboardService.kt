package com.example.materialkeyboard

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.ClipData
import android.content.ClipDescription
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.inputmethodservice.InputMethodService
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.text.InputType
import android.text.TextUtils
import android.view.ContextThemeWrapper
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.graphics.Rect
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.os.Bundle
import android.util.Size
import androidx.annotation.RequiresApi
import androidx.core.content.ContextCompat
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.Manifest
import android.content.pm.PackageManager
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ScrollView
import android.graphics.Typeface
import android.widget.ImageView
import androidx.core.content.FileProvider
import androidx.core.graphics.ColorUtils
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.inputmethod.EditorInfoCompat
import androidx.core.view.inputmethod.InputConnectionCompat
import androidx.core.view.inputmethod.InputContentInfoCompat
import androidx.dynamicanimation.animation.DynamicAnimation
import androidx.dynamicanimation.animation.FloatValueHolder
import androidx.dynamicanimation.animation.SpringAnimation
import androidx.dynamicanimation.animation.SpringForce
import java.io.File
import java.util.concurrent.Executors
import com.example.materialkeyboard.compose.ComposeLayer
import com.example.materialkeyboard.compose.ImeComposeOwner
import com.example.materialkeyboard.compose.MkClipboardPanel
import com.example.materialkeyboard.compose.MkClipboardState
import com.example.materialkeyboard.compose.MkDemoPanel
import com.example.materialkeyboard.compose.MkEmojiPanel
import com.example.materialkeyboard.compose.MkEmojiState
import com.example.materialkeyboard.compose.MkExtraRow
import com.example.materialkeyboard.compose.paletteColorScheme

class KeyboardService : InputMethodService() {

    private enum class Style { NORMAL, SPECIAL, ACCENT }
    private class LetterKey(val view: KeyView, val ch: Char)

    private lateinit var prefs: Prefs
    private lateinit var store: ClipboardStore
    private lateinit var sugg: Suggestions
    private lateinit var recents: EmojiRecents
    private lateinit var ui: Context
    // Jetpack Compose: dono de ciclo de vida/estado exigido pelo ComposeView numa janela de IME
    private val composeOwner = ImeComposeOwner()
    private lateinit var pal: Palette

    private val main = Handler(Looper.getMainLooper())
    // Duas threads separadas: antes vibração/som e consulta de sugestões dividiam UMA fila, e uma
    // sugestão lenta atrasava a vibração e o som das teclas seguintes (sensação de "atraso").
    private val fxExec = Executors.newSingleThreadExecutor()    // vibração e som
    private val suggExec = Executors.newSingleThreadExecutor()  // sugestões
    private val clipExec = Executors.newSingleThreadExecutor()  // leitura de clipboard (texto grande/imagem)
    private fun runFx(r: () -> Unit) { try { fxExec.execute { r() } } catch (_: java.util.concurrent.RejectedExecutionException) { } }
    private fun runSugg(r: () -> Unit) { try { suggExec.execute { r() } } catch (_: java.util.concurrent.RejectedExecutionException) { } }
    private fun runClip(r: () -> Unit) { try { clipExec.execute { r() } } catch (_: java.util.concurrent.RejectedExecutionException) { } }
    private var vibrator: Vibrator? = null
    private var sounds: SoundBank? = null
    @Volatile private var lastUp: Pair<Int, String>? = null   // pacote/clipe para o som de soltar da tecla apertada
    private var clipboard: ClipboardManager? = null
    private lateinit var sysDict: SystemDictionary

    // Estado de digitação
    private var shift = false
    private var caps = false
    private var symbols = false
    private var symPage2 = false
    private var lastShiftTap = 0L
    private var pendingAccent: Char? = null
    private val word = StringBuilder()
    private var prevWord = ""
    private var sentenceEnd = false
    private var suggSeq = 0
    private var smart = true            // sugestões/autocorreção permitidas neste campo
    private var isPassword = false
    private var lastAccent: Char? = null
    private var composeOk = true        // campo aceita composição (Telex): texto comum, sem senha/e-mail/URL
    private val viRaw = StringBuilder() // teclas do Telex (vietnamita) da palavra atual
    private var viFrozen = ""           // parte da palavra que não é mais recomposta (ex.: depois de apagar algo estranho)
    private var viShown = ""            // último texto que o Telex pôs no campo; se `word` for diferente, algo mexeu por fora
    private var shownLang = ""
    private val ar: Boolean get() = prefs.language == Prefs.LANG_AR   // árabe: direita→esquerda, sem maiúsculas
    private val es: Boolean get() = prefs.language == Prefs.LANG_ES
    private val fr: Boolean get() = prefs.language == Prefs.LANG_FR   // francês: AZERTY
    private val tr: Boolean get() = prefs.language == Prefs.LANG_TR   // turco: teclado Q turco, I/İ e ı/I
    private val vi: Boolean get() = prefs.language == Prefs.LANG_VI   // vietnamita: QWERTY + Telex
    private fun viOn() = vi && !symbols && composeOk

    // Views
    private var rootView: LinearLayout? = null
    private var host: FrameLayout? = null
    private var keysContainer: LinearLayout? = null

    // ---- digitação por deslize ----
    private var glideSeq = 0
    private var glideLast: String? = null            // palavra (com espaço) que o último deslize inseriu
    private var glideAlts: List<String> = emptyList()
    private val glideRect = Rect()

    // ---- teclado flutuante / uma mão ----
    private var floatFrame: FrameLayout? = null
    private var floatBox: LinearLayout? = null
    private var floatDragging = false

    // ---- autofill (sugestões inline do Android 11+) ----
    private var afScroll: HorizontalScrollView? = null
    private var afRow: LinearLayout? = null
    private var afSeq = 0
    private var afShown = false
    private var toolbar: View? = null                // barra de ícones deslizável (HorizontalScrollView)
    private var toolbarInner: LinearLayout? = null   // os ícones dentro dela
    private var keycapMode = false                   // "Posicionar Keycaps": arrastar uma letra sobre outra troca as duas
    private var editBar: LinearLayout? = null        // faixa com a dica, "Restaurar" e "Concluído"
    private var keyRoot: KeyRoot? = null
    private var posPanel: View? = null               // painel "Organizar a barra"
    private var posList: LinearLayout? = null
    private var posScroll: ScrollView? = null
    private var strip: LinearLayout? = null
    private var pillBgView: View? = null                 // fundo da pílula dos ícones (some quando as sugestões aparecem)
    private var extraRow: LinearLayout? = null
    private var expandIcon: ImageView? = null
    private var extraOpen = false
    private val suggViews = ArrayList<TextView>()
    private val suggDividers = ArrayList<View>()
    private var activePanel: View? = null
    private var cursorPad: CursorPad? = null          // modo cursor (barra de espaço)
    private var clipPanel: View? = null              // painel Compose (histórico)
    private var clipState: MkClipboardState? = null
    private var translatorBar: TranslatorBar? = null
    private val translator = TranslationEngine()
    private var emojiPanel: View? = null             // painel Compose (emojis)
    private var emojiState: MkEmojiState? = null
    private var demoPanel: View? = null              // painel Compose (Material 3 Expressive)
    private val letterKeys = ArrayList<LetterKey>()
    private var shiftKey: KeyView? = null
    private val deadKeys = HashMap<Char, KeyView>()
    private var textPx = 40f
    private var sc = 1f                 // escala geral do teclado (preferência "Tamanho do teclado".tr())
    private var extraAnim: SpringAnimation? = null
    private var bar: FrameLayout? = null            // barra única: ferramentas OU sugestões (mesma altura)
    private var stripShown = false
    private var altPopup: AltPopup? = null
    private var keyPreview: KeyPreview? = null
    private var toolbarRef: LinearLayout? = null
    private var lastShift = false
    private var lastCaps = false
    private val hideStrip = Runnable { showStrip(false) }
    private val settlePanels = Runnable {
        val h = host ?: return@Runnable
        for (i in 0 until h.childCount) {
            val ch = h.getChildAt(i)
            if (ch === activePanel) { ch.visibility = View.VISIBLE; ch.settle() } else ch.visibility = View.GONE
        }
    }

    private val acute = mapOf('a' to 'á', 'e' to 'é', 'i' to 'í', 'o' to 'ó', 'u' to 'ú')
    private val tilde = mapOf('a' to 'ã', 'o' to 'õ', 'n' to 'ñ')

    /** Variações ao segurar a tecla por 0,5 s. A primeira de cada lista é a mais usada em português. */
    private val altMap: Map<Char, List<String>> = mapOf(
        'a' to "ãáâàäåæā", 'e' to "éêèëēę", 'i' to "íîìïī", 'o' to "óõôòöøœō", 'u' to "úüùûū",
        'е' to "ё", 'ь' to "ъ", 'г' to "ґ",
        'ا' to "أإآءٱ", 'و' to "ؤ", 'ي' to "ئى", 'ى' to "ي", 'ه' to "ة", 'ة' to "ه", 'ك' to "گ", 'ب' to "پ", 'ف' to "ڤ",
        'c' to "çćčĉ", 'ç' to "ćč", 'n' to "ñńň", 's' to "šśßş", 'z' to "žźż", 'y' to "ýÿ",
        'l' to "łĺľ", 'd' to "ďđ", 'g' to "ğ", 'r' to "řŕ", 't' to "ťţ",
        '.' to ",?!':;\"…", '-' to "–—•", '?' to "¿", '!' to "¡", '\$' to "€£¥¢₹", '%' to "‰",
        '"' to "“”«»", '\'' to "‘’‚", '*' to "†‡★", '(' to "[{<", ')' to "]}>", '/' to "\\", '&' to "§",
        '#' to "№", '+' to "±", '=' to "≠≈"
    ).mapValues { (_, v) -> v.map { it.toString() } }

    private val trLocale = java.util.Locale("tr")
    /** Maiúsculas respeitando o turco (i → İ, ı → I); nos demais idiomas é o uppercase() de sempre. */
    private fun up(s: String): String = if (tr) s.uppercase(trLocale) else s.uppercase()
    private fun upperAlt(a: String): String { val u = up(a); return if (u.length == a.length) u else a }

    private fun alts(m: Map<Char, String>): Map<Char, List<String>> = m.mapValues { (_, v) -> v.map { it.toString() } }
    private val altFr = alts(mapOf(
        'a' to "àâáæäãåā", 'e' to "éèêëęēė", 'i' to "îïíìī", 'o' to "ôœöóòõøō", 'u' to "ùûüúū", 'c' to "çćč", 'y' to "ÿý"))
    private val altTr = alts(mapOf(          // ç ğ ı ö ş ü já são teclas; aqui ficam as variações com circunflexo
        'a' to "âäá", 'e' to "êë", 'i' to "îï", 'o' to "ôó", 'u' to "ûú", 'ü' to "û", 'c' to "ć", 's' to "š"))
    private val altVi = alts(mapOf(          // tons prontos, para quem não quer usar o Telex
        'a' to "ăâáàảãạ", 'e' to "êéèẻẽẹ", 'i' to "íìỉĩị", 'o' to "ôơóòỏõọ", 'u' to "ưúùủũụ", 'y' to "ýỳỷỹỵ", 'd' to "đ"))
    private fun altFor(c: Char): List<String>? = (when { fr -> altFr; tr -> altTr; vi -> altVi; else -> null })?.get(c) ?: altMap[c]

    private val clipListener = ClipboardManager.OnPrimaryClipChangedListener { captureClip() }
    private val prefsListener: () -> Unit = {
        sugg.setLanguage(prefs.language); sugg.precise = prefs.preciseCorrect
        runFx { sounds?.prepareAll(prefs.usedSoundTypes()) }
        val langChanged = prefs.language != shownLang
        shownLang = prefs.language
        if (langChanged) { viRaw.setLength(0); viFrozen = ""; viShown = "" }
        if (rootView != null) {
            // se o painel "Organizar a barra" está aberto, ele volta já aberto depois de reconstruir a interface
            val reopenPos = posPanel != null && activePanel === posPanel
            val posY = posScroll?.scrollY ?: 0
            setInputView(buildUi())
            if (langChanged) main.post { waveKeys(); toolbarRef?.let { tb -> if (prefs.fluid) tb.pop(0.94f, 0L, 520f, 0.5f) } }
            if (reopenPos) main.post { openPosition(instant = true, scrollY = posY) }
        }
    }

    /** Opacidade/desfoque do fundo mudaram: reaplica só o fundo (tempo real, sem reconstruir o teclado). */
    private val bgListener: () -> Unit = { applyBgLook() }

    private var videoBg: VideoBgView? = null

    /** Opacidade do fundo (corpo do teclado, imagem ou vídeo) + desfoque da janela. As teclas não mudam. */
    private fun applyBgLook() {
        val a = prefs.bgOpacity.coerceIn(0, 100)
        keyRoot?.background?.alpha = a * 255 / 100
        videoBg?.alpha = a / 100f
        videoBg?.setBlur(prefs.videoBlur)
        if (rootView != null) applyWindowColors()
    }

    // ---------- Ciclo de vida ----------

    override fun onCreate() {
        super.onCreate()
        composeOwner.onCreate()
        window?.window?.decorView?.let { composeOwner.attachTo(it) }
        prefs = Prefs.get(this)
        shownLang = prefs.language
        store = ClipboardStore.get(this)
        sugg = Suggestions(this)
        sysDict = SystemDictionary(this)
        recents = EmojiRecents(this)
        sugg.setLanguage(prefs.language); sugg.precise = prefs.preciseCorrect
        vibrator = getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
        clipboard?.addPrimaryClipChangedListener(clipListener)
        store.onChange = { clipState?.refresh() }
        sounds = SoundBank(this)
        runFx { sounds?.prepareAll(prefs.usedSoundTypes()) }
        instance = this
        prefs.addListener(prefsListener)
        prefs.addBgListener(bgListener)
    }

    override fun onDestroy() {
        addLangPw?.dismiss()
        speech?.release()
        translatorBar?.shutdown()
        translator.release()
        keyPreview?.release()
        prefs.removeListener(prefsListener)
        prefs.removeBgListener(bgListener)
        videoBg?.release()
        clipboard?.removePrimaryClipChangedListener(clipListener)
        store.onChange = null
        main.removeCallbacksAndMessages(null)
        if (instance === this) instance = null
        sounds?.release()
        sysDict.close()
        fxExec.shutdown(); suggExec.shutdown(); clipExec.shutdown()
        composeOwner.destroy()
        super.onDestroy()
    }

    // Evita o modo de tela cheia (extract UI) em paisagem: digitação mais rápida e sem layout extra.
    override fun onEvaluateFullscreenMode(): Boolean = false

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        if (rootView != null) setInputView(buildUi())
    }

    override fun onCreateInputView(): View { composeOwner.resume(); return buildUi() }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        word.clear(); prevWord = ""; pendingAccent = null; sentenceEnd = false
        viRaw.setLength(0); viFrozen = ""; viShown = ""
        caps = false
        computeFieldFlags(info)
        val cls = (info?.inputType ?: 0) and InputType.TYPE_MASK_CLASS
        val wantSymbols = cls == InputType.TYPE_CLASS_NUMBER || cls == InputType.TYPE_CLASS_PHONE
        shift = prefs.autoCaps && smart && !ar && info != null &&
            (currentInputConnection?.getCursorCapsMode(info.inputType) ?: 0) != 0
        if (rootView != null) {
            val changed = symbols != wantSymbols
            symbols = wantSymbols
            showPanel(keysContainer)
            if (changed) buildKeys() else refreshShiftUi()
            updateSuggestions()
        } else symbols = wantSymbols
        if (rootView != null) applyWindowColors()
        flushVoice()
        fx?.resume()
        captureClip(fromOpen = true)   // pega o que foi copiado enquanto o teclado estava fechado
        translatorBar?.onNewInput()
    }

    override fun onFinishInputView(finishingInput: Boolean) {
        super.onFinishInputView(finishingInput)
        altPopup?.cancel()
        clearAutofill()
        speech?.onKeyboardHidden()
        translatorBar?.shutdown()
        if (extraOpen) setExtraOpen(false, animate = false)
        if (keycapMode) setKeycapMode(false)
    }

    // A animação de entrada toca só quando a janela do teclado realmente aparece. Antes tocava a cada
    // troca de campo (com o teclado já aberto): as teclas sumiam e voltavam = "teclado piscando".
    override fun onWindowShown() {
        super.onWindowShown()
        main.removeCallbacks(trimRun)
        composeOwner.resume()
        fx?.resume()          // garante que as partículas/bichinhos voltam a andar quando o teclado reaparece
        videoBg?.resume()
        playEntrance()
    }

    override fun onWindowHidden() {
        super.onWindowHidden()
        main.removeCallbacks(trimRun); main.postDelayed(trimRun, 20_000L)
        altPopup?.cancel()
        keyPreview?.release()
        fx?.pause()
        videoBg?.pause()      // teclado fechado: vídeo parado, sem gastar bateria
        main.removeCallbacks(settlePanels)
        settleAll()
    }

    /** Se o cursor foi movido por fora (toque no texto, colar...), a palavra em andamento é descartada. */
    override fun onUpdateSelection(
        oldSelStart: Int, oldSelEnd: Int, newSelStart: Int, newSelEnd: Int,
        candidatesStart: Int, candidatesEnd: Int
    ) {
        super.onUpdateSelection(oldSelStart, oldSelEnd, newSelStart, newSelEnd, candidatesStart, candidatesEnd)
        translatorBar?.onTextChanged()
        if (word.isEmpty()) return
        val d = newSelStart - oldSelStart
        if (newSelStart != newSelEnd || d > 8 || d < -8) { word.setLength(0); updateSuggestions() }
    }

    private val trimRun = Runnable { trimMemory() }

    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        if (level >= android.content.ComponentCallbacks2.TRIM_MEMORY_BACKGROUND || level >= android.content.ComponentCallbacks2.TRIM_MEMORY_RUNNING_LOW) trimMemory()
    }

    /**
     * Teclado fechado há um tempo (ou o sistema pediu memória): solta o que só existe por conveniência.
     * Painéis (emoji, área de transferência, demo, posicionar), o motor do tradutor e dicionários de outros
     * idiomas são recriados sozinhos na próxima vez que forem usados. Nunca mexe no painel que está aberto.
     */
    private fun trimMemory() {
        if (isInputViewShown) return
        val h = host
        val keep = activePanel
        fun drop(v: View?): Boolean { if (v == null || v === keep) return false; h?.removeView(v); return true }
        if (drop(emojiPanel)) { emojiPanel = null; emojiState = null }
        if (drop(clipPanel)) { clipPanel = null; clipState = null }
        if (drop(demoPanel)) demoPanel = null
        if (drop(posPanel)) { posPanel = null; posList = null; posScroll = null }
        try { translator.release() } catch (_: Exception) { }
        OpenDictionary.keepOnly(prefs.language)
        keyPreview?.release()
    }

    /** Deixa tudo no estado final (opaco, sem deslocamento): nenhuma animação interrompida pode travar a tela. */
    private fun settleAll() {
        bar?.settle(); host?.settle()
        toolbarRef?.let { tb -> for (i in 0 until tb.childCount) { val c = tb.getChildAt(i); if (c !== expandIcon) c.settle() } }
        val kc = keysContainer ?: return
        kc.settle()
        for (i in 0 until kc.childCount) kc.getChildAt(i).settle()
    }

    /**
     * Abertura do teclado, em quatro tempos (tudo com mola):
     *  1. os dois selos giram e crescem das pontas para o centro;
     *  2. a pílula desce do topo e os ícones dentro dela pulam em sequência;
     *  3. as fileiras sobem uma a uma, da barra de espaço para cima, com um leve ricochete;
     *  4. cada fileira entra com fade, escala e um deslocamento curto (12 dp) para o toque continuar preciso.
     */
    private fun playEntrance() {
        if (rootView == null) return
        settleAll()
        if (!prefs.fluid) return
        bar?.springFadeIn(0L, 420f)
        toolbarRef?.let { tb ->
            for (i in 0 until tb.childCount) {
                val c = tb.getChildAt(i)
                if (c is ImageView) {
                    val rest = if (c === expandIcon && extraOpen) 180f else 0f
                    c.rotation = rest + (if (i == 0) -140f else 140f)
                    c.springTo(DynamicAnimation.ROTATION, rest, 170f, 0.6f)
                    c.pop(0.15f, 30L, 240f, 0.5f)
                } else {
                    c.springIn(fromY = -10f, fromScale = 0.9f, delay = 70L, stiffness = 320f, damping = 0.68f)
                }
            }
            toolbarInner?.let { ic ->
                for (i in 0 until ic.childCount) { val c = ic.getChildAt(i); if (c is ImageView) c.pop(0.3f, 190L + 55L * i, 520f, 0.42f) }
            }
        }
        val kc = keysContainer ?: return
        val n = kc.childCount
        for (i in 0 until n) {
            kc.getChildAt(i).springIn(fromY = 12f, fromScale = 0.965f, delay = 110L + 42L * (n - 1 - i), stiffness = 340f, damping = 0.66f)
        }
    }

    private fun computeFieldFlags(info: EditorInfo?) {
        val t = info?.inputType ?: 0
        val cls = t and InputType.TYPE_MASK_CLASS
        val v = t and InputType.TYPE_MASK_VARIATION
        isPassword = (cls == InputType.TYPE_CLASS_TEXT && (v == InputType.TYPE_TEXT_VARIATION_PASSWORD ||
            v == InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD || v == InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD)) ||
            (cls == InputType.TYPE_CLASS_NUMBER && v == InputType.TYPE_NUMBER_VARIATION_PASSWORD)
        composeOk = cls == InputType.TYPE_CLASS_TEXT && !isPassword &&
            v != InputType.TYPE_TEXT_VARIATION_URI && v != InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS &&
            v != InputType.TYPE_TEXT_VARIATION_WEB_EMAIL_ADDRESS
        smart = cls == InputType.TYPE_CLASS_TEXT && !isPassword &&
            v != InputType.TYPE_TEXT_VARIATION_URI && v != InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS &&
            v != InputType.TYPE_TEXT_VARIATION_WEB_EMAIL_ADDRESS &&
            (t and InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS) == 0
    }

    // ---------- Construção da interface ----------

    private fun dpi(v: Int) = (v * resources.displayMetrics.density + 0.5f).toInt()
    /** dp escalado pelo tamanho do teclado escolhido */
    private fun sdp(v: Int) = (v * resources.displayMetrics.density * sc + 0.5f).toInt()

    /**
     * Raiz da janela do teclado = [FrameLayout] com (1) o teclado de sempre e (2) um overlay Compose de
     * tamanho total que NÃO recebe toque (tudo passa às teclas). O overlay está vazio por enquanto.
     */
    private fun buildUi(): View {
        val keyboard = buildKeyboardRoot()
        videoBg?.release()
        videoBg = pal.image?.takeIf { prefs.videoBg && VideoBg.file(this).exists() }?.let { img ->
            VideoBgView(ui, VideoBg.file(this), ImageBgDrawable(img, 0f, prefs.imagePos / 100f, 0f), dpi(prefs.boardRadius).toFloat(), prefs.imagePos / 100f)
        }
        fx?.pause()
        fx = if (prefs.scene > 0 || prefs.petOn.any { it })
            FxOverlay(ui, prefs.scene, dpi(prefs.boardRadius).toFloat(), prefs, pal) { activePanel === keysContainer }
        else null
        videoBg?.let { if (isInputViewShown) it.resume() }
        applyBgLook()
        val sw = resources.displayMetrics.widthPixels
        val sh = resources.displayMetrics.heightPixels
        val floating = prefs.floating
        val oh = if (floating) 0 else prefs.oneHand
        val kbW = if (floating) (sw * 0.92f * prefs.floatScale.coerceIn(60, 110) / 100f).toInt().coerceAtMost(sw) else if (oh != 0) (sw * 0.80f).toInt() else FrameLayout.LayoutParams.MATCH_PARENT
        val kbG = Gravity.BOTTOM or when (oh) { 1 -> Gravity.START; 2 -> Gravity.END; else -> Gravity.CENTER_HORIZONTAL }
        floatFrame = null; floatBox = null; floatDragging = false
        return FrameLayout(ui).apply {
            // atrás das teclas, com a MESMA altura do teclado (não da tela toda), colado embaixo
            if (!floating) videoBg?.let { vb ->
                addView(vb, FrameLayout.LayoutParams(kbW, 0, kbG))
                keyboard.addOnLayoutChangeListener { _, _, top, _, bottom, _, _, _, _ ->
                    val h = bottom - top
                    if (h > 0 && vb.layoutParams.height != h) vb.post {
                        vb.layoutParams = (vb.layoutParams as FrameLayout.LayoutParams).apply { height = h }
                    }
                }
            }
            if (floating) {
                // Flutuante: a janela fica alta e transparente; só o teclado (e a alça) recebe toque (ver onComputeInsets).
                minimumHeight = (sh * 0.7f).toInt()
                // cantos bem arredondados nos quatro lados (recorta fundo, imagem e teclas) + sombra suave
                val fr = dpi(maxOf(prefs.boardRadius, 22)).toFloat()
                val box = LinearLayout(ui).apply {
                    orientation = LinearLayout.VERTICAL
                    outlineProvider = object : android.view.ViewOutlineProvider() {
                        override fun getOutline(v: View, o: android.graphics.Outline) {
                            o.setRoundRect(0, 0, v.width, v.height, fr)
                            o.alpha = 0.28f * prefs.bgOpacity.coerceIn(0, 100) / 100f
                        }
                    }
                    clipToOutline = true
                    elevation = dpi(8).toFloat()
                }
                box.addView(buildFloatHandle(box, fr), LinearLayout.LayoutParams(-1, dpi(30)))
                box.addView(keyboard, LinearLayout.LayoutParams(-1, -2))
                addView(box, FrameLayout.LayoutParams(kbW, -2, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL))
                floatFrame = this; floatBox = box
                restoreFloatPos(box, this)
                if (prefs.fluid) {       // ao redimensionar (− / +) o teclado "assenta" com mola
                    box.scaleX = 0.95f; box.scaleY = 0.95f
                    box.springTo(DynamicAnimation.SCALE_X, 1f, 500f, 0.7f)
                    box.springTo(DynamicAnimation.SCALE_Y, 1f, 500f, 0.7f)
                }
            } else {
                if (oh != 0) addView(buildOneHandColumn(oh), FrameLayout.LayoutParams(sw - kbW, -1, Gravity.BOTTOM or (if (oh == 1) Gravity.END else Gravity.START)))
                addView(keyboard, FrameLayout.LayoutParams(kbW, -2, kbG))   // sempre colado embaixo
                if (oh != 0 && prefs.fluid) keyboard.springIn(fromY = 10f, fromScale = 0.96f, stiffness = 420f, damping = 0.72f)
                fx?.let { addView(it, FrameLayout.LayoutParams(kbW, -1, kbG)) }   // por cima das teclas, abaixo da camada Compose
            }
            addView(ComposeLayer.createOverlay(ui, composeOwner, paletteColorScheme(pal), prefs.fluid),
                FrameLayout.LayoutParams(-1, -1))
        }
    }

    // ---------- Modo uma mão e teclado flutuante ----------

    /** Faixa ao lado do teclado reduzido: voltar para a largura total e trocar de lado. */
    private fun buildOneHandColumn(oh: Int): View = LinearLayout(ui).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER
        val r = dpi(prefs.boardRadius).toFloat()
        background = GradientDrawable().apply {
            setColor(ColorUtils.setAlphaComponent(pal.surface, 235))
            cornerRadii = floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f)
        }
        val ink = pal.onSurface
        val full = iconButton(ui, R.drawable.ic_fullwidth, ink, "Teclado inteiro".tr(), 40) { prefs.putInt("oneHand", 0) }
        val swap = iconButton(ui, R.drawable.ic_swap, ink, "Trocar de lado".tr(), 40) { prefs.putInt("oneHand", if (oh == 1) 2 else 1) }
        (swap.layoutParams as LinearLayout.LayoutParams).topMargin = dpi(14)
        addView(full); addView(swap)
        if (prefs.fluid) { full.pop(0.6f, 80L, 650f, 0.45f); swap.pop(0.6f, 140L, 650f, 0.45f) }
    }

    /**
     * Alça do teclado flutuante: no meio, a pílula de arrastar (levanta com mola e acompanha o dedo);
     * nas pontas, os botões − e + que diminuem/aumentam o teclado em passos de 5%.
     */
    private fun buildFloatHandle(box: View, rr: Float): View {
        val surface = ColorUtils.setAlphaComponent(pal.surface, 245)
        val ink = ColorUtils.setAlphaComponent(pal.onSurface, 110)
        val bgP = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = surface }
        val pillP = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = ink }
        val glyphP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = ColorUtils.setAlphaComponent(pal.onSurface, 190)
            style = Paint.Style.STROKE; strokeWidth = dpi(2).toFloat(); strokeCap = Paint.Cap.ROUND
        }
        val rect = RectF()
        val zone = dpi(56)            // área de toque de cada botão (− à esquerda, + à direita)
        val handle = object : View(ui) {
            override fun onDraw(c: Canvas) {
                rect.set(0f, 0f, width.toFloat(), height + rr)        // o fundo continua por baixo, só o topo é arredondado
                c.drawRoundRect(rect, rr, rr, bgP)
                val w = dpi(44).toFloat(); val h = dpi(4).toFloat()
                rect.set((width - w) / 2f, (height - h) / 2f, (width + w) / 2f, (height + h) / 2f)
                c.drawRoundRect(rect, h / 2f, h / 2f, pillP)
                val cy = height / 2f; val g = dpi(6).toFloat()
                val lx = zone / 2f; val rx = width - zone / 2f
                c.drawLine(lx - g, cy, lx + g, cy, glyphP)             // −
                c.drawLine(rx - g, cy, rx + g, cy, glyphP)             // +
                c.drawLine(rx, cy - g, rx, cy + g, glyphP)
            }
        }
        var lx = 0f; var ly = 0f
        var btn = 0                   // -1 = botão −, 1 = botão +, 0 = arrastando
        handle.setOnTouchListener { _, e ->
            val frame = box.parent as? View
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    btn = when { e.x < zone -> -1; e.x > handle.width - zone -> 1; else -> 0 }
                    handle.performHapticFeedback(android.view.HapticFeedbackConstants.KEYBOARD_TAP)
                    if (btn == 0) {
                        floatDragging = true; lx = e.rawX; ly = e.rawY
                        frame?.requestLayout()
                        box.springTo(DynamicAnimation.SCALE_X, 1.025f, 600f, 0.6f)
                        box.springTo(DynamicAnimation.SCALE_Y, 1.025f, 600f, 0.6f)
                    }
                }
                MotionEvent.ACTION_MOVE -> if (btn == 0 && frame != null) {
                    val maxX = ((frame.width - box.width) / 2f).coerceAtLeast(0f)
                    val minY = -((frame.height - box.height).toFloat()).coerceAtLeast(0f)
                    box.translationX = (box.translationX + e.rawX - lx).coerceIn(-maxX, maxX)
                    box.translationY = (box.translationY + e.rawY - ly).coerceIn(minY, 0f)
                    lx = e.rawX; ly = e.rawY
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (btn != 0) {
                        val inZone = if (btn < 0) e.x < zone else e.x > handle.width - zone
                        if (e.actionMasked == MotionEvent.ACTION_UP && inZone) {
                            val cur = prefs.floatScale
                            val next = (cur + btn * 5).coerceIn(60, 110)
                            if (next != cur) prefs.putInt("floatScale", next)   // reconstrói o teclado no novo tamanho
                        }
                        btn = 0
                    } else {
                        floatDragging = false
                        box.springTo(DynamicAnimation.SCALE_X, 1f, 500f, 0.7f)
                        box.springTo(DynamicAnimation.SCALE_Y, 1f, 500f, 0.7f)
                        try {
                            getSharedPreferences("float_pos", Context.MODE_PRIVATE).edit()
                                .putFloat("x", box.translationX).putFloat("y", box.translationY).apply()
                        } catch (_: Exception) { }
                        frame?.requestLayout()          // o sistema recalcula a área que recebe toque
                    }
                }
            }
            true
        }
        return handle
    }

    private fun restoreFloatPos(box: View, frame: View) {
        val sp = try { getSharedPreferences("float_pos", Context.MODE_PRIVATE) } catch (_: Exception) { null }
        box.translationX = sp?.getFloat("x", 0f) ?: 0f
        box.translationY = sp?.getFloat("y", -dpi(24).toFloat()) ?: -dpi(24).toFloat()
        frame.post {          // com o tamanho já conhecido, garante que ficou dentro da tela
            val maxX = ((frame.width - box.width) / 2f).coerceAtLeast(0f)
            val minY = -((frame.height - box.height).toFloat()).coerceAtLeast(0f)
            box.translationX = box.translationX.coerceIn(-maxX, maxX)
            box.translationY = box.translationY.coerceIn(minY, 0f)
            frame.requestLayout()
        }
    }

    /** Flutuante: o app não é empurrado/redimensionado e só o teclado (e a alça) recebe toques; o resto da janela é transparente. */
    override fun onComputeInsets(outInsets: InputMethodService.Insets) {
        super.onComputeInsets(outInsets)
        val frame = floatFrame ?: return
        val box = floatBox ?: return
        if (!prefs.floating || frame.height <= 0 || !isInputViewShown) return
        val fl = IntArray(2); frame.getLocationInWindow(fl)
        val bottom = fl[1] + frame.height
        outInsets.contentTopInsets = bottom
        outInsets.visibleTopInsets = bottom
        outInsets.touchableInsets = InputMethodService.Insets.TOUCHABLE_INSETS_REGION
        if (floatDragging) outInsets.touchableRegion.set(fl[0], fl[1], fl[0] + frame.width, bottom)
        else {
            val bl = IntArray(2); box.getLocationInWindow(bl)
            outInsets.touchableRegion.set(bl[0], bl[1], bl[0] + box.width, bl[1] + box.height)
        }
    }

    // ---------- Digitação por deslize ----------

    private fun glideLetterAt(root: View, x: Float, y: Float): Char? {
        for (lk in letterKeys) {
            val k = lk.view
            if (k.width == 0 || k.visibility != View.VISIBLE) continue
            glideRect.set(0, 0, k.width, k.height)
            (root as ViewGroup).offsetDescendantRectToMyCoords(k, glideRect)
            if (x >= glideRect.left && x <= glideRect.right && y >= glideRect.top && y <= glideRect.bottom) return lk.ch.lowercaseChar()
        }
        return null
    }

    private fun doGlide(path: String) {
        val seq = ++glideSeq
        runSugg {
            val list = sugg.glide(path)
            main.post { if (seq == glideSeq && list.isNotEmpty()) applyGlideWord(list) }
        }
    }

    private fun applyGlideWord(list: List<String>) {
        val ic = currentInputConnection ?: return
        finishWord()
        val before = ic.getTextBeforeCursor(1, 0)?.toString().orEmpty()
        if (before.isNotEmpty() && !before.last().isWhitespace() && before.last() !in "([{\"'“«¿¡") commit(" ")
        val styled = list.map { w ->
            if (caps) up(w) else if (shift && w.isNotEmpty()) up(w.substring(0, 1)) + w.substring(1) else w
        }
        val best = styled[0]
        commit("$best ")
        glideLast = "$best "
        glideAlts = styled
        word.setLength(0)
        prevWord = best
        sentenceEnd = false
        if (shift && !caps) { shift = false; refreshShiftUi() }
        feedback(true, SoundBank.Slot.SPACE)
        setSuggestionTexts(styled.take(3))          // as outras opções ficam na barra: toque para trocar a palavra
    }

    // ---------- Autofill inline (Android 11+) ----------

    @RequiresApi(Build.VERSION_CODES.R)
    private fun autofillStyle(): Bundle = try {
        val chip = androidx.autofill.inline.common.ViewStyle.Builder().setBackgroundColor(pal.keySpecial).build()
        val title = androidx.autofill.inline.common.TextViewStyle.Builder().setTextColor(pal.onSpecial).setTextSize(14f).build()
        val sub = androidx.autofill.inline.common.TextViewStyle.Builder().setTextColor(ColorUtils.setAlphaComponent(pal.onSpecial, 170)).setTextSize(11f).build()
        val style = androidx.autofill.inline.v1.InlineSuggestionUi.newStyleBuilder()
            .setChipStyle(chip).setSingleIconChipStyle(chip).setTitleStyle(title).setSubtitleStyle(sub).build()
        androidx.autofill.inline.UiVersions.newStylesBuilder().addStyle(style).build()
    } catch (_: Throwable) { Bundle() }

    @RequiresApi(Build.VERSION_CODES.R)
    override fun onCreateInlineSuggestionsRequest(uiExtras: Bundle): android.view.inputmethod.InlineSuggestionsRequest? {
        if (!prefs.autofill) return null
        val d = resources.displayMetrics.density
        val min = Size((72 * d).toInt(), (30 * d).toInt())
        val max = Size((resources.displayMetrics.widthPixels * 0.7f).toInt(), (40 * d).toInt())
        val spec = android.widget.inline.InlinePresentationSpec.Builder(min, max).setStyle(autofillStyle()).build()
        return android.view.inputmethod.InlineSuggestionsRequest.Builder(listOf(spec)).setMaxSuggestionCount(6).build()
    }

    @RequiresApi(Build.VERSION_CODES.R)
    override fun onInlineSuggestionsResponse(response: android.view.inputmethod.InlineSuggestionsResponse): Boolean {
        val list = response.inlineSuggestions
        val row = afRow
        if (!prefs.autofill || row == null || list.isEmpty()) { clearAutofill(); return false }
        val token = ++afSeq
        row.removeAllViews()
        val exec = ContextCompat.getMainExecutor(this)
        val size = Size(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        for (sug in list) {
            sug.inflate(this, size, exec) { v ->
                if (v == null || token != afSeq) return@inflate
                row.addView(v, LinearLayout.LayoutParams(-2, -2).apply { setMargins(dpi(3), 0, dpi(3), 0) })
                showAutofill(true)
            }
        }
        return true
    }

    private fun clearAutofill() {
        afSeq++
        afRow?.removeAllViews()
        showAutofill(false)
    }

    /** Mostra/esconde a faixa de autofill sobre a pílula, com mola. */
    private fun showAutofill(on: Boolean) {
        val s = afScroll ?: return
        if (on == afShown) return
        afShown = on
        s.animate().cancel()
        if (on) {
            s.visibility = View.VISIBLE
            if (prefs.fluid) { s.translationY = dpi(10).toFloat(); s.springTo(DynamicAnimation.TRANSLATION_Y, 0f, 520f, 0.7f) }
            s.animate().alpha(1f).setDuration(140).start()
        } else {
            s.animate().alpha(0f).setDuration(120).withEndAction { if (!afShown) s.visibility = View.GONE }.start()
        }
    }

    private fun buildKeyboardRoot(): LinearLayout {
        // O modo escuro/claro é decidido por Palette.isDark (explícito), não pelo tema do contexto.
        ui = ContextThemeWrapper(this, R.style.Theme_Keyboard)
        pal = Palette.build(this, prefs)
        // flutuante: o tamanho dele (botões − / + da alça) multiplica o tamanho geral
        sc = prefs.keyboardScale.coerceIn(70, 130) / 100f * (if (prefs.floating) prefs.floatScale.coerceIn(60, 110) / 100f else 1f)
        textPx = 20f * resources.displayMetrics.density * prefs.textScale / 100f * sc

        // painéis são recriados com a nova paleta
        clipPanel = null; clipState = null; emojiPanel = null; emojiState = null; demoPanel = null
        posPanel = null; posList = null; posScroll = null
        cursorPad = null
        suggViews.clear(); suggDividers.clear()
        extraOpen = false
        stripShown = false
        main.removeCallbacks(hideStrip)
        altPopup?.cancel()
        altPopup = AltPopup(ui, pal, dpi(prefs.keyRadius).toFloat(), prefs.fluid) { prefs.altShape }
        keyPreview?.release()
        keyPreview = if (prefs.keyPreview) KeyPreview(ui, pal, prefs) else null

        val topR = dpi(prefs.boardRadius).toFloat()
        val root = KeyRoot(ui).apply {
            if (android.os.Build.VERSION.SDK_INT >= 29) isForceDarkAllowed = false
            resolver = { x, y -> nearestKey(this, x, y) }
            glideEnabled = { prefs.glide && smart && !symbols && !keycapMode && pendingAccent == null && !viOn() && activePanel === keysContainer && letterKeys.isNotEmpty() }
            glideHit = { x, y -> glideLetterAt(this, x, y) }
            glideColor = pal.keyAccent
            onGlide = { s -> doGlide(s) }
            editHit = { x, y -> editKeyAt(this, x, y) }
            editLetter = { k -> letterKeys.any { it.view === k } }
            onSwap = { a, b ->
                val ca = letterKeys.firstOrNull { it.view === a }?.ch
                val cb = letterKeys.firstOrNull { it.view === b }?.ch
                if (ca != null && cb != null) swapLetters(ca, cb)
            }
            ghostBg = pal.keyAccent; ghostFg = pal.onAccent
            editMode = keycapMode
            orientation = LinearLayout.VERTICAL
            setPadding(dpi(6), dpi(4), dpi(6), dpi(8))
            // corpo do teclado com os cantos de cima arredondados
            val img = pal.image
            // Cenário animado e bichinhos: ficam no FxOverlay, por cima do teclado (ver buildUi)
            background = if (img != null && prefs.videoBg && VideoBg.file(ui).exists())
                // com vídeo: o vídeo fica atrás (ver buildUi); aqui só o escurecimento
                GradientDrawable().apply {
                    setColor(Color.argb((prefs.imageDim * 255 / 100).coerceIn(0, 255), 0, 0, 0))
                    cornerRadii = floatArrayOf(topR, topR, topR, topR, 0f, 0f, 0f, 0f)
                }
            else if (img != null)
                ColorDrawable(Color.TRANSPARENT)      // v75.2: a imagem é desenhada pela janela (ver applyWindowColors)
            else if (prefs.liquidGlass) LiquidBackdrop(pal.surface, pal.keyAccent, topR)
            else com.example.materialkeyboard.keyscafe.ThemeGradients.surface(prefs, topR) ?: GradientDrawable().apply {
                setColor(if (prefs.keyStyle == 3) androidx.core.graphics.ColorUtils.setAlphaComponent(pal.surface, if (prefs.keyDepth > 0) 90 else 170) else pal.surface)
                cornerRadii = floatArrayOf(topR, topR, topR, topR, 0f, 0f, 0f, 0f)
            }
            // se o sistema desenhar a barra de navegação sobre o teclado, o fundo continua até embaixo
            ViewCompat.setOnApplyWindowInsetsListener(this) { v, insets ->
                // flutuante: não está colado na borda, então não reserva espaço para a barra de navegação
                val nav = if (prefs.floating) 0 else insets.getInsets(WindowInsetsCompat.Type.navigationBars()).bottom
                v.setPadding(dpi(6), dpi(4), dpi(6), dpi(8) + nav)
                insets
            }
        }
        // UMA barra só (antes eram duas: ferramentas + faixa de sugestões quase sempre vazia, que
        // ocupava altura à toa). As sugestões aparecem no lugar dos ícones, só quando existem.
        val barFrame = FrameLayout(ui).apply { layoutParams = LinearLayout.LayoutParams(-1, sdp(44)) }
        // Barra fixa: [seta] [pílula: ícones OU sugestões] [microfone]. Só o miolo da pílula troca.
        barFrame.addView(buildToolbar(), FrameLayout.LayoutParams(-1, -1))
        root.addView(barFrame)
        bar = barFrame
        extraRow = buildExtraRow()
        root.addView(extraRow)
        translatorBar?.shutdown()
        translatorBar = TranslatorBar(ui, pal, TranslatorPrefs.get(this), translator,
            compact = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE,
            read = {
                val ic = currentInputConnection
                Triple(ic?.getTextBeforeCursor(5000, 0)?.toString().orEmpty(),
                    ic?.getSelectedText(0)?.toString().orEmpty(),
                    ic?.getTextAfterCursor(5000, 0)?.toString().orEmpty())
            },
            write = { text, whole ->
                currentInputConnection?.let { ic ->
                    ic.beginBatchEdit()
                    if (whole) ic.deleteSurroundingText(100000, 100000)
                    ic.commitText(text, 1)      // sem seleção ativa, só insere; com seleção, substitui
                    ic.endBatchEdit()
                }
                resetWord()
            },
            canRead = { !isPassword }
        ).also { root.addView(it) }

        editBar = buildEditBar().also { root.addView(it) }
        keyRoot = root
        val rows = 4 + if (prefs.numberRow) 1 else 0
        val landscape = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
        val keyH = (sdp(prefs.keyHeight) * (if (landscape) 0.8f else 1f)).toInt()
        keysContainer = LinearLayout(ui).apply { orientation = LinearLayout.VERTICAL }
        host = FrameLayout(ui).apply {
            addView(keysContainer, FrameLayout.LayoutParams(-1, -1))
            layoutParams = LinearLayout.LayoutParams(-1, keyH * rows)
        }
        root.addView(host)
        activePanel = keysContainer
        rowHeightPx = keyH
        buildKeys()
        rootView = root
        applyWindowColors()
        updateSuggestions()
        return root
    }

    /**
     * Toque fora de qualquer tecla (fresta, borda, espaço abaixo da última fileira): devolve a tecla
     * mais próxima do ponto (x, y), dado em coordenadas da raiz. Só vale na área das teclas.
     */
    private fun nearestKey(root: View, x: Float, y: Float): KeyView? {
        if (!prefs.smartTouch) return null
        val kc = keysContainer ?: return null
        val h = host ?: return null
        if (activePanel !== kc || kc.visibility != View.VISIBLE || y < h.top) return null
        var best: KeyView? = null
        var bestD = Float.MAX_VALUE
        val r = Rect()
        for (ri in 0 until kc.childCount) {
            val rowView = kc.getChildAt(ri) as? ViewGroup ?: continue
            for (ci in 0 until rowView.childCount) {
                val k = rowView.getChildAt(ci) as? KeyView ?: continue
                r.set(0, 0, k.width, k.height)
                (root as ViewGroup).offsetDescendantRectToMyCoords(k, r)
                val dx = maxOf(r.left - x, x - r.right, 0f)
                val dy = maxOf(r.top - y, y - r.bottom, 0f)
                val d = dx * dx + dy * dy
                if (d < bestD) { bestD = d; best = k }
            }
        }
        return best
    }

    /** Barra de navegação (e o fundo da janela) na mesma cor do teclado, com ícones claros/escuros certos. */
    private fun applyWindowColors() {
        val w = window?.window ?: return
        try {
            val bgA = prefs.bgOpacity.coerceIn(0, 100)
            val bgImg = if (prefs.themeImage) pal.image else null
            // v75.2: com imagem, a IMAGEM é o fundo da JANELA inteira. Assim ela também cobre a faixa dos botões
            // (voltar / trocar teclado) que o Android desenha abaixo da nossa view, e acaba a cor diferente embaixo.
            if (bgImg != null) {
                w.setBackgroundDrawable(prefs.imageBg(bgImg, dpi(prefs.boardRadius).toFloat()).also { it.alpha = bgA * 255 / 100 })
            } else w.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))   // deixa os cantos arredondados aparecerem
            // v75.1: com imagem (ou vídeo) de fundo a barra de navegação fica INVISÍVEL: a imagem do teclado segue até o
            // fim da tela. Antes ela ficava com uma cor chapada, que aparecia clara de um lado e escura do outro.
            val imageOn = prefs.themeImage && pal.image != null
            w.navigationBarColor = if (imageOn || (!prefs.liquidGlass && prefs.keyStyle == 3 && prefs.keyDepth > 0)) Color.TRANSPARENT
                else if (bgA < 100) ColorUtils.setAlphaComponent(pal.surface, bgA * 255 / 100) else pal.surface
            if (Build.VERSION.SDK_INT >= 28) w.navigationBarDividerColor = Color.TRANSPARENT
            if (Build.VERSION.SDK_INT >= 29) w.isNavigationBarContrastEnforced = false
            WindowCompat.getInsetsController(w, w.decorView).isAppearanceLightNavigationBars = !pal.isDark
            if (Build.VERSION.SDK_INT >= 31) w.setBackgroundBlurRadius(if (bgImg != null && bgA >= 100) 0 else maxOf(if (prefs.activeKeyStyle == 3) prefs.blurAmount else 0, prefs.bgBlur).let { (it * 1.5f).toInt() })
        } catch (_: Exception) { }
    }

    private var rowHeightPx = 0
    /** Partículas do cenário + bichinhos (null quando nenhum está ligado). */
    private var fx: FxOverlay? = null

    /** Ícone com fundo tonal arredondado (accent = destaque, como o microfone do Expressive Keyboard). */
    private fun tonalIcon(res: Int, desc: String, accent: Boolean = false, onClick: () -> Unit): ImageView {
        val tint = if (accent) pal.onAccent else pal.onSurface
        val fill = if (accent) pal.keyAccent else ColorUtils.setAlphaComponent(pal.onSurface, 28)
        return iconButton(ui, res, tint, desc, 38, onClick).apply {
            background = roundedBg(fill, dpi(14).toFloat(), tint)
            (layoutParams as LinearLayout.LayoutParams).setMargins(dpi(3), 0, dpi(3), 0)
        }
    }

    /** Botão redondo da barra: o formato vem das configurações/tema ([BarShapes]; 0 = cookie, o padrão). accent = destaque. */
    private fun cookieIcon(res: Int, desc: String, accent: Boolean = false, shape: Int = 0, onClick: () -> Unit): ImageView {
        val tint = if (accent) pal.onAccent else pal.onSpecial
        val fill = if (accent) pal.keyAccent else pal.keySpecial
        return iconButton(ui, res, tint, desc, 42, onClick).apply {
            if (accent) setOnClickListener { wiggle(18f); pop(0.82f, 0L, 650f, 0.42f); onClick() }   // microfone: balança e pulsa
            background = BadgeDrawable(fill, shape.coerceIn(0, BarShapes.NAMES.size - 1))
            (layoutParams as LinearLayout.LayoutParams).setMargins(dpi(3), 0, dpi(3), 0)
        }
    }

    /** Cor dos ícones e das sugestões na faixa: sem o fundo da pílula (barStyle 1) eles ficam sobre o fundo do teclado. */
    private fun barInk(): Int = if (prefs.barStyle == 1) pal.onSurface else pal.onSpecial

    /** Barra: [cookie: seta] [pílula: emoji · área de transferência · tradutor · configurações, ou as sugestões] [cookie: voz]. */
    private fun buildToolbar(): LinearLayout = LinearLayout(ui).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        layoutParams = LinearLayout.LayoutParams(-1, sdp(46))
        setPadding(dpi(6), 0, dpi(6), 0)
        toolbarRef = this
        val more = cookieIcon(R.drawable.ic_expand, "Mais ferramentas".tr(), shape = prefs.toolShape) { setExtraOpen(!extraOpen, true) }
        expandIcon = more
        addView(more)

        // A pílula guarda os ícones; quando há sugestões o fundo dela some e cada sugestão vira uma pílula própria (v75.1)
        val pillR = when (prefs.barStyle) { 1 -> 0f; 2 -> dpi(10).toFloat(); else -> dpi(40).toFloat() }
        val pill = FrameLayout(ui).apply {
            layoutParams = LinearLayout.LayoutParams(0, dpi(40), 1f).apply { setMargins(dpi(4), 0, dpi(4), 0) }
            clipChildren = false; clipToPadding = false
        }
        // barStyle: 0 pílula · 1 reta, sem fundo (como o Gboard) · 2 retangular
        val pillBg = View(ui).apply {
            background = GradientDrawable().apply {
                cornerRadius = pillR
                setColor(if (prefs.barStyle == 1) Color.TRANSPARENT else pal.keySpecial)
            }
        }
        pillBgView = pillBg
        pill.addView(pillBg, FrameLayout.LayoutParams(-1, -1))
        // Ícones da barra: ordem e quais aparecem vêm de "Organizar a barra" (Prefs.barItems).
        // Ficam dentro de um HorizontalScrollView: se não couberem, a barra desliza para os lados.
        val inner = LinearLayout(ui).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dpi(10), 0, dpi(10), 0)
            barOrder().forEachIndexed { i, bid ->
                if (i > 0) addView(View(ui).apply { layoutParams = LinearLayout.LayoutParams(dpi(10), 1, 1f) })
                val btn = iconButton(ui, barIcon(bid), barInk(), barTitle(bid), 36) { }
                btn.setOnClickListener { if (prefs.fluid) btn.wiggle(14f); runBarItem(bid) }
                addView(btn)
            }
        }
        toolbarInner = inner
        val icons = HorizontalScrollView(ui).apply {
            isHorizontalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
            isFillViewport = true
            addView(inner, FrameLayout.LayoutParams(-2, -1))
            if (prefs.barSide == 1) post { fullScroll(View.FOCUS_RIGHT) }   // opção: começa pela direita
        }
        toolbar = icons
        // só os ícones são recortados no formato da pílula (as sugestões ficam livres, com mola)
        icons.outlineProvider = object : android.view.ViewOutlineProvider() {
            override fun getOutline(view: View, outline: android.graphics.Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, minOf(pillR, view.height / 2f))
            }
        }
        icons.clipToOutline = true
        pill.addView(icons, FrameLayout.LayoutParams(-1, -1))
        val words = buildStrip()
        strip = words
        pill.addView(words, FrameLayout.LayoutParams(-1, -1))
        // Autofill (senhas, endereços...): cobre os ícones/sugestões enquanto houver itens do serviço de preenchimento
        val afInner = LinearLayout(ui).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dpi(6), 0, dpi(6), 0) }
        val afS = HorizontalScrollView(ui).apply {
            isHorizontalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
            visibility = View.GONE; alpha = 0f
            background = ColorDrawable(if (prefs.barStyle == 1) pal.surface else pal.keySpecial)
            addView(afInner, FrameLayout.LayoutParams(-2, -1))
        }
        afRow = afInner; afScroll = afS; afShown = false
        pill.addView(afS, FrameLayout.LayoutParams(-1, -1))
        addView(pill)

        micBtn = cookieIcon(R.drawable.ic_mic, "Digitação por voz".tr(), accent = true, shape = prefs.micShape) { startVoice() }
        addView(micBtn)
    }

    /** Sugestões: cada palavra é uma pílula separada (a primeira, destacada), com mola ao aparecer e ao tocar. */
    private fun buildStrip(): LinearLayout = LinearLayout(ui).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        clipChildren = false; clipToPadding = false
        visibility = View.INVISIBLE
        alpha = 0f
        for (i in 0 until 3) {
            val tv = TextView(ui).apply {
                gravity = Gravity.CENTER
                textSize = 16f * sc
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
                setPadding(dpi(8), 0, dpi(8), 0)
                typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
                layoutParams = LinearLayout.LayoutParams(0, -1, 1f).apply { setMargins(dpi(3), dpi(1), dpi(3), dpi(1)) }
                background = roundedBg(pal.keySpecial, dpi(20).toFloat(), pal.onSpecial)
                setTextColor(pal.onSpecial)
                // toque: afunda com mola e volta com ricochete (Material You)
                setOnTouchListener { v, e ->
                    when (e.actionMasked) {
                        MotionEvent.ACTION_DOWN -> if (prefs.fluid) { v.springTo(DynamicAnimation.SCALE_X, 0.9f, 900f, 0.8f); v.springTo(DynamicAnimation.SCALE_Y, 0.9f, 900f, 0.8f) }
                        MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> if (prefs.fluid) { v.springTo(DynamicAnimation.SCALE_X, 1f, 520f, 0.42f); v.springTo(DynamicAnimation.SCALE_Y, 1f, 520f, 0.42f) }
                    }
                    false
                }
                setOnClickListener { applySuggestion(text.toString()) }
            }
            suggViews.add(tv)
            addView(tv)
        }
    }

    /** Linha de ações extras: agora em Compose (botões que mudam de forma com mola). */
    private fun buildExtraRow(): LinearLayout = LinearLayout(ui).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        layoutParams = LinearLayout.LayoutParams(-1, 0)
        visibility = View.GONE
        setPadding(dpi(2), 0, dpi(2), 0)
        composeOwner.resume()
        addView(
            ComposeLayer.create(ui, composeOwner, paletteColorScheme(pal), prefs.fluid, passThrough = false) {
                MkExtraRow(
                    scale = sc,
                    feedback = { feedback(false) },
                    onSelectAll = { ctxMenu(android.R.id.selectAll) },
                    onCopy = { ctxMenu(android.R.id.copy) },
                    onPaste = { ctxMenu(android.R.id.paste) },
                    onCut = { ctxMenu(android.R.id.cut) },
                    onLeft = { resetWord(); sendDownUpKeyEvents(KeyEvent.KEYCODE_DPAD_LEFT) },
                    onRight = { resetWord(); sendDownUpKeyEvents(KeyEvent.KEYCODE_DPAD_RIGHT) },
                    showDemo = prefs.showDemo,
                    onDemo = { openDemo() },
                    onHide = { requestHideSelf(0) }
                )
            },
            LinearLayout.LayoutParams(-1, -1)
        )
    }

    private fun ctxMenu(id: Int) { resetWord(); currentInputConnection?.performContextMenuAction(id) }

    private fun setExtraOpen(open: Boolean, animate: Boolean) {
        val row = extraRow ?: return
        extraOpen = open
        // +10dp em relação ao antigo: a fileira agora tem duas páginas (deslizar para trocar) e
        // uma faixinha de pontinhos embaixo mostrando qual página está ativa.
        val full = sdp(50)
        val target = if (open) full else 0
        val fluid = prefs.fluid
        if (fluid && animate) expandIcon?.springTo(DynamicAnimation.ROTATION, if (open) 180f else 0f, 380f, 0.6f)
        else expandIcon?.animate()?.rotation(if (open) 180f else 0f)?.setDuration(if (animate) 180L else 0L)?.start()
        extraAnim?.cancel()
        if (open) row.visibility = View.VISIBLE
        if (open && animate && fluid) for (i in 0 until row.childCount) row.getChildAt(i).pop(0.5f, 50L + 35L * i)
        if (!animate) {
            row.layoutParams.height = target
            row.alpha = 1f
            if (!open) row.visibility = View.GONE
            row.requestLayout()
            return
        }
        val from = row.layoutParams.height
        if (fluid) {
            extraAnim = SpringAnimation(FloatValueHolder(from.toFloat())).also { a ->
                a.setSpring(SpringForce(target.toFloat()).setStiffness(360f).setDampingRatio(0.72f))
                a.setStartValue(from.toFloat())
                a.addUpdateListener { _, v, _ ->
                    val h = v.toInt().coerceAtLeast(0)
                    row.layoutParams.height = h
                    row.alpha = (h / full.toFloat()).coerceIn(0f, 1f)
                    row.requestLayout()
                }
                a.addEndListener { _, canceled, _, _ ->
                    if (!canceled) {
                        row.layoutParams.height = target
                        if (!extraOpen) row.visibility = View.GONE
                        row.requestLayout()
                    }
                }
                a.start()
            }
            return
        }
        ValueAnimator.ofInt(from, target).apply {
            duration = 180
            addUpdateListener {
                val h = it.animatedValue as Int
                row.layoutParams.height = h
                row.alpha = h / full.toFloat()
                row.requestLayout()
            }
            addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(a: Animator) { if (!extraOpen) row.visibility = View.GONE }
            })
            start()
        }
    }

    // ---------- Painéis ----------

    private fun showPanel(target: View?) {
        val h = host ?: return
        val t = target ?: return
        val old = activePanel
        if (old === t) return
        activePanel = t
        if (t.parent == null) h.addView(t, FrameLayout.LayoutParams(-1, -1))
        // o painel novo fica por cima: o antigo (ainda sumindo) nunca intercepta o toque
        t.bringToFront()
        // garantia: passada a animação, só o painel ativo fica visível
        h.removeCallbacks(settlePanels)
        h.postDelayed(settlePanels, 450)
        if (prefs.fluid) {
            // o painel antigo some suavemente enquanto o novo "brota" com mola
            old?.springTo(DynamicAnimation.ALPHA, 0f, 700f, 1f) { if (activePanel !== old) { old?.visibility = View.GONE } }
            t.visibility = View.VISIBLE
            t.springIn(fromY = 22f, fromScale = 0.94f, stiffness = 380f, damping = 0.72f)
            return
        }
        old?.animate()?.cancel()
        old?.visibility = View.GONE
        t.visibility = View.VISIBLE
        t.animate().cancel()
        t.alpha = 0f
        t.translationY = dpi(14).toFloat()
        t.animate().alpha(1f).translationY(0f).setDuration(140).start()
    }

    /** Mostra o painel na hora, sem animação (usado ao reabrir "Organizar a barra" depois de reconstruir a interface). */
    private fun showPanelNow(t: View) {
        val h = host ?: return
        activePanel = t
        if (t.parent == null) h.addView(t, FrameLayout.LayoutParams(-1, -1))
        t.bringToFront()
        settlePanels.run()
    }

    /** Painel Compose com a demonstração dos componentes Material 3 Expressive. Criado só ao abrir. */
    private fun openDemo() {
        composeOwner.resume()   // garante o relógio de quadros do Compose ativo
        if (demoPanel == null) {
            demoPanel = ComposeLayer.create(ui, composeOwner, paletteColorScheme(pal), prefs.fluid, passThrough = false) {
                MkDemoPanel(onBack = { showPanel(keysContainer) })
            }
        }
        showPanel(demoPanel)
    }

    private fun openClipboard() {
        composeOwner.resume()
        if (clipPanel == null) {
            val st = MkClipboardState(store)
            clipState = st
            clipPanel = ComposeLayer.create(ui, composeOwner, paletteColorScheme(pal), prefs.fluid, passThrough = false) {
                MkClipboardPanel(
                    state = st,
                    onBack = { showPanel(keysContainer) },
                    onClear = { store.clear() },
                    onDelete = { store.remove(it) },
                    onPasteText = { t -> resetWord(); commit(t) },
                    onPasteImage = { path -> pasteImage(path) }
                )
            }
        }
        clipState?.refresh()
        showPanel(clipPanel)
    }

    /**
     * Cola uma imagem do histórico (print, figurinha) no campo atual, via InputConnection.commitContent
     * (androidx InputConnectionCompat): é a forma correta de enviar conteúdo rico a um app, sem precisar
     * de permissão de armazenamento. Só funciona se o app de destino aceitar imagens nesse campo;
     * nesse caso avisamos em vez de travar ou falhar em silêncio.
     */
    private fun pasteImage(path: String) {
        val f = File(path)
        val ic = currentInputConnection
        val info = currentInputEditorInfo
        if (!f.exists() || ic == null || info == null) {
            Toast.makeText(this, "Não foi possível colar a imagem".tr(), Toast.LENGTH_SHORT).show()
            return
        }
        val mime = ClipboardStore.mimeOf(path)
        val accepted = EditorInfoCompat.getContentMimeTypes(info)
        val supported = accepted.any { it.equals(mime, true) || it.equals("image/*", true) }
        try {
            val uri = FileProvider.getUriForFile(this, "$packageName.clipfiles", f)
            if (!supported) {
                // O campo não recebe imagem direto: deixa a imagem na área de transferência para colar manualmente.
                clipboard?.setPrimaryClip(ClipData.newUri(contentResolver, "Imagem", uri))
                Toast.makeText(this, "Imagem copiada. Este campo não aceita colar direto: use Colar do app.".tr(), Toast.LENGTH_LONG).show()
                return
            }
            resetWord()
            val contentInfo = InputContentInfoCompat(uri, ClipDescription("Imagem", arrayOf(mime)), null)
            InputConnectionCompat.commitContent(ic, info, contentInfo, InputConnectionCompat.INPUT_CONTENT_GRANT_READ_URI_PERMISSION, null)
        } catch (_: Exception) {
            Toast.makeText(this, "Não foi possível colar a imagem".tr(), Toast.LENGTH_SHORT).show()
        }
    }

    private fun openEmoji() {
        composeOwner.resume()
        if (emojiPanel == null) {
            val st = MkEmojiState(recents)
            emojiState = st
            emojiPanel = ComposeLayer.create(ui, composeOwner, paletteColorScheme(pal), prefs.fluid, passThrough = false) {
                MkEmojiPanel(st, onPick = { e -> resetWord(); commit(e) }, onBack = { showPanel(keysContainer) })
            }
        }
        emojiState?.onShown()
        showPanel(emojiPanel)
    }

    private fun openSettings() {
        try {
            startActivity(Intent(this, SettingsActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (_: Exception) { }
    }

    /**
     * Microfone: ditado dentro do próprio teclado (SpeechRecognizer do Android, sem abrir telas).
     * 1º toque escuta (para sozinho no silêncio), 2º toque encerra na hora; toque ao processar cancela.
     */
    private fun startVoice() {
        if (isPassword) { Toast.makeText(this, "Voz desativada em campos de senha".tr(), Toast.LENGTH_SHORT).show(); return }
        val w = speechVoice()
        when (w.state) {
            SpeechVoice.State.STARTING -> { w.cancel(); return }      // ainda abrindo o microfone: cancela
            SpeechVoice.State.RECORDING -> { w.stop(); return }       // 2º toque: transcreve
            SpeechVoice.State.TRANSCRIBING -> { w.cancel(); return }  // toque durante a transcrição: cancela
            SpeechVoice.State.IDLE -> Unit
        }
        if (!w.isAvailable()) {
            Toast.makeText(this, "Reconhecimento de voz indisponível neste aparelho".tr(), Toast.LENGTH_LONG).show(); return
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            try {
                startActivity(Intent(this, MicPermissionActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION))
            } catch (_: Exception) { }
            return
        }
        w.start()
    }

    // ---------- Voz (reconhecimento do sistema, sem abrir o teclado do Google) ----------

    private var micBtn: ImageView? = null
    private var speech: SpeechVoice? = null

    private fun speechVoice(): SpeechVoice = speech ?: SpeechVoice(this, object : SpeechVoice.Callbacks {
        override fun onState(state: SpeechVoice.State) { main.post { showMicState(state); if (state == SpeechVoice.State.IDLE) endVoiceComposing() } }
        override fun onPartial(text: String) { main.post { showPartialDictation(text) } }
        override fun onInfo(message: String) {
            main.post { Toast.makeText(this@KeyboardService, message.tr(), Toast.LENGTH_LONG).show() }
        }
        override fun onText(text: String) { main.post { insertDictation(text) } }
        override fun onError(message: String) {
            main.post { Toast.makeText(this@KeyboardService, message.tr(), Toast.LENGTH_LONG).show() }
        }
    }).also { speech = it }

    /** Gravando: ícone de parar. Transcrevendo: ícone de fechar (toque cancela) e botão mais fraco. */
    private fun showMicState(state: SpeechVoice.State) {
        val b = micBtn ?: return
        b.setImageResource(when (state) {
            SpeechVoice.State.IDLE, SpeechVoice.State.STARTING -> R.drawable.ic_mic
            SpeechVoice.State.RECORDING -> R.drawable.ic_pause
            SpeechVoice.State.TRANSCRIBING -> R.drawable.ic_close
        })
        b.animate().alpha(if (state == SpeechVoice.State.TRANSCRIBING || state == SpeechVoice.State.STARTING) 0.6f else 1f).setDuration(150).start()
    }

    /**
     * v75.2: o que está sendo reconhecido aparece como "legenda" na faixa de sugestões, NÃO dentro do campo.
     * Escrever no campo como texto em composição fazia alguns apps (corretor/teclado do próprio app) trocarem as
     * palavras no meio da fala. Só o texto final entra no campo, uma vez.
     */
    private fun showPartialDictation(text: String) {
        if (suggViews.isEmpty()) return
        main.removeCallbacks(hideStrip)
        val caption = if (text.length > 28) "…" + text.takeLast(27).trimStart() else text
        for (i in suggViews.indices) {
            val tv = suggViews[i]
            if (i == 0) {
                tv.visibility = View.VISIBLE
                tv.tag = true
                tv.background = roundedBg(pal.keyAccent, dpi(20).toFloat(), pal.onAccent)
                tv.setTextColor(pal.onAccent)
                tv.text = caption
                tv.isClickable = false
            } else { tv.text = ""; tv.visibility = View.GONE; tv.isClickable = false }
        }
        showStrip(true)
    }

    private fun endVoiceComposing() { suggSeq++; updateSuggestions() }   // volta a faixa ao normal

    /** Insere o texto ditado (com espaço antes, se o cursor estiver colado numa palavra). */
    private fun insertDictation(text: String) {
        val before = currentInputConnection?.getTextBeforeCursor(1, 0)
        val lead = if (!before.isNullOrEmpty() && !before.last().isWhitespace()) " " else ""
        pendingVoice = lead + text
        flushVoice()    // se o campo estiver sem foco, fica pendente até o teclado voltar
    }

    private var pendingVoice: String? = null

    /** Texto ditado que chegou enquanto o campo estava sem foco: é inserido assim que o teclado volta. */
    private fun flushVoice() {
        val t = pendingVoice ?: return
        if (currentInputConnection == null) return
        pendingVoice = null
        resetWord()
        commit(t)
    }

    // ---------- Clipboard ----------

    /**
     * Chamado pelo Android sempre que o clipboard muda. Fica tudo dentro de try/catch e qualquer
     * I/O roda em [runClip] (fora da thread principal): antes, um texto "rico" (HTML, link de outro
     * app) ou uma imagem acionava coerceToText() aqui mesmo, que podia abrir um fluxo de leitura
     * (ou faltar permissão) bem na hora em que o teclado deveria continuar respondendo ao toque —
     * dava a sensação de o clipboard "bugar". Texto puro (o caso comum) ainda é lido na hora, porque
     * já vem pronto, sem nenhuma leitura extra.
     */
    private fun captureClip(fromOpen: Boolean = false) {
        if (!prefs.clipboardEnabled || isPassword) return
        try {
            val clip = clipboard?.primaryClip ?: return
            if (clip.itemCount == 0) return
            val d = clip.description
            if (Build.VERSION.SDK_INT >= 33 && d.extras?.getBoolean(ClipDescription.EXTRA_IS_SENSITIVE, false) == true) return
            val item = clip.getItemAt(0)
            val uri = item.uri
            val isImage = uri != null && d.hasMimeType("image/*")   // imagem tem prioridade sobre um eventual rótulo de texto
            val plain = if (isImage) null else item.text?.toString()
            val sig = if (isImage) "i:$uri" else if (plain != null) "t:${plain.length}:${plain.hashCode()}" else "u:$uri:${d.getMimeType(0)}"
            // Ao abrir o teclado só relê se mudou: assim um item excluído não volta sozinho.
            if (fromOpen && store.lastSig == sig) return
            store.lastSig = sig
            if (plain != null) {
                if (!ClipboardStore.looksSensitive(plain)) store.addText(plain)
                return
            }
            if (isImage) {
                runClip {
                    try {
                        contentResolver.openInputStream(uri!!)?.use { input ->
                            ClipboardStore.readCapped(input, ClipboardStore.MAX_IMAGE_BYTES)?.let { store.addImage(it) }
                        }
                    } catch (_: Exception) { }
                }
                return
            }
            // Texto "rico" (HTML etc.) sem texto pronto: converte fora da thread principal.
            if (!d.hasMimeType("text/*")) return
            runClip {
                try {
                    val t = item.coerceToText(this)?.toString()
                    if (!t.isNullOrBlank() && !t.startsWith("content://") && !ClipboardStore.looksSensitive(t)) store.addText(t)
                } catch (_: Exception) { }
            }
        } catch (_: Exception) { }
    }

    // ---------- Posicionar Keycaps: trocar as letras de lugar ----------

    private fun layoutId(): String = when {
        prefs.language == Prefs.LANG_RU -> "ru"
        prefs.language == Prefs.LANG_AR -> "ar"
        prefs.language == Prefs.LANG_ES -> "es"
        prefs.language == Prefs.LANG_FR -> "fr"
        prefs.language == Prefs.LANG_TR -> "tr"
        else -> "qwerty"
    }

    private fun defaultRows(id: String): List<String> = when (id) {
        "ru" -> listOf("йцукенгшщзхъ", "фывапролджэ", "ячсмитьбю")
        "ar" -> listOf("ضصثقفغعهخحجد", "شسيبلاتنمكطذ", "ئءؤرىةوزظ")   // teclado árabe padrão (ا e ل separados); 12 + 12 + 9 teclas
        "es" -> listOf("qwertyuiop", "asdfghjklñ", "zxcvbnm")
        "fr" -> listOf("azertyuiop", "qsdfghjklm", "wxcvbn'")                 // AZERTY; o apóstrofo (l', j', qu'...) fica à mão
        "tr" -> listOf("qwertyuıopğü", "asdfghjklşi", "zxcvbnmöç")           // teclado Q turco: 12 + 11 + 9 teclas
        else -> listOf("qwertyuiop", "asdfghjkl", "zxcvbnm")
    }

    /** Letras das três fileiras: as escolhidas pela pessoa, se forem válidas; senão o padrão do layout. */
    private fun currentRows(): List<String> {
        val def = defaultRows(layoutId())
        val saved = prefs.keyRows(layoutId()).split("|")
        val ok = saved.size == def.size &&
            saved.map { it.length } == def.map { it.length } &&
            saved.joinToString("").toList().sorted() == def.joinToString("").toList().sorted()
        return if (ok) saved else def
    }

    /** Troca a letra [a] com a [b]: cada uma passa a ocupar o lugar da outra. Adiado: salvar reconstrói o teclado, e isso não pode ocorrer no meio do toque. */
    private fun swapLetters(a: Char, b: Char) {
        val id = layoutId()
        val rows = currentRows().map { r -> r.map { if (it == a) b else if (it == b) a else it }.joinToString("") }
        main.post { prefs.putString("rows_$id", rows.joinToString("|")) }
    }

    private fun resetKeycaps() { main.post { prefs.clearKeyRows() } }

    private fun setKeycapMode(on: Boolean) {
        if (keycapMode == on) return
        keycapMode = on
        if (on) {
            if (extraOpen) setExtraOpen(false, animate = false)
            pendingAccent = null
            val needRebuild = symbols
            symbols = false; symPage2 = false
            if (needRebuild) buildKeys()
            showPanel(keysContainer)
            Toast.makeText(ui, "Arraste uma tecla sobre outra para trocar".tr(), Toast.LENGTH_SHORT).show()
        }
        keyRoot?.editMode = on
        editBar?.visibility = if (on) View.VISIBLE else View.GONE
    }

    /** Faixa que aparece no modo Posicionar Keycaps: dica, Restaurar e Concluído. */
    private fun buildEditBar(): LinearLayout = LinearLayout(ui).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        layoutParams = LinearLayout.LayoutParams(-1, dpi(46))
        setPadding(dpi(8), dpi(2), dpi(4), dpi(2))
        visibility = if (keycapMode) View.VISIBLE else View.GONE
        addView(TextView(ui).apply {
            text = "Posicionar Keycaps".tr() + "\n" + "Arraste uma tecla sobre outra para trocar".tr()
            setTextColor(pal.onSurface)
            textSize = 12f
            maxLines = 2
            ellipsize = TextUtils.TruncateAt.END
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        })
        fun chip(t: String, accent: Boolean, onClick: () -> Unit) = TextView(ui).apply {
            text = t
            gravity = Gravity.CENTER
            textSize = 13f
            maxLines = 1
            setTextColor(if (accent) pal.onAccent else pal.onSpecial)
            setPadding(dpi(14), 0, dpi(14), 0)
            background = roundedBg(if (accent) pal.keyAccent else pal.keySpecial, dpi(18).toFloat(), if (accent) pal.onAccent else pal.onSpecial)
            layoutParams = LinearLayout.LayoutParams(-2, dpi(36)).apply { marginStart = dpi(6) }
            setOnClickListener { onClick() }
        }
        addView(chip("Restaurar".tr(), false) { resetKeycaps() })
        addView(chip("Concluído".tr(), true) { setKeycapMode(false) })
    }

    /** Tecla mais próxima do ponto (coordenadas da raiz) dentro da área das teclas; usada pelo modo Posicionar Keycaps. */
    private fun editKeyAt(root: View, x: Float, y: Float): KeyView? {
        val kc = keysContainer ?: return null
        val h = host ?: return null
        if (activePanel !== kc || kc.visibility != View.VISIBLE || y < h.top || y > h.bottom) return null
        var best: KeyView? = null
        var bestD = Float.MAX_VALUE
        val r = Rect()
        for (ri in 0 until kc.childCount) {
            val rowView = kc.getChildAt(ri) as? ViewGroup ?: continue
            for (ci in 0 until rowView.childCount) {
                val k = rowView.getChildAt(ci) as? KeyView ?: continue
                r.set(0, 0, k.width, k.height)
                (root as ViewGroup).offsetDescendantRectToMyCoords(k, r)
                val dx = maxOf(r.left - x, x - r.right, 0f)
                val dy = maxOf(r.top - y, y - r.bottom, 0f)
                val d = dx * dx + dy * dy
                if (d < bestD) { bestD = d; best = k }
            }
        }
        return best
    }

    // ---------- Teclas ----------

    private fun newKey(label: String, weight: Float, style: Style): KeyView = KeyView(ui).apply {
        this.label = label
        fluid = prefs.fluid
        keyStyle = prefs.activeKeyStyle
        lens = prefs.liquidGlass
        borderPx = dpi(prefs.keyBorder.coerceIn(0, 6)).toFloat()
        depthPx = dpi(prefs.activeKeyDepth.coerceIn(0, 8)).toFloat()
        fontStyle = prefs.fontStyle
        glow = prefs.pressGlow
        radius = dpi(prefs.keyRadius).toFloat()
        textSizePx = textPx
        popup = altPopup
        preview = keyPreview
        onLongFeedback = { feedback(false) }
        // Gboard: pouco espaço entre teclas na horizontal (teclas largas) e um pouco mais na vertical (teclas altas)
        layoutParams = LinearLayout.LayoutParams(0, -1, weight).apply {
            val gx = dpi((prefs.keyGap - 1).coerceAtLeast(1)); val gy = dpi(prefs.keyGap + 1)
            setMargins(gx, gy, gx, gy)
        }
        applyStyle(this, style)
    }

    private fun applyStyle(k: KeyView, style: Style) {
        val wt = (k.layoutParams as? LinearLayout.LayoutParams)?.weight ?: 1f
        k.shape = if (prefs.expressive) {
            // Estilo Gboard: todas as teclas = retângulo arredondado uniforme (sem pílulas)
            0
        } else if (style == Style.ACCENT && prefs.accentShape > 0) prefs.accentShape - 1 else prefs.keyShape
        when (style) {
            Style.NORMAL -> { k.bg = pal.keyNormal; k.fg = pal.onNormal }
            Style.SPECIAL -> { k.bg = pal.keySpecial; k.fg = pal.onSpecial }
            Style.ACCENT -> { k.bg = pal.keyAccent; k.fg = pal.onAccent }
        }
        // v75.1: modo "imagem de referência" removido: as teclas sempre aparecem normais sobre a imagem de fundo
        k.invisible = false
        // Keys Café passo 3: gradiente de tecla/destaque do tema ativo (teclas especiais ficam lisas)
        val tg = if (style == Style.SPECIAL) null
            else com.example.materialkeyboard.keyscafe.ThemeGradients.forKey(prefs, if (style == Style.ACCENT) "accent" else "key")
        k.gradColors = tg?.colors?.map { it.toInt() }?.toIntArray()
        k.gradAngle = tg?.angle ?: 0
        k.invalidate()
    }

    private fun row(): LinearLayout = LinearLayout(ui).apply {
        orientation = LinearLayout.HORIZONTAL
        layoutParams = LinearLayout.LayoutParams(-1, rowHeightPx)
    }

    private fun spacer(w: Float) = View(ui).apply { layoutParams = LinearLayout.LayoutParams(0, -1, w) }

    private fun charKey(c: Char, style: Style = Style.NORMAL, w: Float = 1f, letter: Boolean = false): KeyView {
        val k = newKey(if (letter && shift) up(c.toString()) else c.toString(), w, style)
        k.previewOn = true
        if (letter) letterKeys.add(LetterKey(k, c))
        if (prefs.typeOnRelease) {
            k.onDown = { onCharFeedback(c, letter) }       // som/vibração ao encostar
            k.onTap = { onCharCommit(c, letter) }          // a letra entra ao SOLTAR
        } else k.onDown = { onChar(c, letter) }
        val base = if (ar && c == '.') listOf("،", "؟", "؛", "!", ":", "«", "»", "…")
        else if (es && c == '.') listOf(",", "?", "!", "¿", "¡", ":", ";", "…")
        else altFor(c)
        if (base != null) {
            // avaliado no toque, antes de onChar consumir o shift; sem variações se há acento pendente
            k.altsFor = {
                if (pendingAccent != null) null
                else if (letter && shift) base.map { upperAlt(it) } else base
            }
            k.onAlt = { alt -> if (prefs.typeOnRelease) insertAlt(alt) else replaceLast(c, alt) }
        }
        return k
    }

    /** Árabe: tecla das vogais curtas (harakat). Toque = fatha; segurar abre fatha, damma, kasra, shadda, sukun e tanwin. */
    private fun harakatKey(w: Float = 1.5f): KeyView {
        val fatha = "\u064E"
        val k = newKey("\u0640" + fatha, w, Style.SPECIAL)
        k.previewOn = true
        k.onDown = { feedback(false); commit(fatha) }
        val marks = listOf("\u064E", "\u064F", "\u0650", "\u0651", "\u0652", "\u064B", "\u064C", "\u064D")
        k.altsFor = { if (pendingAccent != null) null else marks }
        k.onAlt = { alt -> replaceLast(fatha[0], alt) }
        return k
    }

    /** Árabe: tecla "لا" (lam + alef numa tecla só, como no Gboard): digita as duas letras, uma depois da outra. */
    private fun lamAlefKey(): KeyView {
        val k = newKey("\u0644\u0627", 1f, Style.NORMAL)
        k.previewOn = true
        k.onDown = { onChar('\u0644', true); onChar('\u0627', true) }
        return k
    }

    /** A letra base já foi digitada no toque; ao escolher uma variação, ela é trocada pela escolhida. */
    private fun replaceLast(base: Char, alt: String) {
        val ic = currentInputConnection ?: return
        val before = ic.getTextBeforeCursor(1, 0)?.toString().orEmpty()
        val matched = before.isNotEmpty() && before[0].equals(base, ignoreCase = true)
        ic.beginBatchEdit()
        if (matched) ic.deleteSurroundingText(1, 0)
        ic.commitText(alt, 1)
        ic.endBatchEdit()
        val letterAlt = alt.isNotEmpty() && alt[0].isLetter()
        if (letterAlt) {
            if (matched && word.isNotEmpty()) word.setLength(word.length - 1)
            word.append(alt)
        } else sentenceEnd = alt == "." || alt == "!" || alt == "?"
        updateSuggestions()
    }

    /** Troca de layout (letras ⇄ símbolos): as teclas brotam em onda, fileira por fileira. */
    private fun rebuildKeys() {
        buildKeys()
        waveKeys()
    }

    private fun waveKeys() {
        if (!prefs.fluid) return
        val kc = keysContainer ?: return
        for (r in 0 until kc.childCount) {
            val row = kc.getChildAt(r) as? ViewGroup ?: continue
            for (c in 0 until row.childCount) {
                val v = row.getChildAt(c)
                if (v is KeyView) { val d = r * 30L + c * 12L; v.pop(0.7f, d, 620f, 0.5f); v.springFadeIn(d, 520f) }
            }
        }
    }

    private fun buildKeys() {
        val kc = keysContainer ?: return
        kc.removeAllViews()
        letterKeys.clear(); deadKeys.clear(); shiftKey = null
        val pt = prefs.language == Prefs.LANG_PT
        val ru = prefs.language == Prefs.LANG_RU
        val wide2 = es || ar || fr          // fileira do meio cheia (ñ / m com 10 teclas, árabe com 12): sem espaçadores
        val rtl = ar && !symbols            // árabe como no Gboard: as letras começam pela DIREITA (ض no canto direito)
        val show = { r: String -> if (rtl) r.reversed() else r }
        val letters = !symbols
        val rows = if (symbols && symPage2) listOf("~`|•√π÷×¶∆", "£€¢¥^°={}\\", "©®™[]<>")
        else if (symbols) listOf("1234567890", "@#\$%&-+()/", "*\"':;!?")
        else currentRows()

        if (letters && prefs.numberRow) {
            kc.addView(row().apply { "1234567890".forEach { addView(charKey(it, Style.NORMAL, 1f, false)) } })
        }
        kc.addView(row().apply { show(rows[0]).forEach { addView(charKey(it, Style.NORMAL, 1f, letters)) } })
        kc.addView(row().apply {
            if (!(letters && wide2)) addView(spacer(0.5f))
            show(rows[1]).forEach { addView(charKey(it, Style.NORMAL, 1f, letters)) }
            if (!(letters && wide2)) addView(spacer(0.5f))
        })
        kc.addView(row().apply {
            if (symbols) {
                val more = newKey(if (symPage2) "?123" else "=\\<", 1.5f, Style.ACCENT)
                more.onDown = { feedback(false, SoundBank.Slot.EDGE); symPage2 = !symPage2; rebuildKeys() }
                addView(more)
            }
            else if (ar) {
                addView(harakatKey(1f))                // árabe não tem maiúsculas: no lugar do shift fica a tecla das vogais curtas
            }
            else {
                val s = newKey("", 1.5f, if (shift) Style.ACCENT else Style.SPECIAL)
                s.icon = if (caps) KeyView.ICON_CAPS else KeyView.ICON_SHIFT
                s.onDown = { feedback(false, SoundBank.Slot.SHIFT); onShift() }
                s.onHold = { caps = true; shift = true; refreshShiftUi() }   // segurar = Caps Lock direto
                shiftKey = s
                addView(s)
            }
            if (rtl) {
                // Gboard: ئ ء ؤ ر [لا] ى ة و ز ظ (lido da direita para a esquerda); "لا" é uma tecla só
                val items = ArrayList<View>()
                rows[2].forEachIndexed { i, ch ->
                    if (i == 4) items.add(lamAlefKey())
                    items.add(charKey(ch, Style.NORMAL, 1f, letters))
                }
                items.reversed().forEach { addView(it) }
            } else rows[2].forEach { addView(charKey(it, Style.NORMAL, 1f, letters)) }
            addView(deleteKey(if (ar && letters) 1f else 1.5f))
        })
        kc.addView(row().apply {
            val toggle = newKey(if (symbols) "ABC" else "?123", 1.5f, Style.SPECIAL)
            toggle.onDown = { feedback(false, SoundBank.Slot.EDGE); symbols = !symbols; symPage2 = false; pendingAccent = null; rebuildKeys() }
            addView(toggle)
            addView(customKey(prefs.keyLeft))
            val side = sideKey()                       // botão de idioma (ou emoji) à esquerda do espaço, como no Gboard
            if (side != null) addView(side)
            val space = newKey(when {
                ru -> "Русский"; ar -> "العربية"; es -> "Español"; fr -> "Français"; tr -> "Türkçe"; vi -> "Tiếng Việt"; !pt -> "English"; else -> "Português".tr()
            }, 5f - (if (side != null) 1.2f else 0f), Style.NORMAL)
            // O espaço só é digitado ao SOLTAR (se o dedo não deslizou), para o deslize poder mover o cursor.
            space.onDown = {
                feedback(true, SoundBank.Slot.SPACE)
                if (spaceTaps == 0) spaceSlid = false
                spaceTaps++
                space.kick(0f, 2.5f, 650f, 0.4f)
            }
            space.onUp = {
                val n = spaceTaps; spaceTaps = 0
                if (!spaceSlid) repeat(n) { onSpace() }
                spaceSlid = false
            }
            space.onSlideStart = {
                spaceSlid = true; spaceTaps = 0
                resetWord()
                spaceSlideAcc = 0f
                if (prefs.spaceSlide == Prefs.SPACE_SLIDE_CURSOR) openCursorPad()
            }
            space.onSlideMove = { dx ->
                // enquanto o dedo ainda está na barra de espaço: anda 1 caractere a cada ~stepPx
                spaceSlideAcc += dx
                val step = cursorStepPx()
                val n = (spaceSlideAcc / step).toInt()
                if (n != 0) { spaceSlideAcc -= n * step; moveCursorBy(n) }
            }
            addView(space)
            addView(customKey(prefs.keyRight))
            val enter = newKey("", 1.5f, Style.ACCENT)
            enter.icon = KeyView.ICON_ENTER
            enter.onDown = { feedback(false, SoundBank.Slot.ENTER); onEnter(); enter.kick(5f, 0f) }
            addView(enter)
        })
    }

    // ---------- Barra de ícones: itens, posição e idioma ----------

    private val allBarIds = listOf("emoji", "clip", "translate", "settings", "position", "lang", "selectall", "copy", "paste", "onehand", "float", "hide")
    private val langOrder = listOf(Prefs.LANG_EN, Prefs.LANG_PT, Prefs.LANG_ES, Prefs.LANG_AR, Prefs.LANG_RU, Prefs.LANG_FR, Prefs.LANG_TR, Prefs.LANG_VI)

    private fun barIcon(id: String): Int = when (id) {
        "emoji" -> R.drawable.ic_emoji
        "clip" -> R.drawable.ic_clipboard
        "translate" -> R.drawable.ic_translate
        "settings" -> R.drawable.ic_kb_settings        // engrenagem
        "position" -> R.drawable.ic_position
        "lang" -> R.drawable.ic_globe
        "selectall" -> R.drawable.ic_select_all
        "copy" -> R.drawable.ic_copy
        "paste" -> R.drawable.ic_paste
        "onehand" -> R.drawable.ic_onehand
        "float" -> R.drawable.ic_float
        else -> R.drawable.ic_hide_kb
    }

    private fun barTitle(id: String): String = when (id) {
        "emoji" -> "Emojis"
        "clip" -> "Área de transferência"
        "translate" -> "Tradutor"
        "settings" -> "Configurações"
        "position" -> "Posicionar as teclas"
        "lang" -> "Trocar idioma"
        "selectall" -> "Selecionar tudo"
        "copy" -> "Copiar"
        "paste" -> "Colar"
        "onehand" -> "Modo uma mão"
        "float" -> "Teclado flutuante"
        "hide" -> "Ocultar teclado"
        else -> id
    }.tr()

    private fun runBarItem(id: String) {
        when (id) {
            "emoji" -> openEmoji()
            "clip" -> openClipboard()
            "translate" -> translatorBar?.toggle()
            "settings" -> openSettings()
            "position" -> openPosition()
            "lang" -> cycleLanguage()
            "selectall" -> ctxMenu(android.R.id.selectAll)
            "copy" -> ctxMenu(android.R.id.copy)
            "paste" -> ctxMenu(android.R.id.paste)
            "onehand" -> prefs.putInt("oneHand", if (prefs.floating) 1 else (prefs.oneHand + 1) % 3).also { if (prefs.floating) prefs.putBool("floating", false) }
            "float" -> prefs.putBool("floating", !prefs.floating)
            "hide" -> requestHideSelf(0)
        }
    }

    /** Lista guardada (sem repetidos nem ids desconhecidos). "Organizar a barra" nunca some, para dar sempre o caminho de volta. */
    private fun storedBar(): MutableList<String> {
        val ids = prefs.barItems.split(",").map { it.trim() }.filter { it in allBarIds }.distinct().toMutableList()
        if ("position" !in ids) ids.add("position")
        return ids
    }

    /** O que realmente aparece na barra: com o emoji ao lado do espaço, ele sai da barra (aparece "no lugar" do botão de idioma). */
    private fun barOrder(): List<String> = storedBar().filter { !(it == "emoji" && prefs.langKey == Prefs.LANG_KEY_EMOJI) }

    private fun saveBar(ids: List<String>) { prefs.putString("barItems", ids.joinToString(",")) }

    private fun moveBar(id: String, delta: Int) {
        val stored = storedBar()
        val vis = barOrder()
        val vi = vis.indexOf(id)
        val ni = vi + delta
        if (vi < 0 || ni < 0 || ni >= vis.size) return
        java.util.Collections.swap(stored, stored.indexOf(id), stored.indexOf(vis[ni]))
        saveBar(stored)
    }

    private fun addBar(id: String) { val s = storedBar(); if (id !in s) s.add(id); saveBar(s) }

    private fun removeBar(id: String) { if (id == "position") return; val s = storedBar(); s.remove(id); saveBar(s) }

    /** Idiomas do botão de idioma: só os marcados em Configurações → Idioma (na ordem fixa de [langOrder]); nunca vazio. */
    private fun activeLangs(): List<String> {
        val chosen = prefs.langList.split(",").map { it.trim() }.toSet()
        return langOrder.filter { it in chosen }.ifEmpty { listOf(Prefs.LANG_EN) }
    }

    /** Próximo idioma, só entre os escolhidos. Adiado um instante: trocar o idioma reconstrói o teclado, e isso não pode ocorrer no meio do toque. */
    private fun cycleLanguage() {
        val list = activeLangs()
        val i = list.indexOf(prefs.language)
        val next = list[(i + 1) % list.size]          // idioma atual fora da lista (i = -1): entra no primeiro da lista
        if (next == prefs.language) return
        main.post { prefs.putString("language", next) }
    }

    private var addLangPw: android.widget.PopupWindow? = null

    /** Bolhas (mesmo estilo dos acentos) com os idiomas que ainda não estão no botão; tocar em uma adiciona e já troca para ela. */
    private fun showAddLangPanel(anchor: View) {
        addLangPw?.dismiss(); addLangPw = null
        val on = activeLangs()
        val missing = langOrder.filter { it !in on }
        if (missing.isEmpty()) return
        val d = ui.resources.displayMetrics.density
        val screenW = ui.resources.displayMetrics.widthPixels
        val margin = (4 * d).toInt(); val gap = (4 * d).toInt(); val pad = (4 * d).toInt()
        val count = missing.size + 1                                   // + a bolha "＋"
        val bs = minOf((38 * d).toInt(), (screenW - 2 * margin - 2 * pad) / count - gap)
        val sid = prefs.altShape
        val row = LinearLayout(ui).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(pad, pad, pad, pad)
        }
        fun bubble(text: String, accent: Boolean): AltBubble = AltBubble(ui).apply {
            this.text = text; shapeId = sid; textPx = bs * 0.42f
            paint(if (accent) pal.keyAccent else pal.keySpecial, if (accent) pal.onAccent else pal.onSpecial)
            layoutParams = LinearLayout.LayoutParams(bs, bs).apply { marginStart = gap / 2; marginEnd = gap / 2 }
        }
        row.addView(bubble("＋", true).apply { contentDescription = "Adicionar idioma".tr() })
        missing.forEach { code ->
            row.addView(bubble(code.uppercase(), false).apply {
                contentDescription = TLangs.of(code).name
                setOnClickListener {
                    addLangPw?.dismiss(); addLangPw = null
                    val list = (on + code).joinToString(",")
                    main.post { prefs.putString("langList", list); prefs.putString("language", code) }
                }
            })
        }
        if (prefs.fluid) for (i in 0 until row.childCount) row.getChildAt(i).apply {
            scaleX = 0f; scaleY = 0f
            animate().scaleX(1f).scaleY(1f).setStartDelay(25L * i).setDuration(260)
                .setInterpolator(android.view.animation.OvershootInterpolator(2f)).start()
        }
        row.measure(View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED), View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED))
        try {
            val w = android.widget.PopupWindow(row, android.view.ViewGroup.LayoutParams.WRAP_CONTENT, android.view.ViewGroup.LayoutParams.WRAP_CONTENT, false)
            w.isOutsideTouchable = true
            w.isClippingEnabled = false
            w.setBackgroundDrawable(android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT))
            w.inputMethodMode = android.widget.PopupWindow.INPUT_METHOD_NOT_NEEDED
            val loc = IntArray(2); anchor.getLocationOnScreen(loc)
            val x = loc[0].coerceIn(margin, maxOf(margin, screenW - row.measuredWidth - margin))
            w.showAsDropDown(anchor, x - loc[0], -(anchor.height + row.measuredHeight + (2 * d).toInt()), android.view.Gravity.TOP or android.view.Gravity.START)
            addLangPw = w
        } catch (_: Exception) { }
    }

    /** Tecla à esquerda do espaço: globo (troca o idioma), emoji ou nenhuma, conforme Configurações → Barra de ícones. */
    private fun sideKey(): KeyView? = when (prefs.langKey) {
        Prefs.LANG_KEY_LANG -> newKey("", 1.2f, Style.SPECIAL).also { k ->
            k.icon = KeyView.ICON_GLOBE
            k.onDown = { feedback(false, SoundBank.Slot.EDGE); k.kick(0f, 2f, 650f, 0.4f) }
            k.onTap = { cycleLanguage() }                       // toque = próximo idioma (ao soltar)
            // v65.6: segurar = lista dos idiomas ativos (toque num para trocar) e "＋" para adicionar os que faltam
            k.compactAlts = true
            k.altsFor = {
                val on = activeLangs()
                on.map { it.uppercase() } + (if (langOrder.any { it !in on }) listOf("＋") else emptyList())
            }
            k.onAlt = { alt ->
                if (alt == "＋") showAddLangPanel(k)
                else { val code = alt.lowercase(); main.post { if (code != prefs.language) prefs.putString("language", code) } }
            }
        }
        Prefs.LANG_KEY_EMOJI -> newKey("", 1.2f, Style.SPECIAL).also { k ->
            k.icon = KeyView.ICON_EMOJI                          // ícone original do emoji (o mesmo da barra), não o 😀 do texto
            k.onDown = { feedback(false, SoundBank.Slot.EDGE); k.kick(0f, 2f, 650f, 0.4f); main.post { openEmoji() } }
        }
        else -> null
    }

    // ---------- Painel "Organizar a barra" (ordem dos ícones da barra) ----------

    private fun openPosition(instant: Boolean = false, scrollY: Int = 0) {
        if (posPanel == null) posPanel = buildPositionPanel()
        refreshPosition()
        val panel = posPanel ?: return
        if (instant) {
            showPanelNow(panel)
            posScroll?.post { posScroll?.scrollTo(0, scrollY) }
        } else showPanel(panel)
    }

    private fun buildPositionPanel(): View {
        val col = LinearLayout(ui).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dpi(6), dpi(2), dpi(6), 0)
        }
        val head = LinearLayout(ui).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(-1, dpi(44))
        }
        head.addView(iconButton(ui, R.drawable.ic_back, pal.onSurface, "Voltar".tr(), 36) { showPanel(keysContainer) })
        head.addView(TextView(ui).apply {
            text = "Posicionar as teclas".tr()
            setTextColor(pal.onSurface)
            textSize = 16f
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dpi(6) }
        })
        head.addView(TextView(ui).apply {
            text = "Restaurar".tr()
            gravity = Gravity.CENTER
            textSize = 13f
            setTextColor(pal.onSpecial)
            setPadding(dpi(14), 0, dpi(14), 0)
            background = roundedBg(pal.keySpecial, dpi(16).toFloat(), pal.onSpecial)
            layoutParams = LinearLayout.LayoutParams(-2, dpi(34))
            setOnClickListener { saveBar(Prefs.DEFAULT_BAR.split(",")) }
        })
        col.addView(head)
        val list = LinearLayout(ui).apply { orientation = LinearLayout.VERTICAL }
        val sv = ScrollView(ui).apply {
            isVerticalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
            layoutParams = LinearLayout.LayoutParams(-1, 0, 1f)
            addView(list, FrameLayout.LayoutParams(-1, -2))
        }
        col.addView(sv)
        posList = list
        posScroll = sv
        return col
    }

    private fun refreshPosition() {
        val list = posList ?: return
        list.removeAllViews()
        val on = barOrder()
        list.addView(keycapsRow())
        list.addView(posLabel("Na barra".tr()))
        on.forEachIndexed { i, id -> list.addView(posRow(id, i, on.size, true)) }
        val off = allBarIds.filter { it !in on && !(it == "emoji" && prefs.langKey == Prefs.LANG_KEY_EMOJI) }
        if (off.isNotEmpty()) {
            list.addView(posLabel("Adicionar à barra".tr()))
            off.forEach { list.addView(posRow(it, -1, 0, false)) }
        }
        list.addView(posLabel("Botão ao lado do espaço".tr()))
        list.addView(posChipRow(listOf("Idioma".tr(), "Emoji".tr(), "Nenhum".tr()), prefs.langKey) { prefs.putInt("langKey", it) })
        list.addView(posLabel("Deslizar a barra".tr()))
        list.addView(posChipRow(listOf("Começa à esquerda".tr(), "Começa à direita".tr()), prefs.barSide) { prefs.putInt("barSide", it) })
    }

    /** Opção de destaque do painel: liga o modo de trocar as letras de lugar arrastando. */
    private fun keycapsRow(): View = LinearLayout(ui).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        layoutParams = LinearLayout.LayoutParams(-1, dpi(56)).apply { setMargins(0, dpi(4), 0, dpi(2)) }
        setPadding(dpi(14), 0, dpi(14), 0)
        background = roundedBg(pal.keyAccent, dpi(18).toFloat(), pal.onAccent)
        addView(ImageView(ui).apply {
            setImageDrawable(androidx.core.content.ContextCompat.getDrawable(ui, R.drawable.ic_position)?.mutate())
            setColorFilter(pal.onAccent)
            layoutParams = LinearLayout.LayoutParams(dpi(24), dpi(24))
        })
        addView(LinearLayout(ui).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dpi(12) }
            addView(TextView(ui).apply { text = "Posicionar Keycaps".tr(); textSize = 15f; setTextColor(pal.onAccent); typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL) })
            addView(TextView(ui).apply { text = "Arraste uma tecla sobre outra para trocar".tr(); textSize = 11f; setTextColor(ColorUtils.setAlphaComponent(pal.onAccent, 200)); maxLines = 1; ellipsize = TextUtils.TruncateAt.END })
        })
        setOnClickListener { setKeycapMode(true) }
    }

    private fun posLabel(t: String) = TextView(ui).apply {
        text = t
        textSize = 12f
        setTextColor(ColorUtils.setAlphaComponent(pal.onSurface, 170))
        setPadding(dpi(8), dpi(10), 0, dpi(4))
    }

    private fun posRow(itemId: String, index: Int, count: Int, on: Boolean): View = LinearLayout(ui).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        layoutParams = LinearLayout.LayoutParams(-1, dpi(44)).apply { setMargins(0, dpi(2), 0, dpi(2)) }
        setPadding(dpi(12), 0, dpi(6), 0)
        background = roundedBg(pal.keySpecial, dpi(16).toFloat(), pal.onSpecial)
        addView(ImageView(ui).apply {
            setImageDrawable(androidx.core.content.ContextCompat.getDrawable(ui, barIcon(itemId))?.mutate())
            setColorFilter(pal.onSpecial)
            layoutParams = LinearLayout.LayoutParams(dpi(24), dpi(24))
        })
        addView(TextView(ui).apply {
            text = barTitle(itemId)
            textSize = 14f
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            setTextColor(pal.onSpecial)
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dpi(12) }
        })
        if (on) {
            addView(posGlyph("\u25B2", index > 0) { moveBar(itemId, -1) })
            addView(posGlyph("\u25BC", index < count - 1) { moveBar(itemId, 1) })
            addView(posGlyph("\u2715", itemId != "position") { removeBar(itemId) })
        } else {
            addView(posGlyph("+", true) { addBar(itemId) })
            setOnClickListener { addBar(itemId) }
        }
    }

    private fun posGlyph(g: String, enabled: Boolean, onClick: () -> Unit) = TextView(ui).apply {
        text = g
        gravity = Gravity.CENTER
        textSize = 15f
        setTextColor(ColorUtils.setAlphaComponent(pal.onSpecial, if (enabled) 255 else 60))
        layoutParams = LinearLayout.LayoutParams(dpi(38), dpi(38))
        if (enabled) {
            background = roundedBg(Color.TRANSPARENT, dpi(19).toFloat(), pal.onSpecial)
            setOnClickListener { onClick() }
        }
    }

    private fun posChipRow(options: List<String>, selected: Int, onSelect: (Int) -> Unit) = LinearLayout(ui).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        layoutParams = LinearLayout.LayoutParams(-1, dpi(44))
        options.forEachIndexed { i, t ->
            addView(TextView(ui).apply {
                text = t
                gravity = Gravity.CENTER
                textSize = 13f
                maxLines = 1
                val sel = i == selected
                setTextColor(if (sel) pal.onAccent else pal.onSpecial)
                background = roundedBg(if (sel) pal.keyAccent else pal.keySpecial, dpi(16).toFloat(), if (sel) pal.onAccent else pal.onSpecial)
                layoutParams = LinearLayout.LayoutParams(0, dpi(38), 1f).apply { setMargins(dpi(3), 0, dpi(3), 0) }
                setOnClickListener { onSelect(i) }
            })
        }
    }

    private fun customKey(t: String): KeyView {
        if (t.length == 1) return charKey(t[0], Style.SPECIAL)
        val k = newKey(t, 1f, Style.SPECIAL)
        k.onDown = { feedback(false); finishWord(); commit(t) }
        return k
    }

    private fun deadKey(c: Char): KeyView {
        val k = newKey(c.toString(), 1f, Style.SPECIAL)
        k.onDown = {
            feedback(false)
            pendingAccent = if (pendingAccent == c) null else c
            updateAccentUi()
        }
        deadKeys[c] = k
        return k
    }

    private fun updateAccentUi() {
        val changed = lastAccent != pendingAccent
        lastAccent = pendingAccent
        for ((c, k) in deadKeys) {
            val on = pendingAccent == c
            applyStyle(k, if (on) Style.ACCENT else Style.SPECIAL)
            if (changed && prefs.fluid && (on || lastAccent == null)) k.pop(if (on) 0.8f else 0.92f, 0L, 700f, 0.42f)
        }
    }

    private fun deleteKey(w: Float = 1.5f): KeyView {
        val k = newKey("", w, Style.SPECIAL)
        k.icon = KeyView.ICON_BACKSPACE
        val repeat = object : Runnable {
            override fun run() {
                backspace(); k.kick(-3f)
                // repetindo: o som/vibração não tocam a cada apagada (virava "metralhadora"), só num ritmo calmo e mais suave
                val now = android.os.SystemClock.uptimeMillis()
                if (now - delFxT >= 170L) { delFxT = now; feedback(false, SoundBank.Slot.DELETE, soft = true) }
                main.postDelayed(this, (50f / AnimCfg.repeatSpeed).toLong().coerceAtLeast(12L))
            }
        }
        k.onDown = {
            // guarda o caractere que este toque vai apagar: se virar um deslize, devolvemos (ver onSlideStart)
            delJustDeleted = if (prefs.deleteSlide) currentInputConnection?.let { ic ->
                if (ic.getSelectedText(0) != null) null else ic.getTextBeforeCursor(1, 0)?.toString()?.takeIf { it.isNotEmpty() }
            } else null
            feedback(false, SoundBank.Slot.DELETE); backspace(); k.kick(-6f); main.removeCallbacks(repeat); main.postDelayed(repeat, (400f / AnimCfg.repeatSpeed).toLong())
        }
        k.onUp = { main.removeCallbacks(repeat) }
        // v65.5 (gesto do Gboard): segure o apagar e deslize para a esquerda = seleciona palavra por palavra; ao soltar, apaga
        k.onSlideStart = {
            main.removeCallbacks(repeat)
            delAcc = 0f; delSelLen = 0; delAnchor = -1
            val ic = currentInputConnection
            if (prefs.deleteSlide && ic != null) {
                delJustDeleted?.let { ic.commitText(it, 1) }          // desfaz o apagão do toque inicial
                val ex = ic.getExtractedText(android.view.inputmethod.ExtractedTextRequest(), 0)
                if (ex != null && ex.selectionStart == ex.selectionEnd) {
                    delAnchor = ex.startOffset + ex.selectionEnd
                    delStops = wordStops(ic.getTextBeforeCursor(400, 0)?.toString() ?: "")
                }
                resetWord()
            }
            delJustDeleted = null
        }
        k.onSlideMove = { dx ->
            val ic = currentInputConnection
            if (delAnchor >= 0 && ic != null) {
                delAcc += dx
                val n = ((-delAcc) / (cursorStepPx() * 3f)).toInt().coerceIn(0, delStops.size)
                val len = if (n == 0) 0 else delStops[n - 1]
                if (len != delSelLen) { delSelLen = len; ic.setSelection(delAnchor - len, delAnchor); feedback(false, SoundBank.Slot.DELETE) }
            }
        }
        k.onSlideEnd = {
            val ic = currentInputConnection
            if (delAnchor >= 0 && ic != null && delSelLen > 0) { ic.commitText("", 1); resetWord() }
            delAnchor = -1; delSelLen = 0
        }
        return k
    }

    private var delJustDeleted: String? = null
    private var delAnchor = -1
    private var delSelLen = 0
    private var delAcc = 0f
    private var delStops = IntArray(0)

    /** Comprimentos acumulados, do cursor para trás, a cada palavra (pula espaços e depois a palavra). */
    private fun wordStops(s: String): IntArray {
        val out = ArrayList<Int>()
        var i = s.length
        while (i > 0) {
            while (i > 0 && s[i - 1].isWhitespace()) i--
            while (i > 0 && !s[i - 1].isWhitespace()) i--
            out.add(s.length - i)
        }
        return out.toIntArray()
    }

    // ---------- Ações de digitação ----------

    private fun commit(s: String) { currentInputConnection?.commitText(s, 1) }

    private fun resetWord() {
        word.setLength(0); updateSuggestions()
    }

    // ---------- Vietnamita (Telex) ----------

    /** Refaz o estado do Telex a partir do que está na tela (depois de apagar, de escolher variação ou de o cursor mexer). */
    private fun viResync() {
        val w = word.toString()
        val raw = Telex.toRaw(w)
        viRaw.setLength(0)
        if (w.isNotEmpty() && Telex.compose(raw) == w) { viRaw.append(raw); viFrozen = "" }
        else viFrozen = w                       // palavra que o Telex não reproduz igual: fica como está, sem recompor
        viShown = w
    }

    /** Uma letra no Telex: a palavra inteira é recomposta (aa → â, dd → đ, s/f/r/x/j = tons) e só a ponta que mudou é reescrita. */
    private fun onViChar(s: String) {
        val ic = currentInputConnection ?: return
        if (word.toString() != viShown) viResync()
        var old = word.toString()
        viRaw.append(s)
        var disp = viFrozen + Telex.compose(viRaw)
        var common = 0
        while (common < old.length && common < disp.length && old[common] == disp[common]) common++
        if (old.length > common && ic.getTextBeforeCursor(old.length, 0)?.toString() != old) {
            // o cursor mudou por fora: começa uma palavra nova em vez de apagar texto que não é nosso
            word.setLength(0); old = ""
            viRaw.setLength(0); viRaw.append(s); viFrozen = ""
            disp = Telex.compose(viRaw); common = 0
        }
        ic.beginBatchEdit()
        if (old.length > common) ic.deleteSurroundingText(old.length - common, 0)
        ic.commitText(disp.substring(common), 1)
        ic.endBatchEdit()
        word.setLength(0); word.append(disp); viShown = disp
        sentenceEnd = false
        if (shift && !caps) { shift = false; refreshShiftUi() }
        updateSuggestions()
    }

    private fun onChar(c: Char, letterKey: Boolean) { onCharFeedback(c, letterKey); onCharCommit(c, letterKey) }

    private fun onCharFeedback(c: Char, letterKey: Boolean) { feedback(false, SoundBank.Slot.of(c, letterKey), c) }

    /** Variação escolhida ao segurar (a letra base ainda NÃO foi digitada, no modo "digitar ao soltar"). */
    private fun insertAlt(alt: String) {
        val ic = currentInputConnection ?: return
        val letterAlt = alt.isNotEmpty() && alt[0].isLetter()
        if (!letterAlt) finishWord()
        ic.commitText(alt, 1)
        if (letterAlt) { word.append(alt); sentenceEnd = false }
        else sentenceEnd = alt == "." || alt == "!" || alt == "?"
        if (shift && !caps) { shift = false; refreshShiftUi() }
        updateSuggestions()
    }

    private fun onCharCommit(c: Char, letterKey: Boolean) {
        if (letterKey && viOn() && c in 'a'..'z' && pendingAccent == null) { onViChar(if (shift) c.uppercase() else c.toString()); return }
        var s = c.toString()
        if (letterKey && shift) s = up(s)
        val acc = pendingAccent
        if (acc != null) { pendingAccent = null; updateAccentUi() }
        val isLetter = s[0].isLetter()

        if (isLetter) {
            var out = s
            if (acc != null) out = composeAccent(acc, s) ?: (acc.toString() + s)
            commit(out)
            word.append(out)
            sentenceEnd = false
            if (shift && !caps) { shift = false; refreshShiftUi() }
            updateSuggestions()
        } else {
            if (acc != null) commit(acc.toString())
            finishWord()
            if (ar) s = when (s) { "," -> "،"; "?" -> "؟"; ";" -> "؛"; else -> s }   // vírgula, interrogação e ponto e vírgula árabes
            commit(s)
            sentenceEnd = s == "." || s == "!" || s == "?" || s == "؟"
            if (shift && !caps) { shift = false; refreshShiftUi() }
            updateSuggestions()
        }
    }

    private fun composeAccent(acc: Char, s: String): String? {
        if (s.length != 1) return null
        val lower = s[0].lowercaseChar()
        val r = (if (acc == '´') acute[lower] else tilde[lower]) ?: return null
        return if (s[0].isUpperCase()) r.uppercaseChar().toString() else r.toString()
    }

    // ---------- Barra de espaço: deslizar para mover o cursor ----------

    private var spaceTaps = 0
    private var spaceSlid = false
    private var spaceSlideAcc = 0f

    private fun cursorStepPx(): Float = dpi(11).toFloat()

    /** Move o cursor do texto n caracteres (negativo = esquerda). */
    private fun moveCursorBy(n: Int) {
        val ic = currentInputConnection ?: return
        val code = if (n < 0) KeyEvent.KEYCODE_DPAD_LEFT else KeyEvent.KEYCODE_DPAD_RIGHT
        val t = android.os.SystemClock.uptimeMillis()
        ic.beginBatchEdit()
        repeat(Math.abs(n)) {
            ic.sendKeyEvent(KeyEvent(t, t, KeyEvent.ACTION_DOWN, code, 0))
            ic.sendKeyEvent(KeyEvent(t, t, KeyEvent.ACTION_UP, code, 0))
        }
        ic.endBatchEdit()
        if (prefs.vibrate) rootView?.performHapticFeedback(android.view.HapticFeedbackConstants.CLOCK_TICK)
    }

    /** Esconde as teclas e mostra a área "Arraste o dedo aqui" (o dedo continua o mesmo gesto). */
    private fun openCursorPad() {
        if (activePanel === cursorPad) return
        val pad = cursorPad ?: CursorPad(ui).also { p ->
            p.onMoveChars = { n -> if (word.isNotEmpty()) resetWord(); moveCursorBy(n) }
            p.onExit = { showPanel(keysContainer) }
            cursorPad = p
        }
        pad.bg = pal.keySpecial
        pad.fg = pal.onSpecial
        pad.radius = dpi(prefs.keyRadius).toFloat()
        pad.stepPx = cursorStepPx()
        pad.hint = "Arraste o dedo aqui".tr()
        showPanel(pad)
    }

    private fun onSpace() {
        val acc = pendingAccent
        if (acc != null) { pendingAccent = null; updateAccentUi(); commit(acc.toString()) }
        finishWord()
        commit(" ")
        if (sentenceEnd && prefs.autoCaps && smart && !ar && !shift) { shift = true; refreshShiftUi() }
        sentenceEnd = false
        updateSuggestions()
    }

    /** Fecha a palavra atual: autocorrige (se ativado) ou aprende; guarda para "próxima palavra". */
    private fun finishWord() {
        if (word.isEmpty()) return
        val w = word.toString()
        word.setLength(0)
        var finalWord = w
        if (smart) {
            val fix = if (prefs.autoCorrect) sugg.correct(w) else null
            if (fix != null && replaceBeforeCursor(w, fix)) finalWord = fix
            else {
                sugg.learn(w)
                if (prefs.autoCorrect && prefs.preciseCorrect) trySystemCorrect(w)
            }
        }
        prevWord = finalWord
    }

    /**
     * Reforço opcional ("Melhorar precisão do corretor"): quando o dicionário embutido não achou
     * nada, pergunta ao corretor ortográfico do próprio Android (bem maior, no idioma do teclado).
     * A resposta chega depois, então só aplica se a palavra ainda estiver intacta bem antes do
     * cursor (o mesmo teste que replaceBeforeCursor já faz) — senão, o usuário já seguiu em frente
     * e mexer no texto seria pior que não corrigir.
     */
    private fun trySystemCorrect(w: String) {
        if (w.length < 4 || w.any { !it.isLetter() }) return
        if (w[0].isUpperCase() && w.drop(1).all { it.isLowerCase() }) return   // nome próprio: não mexe
        sysDict.suggest(w, prefs.language) { list ->
            val best = list.firstOrNull { it.isNotEmpty() && !it.equals(w, ignoreCase = true) } ?: return@suggest
            if (Math.abs(best.length - w.length) > 2) return@suggest
            val cased = if (w[0].isUpperCase()) best.replaceFirstChar { it.uppercase() } else best
            if (replaceBeforeCursor(w, cased)) sugg.learn(best.lowercase())
        }
    }

    private fun replaceBeforeCursor(old: String, new: String): Boolean {
        val ic = currentInputConnection ?: return false
        val before = ic.getTextBeforeCursor(old.length, 0)?.toString()
        if (before != old) return false          // o cursor mudou: não mexe no texto
        ic.beginBatchEdit()
        ic.deleteSurroundingText(old.length, 0)
        ic.commitText(new, 1)
        ic.endBatchEdit()
        return true
    }

    private fun applySuggestion(t: String) {
        if (t.isEmpty()) return
        feedback(false)
        val gl = glideLast
        if (gl != null && word.isEmpty() && t in glideAlts && replaceBeforeCursor(gl, "$t ")) {
            // acabou de deslizar: tocar numa das opções troca a palavra inserida (e as opções continuam ali)
            glideLast = "$t "; prevWord = t
            setSuggestionTexts(glideAlts.take(3))
            return
        }
        val w = word.toString()
        if (w.isNotEmpty()) {
            if (!replaceBeforeCursor(w, t)) commit(t)
            commit(" ")
        } else commit("$t ")
        word.setLength(0)
        prevWord = t
        sentenceEnd = false
        updateSuggestions()
    }

    private fun backspace() {
        // DEL apaga a seleção, se houver, ou o caractere anterior: sem consulta ao app (rápido).
        sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL)
        if (word.isNotEmpty()) word.setLength(word.length - 1)
        if (viOn()) viResync()                  // Telex: refaz as teclas a partir do que ficou na tela (apagar "việt" → "việ")
        updateSuggestions()
    }

    private fun onShift() {
        val now = System.currentTimeMillis()
        if (now - lastShiftTap < 350) { caps = true; shift = true }   // toque duplo = CAPS LOCK
        else if (caps) { caps = false; shift = false }
        else { shift = !shift }
        lastShiftTap = now
        refreshShiftUi()
    }

    /** Atualiza só os rótulos/cores (sem recriar as teclas). */
    private fun refreshShiftUi() {
        for (lk in letterKeys) lk.view.label = if (shift) up(lk.ch.toString()) else lk.ch.toString()
        if (prefs.fluid && (lastShift != shift || lastCaps != caps)) {      // onda de letras ao trocar maiúscula/minúscula
            letterKeys.forEachIndexed { i, lk -> lk.view.pop(0.9f, (i % 10) * 14L, 700f, 0.5f) }
            shiftKey?.pop(0.78f, 0L, 700f, 0.4f)
        }
        lastShift = shift; lastCaps = caps
        shiftKey?.let {
            it.icon = if (caps) KeyView.ICON_CAPS else KeyView.ICON_SHIFT
            applyStyle(it, if (shift) Style.ACCENT else Style.SPECIAL)
        }
    }

    private fun onEnter() {
        finishWord()
        prevWord = ""
        val opts = currentInputEditorInfo?.imeOptions ?: 0
        val action = opts and EditorInfo.IME_MASK_ACTION
        if (opts and EditorInfo.IME_FLAG_NO_ENTER_ACTION != 0 ||
            action == EditorInfo.IME_ACTION_NONE ||
            action == EditorInfo.IME_ACTION_UNSPECIFIED
        ) {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER)
            if (prefs.autoCaps && smart && !ar && !shift) { shift = true; refreshShiftUi() }
        } else currentInputConnection?.performEditorAction(action)
        sentenceEnd = false
        updateSuggestions()
    }

    // ---------- Sugestões (consulta fora da thread principal) ----------

    private fun updateSuggestions() {
        if (suggViews.isEmpty()) return
        val on = smart && (prefs.suggestions || prefs.nextWord)
        val seq = ++suggSeq
        if (!on) { setSuggestionTexts(emptyList()); return }
        val w = word.toString()
        if (w.isNotEmpty() && afShown) clearAutofill()
        val prev = prevWord
        val wantComplete = prefs.suggestions
        val wantNext = prefs.nextWord
        runSugg {
            if (seq != suggSeq) return@runSugg      // já veio outra tecla: descarta esta consulta
            val list: List<String> =
                if (w.isNotEmpty()) { if (wantComplete) sugg.complete(w) else emptyList() }
                else if (wantNext) sugg.next(prev) else emptyList()
            main.post { if (seq == suggSeq) setSuggestionTexts(list) }
        }
    }

    private fun setSuggestionTexts(list: List<String>) {
        if (list.none { it.isNotEmpty() }) {
            if (stripShown) { main.removeCallbacks(hideStrip); main.postDelayed(hideStrip, 220) }   // pequena folga: sem piscar
            return
        }
        main.removeCallbacks(hideStrip)
        var first = true
        for (i in suggViews.indices) {
            val tv = suggViews[i]
            val t = list.getOrNull(i) ?: ""
            val has = t.isNotEmpty()
            val hi = has && first            // a primeira sugestão é a destacada (cor de destaque)
            if (has) first = false
            val vis = if (has) View.VISIBLE else View.GONE
            if (tv.visibility != vis) tv.visibility = vis
            val wasHi = tv.tag == true
            if (hi != wasHi) {
                tv.tag = hi
                tv.background = roundedBg(if (hi) pal.keyAccent else pal.keySpecial, dpi(20).toFloat(), if (hi) pal.onAccent else pal.onSpecial)
                tv.setTextColor(if (hi) pal.onAccent else pal.onSpecial)
            }
            if (tv.text.toString() != t) {                    // não força novo layout se nada mudou
                tv.text = t
                if (prefs.fluid && has) tv.pop(0.78f, 40L * i, 520f, 0.46f)
            }
            tv.isClickable = has
        }
        showStrip(true)
    }

    /** Troca os ícones da barra pelas sugestões (e volta), com fade curto. */
    private fun showStrip(on: Boolean) {
        val s = strip ?: return
        val t = toolbar ?: return
        if (on == stripShown) return
        stripShown = on
        pillBgView?.animate()?.cancel()
        pillBgView?.animate()?.alpha(if (on) 0f else 1f)?.setDuration(if (prefs.fluid) 220 else 110)?.start()
        val inc = if (on) s else t
        val out = if (on) t else s
        inc.animate().cancel(); out.animate().cancel()
        inc.visibility = View.VISIBLE
        if (prefs.fluid) {          // quem entra desliza com mola (sugestões sobem, ícones descem)
            inc.translationY = dpi(if (on) 9 else -9).toFloat()
            inc.springTo(DynamicAnimation.TRANSLATION_Y, 0f, 520f, 0.7f)
        }
        inc.animate().alpha(1f).setDuration(110).start()
        out.animate().alpha(0f).setDuration(110).withEndAction {
            if (stripShown == on) {
                out.visibility = View.INVISIBLE
                if (!on) for (tv in suggViews) { tv.text = ""; tv.isClickable = false }
            }
        }.start()
    }

    // ---------- Vibração e som (fora da thread principal) ----------

    private var delFxT = 0L

    private fun feedback(space: Boolean, slot: Int = -1, clipChar: Char? = null, soft: Boolean = false) {
        val vib = prefs.vibrate && (!space || prefs.vibrateOnSpace)
        val snd = prefs.sound && prefs.soundVolume > 0
        if (!vib && !snd) return
        val strength = if (soft) prefs.vibrateStrength * 6 / 10 else prefs.vibrateStrength
        val own = if (slot in 0 until SoundBank.Slot.COUNT) prefs.keySounds[slot] else -1
        val type = if (own >= 0) own else prefs.soundType
        val clip = SoundBank.Slot.clip(slot) ?: clipChar?.let { SoundBank.clipOf(it) } ?: "a"
        lastUp = if (snd) Pair(type, clip) else null
        val vol = prefs.soundVolume / 100f * (if (soft) 0.55f else 1f)
        val pitch = prefs.soundPitch / 100f
        val human = prefs.soundHumanize
        runFx {
            if (vib) try {
                val v = vibrator
                if (v != null && v.hasVibrator()) {
                    val ms = 8L + strength / 5
                    val amp = if (v.hasAmplitudeControl()) (strength * 255 / 100).coerceIn(1, 255) else VibrationEffect.DEFAULT_AMPLITUDE
                    v.vibrate(VibrationEffect.createOneShot(ms, amp))
                }
            } catch (_: Exception) { }
            if (snd) sounds?.play(type, clip, vol, pitch, human)
        }
    }

    /** Toca o som de soltar da tecla (se o pacote tiver). */
    private fun playRelease(p: Pair<Int, String>) {
        if (!(prefs.sound && prefs.soundVolume > 0)) return
        val vol = prefs.soundVolume / 100f; val pitch = prefs.soundPitch / 100f; val human = prefs.soundHumanize
        runFx { sounds?.play(p.first, p.second + "_up", vol, pitch, human) }
    }

    companion object {
        @Volatile private var instance: KeyboardService? = null

        /** O [KeyView] pega, logo após o onDown, o que tocar quando soltar. */
        fun takeUp(): Pair<Int, String>? { val s = instance ?: return null; val r = s.lastUp; s.lastUp = null; return r }
        fun playUp(p: Pair<Int, String>?) { if (p != null) instance?.playRelease(p) }

        /** Chamado pela [VoiceInputActivity] com o texto reconhecido. */
        fun deliverVoice(text: String) {
            val svc = instance ?: return
            svc.main.post {
                svc.pendingVoice = text
                svc.main.postDelayed({ svc.flushVoice() }, 450)
            }
        }
    }
}

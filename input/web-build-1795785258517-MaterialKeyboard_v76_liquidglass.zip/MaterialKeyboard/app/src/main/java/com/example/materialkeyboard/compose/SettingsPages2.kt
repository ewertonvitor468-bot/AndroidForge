package com.example.materialkeyboard.compose

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.foundation.layout.heightIn
import androidx.compose.ui.unit.sp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.materialkeyboard.BarShapes
import com.example.materialkeyboard.KeyShapes
import com.example.materialkeyboard.L
import com.example.materialkeyboard.PopupShapeTile
import com.example.materialkeyboard.PopupShapes
import com.example.materialkeyboard.Prefs
import com.example.materialkeyboard.R
import com.example.materialkeyboard.ShapeTile
import com.example.materialkeyboard.SoundBank
import com.example.materialkeyboard.tr

private val pop2 = spring<Float>(Spring.DampingRatioMediumBouncy, Spring.StiffnessMedium)

class KeysHooks(val style: (Int) -> Unit, val shape: (Int) -> Unit, val font: (Int) -> Unit, val glow: (Boolean) -> Unit)
class SoundHooks(val pickGeneral: () -> Unit, val pickKey: (Int) -> Unit, val add: () -> Unit, val removeAll: () -> Unit, val resetKeys: () -> Unit)

/** Faixa de formatos (miniaturas) com seleção elástica. */
@Composable
fun PageCtx.ShapeRow(names: List<String>, current: Int, same: Boolean, popup: Boolean, onPick: (Int) -> Unit) {
    val cs = MaterialTheme.colorScheme
    val on = cs.primary.toArgb(); val off = cs.secondaryContainer.toArgb()
    var cur by remember(current) { mutableIntStateOf(current) }
    val ids = (if (same) listOf(-1) else emptyList()) + names.indices.toList()
    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(vertical = 10.dp)) {
        items(ids) { id ->
            val sel = cur == id
            val sc by animateFloatAsState(if (sel) 1.1f else 1f, pop2, label = "shape")
            Column(
                Modifier.scale(sc).clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { cur = id; onPick(id) },
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(Modifier.size(72.dp, 52.dp)) {
                    if (id < 0) Box(Modifier.fillMaxSize().clip(RoundedCornerShape(14.dp)).background(if (sel) cs.primary else cs.secondaryContainer),
                        contentAlignment = Alignment.Center) { Text("=", color = if (sel) cs.onPrimary else cs.onSecondaryContainer, fontWeight = FontWeight.Bold) }
                    else key(sel) {
                        AndroidView({ c -> if (popup) PopupShapeTile(c, id, sel, on, off) else ShapeTile(c, id, sel, on, off) }, Modifier.fillMaxSize())
                    }
                }
                Text(if (id < 0) "Igual".tr() else names[id].tr(), color = cs.onSurface, style = MaterialTheme.typography.labelSmall,
                    modifier = Modifier.padding(top = 4.dp))
            }
        }
    }
}

/** Pílulas roláveis para escolher uma opção. */
@Composable
fun PageCtx.ChipRow(options: List<String>, sel: Int, onSel: (Int) -> Unit) {
    val cs = MaterialTheme.colorScheme
    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(vertical = 10.dp)) {
        itemsIndexed(options) { i, t ->
            val bg by animateColorAsState(if (i == sel) cs.primary else cs.onSurface.copy(alpha = 0.08f), label = "chip")
            Box(Modifier.clip(CircleShape).background(bg).clickable { onSel(i) }.heightIn(min = 44.dp).padding(horizontal = 18.dp, vertical = 11.dp)) {
                Text(t, color = if (i == sel) cs.onPrimary else cs.onSurface, fontSize = 15.sp, fontWeight = FontWeight.Medium)
            }
        }
    }
}

@Composable
fun PageCtx.MkRow(text: String, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Row(Modifier.fillMaxWidth().rowLine(lineColor()).clickable(onClick = onClick).heightIn(min = 60.dp).padding(vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(text, color = cs.onSurface, fontSize = 17.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f).padding(end = 10.dp))
        Icon(painterResource(R.drawable.ic_chevron), null, tint = cs.onSurface.copy(alpha = 0.45f))
    }
}

@Composable
private fun PageCtx.Label(t: String) = Text(t, color = MaterialTheme.colorScheme.onSurface, fontWeight = FontWeight.Medium,
    modifier = Modifier.padding(top = 12.dp))

@Composable
fun KeysScreen(prefs: Prefs, h: KeysHooks) = PageHost(prefs) {
    MkCard("Liquid Glass") {
        MkSwitch("Ativar Liquid Glass".tr(), "Vidro com lente e brilho por cima do tema atual, sem trocar de tema".tr(), prefs.liquidGlass) {
            prefs.putBool("liquidGlass", it); h.style(if (it) 3 else prefs.keyStyle); refresh()
        }
        AnimatedVisibility(prefs.liquidGlass) {
            MkNote("Com o Liquid Glass ligado, o estilo escolhido abaixo só volta quando você desligar.".tr())
        }
    }
    MkCard("Estilo das teclas".tr()) {
        Label("Visual".tr())
        ChipRow(listOf("Material You".tr(), "iOS", "One UI", "Vidro".tr(), "Mecânico".tr()), prefs.keyStyle.coerceIn(0, 4)) { prefs.putInt("keyStyle", it); h.style(prefs.activeKeyStyle); refresh() }
        AnimatedVisibility(prefs.activeKeyStyle == 3) {
            MkSlider("Desfoque do fundo (estilo Vidro)".tr(), prefs.blurAmount, 0, 100, "%") { prefs.putInt("blurAmount", it) }
        }
    }
    MkCard("Borda e profundidade".tr()) {
        MkSlider("Borda das teclas".tr(), prefs.keyBorder, 0, 6, "dp") { prefs.putInt("keyBorder", it) }
        MkSlider("Profundidade 3D das teclas".tr(), prefs.keyDepth, 0, 8, "dp") { prefs.putInt("keyDepth", it) }
        MkSwitch("Formas livres nas teclas".tr(), "Liga os formatos escolhidos (Enter em cookie, flor...) no lugar do visual uniforme".tr(), !prefs.expressive) {
            prefs.putBool("expressive", !it); refresh()
        }
    }
    MkCard("Microfone e barra".tr()) {
        Label("Formato do microfone".tr())
        ChipRow(BarShapes.NAMES.map { it.tr() }, prefs.micShape.coerceIn(0, BarShapes.NAMES.size - 1)) { prefs.putInt("micShape", it); refresh() }
        Label("Formato do botão de seta".tr())
        ChipRow(BarShapes.NAMES.map { it.tr() }, prefs.toolShape.coerceIn(0, BarShapes.NAMES.size - 1)) { prefs.putInt("toolShape", it); refresh() }
        Label("Faixa de ícones".tr())
        ChipRow(listOf("Pílula", "Reta", "Retangular").map { it.tr() }, prefs.barStyle.coerceIn(0, 2)) { prefs.putInt("barStyle", it); refresh() }
    }
    MkCard("Teclas personalizadas".tr()) {
        val lefts = listOf(",", "@", "/", "-"); val rights = listOf(".", ".com", "?", "!")
        Label("Tecla à esquerda do espaço".tr())
        ChipRow(lefts, lefts.indexOf(prefs.keyLeft).coerceAtLeast(0)) { prefs.putString("keyLeft", lefts[it]); refresh() }
        Label("Tecla à direita do espaço".tr())
        ChipRow(rights, rights.indexOf(prefs.keyRight).coerceAtLeast(0)) { prefs.putString("keyRight", rights[it]); refresh() }
    }
    MkCard("Teclas (BARRA DE ESPAÇO)".tr()) {
        Label("Ao deslizar a barra de espaço".tr())
        ChipRow(listOf("Deslizar com modo cursor".tr(), "Deslizar padrão (Gboard)".tr()),
            if (prefs.spaceSlide == Prefs.SPACE_SLIDE_CURSOR) 0 else 1) {
            prefs.putInt("spaceSlide", if (it == 0) Prefs.SPACE_SLIDE_CURSOR else Prefs.SPACE_SLIDE_GBOARD); refresh()
        }
        MkNote("Com modo cursor, as teclas somem e aparece \"Arraste o dedo aqui\": deslize para os lados para mover o cursor, como no iPhone. Para voltar ao teclado, toque ou deslize para cima/baixo. No modo padrão, só o cursor anda e as teclas continuam visíveis, como no Gboard.".tr())
    }
    MkCard("Gestos".tr()) {
        MkSwitch("Digitar ao soltar".tr(), "A letra só aparece quando você levanta o dedo. Desligado: aparece assim que encosta.".tr(), prefs.typeOnRelease) { prefs.putBool("typeOnRelease", it); refresh() }
        MkSwitch("Deslizar no apagar".tr(), "Segure o apagar e deslize para a esquerda para selecionar palavras; ao soltar, o texto selecionado é apagado.".tr(), prefs.deleteSlide) { prefs.putBool("deleteSlide", it); refresh() }
    }
    MkCard("Formato das teclas".tr()) {
        ShapeRow(KeyShapes.NAMES, prefs.keyShape, false, false) { prefs.putInt("keyShape", it); h.shape(it) }
    }
    MkCard("Formato do Enter e destaques".tr()) {
        ShapeRow(KeyShapes.NAMES, prefs.accentShape - 1, true, false) { prefs.putInt("accentShape", it + 1) }
    }
    MkCard("Detalhes".tr()) {
        MkSlider("Espaço entre as teclas".tr(), prefs.keyGap, 1, 8, "dp") { prefs.putInt("keyGap", it) }
        Label("Fonte".tr())
        ChipRow(listOf("Padrão".tr(), "Black", "Serif", "Mono", "Casual".tr(), "Fina".tr()), prefs.fontStyle.coerceIn(0, 5)) {
            prefs.putInt("fontStyle", it); h.font(it); refresh()
        }
        MkSwitch("Brilho ao tocar".tr(), "Uma onda de luz se espalha a partir do dedo".tr(), prefs.pressGlow) {
            prefs.putBool("pressGlow", it); h.glow(it); refresh()
        }
    }
}

@Composable
fun PreviewScreen(prefs: Prefs) = PageHost(prefs) {
    MkCard {
        MkSwitch("Popup ao tocar na tecla".tr(), "Mostra a letra ampliada acima do dedo".tr(), prefs.keyPreview) { prefs.putBool("keyPreview", it); refresh() }
    }
    AnimatedVisibility(prefs.keyPreview) {
        Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
            MkCard("Visual".tr()) {
                Label("Formato".tr())
                ShapeRow(PopupShapes.NAMES, prefs.previewShape, false, true) { prefs.putInt("previewShape", it) }
                Label("Cor".tr())
                ChipRow(listOf("Destaque".tr(), "Especial".tr(), "Tecla".tr(), "Minha cor".tr()), prefs.previewColor) { prefs.putInt("previewColor", it); refresh() }
                AnimatedVisibility(prefs.previewColor == 3) { MkSlider("Matiz da cor".tr(), prefs.previewHue, 0, 360, "°") { prefs.putInt("previewHue", it) } }
                MkSlider("Tamanho do popup".tr(), prefs.previewSize, 70, 160, "%") { prefs.putInt("previewSize", it) }
            }
            MkCard("Animação".tr()) {
                MkSwitch("Animar o popup".tr(), "O balão cresce rapidamente ao aparecer".tr(), prefs.previewAnim) { prefs.putBool("previewAnim", it); refresh() }
            }
        }
    }
    MkCard("Acentos e idiomas (segurar a tecla)".tr()) {
        Label("Formato das bolhas".tr())
        ShapeRow(PopupShapes.NAMES, prefs.altShape, false, true) { prefs.putInt("altShape", it) }
    }
}

@Composable
fun FeedbackScreen(prefs: Prefs, h: SoundHooks) = PageHost(prefs) {
    val ctx = LocalContext.current
    MkCard("Vibração".tr()) {
        MkSwitch("Vibrar ao pressionar".tr(), "Feedback tátil a cada tecla".tr(), prefs.vibrate) { prefs.putBool("vibrate", it); refresh() }
        MkSlider("Intensidade da vibração".tr(), prefs.vibrateStrength, 1, 100, "%") { prefs.putInt("vibrateStrength", it) }
        MkSwitch("Vibrar ao pressionar espaço".tr(), null, prefs.vibrateOnSpace) { prefs.putBool("vibrateOnSpace", it); refresh() }
    }
    MkCard("Som".tr()) {
        MkSwitch("Som das teclas".tr(), null, prefs.sound) { prefs.putBool("sound", it); refresh() }
        MkSlider("Volume do som".tr(), prefs.soundVolume, 0, 100, "%") { prefs.putInt("soundVolume", it) }
        MkRow(L.f("Som das teclas: %s", SoundBank.label(prefs.soundType)), h.pickGeneral)
        MkRow("＋ Adicionar som de um arquivo (wav, mp3, ogg)".tr(), h.add)
        val n = SoundBank.customFiles(ctx).size
        if (n > 0) MkRow(L.f("Remover meus sons (%d)", n), h.removeAll)
        MkSlider("Tom do som".tr(), prefs.soundPitch, 50, 200, "%") { prefs.putInt("soundPitch", it) }
        MkSwitch("Variação natural".tr(), "Muda o tom levemente a cada toque, como um teclado real".tr(), prefs.soundHumanize) { prefs.putBool("soundHumanize", it); refresh() }
    }
    MkCard("Som individual por tecla".tr()) {
        MkNote("Escolha um som diferente para cada tecla. \"Padrão\" usa o som geral. As bordas são ç, 1 e 0, além de ⇧ e ?123.".tr())
        SoundBank.Slot.NAMES.forEachIndexed { i, name ->
            val cur = prefs.keySounds[i]
            MkRow(L.f("%s: %s", name.tr(), if (cur < 0) "Padrão".tr() else SoundBank.label(cur))) { h.pickKey(i) }
        }
        MkAction("Redefinir sons por tecla".tr(), false, h.resetKeys)
    }
}

package com.example.materialkeyboard

import android.content.Context
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Path
import android.graphics.Shader
import android.animation.ValueAnimator
import android.view.animation.DecelerateInterpolator
import android.graphics.RectF
import android.graphics.Typeface
import android.os.Build
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.widget.LinearLayout
import androidx.core.graphics.ColorUtils
import androidx.dynamicanimation.animation.DynamicAnimation
import androidx.dynamicanimation.animation.FloatPropertyCompat
import androidx.dynamicanimation.animation.SpringAnimation
import androidx.dynamicanimation.animation.SpringForce

/**
 * Paleta do teclado. IMPORTANTE (bug do modo escuro): antes as cores das teclas vinham direto das
 * cores tonais do sistema (system_neutral1_800 etc.). Em alguns aparelhos (ex.: Xiaomi/HyperOS) esses
 * valores chegam trocados dentro de um serviço de teclado e as teclas ficavam CLARAS com texto claro
 * (letras invisíveis). Agora o sistema só fornece o matiz (accent1_500) e todos os tons são calculados
 * aqui, com contraste garantido entre tecla e texto.
 */
/** Tema pronto: cores fixas (não dependem do Android). */
class Preset(
    val name: String, val dark: Boolean,
    val surface: Long, val normal: Long, val special: Long, val accent: Long,
    val onNormal: Long, val onSpecial: Long, val onAccent: Long
)

class Palette(
    val isDark: Boolean,
    val surface: Int, val keyNormal: Int, val keySpecial: Int, val keyAccent: Int,
    val onNormal: Int, val onSpecial: Int, val onAccent: Int, val onSurface: Int, val outline: Int,
    val image: Bitmap? = null
) {
    companion object {
        val PRESETS = listOf(
            Preset("Meia-noite", true,  0xFF000000, 0xFF1A1A1C, 0xFF2C2C30, 0xFF8AB4FF, 0xFFF2F2F2, 0xFFFFFFFF, 0xFF00204A),
            Preset("Oceano",     true,  0xFF08202E, 0xFF123A4F, 0xFF1B5670, 0xFF4FD1E8, 0xFFE8F6FB, 0xFFE8F6FB, 0xFF03303B),
            Preset("Floresta",   true,  0xFF0F1A12, 0xFF1C2E21, 0xFF2B4733, 0xFF7BD88F, 0xFFE6F2E8, 0xFFE6F2E8, 0xFF0B3017),
            Preset("Pôr do sol", true,  0xFF2A1220, 0xFF43203A, 0xFF6A2F45, 0xFFFF9E64, 0xFFFFEFE6, 0xFFFFEFE6, 0xFF4A1A00),
            Preset("Dracula",    true,  0xFF282A36, 0xFF3A3D4E, 0xFF44475A, 0xFFBD93F9, 0xFFF8F8F2, 0xFFF8F8F2, 0xFF282A36),
            Preset("Nord",       true,  0xFF2E3440, 0xFF3B4252, 0xFF4C566A, 0xFF88C0D0, 0xFFECEFF4, 0xFFECEFF4, 0xFF2E3440),
            Preset("Café",       true,  0xFF2B1D16, 0xFF3E2B21, 0xFF5A4032, 0xFFE0B07A, 0xFFF5E9DD, 0xFFF5E9DD, 0xFF3A2412),
            Preset("Neon",       true,  0xFF0A0A14, 0xFF15152A, 0xFF211B3F, 0xFF00F5D4, 0xFFE6E6FF, 0xFFE6E6FF, 0xFF00231E),
            Preset("Sakura",     false, 0xFFFCE8EF, 0xFFFFFFFF, 0xFFF7C9D9, 0xFFD6336C, 0xFF3A1020, 0xFF4A1530, 0xFFFFFFFF),
            Preset("Lavanda",    false, 0xFFEEE9FB, 0xFFFFFFFF, 0xFFD9CFF5, 0xFF6C4BD8, 0xFF1F1636, 0xFF2A1F4A, 0xFFFFFFFF),
            Preset("Menta",      false, 0xFFE3F5EC, 0xFFFFFFFF, 0xFFC4E8D5, 0xFF1F9D6B, 0xFF0E2A1E, 0xFF12382A, 0xFFFFFFFF),
            Preset("Papel",      false, 0xFFEFE6D2, 0xFFFBF6EA, 0xFFE2D5B8, 0xFF8B5E34, 0xFF2E2416, 0xFF3A2D1B, 0xFFFFFFFF),
            Preset("Expressive", true,  0xFF141318, 0xFF2B2930, 0xFF3A3741, 0xFFB8C7FF, 0xFFE6E0E9, 0xFFE6E0E9, 0xFF1B2D5C)
        )

        /** Tema pronto escolhido (ou null). Só vale quando não há imagem de fundo. */
        fun presetOf(p: Prefs): Preset? = if (p.themeImage) null else PRESETS.getOrNull(p.preset - 1)

        fun isDark(ctx: Context, p: Prefs): Boolean = presetOf(p)?.dark ?: Patches.of(p)?.dark ?: when (p.theme) {
            Prefs.THEME_DARK -> true
            Prefs.THEME_LIGHT -> false
            else -> (ctx.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
                Configuration.UI_MODE_NIGHT_YES
        }

        private fun seed(ctx: Context, p: Prefs): Int {
            if (p.useCustomColor) return p.customColor
            if (Build.VERSION.SDK_INT >= 31) {
                try { return ctx.getColor(android.R.color.system_accent1_500) } catch (_: Exception) { }
            }
            return 0xFF5B6EE1.toInt()
        }

        private fun hsv(h: Float, s: Float, v: Float) = Color.HSVToColor(floatArrayOf(h, s.coerceIn(0f, 1f), v.coerceIn(0f, 1f)))

        private fun contrast(a: Int, b: Int): Double {
            val l1 = ColorUtils.calculateLuminance(a); val l2 = ColorUtils.calculateLuminance(b)
            return (maxOf(l1, l2) + 0.05) / (minOf(l1, l2) + 0.05)
        }

        /** Garante contraste mínimo do texto sobre o fundo: se faltar, vai para branco/preto. */
        private fun readable(fg: Int, bg: Int): Int {
            if (contrast(fg, bg) >= 4.0) return fg
            val bgOpaque = ColorUtils.setAlphaComponent(bg, 255)
            return if (ColorUtils.calculateLuminance(bgOpaque) > 0.4) 0xFF111114.toInt() else 0xFFF4F2F7.toInt()
        }

        /** Paleta de um patch (com contraste garantido por readable()). Usada no teclado e nas prévias. */
        fun fromPatch(pt: Patch): Palette {
            val n = pt.normal.toInt(); val sp = pt.special.toInt(); val ac = pt.accent.toInt(); val sf = pt.surface.toInt()
            val on = readable(pt.onNormal.toInt(), n)
            val os = readable(pt.onSpecial.toInt(), sp)
            val oa = readable(pt.onAccent.toInt(), ac)
            val osf = readable(on, sf)
            return Palette(pt.dark, sf, n, sp, ac, on, os, oa, osf, ColorUtils.setAlphaComponent(osf, 40), null)
        }

        fun build(ctx: Context, p: Prefs): Palette {
            val b = buildBase(ctx, p)
            if (!p.fontColorOn) return b
            val f = p.fontColor or 0xFF000000.toInt()
            // só a fonte das teclas normais/especiais; ícones da barra e tecla de destaque ficam como estavam
            return Palette(b.isDark, b.surface, b.keyNormal, b.keySpecial, b.keyAccent, f, f, b.onAccent, b.onSurface, b.outline, b.image)
        }

        private fun buildBase(ctx: Context, p: Prefs): Palette {
            var dark = isDark(ctx, p)
            val bmp = if (p.themeImage) ThemeImage.get(ctx, p.themeImageRev) else null
            if (bmp != null) {
                // com imagem: o claro/escuro depende do brilho da foto já escurecida
                dark = ThemeImage.luminance() * (1f - p.imageDim / 100f) < 0.45f
            }
            val pr = if (bmp == null) presetOf(p) else null
            if (pr != null) {
                val n = pr.normal.toInt(); val sp = pr.special.toInt(); val ac = pr.accent.toInt(); val sf = pr.surface.toInt()
                val on = readable(pr.onNormal.toInt(), n)
                val os = readable(pr.onSpecial.toInt(), sp)
                val oa = readable(pr.onAccent.toInt(), ac)
                val osf = readable(on, sf)
                return Palette(pr.dark, sf, n, sp, ac, on, os, oa, osf, ColorUtils.setAlphaComponent(osf, 40), null)
            }
            if (bmp == null) Patches.of(p)?.let { return fromPatch(it) }   // patch ativo (com imagem, só o acabamento vale)
            val c = seed(ctx, p)
            val hh = FloatArray(3).also { Color.colorToHSV(c, it) }
            val h = hh[0]
            val sat = hh[1].coerceIn(0.25f, 1f)

            var surface: Int; var normal: Int; var special: Int; var accent: Int
            var onNormal: Int; var onSpecial: Int; var onAccent: Int
            if (dark) {
                surface = hsv(h, 0.10f * sat, 0.10f)
                normal = hsv(h, 0.12f * sat, 0.21f)
                special = hsv(h, 0.32f * sat, 0.34f)
                accent = hsv(h, 0.42f * sat, 0.98f)
                onNormal = hsv(h, 0.05f, 0.93f)
                onSpecial = hsv(h, 0.10f, 0.95f)
                onAccent = hsv(h, 0.90f * sat, 0.22f)
            } else {
                surface = hsv(h, 0.05f * sat, 0.95f)
                normal = 0xFFFFFFFF.toInt()
                special = hsv(h, 0.16f * sat, 0.92f)
                accent = hsv(h, 0.75f * sat, 0.72f)
                onNormal = hsv(h, 0.12f, 0.12f)
                onSpecial = hsv(h, 0.35f * sat, 0.20f)
                onAccent = 0xFFFFFFFF.toInt()
            }
            if (bmp != null) {
                val a = (p.keyAlpha.coerceIn(10, 100) * 255 / 100)
                normal = ColorUtils.setAlphaComponent(normal, a)
                special = ColorUtils.setAlphaComponent(special, a)
                surface = ColorUtils.blendARGB(ThemeImage.averageColor(), 0xFF000000.toInt(), p.imageDim / 100f)
            }
            onNormal = readable(onNormal, normal)
            onSpecial = readable(onSpecial, special)
            onAccent = readable(onAccent, accent)
            val onSurface = if (bmp != null) onNormal else readable(onNormal, surface)
            val outline = ColorUtils.setAlphaComponent(onSurface, 40)
            return Palette(dark, surface, normal, special, accent, onNormal, onSpecial, onAccent, onSurface, outline, bmp)
        }
    }
}

/**
 * Tecla desenhada diretamente em Canvas (sem layouts internos, sem RippleDrawable).
 * A ação dispara no ACTION_DOWN, então não há espera do detector de clique.
 *
 * Segurar a tecla por 0,5 s abre o painel de variações (ç, ã, á, č...). A letra base já foi digitada
 * no toque; ao soltar sobre uma variação, o serviço troca a letra base pela escolhida.
 */
class KeyView(ctx: Context) : View(ctx) {

    var label: String = ""
        set(v) { if (field != v) { field = v; invalidate() } }
    var bg: Int = 0
    var fg: Int = 0
    /** Tecla invisível: não desenha o corpo (sombra, fundo, borda), só a letra e o brilho do toque. Usado com imagem de referência. */
    var invisible: Boolean = false
        set(v) { if (field != v) { field = v; invalidate() } }
    /** Keys Café passo 3: gradiente da tecla (2 a 4 cores ARGB) vindo do tema ativo; null = cor lisa [bg]. */
    var gradColors: IntArray? = null
        set(v) { field = v; gShader = null; invalidate() }
    var gradAngle: Int = 0
        set(v) { field = v; gShader = null }
    private var gShader: android.graphics.LinearGradient? = null
    private var gShW = -1f; private var gShH = -1f; private var gShAlpha = -1

    /** Shader do gradiente do tema para o tamanho atual (refeito só quando muda tamanho, cores ou opacidade). */
    private fun themeShader(w: Float, h: Float): android.graphics.LinearGradient? {
        val cs = gradColors ?: return null
        if (cs.size < 2) return null
        val a = Color.alpha(bg)
        if (gShader == null || gShW != w || gShH != h || gShAlpha != a) {
            gShW = w; gShH = h; gShAlpha = a
            val rad = Math.toRadians(gradAngle.toDouble())
            val dx = Math.cos(rad).toFloat(); val dy = -Math.sin(rad).toFloat()   // 0 = esq→dir, 90 = baixo→cima
            val half = (Math.abs(dx) * w + Math.abs(dy) * h) / 2f
            val cx = w / 2f; val cy = h / 2f
            gShader = android.graphics.LinearGradient(cx - dx * half, cy - dy * half, cx + dx * half, cy + dy * half,
                IntArray(cs.size) { ColorUtils.setAlphaComponent(cs[it], a) }, null, android.graphics.Shader.TileMode.CLAMP)
        }
        return gShader
    }

    init {
        // Xiaomi/MIUI "modo escuro forçado" inverte as cores desenhadas e deixava tecla e letra iguais
        if (Build.VERSION.SDK_INT >= 29) isForceDarkAllowed = false
    }

    /** Última defesa: se letra e tecla ficarem quase da mesma cor, usa preto/branco. */
    private fun safeFg(): Int {
        val b = ColorUtils.setAlphaComponent(bg, 255)
        return if (ColorUtils.calculateContrast(ColorUtils.setAlphaComponent(fg, 255), b) < 1.6)
            (if (ColorUtils.calculateLuminance(b) > 0.4) 0xFF111114.toInt() else 0xFFF4F2F7.toInt())
        else fg
    }
    var radius: Float = 16f
    var textSizePx: Float = 40f
    var onDown: (() -> Unit)? = null
    var onUp: (() -> Unit)? = null
    /** v65.6: dispara ao SOLTAR o dedo (sem deslizar e sem ter aberto as variações). O onDown continua só para som/vibração. */
    var onTap: (() -> Unit)? = null
    /** Painel de variações com itens estreitos (usado no botão de idioma, que mostra códigos curtos). */
    var compactAlts = false
    /** Deslizar horizontal na tecla (barra de espaço): início, deslocamento em px desde o último evento, fim. */
    var onSlideStart: (() -> Unit)? = null
    var onSlideMove: ((Float) -> Unit)? = null
    var onSlideEnd: (() -> Unit)? = null
    private var slideActive = false
    private var slideLastX = 0f
    private var slideDownX = 0f
    private var upSound: Pair<Int, String>? = null   // som de soltar desta tecla
    /** Disparado ao segurar a tecla (ex.: Shift -> Caps Lock automático). */
    var onHold: (() -> Unit)? = null
    private val holdRun = Runnable { onHold?.invoke(); performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS) }

    /** Chamado no toque, ANTES de onDown: devolve as variações desta tecla (ou null se não há). */
    var altsFor: (() -> List<String>?)? = null
    var onAlt: ((String) -> Unit)? = null
    var onLongFeedback: (() -> Unit)? = null
    var popup: AltPopup? = null
    /** Balão ao tocar (só nas teclas de caractere). */
    var preview: KeyPreview? = null
    var previewOn = false

    /** Animações fluidas: a tecla afunda com mola e os cantos "derretem"; ao soltar volta suave. */
    var fluid = false
    private var morph = 0f

    // Molas criadas UMA vez por tecla e reaproveitadas (animateToFinalPosition mantém a velocidade).
    // Antes cada toque criava 3 molas novas, cancelava as anteriores e perdia a velocidade: em
    // digitação rápida isso gerava lixo na memória e saltos visuais.
    private val springX = SpringAnimation(this, DynamicAnimation.SCALE_X, 1f).apply {
        spring.setStiffness(1100f).setDampingRatio(0.72f)
    }
    private val springY = SpringAnimation(this, DynamicAnimation.SCALE_Y, 1f).apply {
        spring.setStiffness(1100f).setDampingRatio(0.72f)
    }
    private val morphProp = object : FloatPropertyCompat<KeyView>("morph") {
        override fun getValue(o: KeyView) = o.morph
        override fun setValue(o: KeyView, v: Float) { o.morph = v; o.invalidate() }
    }
    // morph vai de 0 a 1: o limite visível padrão (1.0) faria a mola parar na hora
    private val springM = SpringAnimation(this, morphProp, 0f).apply {
        spring.setStiffness(900f).setDampingRatio(0.8f)
        setMinimumVisibleChange(0.002f)
    }

    private fun fluidPress() {
        springX.animateToFinalPosition(0.92f)
        springY.animateToFinalPosition(0.92f)
        springM.animateToFinalPosition(1f)
    }

    private fun fluidRelease() {
        springX.animateToFinalPosition(1f)
        springY.animateToFinalPosition(1f)
        springM.animateToFinalPosition(0f)
    }

    private val boxPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    }
    private val rect = RectF()
    private val clip = Path()
    private val iconPath = Path()
    private val gradPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val iconPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
    }
    private val dens = ctx.resources.displayMetrics.density

    /** 0 = Material You (plana), 1 = iOS (sombra inferior), 2 = One UI (brilho suave), 3 = Vidro, 4 = Mecânico (keycap 3D). */
    var keyStyle = 0
        set(v) { field = v; invalidate() }
    /** Liquid Glass: a tecla amplia o [LiquidBackdrop] que está atrás dela (efeito de lente). */
    var lens = false
        set(v) { if (field != v) { field = v; invalidate() } }
    private val lensOuter = Path()
    private val lensInner = Path()
    private val lensRect = RectF()
    /** v54.2: borda fina em volta da tecla (px; 0 = sem borda). */
    var borderPx = 0f
        set(v) { if (field != v) { field = v; invalidate() } }
    /** v54.2: profundidade 3D em px (0 = a do estilo: iOS 1,6 dp, Mecânico 3,5 dp, os demais sem). */
    var depthPx = 0f
        set(v) { if (field != v) { field = v; invalidate() } }
    /** Brilho que se espalha a partir do ponto tocado. */
    var glow = true
    /** Anel de destaque (Posicionar Keycaps: tecla de destino sob o dedo). */
    var ring = false
        set(v) { if (field != v) { field = v; invalidate() } }
    /** Ícone vetorial desenhado no lugar do texto (ICON_*). */
    var icon = ICON_NONE
        set(v) { if (field != v) { field = v; invalidate() } }

    private var glowT = 1f
    private var gx = 0f
    private var gy = 0f
    private val glowAnim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 420; interpolator = DecelerateInterpolator(1.6f)
        addUpdateListener { glowT = it.animatedValue as Float; invalidate() }
    }
    private fun startGlow(x: Float, y: Float) {
        if (!glow) return
        gx = x; gy = y
        glowAnim.cancel(); glowAnim.start()
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        gradPaint.shader = LinearGradient(0f, 0f, 0f, h.toFloat(),
            intArrayOf(0x38FFFFFF, 0x00FFFFFF, 0x18000000), floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP)
    }
    private var pressed = false
    val isDown: Boolean get() = pressed
    private var downCount = 0

    // long-press
    private val slop = ViewConfiguration.get(ctx).scaledTouchSlop * 2
    private var activeAlts: List<String>? = null
    private var longShown = false
    private var downX = 0f
    private var downY = 0f
    private val longRun = Runnable {
        val a = activeAlts
        val p = popup
        if (pressed && !longShown && a != null && p != null) {
            longShown = p.show(this, a, lastRawX, compactAlts)
            if (longShown) { preview?.hide(this); onLongFeedback?.invoke() }
        }
    }
    private var lastRawX = 0f

    private val release = Runnable { if (!pressed) { scaleX = 1f; scaleY = 1f; invalidate() } }

    var shape = 0
        set(v) { if (field != v) { field = v; invalidate() } }
    var fontStyle = 0
        set(v) { field = v; textPaint.typeface = when (v) {
            1 -> Typeface.create("sans-serif-black", Typeface.NORMAL); 2 -> Typeface.SERIF
            3 -> Typeface.MONOSPACE; 4 -> Typeface.create("casual", Typeface.NORMAL)
            5 -> Typeface.create("sans-serif-light", Typeface.NORMAL); else -> Typeface.DEFAULT }; invalidate() }
    private val shapePath = Path()
    private var cL = -1f; private var cT = -1f; private var cR = -1f; private var cB = -1f; private var cRad = -1f; private var cShape = -1
    private fun drawBox(c: Canvas, r: Float, paint: Paint) {
        val rr = minOf(r, minOf(rect.width(), rect.height()) / 2f)
        if (shape == 0) c.drawRoundRect(rect, rr, rr, paint)
        else {
            if (rect.left != cL || rect.top != cT || rect.right != cR || rect.bottom != cB || rr != cRad || shape != cShape) {
                cL = rect.left; cT = rect.top; cR = rect.right; cB = rect.bottom; cRad = rr; cShape = shape
                shapePath.rewind(); KeyShapes.build(shapePath, rect, rr, shape)
            }
            c.drawPath(shapePath, paint)
        }
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        val m = if (fluid) morph.coerceIn(0f, 1f) else if (pressed) 1f else 0f
        val r = if (fluid && shape == 0) radius * (1f - 0.5f * m) else radius
        val bgOpaque = ColorUtils.setAlphaComponent(bg, 255)
        val lightKey = ColorUtils.calculateLuminance(bgOpaque) > 0.4

        // Sombra/profundidade embaixo que "some" quando a tecla afunda (iOS fina, Mecânico grossa, ou a escolhida em keyDepth)
        val baseDepth = when {
            keyStyle == 3 -> 0f
            depthPx > 0f -> depthPx
            keyStyle == 1 -> 1.6f * dens
            keyStyle == 4 -> 3.5f * dens
            else -> 0f
        }
        val depth = baseDepth * (1f - m)
        if (!invisible && depth > 0.4f) {
            rect.set(0f, depth, w, h)
            boxPaint.color = if (keyStyle == 4)    // keycap: a lateral é a própria cor da tecla, bem mais escura
                ColorUtils.setAlphaComponent(ColorUtils.blendARGB(bgOpaque, Color.BLACK, 0.55f), Color.alpha(bg))
            else Color.argb(if (lightKey) 70 else 130, 0, 0, 0)
            drawBox(canvas, r, boxPaint)
        }
        rect.set(0f, 0f, w, h - depth)
        if (invisible) {
            rect.set(0f, 0f, w, h - depth)
        } else if (keyStyle == 3) {                      // Vidro / Liquid Glass
            drawGlass(canvas, r, w, h, lightKey, m)
            rect.set(0f, 0f, w, h)
        } else {
            boxPaint.color = bg
            val sh = themeShader(w, h)
            boxPaint.shader = sh
            drawBox(canvas, r, boxPaint)
            boxPaint.shader = null
        }
        if (!invisible && keyStyle == 4) {                      // Mecânico: borda do keycap + face do topo levemente mais clara
            val a = Color.alpha(bg)
            val inset = dens * 3.2f
            val face = minOf(w, h - depth)
            if (face > inset * 4f) {
                rect.set(inset, inset * 0.6f, w - inset, h - depth - inset * 1.4f)
                boxPaint.color = ColorUtils.setAlphaComponent(ColorUtils.blendARGB(bgOpaque, Color.WHITE, if (lightKey) 0.55f else 0.10f), a)
                drawBox(canvas, maxOf(r - inset * 0.5f, 2f * dens), boxPaint)
                rect.set(0f, 0f, w, h - depth)
            }
        }
        if (!invisible && keyStyle == 2) {                      // One UI: brilho suave de cima para baixo
            gradPaint.alpha = if (lightKey) 150 else 255
            drawBox(canvas, r, gradPaint)
        }
        if (!invisible && borderPx > 0f) {                      // borda fina escolhida no tema (cor da letra com transparência)
            boxPaint.style = Paint.Style.STROKE; boxPaint.strokeWidth = borderPx
            boxPaint.color = ColorUtils.setAlphaComponent(fg, 110)
            rect.set(0f, 0f, w, h - depth); rect.inset(borderPx / 2f, borderPx / 2f)
            drawBox(canvas, r, boxPaint)
            boxPaint.style = Paint.Style.FILL
            rect.set(0f, 0f, w, h - depth)
        }
        if (fluid) {
            val a = (70 * m).toInt()
            if (a > 0) {
                boxPaint.color = ColorUtils.setAlphaComponent(fg, a)
                drawBox(canvas, r, boxPaint)
            }
        } else if (pressed) {
            boxPaint.color = ColorUtils.setAlphaComponent(fg, 60)
            drawBox(canvas, r, boxPaint)
        }
        // brilho que se espalha a partir do toque (recortado no formato da tecla)
        if (glow && glowT < 1f) {
            clip.rewind(); if (shape == 0) clip.addRoundRect(rect, r, r, Path.Direction.CW) else KeyShapes.build(clip, rect, r, shape)
            canvas.save(); canvas.clipPath(clip)
            boxPaint.color = ColorUtils.setAlphaComponent(fg, (90 * (1f - glowT)).toInt())
            canvas.drawCircle(gx, gy, Math.hypot(w.toDouble(), h.toDouble()).toFloat() * (0.15f + 0.85f * glowT), boxPaint)
            canvas.restore()
        }
        if (ring) {
            val sw = dens * 3f
            boxPaint.style = Paint.Style.STROKE; boxPaint.strokeWidth = sw
            boxPaint.color = ColorUtils.setAlphaComponent(fg, 255)
            rect.set(0f, 0f, w, h - depth); rect.inset(sw / 2, sw / 2)
            drawBox(canvas, r, boxPaint)
            boxPaint.style = Paint.Style.FILL
        }
        val color = safeFg()
        val cy0 = (h - depth) / 2f
        if (icon != ICON_NONE) {
            drawIcon(canvas, w / 2f, cy0, textSizePx * 0.85f, color)
        } else {
            textPaint.color = color
            textPaint.textSize = if (label.length > 2) textSizePx * 0.72f else textSizePx
            val y = cy0 - (textPaint.ascent() + textPaint.descent()) / 2f
            canvas.drawText(label, w / 2f, y, textPaint)
        }
    }

    // ---- Liquid Glass: gradiente translúcido, reflexo suave, sombra interna e borda iluminada ----
    // (o desfoque do fundo vem da janela, Android 12+; abaixo disso fica o vidro translúcido sem desfoque)
    private val gPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var gLiq = false; private var gBg = 0; private var gW = -1f; private var gH = -1f; private var gLight = false
    private var gFill: Shader? = null; private var gEdge: Shader? = null
    private var gShade: Shader? = null; private var gShine: Shader? = null

    private val lqPaint = Paint(Paint.ANTI_ALIAS_FLAG)

    private fun drawGlass(c: Canvas, r: Float, w: Float, h: Float, light: Boolean, m: Float) {
        val liquid = depthPx > 0f
        if (liquid) {        // profundidade: sombra suave embaixo, que encolhe quando a tecla afunda
            val d = depthPx * (1f - 0.8f * m)
            rect.set(dens * 0.6f, d, w - dens * 0.6f, h)
            lqPaint.shader = null; lqPaint.style = Paint.Style.FILL
            lqPaint.color = Color.argb(if (light) 34 else 70, 0, 0, 0)
            drawBox(c, r, lqPaint)
        }
        if (gFill == null || gBg != bg || gLiq != (depthPx > 0f) || gW != w || gH != h || gLight != light) {
            gBg = bg; gLiq = depthPx > 0f; gW = w; gH = h; gLight = light
            val top = ColorUtils.setAlphaComponent(ColorUtils.blendARGB(bg, Color.WHITE, 0.22f), if (depthPx > 0f) 110 else 150)
            val bot = ColorUtils.setAlphaComponent(bg, if (depthPx > 0f) 50 else 85)
            gFill = LinearGradient(0f, 0f, 0f, h, top, bot, Shader.TileMode.CLAMP)
            gEdge = LinearGradient(0f, 0f, w, h, intArrayOf(Color.argb(210, 255, 255, 255), Color.argb(30, 255, 255, 255), Color.argb(120, 255, 255, 255)),
                floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP)
            gShade = LinearGradient(0f, 0f, 0f, h, intArrayOf(Color.argb(0, 0, 0, 0), Color.argb(0, 0, 0, 0), Color.argb(if (light) 48 else 100, 0, 0, 0)),
                floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP)
            gShine = LinearGradient(0f, 0f, 0f, h * 0.5f, Color.argb(112, 255, 255, 255), Color.argb(0, 255, 255, 255), Shader.TileMode.CLAMP)
        }
        rect.set(0f, 0f, w, if (liquid) h - depthPx * (1f - 0.8f * m) else h)
        val gh = rect.bottom
        if (lens) drawLens(c, r, m)
        gPaint.style = Paint.Style.FILL
        gPaint.shader = gFill; drawBox(c, r, gPaint)
        val rr = minOf(r, minOf(w, h) / 2f)
        clip.rewind()
        if (shape == 0) clip.addRoundRect(rect, rr, rr, Path.Direction.CW) else KeyShapes.build(clip, rect, rr, shape)
        c.save(); c.clipPath(clip)
        gPaint.shader = gShine; c.drawRect(0f, 0f, w, h * 0.5f, gPaint)      // reflexo suave no topo
        gPaint.shader = gShade; c.drawRect(0f, 0f, w, h, gPaint)             // sombra interna na base
        c.restore()
        val sw = dens * 1.2f
        gPaint.style = Paint.Style.STROKE; gPaint.strokeWidth = sw; gPaint.shader = gEdge
        rect.inset(sw / 2, sw / 2); drawBox(c, r, gPaint); rect.inset(-sw / 2, -sw / 2)   // borda iluminada
        gPaint.shader = null; gPaint.style = Paint.Style.FILL
        if (liquid) {
            val rr2 = minOf(r, minOf(w, gh) / 2f)
            clip.rewind()
            if (shape == 0) clip.addRoundRect(rect, rr2, rr2, Path.Direction.CW) else KeyShapes.build(clip, rect, rr2, shape)
            c.save(); c.clipPath(clip)
            lqPaint.style = Paint.Style.FILL
            // reflexo curvo (lente) no topo, que fica mais claro ao pressionar
            lqPaint.shader = null
            lqPaint.color = Color.argb((38 + 50 * m).toInt(), 255, 255, 255)
            c.drawOval(-w * 0.15f, -gh * 0.55f, w * 1.15f, gh * 0.42f, lqPaint)
            // brilho especular que desliza da esquerda para a direita com o toque
            val cx = w * (0.25f + 0.5f * m)
            lqPaint.shader = RadialGradient(cx, gh * 0.30f, w * 0.55f,
                Color.argb((70 + 90 * m).toInt(), 255, 255, 255), Color.argb(0, 255, 255, 255), Shader.TileMode.CLAMP)
            c.drawRect(0f, 0f, w, gh, lqPaint)
            // véu de luz do acento ao afundar (a tecla "acende" por dentro)
            if (m > 0.01f) {
                lqPaint.shader = null
                lqPaint.color = Color.argb((46 * m).toInt(), 255, 255, 255)
                c.drawRect(0f, 0f, w, gh, lqPaint)
            }
            c.restore()
            // borda interna fina (reflexo de aresta) e borda luminosa mais forte ao pressionar
            lqPaint.shader = null; lqPaint.style = Paint.Style.STROKE
            lqPaint.strokeWidth = dens * (0.8f + 0.8f * m)
            lqPaint.color = Color.argb((60 + 120 * m).toInt(), 255, 255, 255)
            rect.inset(dens * 1.4f, dens * 1.4f)
            drawBox(c, maxOf(r - dens * 1.4f, 0f), lqPaint)
            rect.inset(-dens * 1.4f, -dens * 1.4f)
            lqPaint.style = Paint.Style.FILL
        }
    }

    /**
     * Lente: redesenha o fundo ampliado dentro da tecla, com ampliação maior no anel da borda (imita a refração
     * do vidro curvo; não é um shader). Sem [LiquidBackdrop] atrás (imagem ou vídeo), não desenha nada.
     */
    private fun drawLens(c: Canvas, r: Float, m: Float) {
        var v: View = this
        var ox = 0f; var oy = 0f
        var back = v.background as? LiquidBackdrop
        while (back == null) {
            val p = v.parent as? View ?: return
            ox += v.left - p.scrollX; oy += v.top - p.scrollY
            v = p
            back = v.background as? LiquidBackdrop
        }
        val bd: LiquidBackdrop = back ?: return
        val rr = minOf(r, minOf(rect.width(), rect.height()) / 2f)
        lensOuter.rewind()
        if (shape == 0) lensOuter.addRoundRect(rect, rr, rr, Path.Direction.CW) else KeyShapes.build(lensOuter, rect, rr, shape)
        val edge = dens * 5f
        lensRect.set(rect); lensRect.inset(edge, edge)
        lensInner.rewind()
        if (!lensRect.isEmpty) {
            val ir = maxOf(rr - edge, 0f)
            if (shape == 0) lensInner.addRoundRect(lensRect, ir, ir, Path.Direction.CW) else KeyShapes.build(lensInner, lensRect, ir, shape)
        }
        val cx = rect.centerX(); val cy = rect.centerY()
        // miolo: ampliação leve, que cresce ao apertar
        c.save(); c.clipPath(lensOuter)
        c.scale(1.12f + 0.10f * m, 1.12f + 0.10f * m, cx, cy)
        c.translate(-ox, -oy); bd.paint(c)
        c.restore()
        // borda: ampliação forte, que "dobra" as cores como a quina de um vidro
        c.save(); c.clipPath(lensOuter); c.clipOutPath(lensInner)
        c.scale(1.7f, 1.7f, cx, cy)
        c.translate(-ox, -oy); bd.paint(c)
        c.restore()
    }

    /** Ícones desenhados com traço arredondado: nítidos em qualquer tamanho e sem depender de fonte. */
    private fun drawIcon(c: Canvas, cx: Float, cy: Float, s: Float, color: Int) {
        iconPaint.color = color
        iconPaint.strokeWidth = s * 0.11f
        val p = iconPath
        p.rewind()
        when (icon) {
            ICON_SHIFT, ICON_CAPS -> {
                val o = if (icon == ICON_CAPS) -0.10f else 0f
                p.moveTo(cx, cy + (-0.5f + o) * s)
                p.lineTo(cx + 0.5f * s, cy + (0.05f + o) * s)
                p.lineTo(cx + 0.22f * s, cy + (0.05f + o) * s)
                p.lineTo(cx + 0.22f * s, cy + (0.42f + o) * s)
                p.lineTo(cx - 0.22f * s, cy + (0.42f + o) * s)
                p.lineTo(cx - 0.22f * s, cy + (0.05f + o) * s)
                p.lineTo(cx - 0.5f * s, cy + (0.05f + o) * s)
                p.close()
                iconPaint.style = if (icon == ICON_CAPS) Paint.Style.FILL_AND_STROKE else Paint.Style.STROKE
                c.drawPath(p, iconPaint)
                iconPaint.style = Paint.Style.STROKE
                if (icon == ICON_CAPS) c.drawLine(cx - 0.22f * s, cy + 0.6f * s, cx + 0.22f * s, cy + 0.6f * s, iconPaint)
            }
            ICON_BACKSPACE -> {
                p.moveTo(cx - 0.55f * s, cy)
                p.lineTo(cx - 0.22f * s, cy - 0.38f * s)
                p.lineTo(cx + 0.55f * s, cy - 0.38f * s)
                p.lineTo(cx + 0.55f * s, cy + 0.38f * s)
                p.lineTo(cx - 0.22f * s, cy + 0.38f * s)
                p.close()
                iconPaint.style = Paint.Style.STROKE
                c.drawPath(p, iconPaint)
                c.drawLine(cx + 0.0f * s, cy - 0.14f * s, cx + 0.3f * s, cy + 0.14f * s, iconPaint)
                c.drawLine(cx + 0.3f * s, cy - 0.14f * s, cx + 0.0f * s, cy + 0.14f * s, iconPaint)
            }
            ICON_GLOBE -> {
                iconPaint.style = Paint.Style.STROKE
                val r = 0.48f * s
                c.drawCircle(cx, cy, r, iconPaint)
                c.drawLine(cx - r, cy, cx + r, cy, iconPaint)
                c.drawLine(cx, cy - r, cx, cy + r, iconPaint)
                c.drawOval(cx - 0.22f * s, cy - r, cx + 0.22f * s, cy + r, iconPaint)
            }
            ICON_EMOJI -> {
                // mesmo desenho do ic_emoji da barra: rosto redondo, dois olhos e sorriso
                iconPaint.style = Paint.Style.STROKE
                c.drawCircle(cx, cy, 0.48f * s, iconPaint)
                iconPaint.style = Paint.Style.FILL
                val eye = 0.065f * s
                c.drawCircle(cx - 0.17f * s, cy - 0.12f * s, eye, iconPaint)
                c.drawCircle(cx + 0.17f * s, cy - 0.12f * s, eye, iconPaint)
                iconPaint.style = Paint.Style.STROKE
                p.moveTo(cx - 0.22f * s, cy + 0.12f * s)
                p.quadTo(cx, cy + 0.36f * s, cx + 0.22f * s, cy + 0.12f * s)
                c.drawPath(p, iconPaint)
            }
            ICON_ENTER -> {
                p.moveTo(cx + 0.5f * s, cy - 0.4f * s)
                p.lineTo(cx + 0.5f * s, cy + 0.1f * s)
                p.lineTo(cx - 0.4f * s, cy + 0.1f * s)
                iconPaint.style = Paint.Style.STROKE
                c.drawPath(p, iconPaint)
                p.rewind()
                p.moveTo(cx - 0.1f * s, cy - 0.2f * s)
                p.lineTo(cx - 0.4f * s, cy + 0.1f * s)
                p.lineTo(cx - 0.1f * s, cy + 0.4f * s)
                c.drawPath(p, iconPaint)
            }
        }
    }

    /**
     * Cada dedo que encosta na tecla conta como um toque novo (ACTION_POINTER_DOWN também dispara),
     * para toques rápidos na mesma tecla não se perderem.
     */
    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downCount++
                pressed = true
                longShown = false
                downX = e.x; downY = e.y; lastRawX = e.rawX
                slideActive = false; slideDownX = e.rawX; slideLastX = e.rawX
                removeCallbacks(release)
                removeCallbacks(longRun)
                activeAlts = altsFor?.invoke()          // antes do onDown (que consome o shift)
                startGlow(e.x, e.y)
                if (fluid) fluidPress() else { scaleX = 0.94f; scaleY = 0.94f }
                invalidate()
                KeyboardService.takeUp()                  // descarta restos de outra tecla
                onDown?.invoke()
                upSound = KeyboardService.takeUp()
                if (previewOn) preview?.show(this, label, textSizePx)
                if (onHold != null) { removeCallbacks(holdRun); postDelayed(holdRun, 380L) }
                if (activeAlts != null && popup != null) postDelayed(longRun, AnimCfg.longPressMs)
            }
            MotionEvent.ACTION_POINTER_DOWN -> {
                downCount++
                startGlow(e.getX(e.actionIndex), e.getY(e.actionIndex))
                if (!longShown) removeCallbacks(longRun)
                if (!longShown) {                        // segundo dedo na mesma tecla = nova digitação
                    activeAlts = altsFor?.invoke()
                    onDown?.invoke()
                    upSound = KeyboardService.takeUp() ?: upSound
                }
            }
            MotionEvent.ACTION_MOVE -> {
                lastRawX = e.rawX
                if (onSlideMove != null && !longShown) {
                    if (!slideActive && Math.abs(e.rawX - slideDownX) > slop) {
                        slideActive = true; slideLastX = e.rawX
                        removeCallbacks(longRun); removeCallbacks(holdRun)
                        onSlideStart?.invoke()
                    } else if (slideActive) {
                        val d = e.rawX - slideLastX
                        slideLastX = e.rawX
                        onSlideMove?.invoke(d)
                    }
                }
                if (longShown) popup?.move(e.rawX)
                else if (Math.abs(e.x - downX) > slop || Math.abs(e.y - downY) > slop * 2) removeCallbacks(longRun)
            }
            MotionEvent.ACTION_POINTER_UP -> {
                if (downCount > 1) { downCount--; if (!longShown && !slideActive) onTap?.invoke() }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                downCount = 0
                pressed = false
                preview?.hide(this)
                removeCallbacks(holdRun)
                removeCallbacks(longRun)
                var consumed = slideActive            // deslizou ou abriu as variações: não é um toque simples
                if (longShown) {
                    longShown = false
                    consumed = true
                    val pick = if (e.actionMasked == MotionEvent.ACTION_UP) popup?.finish() else { popup?.cancel(); null }
                    if (pick != null) onAlt?.invoke(pick)
                }
                if (slideActive) { slideActive = false; onSlideEnd?.invoke() }
                if (!consumed && e.actionMasked == MotionEvent.ACTION_UP) onTap?.invoke()   // v65.6: digita ao soltar
                onUp?.invoke()
                KeyboardService.playUp(upSound); upSound = null
                if (fluid) fluidRelease()
                else postDelayed(release, 60)   // pequeno atraso só visual; novo toque cancela
                if (e.actionMasked == MotionEvent.ACTION_UP) performClick()
                invalidate()
            }
        }
        return true
    }

    override fun onDetachedFromWindow() {
        removeCallbacks(longRun)
        popup?.cancel()
        longShown = false
        pressed = false
        springX.cancel(); springY.cancel(); springM.cancel(); glowAnim.cancel(); glowT = 1f
        scaleX = 1f; scaleY = 1f; morph = 0f
        super.onDetachedFromWindow()
    }

    override fun performClick(): Boolean { super.performClick(); return true }

    companion object {
        const val LONG_PRESS_MS = 500L
        const val ICON_NONE = 0; const val ICON_SHIFT = 1; const val ICON_CAPS = 2
        const val ICON_BACKSPACE = 3; const val ICON_ENTER = 4; const val ICON_GLOBE = 5; const val ICON_EMOJI = 6
    }
}

/**
 * Raiz do teclado. Toques que NÃO acertam uma tecla (as frestas entre elas, as bordas, o espaço
 * abaixo da última fileira) chegam aqui; o [resolver] escolhe a tecla mais próxima e o toque é
 * repassado a ela como se tivesse sido feito em cima dela. Cada dedo é tratado separadamente.
 */
class KeyRoot(ctx: Context) : LinearLayout(ctx) {
    var resolver: ((Float, Float) -> KeyView?)? = null
    private val targets = HashMap<Int, KeyView>()
    private var downTime = 0L
    private val rootLoc = IntArray(2)
    private val keyLoc = IntArray(2)

    // ---- Posicionar Keycaps: arrastar uma tecla sobre outra para trocar as duas de lugar ----
    /** Liga o modo: os toques na área das teclas não digitam, só arrastam. */
    var editMode = false
        set(v) { if (field != v) { field = v; endDrag(false) } }
    /** Tecla (qualquer uma) sob o ponto, em coordenadas da raiz; null fora da área das teclas. */
    var editHit: ((Float, Float) -> KeyView?)? = null
    /** Diz se a tecla é uma letra que pode ser trocada. */
    var editLetter: ((KeyView) -> Boolean)? = null
    var onSwap: ((KeyView, KeyView) -> Unit)? = null
    var ghostBg = 0
    var ghostFg = 0
    private var dragFrom: KeyView? = null
    private var dragTo: KeyView? = null
    private var dragX = 0f
    private var dragY = 0f
    private var dragId = -1
    private val ghostPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ghostRect = RectF()

    // ---- Digitação por deslize (glide): um dedo arrasta por várias letras e solta; o serviço decodifica a palavra ----
    var glideEnabled: () -> Boolean = { false }
    /** Letra (minúscula) da tecla sob o ponto, em coordenadas da raiz; null fora das letras. */
    var glideHit: ((Float, Float) -> Char?)? = null
    var onGlide: ((String) -> Unit)? = null
    var glideColor = 0
    private val gPts = ArrayList<Float>()          // x, y, x, y...
    private val gSeq = StringBuilder()
    private var gTracking = false
    private var gActive = false
    private var gId = -1
    private var gStartT = 0L
    private var gMovedT = 0L
    private var gLen = 0f
    private var gLastX = 0f
    private var gLastY = 0f
    private var gFade = 0f
    private var gFadeAnim: ValueAnimator? = null
    private val gPath = Path()
    private val gPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND }
    private val gSlop = ViewConfiguration.get(ctx).scaledTouchSlop

    private fun glideReset() {
        gFadeAnim?.cancel(); gFade = 0f
        gPts.clear(); gSeq.setLength(0)
        gTracking = false; gActive = false; gLen = 0f; gMovedT = 0L; gId = -1
    }

    private fun glideFeed(x: Float, y: Float) {
        val hit = glideHit ?: return
        val step = resources.displayMetrics.density * 5f
        val dx = x - gLastX; val dy = y - gLastY
        val dist = Math.hypot(dx.toDouble(), dy.toDouble()).toFloat()
        val n = maxOf(1, (dist / step).toInt())
        for (i in 1..n) {                       // interpola: um deslize rápido não pula teclas
            val px = gLastX + dx * i / n; val py = gLastY + dy * i / n
            hit(px, py)?.let { c -> if (gSeq.isEmpty() || gSeq.last() != c) gSeq.append(c) }
        }
        gLen += dist
        gLastX = x; gLastY = y
        if (gPts.size < 1600) { gPts.add(x); gPts.add(y) }
    }

    private fun glideFade(then: (() -> Unit)? = null) {
        gFadeAnim?.cancel()
        gFadeAnim = ValueAnimator.ofFloat(gFade.coerceAtLeast(0.01f), 0f).apply {
            duration = 260
            interpolator = DecelerateInterpolator()
            addUpdateListener { gFade = it.animatedValue as Float; invalidate() }
            addListener(object : android.animation.AnimatorListenerAdapter() {
                override fun onAnimationEnd(a: android.animation.Animator) { if (!gActive) gPts.clear(); invalidate(); then?.invoke() }
            })
            start()
        }
    }

    override fun dispatchTouchEvent(e: MotionEvent): Boolean {
        if (!editMode && glideHit != null) {
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    glideReset()
                    if (glideEnabled()) {
                        val c = glideHit?.invoke(e.x, e.y)
                        if (c != null) {
                            gTracking = true; gId = e.getPointerId(0); gStartT = e.eventTime
                            gLastX = e.x; gLastY = e.y; gSeq.append(c); gPts.add(e.x); gPts.add(e.y)
                        }
                    }
                }
                MotionEvent.ACTION_POINTER_DOWN -> if (gTracking && !gActive) gTracking = false   // segundo dedo: digitação normal
                MotionEvent.ACTION_MOVE -> if (gTracking) {
                    val idx = e.findPointerIndex(gId)
                    if (idx >= 0) {
                        for (h in 0 until e.historySize) glideFeed(e.getHistoricalX(idx, h), e.getHistoricalY(idx, h))
                        glideFeed(e.getX(idx), e.getY(idx))
                        if (!gActive) {
                            if (gMovedT == 0L && gLen > gSlop) {
                                gMovedT = e.eventTime
                                // começou a mexer só depois do tempo do toque longo: é a escolha de acentos, não um deslize
                                if (gMovedT - gStartT >= AnimCfg.longPressMs) gTracking = false
                            }
                            if (gTracking && gSeq.length >= 2 && gLen > resources.displayMetrics.density * 40f) {
                                gActive = true
                                gFadeAnim?.cancel(); gFade = 1f
                                val c = MotionEvent.obtain(e); c.action = MotionEvent.ACTION_CANCEL
                                super.dispatchTouchEvent(c); c.recycle()          // a tecla onde o dedo caiu não digita
                                performHapticFeedback(android.view.HapticFeedbackConstants.CLOCK_TICK)
                            }
                        }
                    }
                }
                MotionEvent.ACTION_UP -> if (gActive) {
                    val seq = gSeq.toString()
                    gActive = false; gTracking = false
                    glideFade()
                    if (seq.length >= 2) onGlide?.invoke(seq)
                    return true
                } else gTracking = false
                MotionEvent.ACTION_CANCEL -> {
                    if (gActive) { gActive = false; glideFade() }
                    gTracking = false
                }
            }
            if (gActive) { invalidate(); return true }
        }
        return super.dispatchTouchEvent(e)
    }

    init { setWillNotDraw(false) }

    private fun endDrag(commit: Boolean) {
        val a = dragFrom; val b = dragTo
        dragFrom?.let { it.alpha = 1f }
        dragTo?.ring = false
        dragFrom = null; dragTo = null; dragId = -1
        invalidate()
        if (commit && a != null && b != null && a !== b) onSwap?.invoke(a, b)
    }

    override fun onInterceptTouchEvent(e: MotionEvent): Boolean {
        if (!editMode) return super.onInterceptTouchEvent(e)
        if (e.actionMasked == MotionEvent.ACTION_DOWN) return editHit?.invoke(e.x, e.y) != null
        return dragId != -1
    }

    private fun editTouch(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                val k = editHit?.invoke(e.x, e.y) ?: return false
                if (editLetter?.invoke(k) != true) return true            // tecla que não é letra: não faz nada
                dragFrom = k; dragTo = null; dragId = e.getPointerId(0)
                dragX = e.x; dragY = e.y
                k.alpha = 0.35f
                performHapticFeedback(android.view.HapticFeedbackConstants.KEYBOARD_TAP)
                invalidate()
            }
            MotionEvent.ACTION_MOVE -> {
                if (dragFrom == null) return true
                val i = e.findPointerIndex(dragId).takeIf { it >= 0 } ?: return true
                dragX = e.getX(i); dragY = e.getY(i)
                val over = editHit?.invoke(dragX, dragY)?.takeIf { it !== dragFrom && editLetter?.invoke(it) == true }
                if (over !== dragTo) {
                    dragTo?.ring = false
                    dragTo = over
                    over?.ring = true
                    if (over != null) performHapticFeedback(android.view.HapticFeedbackConstants.CLOCK_TICK)
                }
                invalidate()
            }
            MotionEvent.ACTION_UP -> endDrag(true)
            MotionEvent.ACTION_CANCEL -> endDrag(false)
        }
        return true
    }

    override fun dispatchDraw(canvas: Canvas) {
        super.dispatchDraw(canvas)
        if (gPts.size >= 4 && gFade > 0f) {
            // rastro do deslize: linha suave na cor de destaque, que some com fade ao soltar
            val d = resources.displayMetrics.density
            gPath.rewind()
            gPath.moveTo(gPts[0], gPts[1])
            var i = 2
            while (i + 3 < gPts.size) {
                val mx = (gPts[i] + gPts[i + 2]) / 2f; val my = (gPts[i + 1] + gPts[i + 3]) / 2f
                gPath.quadTo(gPts[i], gPts[i + 1], mx, my)
                i += 2
            }
            gPath.lineTo(gPts[gPts.size - 2], gPts[gPts.size - 1])
            gPaint.strokeWidth = 5f * d
            gPaint.color = ColorUtils.setAlphaComponent(glideColor, (230 * gFade.coerceIn(0f, 1f)).toInt())
            canvas.drawPath(gPath, gPaint)
        }
        val k = dragFrom ?: return
        // tecla "fantasma" seguindo o dedo
        val w = k.width * 1.05f; val h = k.height * 1.05f
        ghostRect.set(dragX - w / 2, dragY - h * 1.1f, dragX + w / 2, dragY - h * 0.1f)
        ghostPaint.style = Paint.Style.FILL
        ghostPaint.color = ghostBg
        canvas.drawRoundRect(ghostRect, k.radius, k.radius, ghostPaint)
        ghostPaint.color = ghostFg
        ghostPaint.textAlign = Paint.Align.CENTER
        ghostPaint.textSize = k.textSizePx
        ghostPaint.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        canvas.drawText(k.label, ghostRect.centerX(), ghostRect.centerY() - (ghostPaint.ascent() + ghostPaint.descent()) / 2f, ghostPaint)
    }

    private fun send(k: KeyView, action: Int, e: MotionEvent, idx: Int) {
        getLocationOnScreen(rootLoc)
        k.getLocationOnScreen(keyLoc)
        val ev = MotionEvent.obtain(
            downTime, e.eventTime, action,
            e.getX(idx) + rootLoc[0], e.getY(idx) + rootLoc[1], 0
        )
        ev.offsetLocation(-keyLoc[0].toFloat(), -keyLoc[1].toFloat())   // x/y locais da tecla, rawX/rawY na tela
        k.dispatchTouchEvent(ev)
        ev.recycle()
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (editMode) return editTouch(e)
        val res = resolver ?: return super.onTouchEvent(e)
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                val i = e.actionIndex
                val k = res(e.getX(i), e.getY(i)) ?: return targets.isNotEmpty()
                if (e.actionMasked == MotionEvent.ACTION_DOWN) { targets.clear(); downTime = e.eventTime }
                targets[e.getPointerId(i)] = k
                send(k, MotionEvent.ACTION_DOWN, e, i)
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                for (i in 0 until e.pointerCount) targets[e.getPointerId(i)]?.let { send(it, MotionEvent.ACTION_MOVE, e, i) }
                return targets.isNotEmpty()
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> {
                val i = e.actionIndex
                targets.remove(e.getPointerId(i))?.let { send(it, MotionEvent.ACTION_UP, e, i) }
                if (e.actionMasked == MotionEvent.ACTION_UP) targets.clear()
                return true
            }
            MotionEvent.ACTION_CANCEL -> {
                for (i in 0 until e.pointerCount) targets[e.getPointerId(i)]?.let { send(it, MotionEvent.ACTION_CANCEL, e, i) }
                targets.clear()
                return true
            }
        }
        return super.onTouchEvent(e)
    }
}

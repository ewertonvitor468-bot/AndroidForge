package com.monet.launcher

import android.app.Application
import android.content.pm.LauncherApps
import android.os.UserHandle
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.monet.launcher.data.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class LauncherViewModel(app: Application) : AndroidViewModel(app) {

    private val repo = AppRepository(app)
    private val store = SettingsRepository(app)

    private val _apps = MutableStateFlow<List<AppInfo>>(emptyList())
    val apps: StateFlow<List<AppInfo>> = _apps

    val settings: StateFlow<LauncherSettings> =
        store.flow.stateIn(viewModelScope, SharingStarted.Eagerly, LauncherSettings())

    val defaultDock: List<String> = repo.defaultDock()

    private val _home = MutableSharedFlow<Unit>(extraBufferCapacity = 1)
    val homeEvents = _home.asSharedFlow()

    private val launcherApps = app.getSystemService(LauncherApps::class.java)
    private val callback = object : LauncherApps.Callback() {
        override fun onPackageRemoved(p: String, u: UserHandle) = refresh()
        override fun onPackageAdded(p: String, u: UserHandle) = refresh()
        override fun onPackageChanged(p: String, u: UserHandle) = refresh()
        override fun onPackagesAvailable(p: Array<out String>, u: UserHandle, r: Boolean) = refresh()
        override fun onPackagesUnavailable(p: Array<out String>, u: UserHandle, r: Boolean) = refresh()
    }

    init {
        refresh()
        launcherApps.registerCallback(callback)
    }

    override fun onCleared() = launcherApps.unregisterCallback(callback)

    fun refresh() { viewModelScope.launch { _apps.value = repo.loadApps() } }
    fun homePressed() { _home.tryEmit(Unit) }
    fun launch(a: AppInfo) {
        repo.launch(a)
        update { it.copy(recentApps = (listOf(a.pkg) + it.recentApps).distinct().take(5)) }
    }
    fun update(t: (LauncherSettings) -> LauncherSettings) { viewModelScope.launch { store.update(t) } }
}

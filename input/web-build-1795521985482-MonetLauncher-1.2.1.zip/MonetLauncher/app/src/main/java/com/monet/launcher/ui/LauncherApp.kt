package com.monet.launcher.ui

import androidx.compose.animation.*
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import com.monet.launcher.LauncherViewModel
import com.monet.launcher.widgets.WidgetController

enum class Screen { HOME, SETTINGS, WIDGETS }

@Composable
fun LauncherApp(vm: LauncherViewModel, widgets: WidgetController) {
    var screen by rememberSaveable { mutableStateOf(Screen.HOME) }
    var drawer by remember { mutableStateOf(false) }

    // botão Home: fecha tudo
    LaunchedEffect(Unit) { vm.homeEvents.collect { drawer = false; screen = Screen.HOME } }

    // widget adicionado -> salva o id
    DisposableEffect(Unit) {
        widgets.onAdded = { id -> vm.update { it.copy(widgetIds = it.widgetIds + id) } }
        onDispose { widgets.onAdded = null }
    }

    Box(Modifier.fillMaxSize()) {
        HomeScreen(
            vm, widgets,
            onOpenDrawer = { drawer = true },
            onOpenSettings = { screen = Screen.SETTINGS },
            onPickWidget = { screen = Screen.WIDGETS },
        )

        AnimatedVisibility(
            visible = drawer,
            enter = slideInVertically { it } + fadeIn(),
            exit = slideOutVertically { it } + fadeOut(),
        ) { DrawerScreen(vm) { drawer = false } }

        AnimatedVisibility(
            visible = screen != Screen.HOME,
            enter = slideInHorizontally { it } + fadeIn(),
            exit = slideOutHorizontally { it } + fadeOut(),
        ) {
            when (screen) {
                Screen.SETTINGS -> SettingsScreen(vm, widgets,
                    onPickWidget = { screen = Screen.WIDGETS },
                    onBack = { screen = Screen.HOME })
                Screen.WIDGETS -> WidgetPickerScreen(widgets, onBack = { screen = Screen.HOME })
                Screen.HOME -> Unit
            }
        }
    }
}

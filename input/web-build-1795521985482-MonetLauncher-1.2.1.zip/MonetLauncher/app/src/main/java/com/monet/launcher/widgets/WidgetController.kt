package com.monet.launcher.widgets

import android.app.Activity
import android.appwidget.AppWidgetHost
import android.appwidget.AppWidgetHostView
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProviderInfo
import android.content.Intent
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts

/**
 * Hospeda widgets: aloca o id, faz o bind (pedindo permissão ao usuário se preciso),
 * abre a tela de configuração do widget quando existir e devolve o id pronto.
 * Deve ser criado como propriedade da Activity (registra launchers).
 */
class WidgetController(private val activity: ComponentActivity) {

    companion object {
        const val HOST_ID = 1024
        const val REQ_CONFIG = 4242
    }

    private val manager by lazy { AppWidgetManager.getInstance(activity) }
    private val host by lazy { AppWidgetHost(activity, HOST_ID) }
    private val density by lazy { activity.resources.displayMetrics.density }
    private var pendingId = -1

    var onAdded: ((Int) -> Unit)? = null

    private val bindLauncher = activity.registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { r ->
        if (r.resultCode == Activity.RESULT_OK) configureOrFinish(pendingId) else discard()
    }

    fun start() = host.startListening()
    fun stop() = host.stopListening()

    fun providers(): List<AppWidgetProviderInfo> =
        manager.installedProviders
            .filter { it.widgetCategory and AppWidgetProviderInfo.WIDGET_CATEGORY_HOME_SCREEN != 0 }
            .sortedBy { it.loadLabel(activity.packageManager).lowercase() }

    fun add(provider: AppWidgetProviderInfo) {
        val id = host.allocateAppWidgetId()
        pendingId = id
        if (manager.bindAppWidgetIdIfAllowed(id, provider.provider)) {
            configureOrFinish(id)
        } else {
            bindLauncher.launch(
                Intent(AppWidgetManager.ACTION_APPWIDGET_BIND)
                    .putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
                    .putExtra(AppWidgetManager.EXTRA_APPWIDGET_PROVIDER, provider.provider)
            )
        }
    }

    private fun configureOrFinish(id: Int) {
        val info = manager.getAppWidgetInfo(id)
        if (info?.configure != null) {
            @Suppress("DEPRECATION")
            host.startAppWidgetConfigureActivityForResult(activity, id, 0, REQ_CONFIG, null)
        } else finish(id)
    }

    /** Chamado pela MainActivity.onActivityResult */
    fun onConfigResult(resultCode: Int) {
        if (resultCode == Activity.RESULT_OK) finish(pendingId) else discard()
    }

    private fun finish(id: Int) { pendingId = -1; onAdded?.invoke(id) }
    private fun discard() { if (pendingId != -1) host.deleteAppWidgetId(pendingId); pendingId = -1 }

    fun remove(id: Int) = host.deleteAppWidgetId(id)

    fun label(id: Int): String =
        manager.getAppWidgetInfo(id)?.loadLabel(activity.packageManager) ?: "Widget removido"

    fun exists(id: Int) = manager.getAppWidgetInfo(id) != null

    fun heightDp(id: Int): Int =
        ((manager.getAppWidgetInfo(id)?.minHeight ?: 0) / density).toInt().coerceAtLeast(72)

    fun createView(id: Int): AppWidgetHostView? {
        val info = manager.getAppWidgetInfo(id) ?: return null
        return host.createView(activity, id, info).apply { setAppWidget(id, info) }
    }
}

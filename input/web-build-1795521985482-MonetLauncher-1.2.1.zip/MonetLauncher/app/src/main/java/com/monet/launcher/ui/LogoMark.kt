package com.monet.launcher.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp

/** Logo do MonetLauncher: fundo roxo em degradê + 4 "apps" (2 quadrados, 2 círculos). */
@Composable
fun LogoMark(dp: Dp, modifier: Modifier = Modifier) {
    Canvas(modifier.size(dp)) {
        val w = this.size.width
        val k = w / 108f
        drawRoundRect(
            brush = Brush.linearGradient(
                listOf(Color(0xFF6750A4), Color(0xFFB69DF8)),
                start = Offset.Zero, end = Offset(w, w),
            ),
            cornerRadius = CornerRadius(w * 0.28f),
            size = this.size,
        )
        val tile = 22f * k
        fun square(x: Float, y: Float, c: Color) =
            drawRoundRect(c, Offset(x * k, y * k), Size(tile, tile), CornerRadius(7f * k))
        fun circle(x: Float, y: Float, c: Color) =
            drawCircle(c, tile / 2, Offset(x * k + tile / 2, y * k + tile / 2))
        square(29f, 29f, Color.White)
        circle(57f, 29f, Color(0xFFFFD8E4))
        circle(29f, 57f, Color(0xFFEADDFF))
        square(57f, 57f, Color(0xFFB8F0DC))
    }
}

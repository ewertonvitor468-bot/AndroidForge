package com.monet.launcher.ui

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.monet.launcher.LauncherViewModel

@Composable
fun DrawerScreen(vm: LauncherViewModel, onClose: () -> Unit) {
    BackHandler(onBack = onClose)
    val s by vm.settings.collectAsState()
    val apps by vm.apps.collectAsState()
    val ctx = LocalContext.current
    var query by remember { mutableStateOf("") }
    val byPkg = remember(apps) { apps.associateBy { it.pkg } }
    val recents = s.recentApps.mapNotNull { byPkg[it] }
    val shown = remember(apps, query) {
        if (query.isBlank()) apps else apps.filter { it.label.contains(query.trim(), ignoreCase = true) }
    }

    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.surface.copy(alpha = 0.95f)) {
        Column(Modifier.statusBarsPadding().padding(horizontal = 12.dp)) {
            TextField(
                value = query,
                onValueChange = { query = it },
                placeholder = { Text("Pesquisar apps") },
                leadingIcon = { Icon(Icons.Default.Search, null) },
                singleLine = true,
                shape = RoundedCornerShape(28.dp),
                colors = TextFieldDefaults.colors(
                    focusedIndicatorColor = Color.Transparent,
                    unfocusedIndicatorColor = Color.Transparent,
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp)
                    .pointerInput(Unit) {
                        var total = 0f
                        detectVerticalDragGestures(
                            onDragStart = { total = 0f },
                            onDragEnd = { if (total > 120f) onClose() },
                            onVerticalDrag = { _, dy -> total += dy },
                        )
                    },
            )
            LazyVerticalGrid(
                columns = GridCells.Fixed(s.drawerColumns),
                contentPadding = PaddingValues(bottom = 24.dp),
                modifier = Modifier.navigationBarsPadding(),
            ) {
                if (query.isBlank() && recents.isNotEmpty()) {
                    item(span = { GridItemSpan(maxLineSpan) }) {
                        Surface(
                            shape = RoundedCornerShape(24.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                            modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
                        ) {
                            Column(Modifier.padding(12.dp)) {
                                Text(
                                    "Recentes",
                                    color = MaterialTheme.colorScheme.primary,
                                    fontWeight = FontWeight.Medium,
                                    modifier = Modifier.padding(start = 4.dp, bottom = 4.dp),
                                )
                                Row(Modifier.fillMaxWidth()) {
                                    recents.forEach { r ->
                                        AppIcon(
                                            r, s, Modifier.weight(1f), showLabel = false,
                                            onClick = { vm.launch(r); onClose() },
                                        )
                                    }
                                    repeat(5 - recents.size) { Spacer(Modifier.weight(1f)) }
                                }
                            }
                        }
                    }
                }
                items(shown, key = { it.pkg }) { app ->
                    AppIcon(
                        app, s,
                        labelColor = MaterialTheme.colorScheme.onSurface,
                        shadow = false,
                        actions = listOf(
                            "Adicionar à tela inicial" to {
                                vm.update { it.copy(homeApps = (it.homeApps + app.pkg).distinct()) }
                            },
                            "Adicionar ao dock" to {
                                vm.update {
                                    val cur = it.dockApps.ifEmpty { vm.defaultDock }
                                    if (cur.size < 5) it.copy(dockApps = (cur + app.pkg).distinct()) else it
                                }
                            },
                            "Informações do app" to {
                                ctx.startActivity(
                                    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                                        Uri.fromParts("package", app.pkg, null))
                                )
                            },
                            "Desinstalar" to {
                                ctx.startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:${app.pkg}")))
                            },
                        ),
                        onClick = { vm.launch(app); onClose() },
                    )
                }
            }
        }
    }
}

package com.monet.launcher.ui

import android.appwidget.AppWidgetProviderInfo
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import com.monet.launcher.widgets.WidgetController

@Composable
fun WidgetPickerScreen(widgets: WidgetController, onBack: () -> Unit) {
    BackHandler(onBack = onBack)
    val providers = remember { widgets.providers() }

    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.surface) {
        Column(Modifier.systemBarsPadding().padding(horizontal = 16.dp)) {
            Text("Widgets", fontSize = 34.sp, fontWeight = FontWeight.Medium,
                modifier = Modifier.padding(start = 8.dp, top = 48.dp, bottom = 16.dp))
            LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(bottom = 24.dp)) {
                items(providers, key = { it.provider.flattenToString() }) { p ->
                    ProviderCard(p) { widgets.add(p); onBack() }
                }
            }
        }
    }
}

@Composable
private fun ProviderCard(p: AppWidgetProviderInfo, onClick: () -> Unit) {
    val ctx = LocalContext.current
    val label = remember(p) { p.loadLabel(ctx.packageManager) }
    val preview = remember(p) {
        runCatching {
            (p.loadPreviewImage(ctx, 0) ?: p.loadIcon(ctx, 0)).toBitmap(480, 240).asImageBitmap()
        }.getOrNull()
    }
    Surface(
        shape = RoundedCornerShape(24.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
    ) {
        Column(Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            preview?.let {
                Image(it, label.toString(), Modifier.fillMaxWidth().height(120.dp), contentScale = ContentScale.Fit)
            }
            Spacer(Modifier.height(8.dp))
            Text(label.toString(), fontWeight = FontWeight.Medium)
        }
    }
}

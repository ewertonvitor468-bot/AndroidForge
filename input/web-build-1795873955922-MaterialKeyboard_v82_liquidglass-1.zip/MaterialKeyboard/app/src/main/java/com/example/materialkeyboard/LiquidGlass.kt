package com.example.materialkeyboard

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.RuntimeShader
import android.graphics.Shader
import android.graphics.drawable.Drawable
import android.os.Build
import android.view.View
import androidx.annotation.RequiresApi

/**
 * Uma peça de vidro líquido desenhada sobre o [LiquidBackdrop] que está atrás da view.
 * Android 13+: shader AGSL (refração na borda, leve separação de cores, aumento no miolo e fio de luz).
 * Abaixo disso: aproximação com o fundo ampliado e o mesmo fio de luz, sem curvar os pixels.
 */
class LiquidGlass(private val density: Float) {
    private val path = Path()
    private val inner = Path()
    private val box = RectF()
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rim = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private var rimShader: Shader? = null
    private var rimW = -1f; private var rimH = -1f
    private var agsl: Agsl? = null
    private var agslFailed = false

    /**
     * Desenha em [area] (coordenadas da view). [shape] e [radius] como nas teclas; [tint] é a cor
     * (com alfa) misturada no vidro; [press] vai de 0 a 1. Devolve false se não há fundo para refratar.
     */
    fun draw(c: Canvas, host: View, area: RectF, radius: Float, shape: Int, tint: Int, press: Float,
             touchX: Float = 0f, touchY: Float = 0f, wave: Float = -1f): Boolean {
        var v: View = host
        var ox = 0f; var oy = 0f
        var found = v.background as? LiquidBackdrop
        while (found == null) {
            val p = v.parent as? View ?: return false
            ox += v.left - p.scrollX; oy += v.top - p.scrollY
            v = p
            found = v.background as? LiquidBackdrop
        }
        val back: LiquidBackdrop = found ?: return false
        val w = area.width(); val h = area.height()
        if (w <= 1f || h <= 1f) return true
        val r = minOf(radius, minOf(w, h) / 2f)
        path.rewind()
        if (shape == 0) path.addRoundRect(area, r, r, Path.Direction.CW) else KeyShapes.build(path, area, r, shape)
        val bg = back.shader
        var done = false
        if (Build.VERSION.SDK_INT >= 33 && c.isHardwareAccelerated && bg != null && !agslFailed) {
            try {
                val s = agsl ?: Agsl().also { agsl = it }
                s.draw(c, path, bg, area, ox, oy, r, tint, press, density, back.clear, touchX, touchY, wave)
                done = true
            } catch (_: IllegalArgumentException) { agslFailed = true }
        }
        if (!done) {
            fallback(c, back, area, r, shape, ox, oy, tint, press)
            if (wave >= 0f) {                                   // sem shader: a onda é um anel que se abre
                rim.shader = null
                rim.color = Color.argb((150 * (1f - wave / WAVE_SECONDS).coerceIn(0f, 1f)).toInt(), 255, 255, 255)
                rim.strokeWidth = density * 4f
                c.save(); c.clipPath(path); c.drawCircle(touchX, touchY, wave * density * 95f, rim); c.restore()
            }
        }
        return true
    }

    private fun fallback(c: Canvas, back: LiquidBackdrop, area: RectF, r: Float, shape: Int,
                         ox: Float, oy: Float, tint: Int, press: Float) {
        val cx = area.centerX(); val cy = area.centerY()
        val edge = density * 5f
        box.set(area); box.inset(edge, edge)
        inner.rewind()
        val ir = maxOf(r - edge, 0f)
        if (shape == 0) inner.addRoundRect(box, ir, ir, Path.Direction.CW) else KeyShapes.build(inner, box, ir, shape)
        c.save(); c.clipPath(path)
        if (!back.clear) {
        c.save(); c.scale(1.08f + 0.10f * press, 1.08f + 0.10f * press, cx, cy); c.translate(-ox, -oy); back.paint(c); c.restore()
        c.save(); c.clipOutPath(inner); c.scale(0.72f, 0.72f, cx, cy); c.translate(-ox, -oy); back.paint(c); c.restore()
        }
        fill.color = tint; c.drawPath(path, fill)
        if (press > 0.01f) { fill.color = Color.argb((26 * press).toInt(), 255, 255, 255); c.drawPath(path, fill) }
        c.restore()
        if (rimShader == null || rimW != area.width() || rimH != area.height()) {
            rimW = area.width(); rimH = area.height()
            rimShader = LinearGradient(area.left, area.top, area.right, area.bottom,
                intArrayOf(0xB8FFFFFF.toInt(), 0x38FFFFFF, 0x38FFFFFF, 0x8CFFFFFF.toInt()),
                floatArrayOf(0f, 0.35f, 0.68f, 1f), Shader.TileMode.CLAMP)
        }
        rim.color = Color.WHITE; rim.shader = rimShader; rim.strokeWidth = density * 1.4f
        c.save(); c.clipPath(path); c.drawPath(path, rim); c.restore()
    }

    @RequiresApi(33)
    private class Agsl {
        private val shader = RuntimeShader(SOURCE)
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

        fun draw(c: Canvas, path: Path, bg: Shader, area: RectF, ox: Float, oy: Float,
                 radius: Float, tint: Int, press: Float, density: Float,
                 clear: Boolean, touchX: Float, touchY: Float, wave: Float) {
            val w = area.width(); val h = area.height()
            shader.setInputShader("bg", bg)
            shader.setFloatUniform("size", w, h)
            shader.setFloatUniform("corner", area.left, area.top)
            shader.setFloatUniform("origin", ox, oy)
            shader.setFloatUniform("radius", radius)
            shader.setFloatUniform("bezel", minOf(density * 13f, minOf(w, h) * 0.38f))
            shader.setFloatUniform("dp", density)
            shader.setFloatUniform("press", press)
            shader.setFloatUniform("clearMode", if (clear) 1f else 0f)
            shader.setFloatUniform("ripple", touchX - area.left, touchY - area.top, wave)
            shader.setFloatUniform("tint", Color.red(tint) / 255f, Color.green(tint) / 255f,
                Color.blue(tint) / 255f, Color.alpha(tint) / 255f)
            paint.shader = shader
            c.drawPath(path, paint)
        }
    }

    companion object {
        /** Quanto tempo a onda do toque leva para sumir. */
        const val WAVE_SECONDS = 1.1f
        private const val SOURCE = """
uniform shader bg;
uniform float2 size;
uniform float2 corner;
uniform float2 origin;
uniform float radius;
uniform float bezel;
uniform float dp;
uniform float press;
uniform float4 tint;
uniform float clearMode;
uniform float3 ripple;

half4 main(float2 coord) {
    float2 half_ = size * 0.5;
    float2 p = coord - corner - half_;
    float2 q = abs(p) - half_ + radius;
    float d = min(max(q.x, q.y), 0.0) + length(max(q, float2(0.0))) - radius;

    float2 n;
    if (q.x > 0.0 && q.y > 0.0) n = normalize(q);
    else if (q.x > q.y) n = float2(1.0, 0.0);
    else n = float2(0.0, 1.0);
    n *= float2(p.x < 0.0 ? -1.0 : 1.0, p.y < 0.0 ? -1.0 : 1.0);

    float t = clamp(1.0 + d / bezel, 0.0, 1.0);
    float bend = (1.0 - sqrt(max(1.0 - t * t, 0.0))) * bezel * 2.2;
    float2 base = origin + corner + half_ + p / (1.06 + 0.12 * press);
    float2 shift = -n * bend;

    // onda grossa e lenta que sai do ponto do toque
    float wave = 0.0;
    if (ripple.z >= 0.0) {
        float2 v = coord - corner - ripple.xy;
        float dist = length(v);
        float x = (dist - ripple.z * 95.0 * dp) / (11.0 * dp);
        wave = sin(x * 3.14159) * exp(-x * x * 0.6) * exp(-2.8 * ripple.z);
        base += v / max(dist, 1.0) * wave * 9.0 * dp;
    }

    // refração discreta: a borda curva o fundo, quase sem separar as cores
    float3 col;
    col.r = bg.eval(base + shift * 1.04).r;
    col.g = bg.eval(base + shift).g;
    col.b = bg.eval(base + shift * 0.96).b;

    float luma = dot(col, float3(0.299, 0.587, 0.114));
    col = mix(float3(luma), col, 1.04);
    col = mix(col, tint.rgb, tint.a);
    col += 0.02 + 0.06 * press;

    // luz vinda do canto de cima à esquerda, com a contraluz fraca no canto oposto
    float light = abs(dot(n, normalize(float2(-0.55, -0.83))));
    float l3 = light * light * light;
    // fio da borda: fino, sempre visível, mais forte nos dois cantos
    float line = smoothstep(-1.5 * dp, -0.3 * dp, d);
    float rimA = line * (0.22 + 0.50 * l3);
    // névoa suave logo dentro da borda (o "volume" do vidro)
    float haze = t * t * t * (0.05 + 0.07 * light);

    col += rimA + haze;
    col += max(wave, 0.0) * 0.20;

    float a = clamp(0.5 - d, 0.0, 1.0);
    if (clearMode > 0.5) {
        // vidro transparente: corpo bem leve e fosco (branco ~10%), luz só na borda e um pouco por dentro
        float shine = rimA + haze + abs(wave) * 0.30 + 0.07 * press;
        float gloss = (1.0 - smoothstep(0.0, 0.50, (p.y + half_.y) / size.y)) * 0.025;
        shine = clamp(shine + gloss, 0.0, 0.80);
        bool tinted = tint.a > 0.3;
        float body = tinted ? tint.a : 0.10;
        float3 bodyColor = tinted ? tint.rgb : float3(1.0);
        float outA = shine + body * (1.0 - shine);
        float3 pre = float3(shine) + bodyColor * body * (1.0 - shine);
        return half4(half3(pre * a), outA * a);
    }
    return half4(half3(clamp(col, 0.0, 1.0) * a), a);
}
"""
    }
}

/** O mesmo vidro como fundo de uma view qualquer (barra de ícones, seta e microfone). */
class LiquidGlassDrawable(private val host: View, private val radius: Float, private val tint: Int) : Drawable() {
    private val glass = LiquidGlass(host.resources.displayMetrics.density)
    private val area = RectF()
    private val flat = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun draw(canvas: Canvas) {
        area.set(bounds)
        if (!glass.draw(canvas, host, area, radius, 0, tint, 0f)) {
            flat.color = tint
            canvas.drawRoundRect(area, radius, radius, flat)
        }
    }

    override fun setAlpha(alpha: Int) {}
    override fun setColorFilter(colorFilter: ColorFilter?) {}
    @Deprecated("Deprecated in Java")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}

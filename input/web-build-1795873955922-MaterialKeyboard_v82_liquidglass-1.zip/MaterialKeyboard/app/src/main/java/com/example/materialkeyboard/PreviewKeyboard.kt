package com.example.materialkeyboard

import android.content.Context
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout

/**
 * Prévia do teclado em tempo real: mini teclado com as cores, formato, estilo, fonte, borda, relevo,
 * altura e animações atuais. Atualiza sozinho a cada mudança nas preferências e toca o som escolhido
 * (e vibra) ao tocar nas teclas, para testar tudo sem sair das configurações.
 */
class PreviewKeyboard(ctx: Context, private val prefs: Prefs) : LinearLayout(ctx) {

    private data class K(val view: KeyView, val ch: String, val kind: Int)   // kind: 0 letra, 1 especial, 2 destaque

    private val all = ArrayList<K>()
    private var bank: SoundBank? = null
    private val listener: () -> Unit = { post { sync() } }
    private fun dp(v: Int) = (v * resources.displayMetrics.density + 0.5f).toInt()

    /** Teclas, para páginas que alteram um valor ao vivo (antes de salvar). */
    val keys: List<KeyView> get() = all.map { it.view }

    init {
        orientation = VERTICAL
        setPadding(dp(8), dp(10), dp(8), dp(10))
        layoutParams = LayoutParams(-1, -2).apply { bottomMargin = dp(8) }
        row("qwertyuiop", 0f)
        row("asdfghjkl", 0.5f)
        row("⇧zxcvbnm⌫", 0f)
        val last = LinearLayout(ctx).apply { orientation = HORIZONTAL; gravity = Gravity.CENTER }
        fun add(ch: String, w: Float, kind: Int) = last.addView(key(ch, kind), LayoutParams(0, -1, w).apply { setMargins(dp(2), dp(2), dp(2), dp(2)) })
        add("?123", 1.4f, 1); add(",", 1f, 1); add("␣", 5f, 0); add(".", 1f, 1); add("↵", 1.4f, 2)
        addView(last, LayoutParams(-1, dp(40)))
        sync()
    }

    private fun row(chars: String, pad: Float) {
        val r = LinearLayout(context).apply { orientation = HORIZONTAL; gravity = Gravity.CENTER }
        if (pad > 0) r.addView(View(context), LayoutParams(0, 1, pad))
        chars.forEach { c ->
            val kind = if (c in "⇧⌫") 1 else 0
            r.addView(key(c.toString(), kind), LayoutParams(0, -1, if (kind == 1) 1.4f else 1f).apply { setMargins(dp(2), dp(2), dp(2), dp(2)) })
        }
        if (pad > 0) r.addView(View(context), LayoutParams(0, 1, pad))
        addView(r, LayoutParams(-1, dp(40)))
    }

    private fun key(ch: String, kind: Int): KeyView {
        val k = KeyView(context)
        k.label = if (ch.length == 1 && ch[0].isLetter()) ch.lowercase() else ch
        k.onDown = { play(ch) }
        all.add(K(k, ch, kind))
        return k
    }

    private fun play(ch: String) {
        val c = ch[0]
        val slot = when (ch) {
            "⇧" -> SoundBank.Slot.SHIFT; "⌫" -> SoundBank.Slot.DELETE; "↵" -> SoundBank.Slot.ENTER
            "␣" -> SoundBank.Slot.SPACE; "?123" -> SoundBank.Slot.EDGE
            else -> SoundBank.Slot.of(c, c.isLetter())
        }
        val own = if (slot >= 0) prefs.keySounds[slot] else -1
        val type = if (own >= 0) own else prefs.soundType
        val clip = SoundBank.Slot.clip(slot) ?: when (ch) { "␣" -> "space"; else -> SoundBank.clipOf(c) }
        val b = bank
        if (b != null && prefs.sound && prefs.soundVolume > 0) Thread {
            b.prepare(type)
            b.play(type, clip, prefs.soundVolume / 100f, prefs.soundPitch / 100f, prefs.soundHumanize)
        }.start()
        if (prefs.vibrate) try {
            val v = context.getSystemService(Context.VIBRATOR_SERVICE) as android.os.Vibrator
            v.vibrate(android.os.VibrationEffect.createOneShot(8L + prefs.vibrateStrength / 5, (prefs.vibrateStrength * 255 / 100).coerceIn(1, 255)))
        } catch (_: Exception) { }
    }

    /** Relê as preferências e repinta tudo. */
    fun sync() {
        val pal = Palette.build(context, prefs)
        background = if (prefs.liquidGlass) com.example.materialkeyboard.LiquidBackdrop(pal.surface, pal.keyAccent, dp(26).toFloat())
            else GradientDrawable().apply { cornerRadius = dp(26).toFloat(); setColor(pal.surface) }
        val h = dp((prefs.keyHeight * 0.8f).toInt().coerceIn(30, 46))
        for (i in 0 until childCount) getChildAt(i).layoutParams = (getChildAt(i).layoutParams as LayoutParams).apply { height = h }
        all.forEach { (v, _, kind) ->
            v.bg = when (kind) { 1 -> pal.keySpecial; 2 -> pal.keyAccent; else -> pal.keyNormal }
            v.fg = when (kind) { 1 -> pal.onSpecial; 2 -> pal.onAccent; else -> pal.onNormal }
            v.radius = dp(prefs.keyRadius).toFloat(); v.textSizePx = dp(15).toFloat()
            v.fluid = prefs.fluid; v.keyStyle = prefs.activeKeyStyle; v.lens = prefs.liquidGlass; v.liquidAccent = pal.keyAccent; v.glow = prefs.pressGlow
            v.shape = prefs.keyShape; v.fontStyle = prefs.fontStyle
            v.borderPx = dp(prefs.keyBorder).toFloat(); v.depthPx = dp(prefs.activeKeyDepth).toFloat()
            v.invalidate()
        }
        requestLayout()
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow(); prefs.addListener(listener)
        val b = SoundBank(context); bank = b
        Thread { b.prepareAll(prefs.usedSoundTypes()) }.start()
        sync()
    }
    override fun onDetachedFromWindow() { prefs.removeListener(listener); bank?.release(); bank = null; super.onDetachedFromWindow() }
}

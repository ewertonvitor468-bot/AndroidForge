# MonetLauncher 1.2

Kotlin + Jetpack Compose. Visual One UI 3.1 + home no estilo Motorola. Material You (Monet).

## Novidades 1.2
- CORRIGIDO: erro de compilação (combinedClickable é API experimental -> @OptIn)
- Home Motorola: data + saudação ("At a Glance"), várias páginas com indicador, dock + barra de pesquisa embaixo
- Deslizar para baixo abre as notificações; para cima abre a gaveta
- Gaveta com linha de "Recentes"
- Novas opções: data/saudação, barra de pesquisa, fundo do dock, gesto de notificações

## Requisitos
Android 12+ (minSdk 31). Defina como tela inicial padrão após instalar.

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}


android {
    namespace = "com.example.materialkeyboard"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.example.materialkeyboard"
        minSdk = 26
        ndk { abiFilters += listOf("arm64-v8a", "armeabi-v7a") }   // tira x86: APK bem menor
        targetSdk = 34
        versionCode = 75 // << a cada versão nova, mude aqui e abaixo (72 -> 73...)
        versionName = "75.2"
        // (sem resourceConfigurations: o PocketCode não compila essa linha. No Android Studio, dá para recolocá-la para o APK ficar menor.)
    }
    // Assinatura FIXA (v65.5): o GitHub gera uma chave de teste nova a cada build, e por isso o Android recusava a atualização
    // automática ("App não instalado"). Com a chave guardada nos Secrets do GitHub, todo APK sai com a mesma assinatura e atualiza por cima.
    val mkStore = System.getenv("MK_KEYSTORE")
    signingConfigs {
        if (!mkStore.isNullOrBlank()) create("mk") {
            storeFile = file(mkStore)
            storePassword = System.getenv("MK_PASS")
            keyAlias = "mk"
            keyPassword = System.getenv("MK_PASS")
        }
    }
    buildTypes {
        debug { signingConfigs.findByName("mk")?.let { signingConfig = it } }
        release { isMinifyEnabled = true; isShrinkResources = true; proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro"); signingConfigs.findByName("mk")?.let { signingConfig = it } }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { compose = true }
    // Comprime as bibliotecas nativas (tradução offline) dentro do APK: o download/arquivo fica bem menor.
    packaging { jniLibs { useLegacyPackaging = true } }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.dynamicanimation:dynamicanimation:1.0.0")
    // Estilo das sugestões inline de autofill (senhas, endereços) mostradas na barra do teclado (Android 11+).
    implementation("androidx.autofill:autofill:1.1.0")
    // Tradução no aparelho. Os modelos de idioma NÃO vêm no APK: são baixados sob demanda.
    implementation("com.google.mlkit:translate:17.0.3")

    // ---- Jetpack Compose (integração via ComposeView dentro do InputMethodService) ----
    // BOM 2024.09.03 = Compose 1.7.3 + Material3 1.3.0: compatível com AGP 8.5.2, Kotlin 2.0.0 e compileSdk 34.
    // Material 3 Expressive: a API oficial (MotionScheme/MaterialExpressiveTheme) só existe em Material3 1.5+ (1.4.0 estável a removeu),
    // que depende de Compose 1.12 => AGP 9.2+ e compileSdk 37. Por isso o Expressive é implementado em compose/ (ver README).
    implementation(platform("androidx.compose:compose-bom:2024.09.03"))
    implementation("androidx.compose.ui:ui")                 // ComposeView
    implementation("androidx.compose.foundation:foundation") // Canvas, gestos, animações base
    implementation("androidx.compose.animation:animation")   // AnimatedContent/AnimatedVisibility (já vem transitivo; explícito p/ o classpath)
    implementation("androidx.compose.material3:material3")   // Material 3
    // Morfing de formas de verdade (RoundedPolygon/Morph): é a base das formas do Material 3 Expressive.
    implementation("androidx.graphics:graphics-shapes:1.0.1")
    // Donos de ciclo de vida/estado salvo que o ComposeView exige numa janela de IME (não há Activity).
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.6")
    implementation("androidx.savedstate:savedstate-ktx:1.2.1")

    // ---- Conta e nuvem: login com Google (Firebase Auth) + backup das configurações (Firestore, plano gratuito Spark) ----
    // Versões escolhidas para o compileSdk 34 / AGP 8.5.2 atuais: Credential Manager 1.2.x (a 1.3+ exige compileSdk 35) e Firebase BoM 33.1.x.
    // Sem o plugin google-services: o Firebase é iniciado por código com cloud/CloudConfig.kt, e só quando a pessoa abre "Conta e nuvem".
    implementation(platform("com.google.firebase:firebase-bom:33.1.2"))
    implementation("com.google.firebase:firebase-auth")
    implementation("com.google.firebase:firebase-firestore")
    implementation("androidx.credentials:credentials:1.2.2")
    implementation("androidx.credentials:credentials-play-services-auth:1.2.2")
    implementation("com.google.android.libraries.identity.googleid:googleid:1.1.1")
}

package com.example.materialkeyboard.cloud

/**
 * Configuração do Firebase (login com Google + backup no Firestore). Fica em código, como o ThemeBoardConfig, para compilar
 * também em ambientes simples (PocketCode/GitHub Actions) SEM o plugin google-services e SEM o arquivo google-services.json.
 *
 * Os quatro valores vêm do console do Firebase (passo a passo em docs/firebase/README.md). Nenhum deles é segredo:
 * quem protege os dados são as regras do Firestore (docs/firebase/firestore.rules) e a restrição da chave de API ao app.
 * Para DESLIGAR a nuvem, deixe qualquer um em branco: o item "Conta e nuvem" some das configurações e o Firebase nunca é iniciado.
 */
object CloudConfig {
    /** Configurações do projeto > Seus apps > app Android > "Chave de API" (current_key no google-services.json). */
    const val API_KEY = ""
    /** ID do app Android no Firebase, algo como 1:123456789012:android:abcdef0123456789 (mobilesdk_app_id). */
    const val APP_ID = ""
    /** ID do projeto (project_id). */
    const val PROJECT_ID = ""
    /** ID do cliente OAuth do tipo WEB, terminado em .apps.googleusercontent.com (Authentication > Google > Web SDK configuration). */
    const val WEB_CLIENT_ID = ""

    val configured: Boolean
        get() = API_KEY.isNotBlank() && APP_ID.isNotBlank() && PROJECT_ID.isNotBlank() && WEB_CLIENT_ID.isNotBlank()
}

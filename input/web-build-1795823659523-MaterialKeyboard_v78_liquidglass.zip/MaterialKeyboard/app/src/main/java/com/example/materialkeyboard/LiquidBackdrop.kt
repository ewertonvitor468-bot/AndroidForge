package com.example.materialkeyboard

import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.drawable.Drawable
import androidx.core.graphics.ColorUtils

/**
 * Fundo próprio do Liquid Glass. O teclado não enxerga o app atrás dele; é este fundo que o vidro refrata.
 * Usa a imagem escolhida pela pessoa ou, sem imagem, uma cena gerada por código com formas de bordas
 * visíveis (num gradiente liso a refração não aparece). A cena é desenhada pequena e desfocada uma única
 * vez por tamanho; funciona em qualquer versão do Android.
 */
class LiquidBackdrop(
    private val surface: Int, private val accent: Int, private val topR: Float,
    private val photo: Bitmap? = null, private val dim: Float = 0f, private val pos: Float = 0.5f,
    /** Transparente: só um véu leve para as letras continuarem legíveis; o que está atrás da janela aparece. */
    val clear: Boolean = false
) : Drawable() {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val clip = Path()
    private var scene: Bitmap? = null
    private var a = 255

    /** O fundo já pronto, com a matriz que o leva às coordenadas do teclado. */
    var shader: BitmapShader? = null
        private set

    override fun onBoundsChange(b: Rect) {
        val w = b.width(); val h = b.height()
        if (w <= 0 || h <= 0) return
        clip.rewind()
        clip.addRoundRect(RectF(0f, 0f, w.toFloat(), h.toFloat()),
            floatArrayOf(topR, topR, topR, topR, 0f, 0f, 0f, 0f), Path.Direction.CW)
        if (clear) {
            // o shader pede uma textura de entrada; no modo transparente ela é um ponto vazio
            shader = BitmapShader(Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888), Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
            return
        }
        val sw = (w / SCALE).coerceAtLeast(2); val sh = (h / SCALE).coerceAtLeast(2)
        val bmp = Bitmap.createBitmap(sw, sh, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        if (photo != null) drawPhoto(c, sw, sh) else drawScene(c, sw.toFloat(), sh.toFloat())
        blur(bmp, if (photo != null) 1 else 2)
        scene = bmp
        shader = BitmapShader(bmp, Shader.TileMode.MIRROR, Shader.TileMode.MIRROR).apply {
            setLocalMatrix(Matrix().apply { setScale(w.toFloat() / sw, h.toFloat() / sh) })
        }
    }

    private fun drawPhoto(c: Canvas, w: Int, h: Int) {
        val p = photo ?: return
        val s = maxOf(w.toFloat() / p.width, h.toFloat() / p.height)
        val vw = w / s; val vh = h / s
        val x = (p.width - vw) / 2f; val y = (p.height - vh) * pos.coerceIn(0f, 1f)
        c.drawBitmap(p, Rect(x.toInt(), y.toInt(), (x + vw).toInt(), (y + vh).toInt()), Rect(0, 0, w, h), Paint(Paint.FILTER_BITMAP_FLAG))
        c.drawColor(Color.argb((dim.coerceIn(0.1f, 1f) * 255).toInt(), 0, 0, 0))
    }

    private fun tone(deg: Float, light: Float): Int {
        val hsl = FloatArray(3)
        ColorUtils.colorToHSL(accent, hsl)
        // destaque cinza (sem matiz) vira azul, para a cena não ficar apagada
        val hue = if (hsl[1] < 0.15f) 212f else hsl[0]
        return ColorUtils.HSLToColor(floatArrayOf((hue + deg + 360f) % 360f, 0.82f, light))
    }

    private fun drawScene(c: Canvas, w: Float, h: Float) {
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.shader = LinearGradient(0f, 0f, w, h, tone(0f, 0.52f), tone(28f, 0.36f), Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, w, h, p)
        p.shader = null
        p.strokeCap = Paint.Cap.ROUND
        // faixas diagonais: x0, y0, x1, y1, espessura (frações), matiz e claridade
        fun band(x0: Float, y0: Float, x1: Float, y1: Float, t: Float, deg: Float, l: Float) {
            p.color = tone(deg, l); p.strokeWidth = w * t
            c.drawLine(w * x0, h * y0, w * x1, h * y1, p)
        }
        band(-0.05f, 0.30f, 0.42f, 1.10f, 0.085f, 140f, 0.52f)
        band(0.02f, 0.18f, 0.55f, 0.95f, 0.030f, 0f, 0.90f)
        band(0.30f, -0.10f, 0.52f, 0.70f, 0.055f, 118f, 0.62f)
        band(0.55f, 1.10f, 0.98f, 0.05f, 0.100f, 150f, 0.55f)
        band(0.70f, 1.05f, 1.08f, 0.30f, 0.028f, 40f, 0.86f)
        band(0.62f, -0.05f, 1.05f, 0.42f, 0.050f, -60f, 0.30f)
        p.color = tone(165f, 0.60f); c.drawCircle(w * 0.10f, h * 0.88f, w * 0.12f, p)
        p.color = tone(105f, 0.55f); c.drawCircle(w * 0.86f, h * 0.16f, w * 0.09f, p)
    }

    /** Desfoque de caixa em 3 passadas sobre a cena pequena (barato e igual em todos os Androids). */
    private fun blur(b: Bitmap, r: Int) {
        val w = b.width; val h = b.height
        var src = IntArray(w * h); var dst = IntArray(w * h)
        b.getPixels(src, 0, w, 0, 0, w, h)
        repeat(3) {
            for (vertical in 0..1) {
                for (y in 0 until h) for (x in 0 until w) {
                    var cr = 0; var cg = 0; var cb = 0
                    for (k in -r..r) {
                        val v = if (vertical == 0) src[y * w + (x + k).coerceIn(0, w - 1)]
                            else src[(y + k).coerceIn(0, h - 1) * w + x]
                        cr += Color.red(v); cg += Color.green(v); cb += Color.blue(v)
                    }
                    val n = 2 * r + 1
                    dst[y * w + x] = Color.rgb(cr / n, cg / n, cb / n)
                }
                val t = src; src = dst; dst = t
            }
        }
        b.setPixels(src, 0, w, 0, 0, w, h)
    }

    override fun draw(canvas: Canvas) {
        canvas.save()
        canvas.translate(bounds.left.toFloat(), bounds.top.toFloat())
        canvas.clipPath(clip)
        paint(canvas)
        canvas.restore()
    }

    /** Desenha o fundo em coordenadas próprias (0,0 = canto do teclado). */
    fun paint(canvas: Canvas) {
        if (clear) { canvas.drawColor(Color.argb(0x38 * a / 255, 0, 0, 0)); return }
        if (scene == null) { canvas.drawColor(surface); return }
        paint.shader = shader
        paint.alpha = a
        canvas.drawRect(0f, 0f, bounds.width().toFloat(), bounds.height().toFloat(), paint)
    }

    override fun setAlpha(alpha: Int) { if (a != alpha) { a = alpha; invalidateSelf() } }
    override fun getAlpha(): Int = a
    override fun setColorFilter(colorFilter: ColorFilter?) { paint.colorFilter = colorFilter }
    @Deprecated("Deprecated in Java")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT

    private companion object { const val SCALE = 4 }
}

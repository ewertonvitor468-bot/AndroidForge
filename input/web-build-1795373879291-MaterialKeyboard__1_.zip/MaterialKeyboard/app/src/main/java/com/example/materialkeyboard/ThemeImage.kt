package com.example.materialkeyboard

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.drawable.Drawable
import android.net.Uri
import androidx.core.graphics.ColorUtils
import java.io.File

/** Imagem de fundo do teclado: copiada da galeria para a pasta do app (sem precisar de permissão). */
object ThemeImage {
    private var cache: Bitmap? = null
    private var cacheRev = -1
    private var lum = 0.5f
    private var avg = 0xFF303030.toInt()

    fun file(ctx: Context) = File(ctx.applicationContext.filesDir, "theme_bg.jpg")

    @Synchronized
    fun get(ctx: Context, rev: Int): Bitmap? {
        if (cache != null && cacheRev == rev) return cache
        val f = file(ctx)
        if (!f.exists()) { cache = null; return null }
        val bmp = try { BitmapFactory.decodeFile(f.absolutePath) } catch (_: Throwable) { null }
        cache = bmp; cacheRev = rev
        if (bmp != null) analyze(bmp)
        return bmp
    }

    fun luminance() = lum
    fun averageColor() = avg

    private fun analyze(b: Bitmap) {
        val s = Bitmap.createScaledBitmap(b, 24, 24, true)
        var r = 0L; var g = 0L; var bl = 0L
        for (y in 0 until 24) for (x in 0 until 24) {
            val p = s.getPixel(x, y)
            r += Color.red(p); g += Color.green(p); bl += Color.blue(p)
        }
        val n = 24 * 24
        avg = Color.rgb((r / n).toInt(), (g / n).toInt(), (bl / n).toInt())
        lum = ColorUtils.calculateLuminance(avg).toFloat()
        if (s !== b) s.recycle()
    }

    /** Lê a imagem escolhida, reduz (lado maior 1280px) e grava como JPEG. Chamar fora da thread principal. */
    fun import(ctx: Context, uri: Uri): Boolean = try {
        val cr = ctx.contentResolver
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        val longSide = maxOf(bounds.outWidth, bounds.outHeight)
        while (longSide / (sample * 2) >= 1280) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        val raw = cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
        if (raw == null) false else {
            val scale = 1280f / maxOf(raw.width, raw.height)
            val out = if (scale < 1f)
                Bitmap.createScaledBitmap(raw, (raw.width * scale).toInt(), (raw.height * scale).toInt(), true)
            else raw
            file(ctx).outputStream().use { out.compress(Bitmap.CompressFormat.JPEG, 90, it) }
            true
        }
    } catch (_: Throwable) { false }

    /** Grava um quadro (capa do vídeo) como imagem de fundo, no mesmo formato da importação da galeria. */
    fun saveBitmap(ctx: Context, raw: Bitmap): Boolean = try {
        val scale = 1280f / maxOf(raw.width, raw.height)
        val out = if (scale < 1f) Bitmap.createScaledBitmap(raw, (raw.width * scale).toInt(), (raw.height * scale).toInt(), true) else raw
        file(ctx).outputStream().use { out.compress(Bitmap.CompressFormat.JPEG, 90, it) }
        true
    } catch (_: Throwable) { false }

    fun delete(ctx: Context) { file(ctx).delete(); VideoBg.file(ctx).delete(); synchronized(this) { cache = null; cacheRev = -1 } }
}

/**
 * Fundo com a imagem, escurecida e com cantos arredondados.
 * [fit] 0 = preenche e corta (com posição vertical ajustável); 1 = estica a imagem de referência até as bordas do teclado.
 * [cl], [ct], [cr], [cb] = recorte da imagem (fração 0..0.45 de cada lado) antes de encaixar.
 */
class ImageBgDrawable(
    private val bmp: Bitmap, private val dim: Float, private val pos: Float,
    private val topR: Float, private val bottomR: Float = 0f,
    private val fit: Int = 0, private val cl: Float = 0f, private val ct: Float = 0f,
    private val cr: Float = 0f, private val cb: Float = 0f
) : Drawable() {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val path = Path()
    private val src = Rect()
    private val dst = RectF()
    private var alphaV = 255

    override fun onBoundsChange(b: Rect) {
        val w = b.width().toFloat(); val h = b.height().toFloat()
        if (w <= 0f || h <= 0f) return
        path.reset()
        path.addRoundRect(RectF(b), floatArrayOf(topR, topR, topR, topR, bottomR, bottomR, bottomR, bottomR), Path.Direction.CW)
        val bw = bmp.width.toFloat(); val bh = bmp.height.toFloat()
        // área da imagem que vale (depois do recorte); sempre sobra pelo menos 10% de cada eixo
        val l = bw * cl.coerceIn(0f, 0.45f)
        val t = bh * ct.coerceIn(0f, 0.45f)
        val r = bw * (1f - cr.coerceIn(0f, 0.45f)).coerceAtLeast(0.1f)
        val bt = bh * (1f - cb.coerceIn(0f, 0.45f)).coerceAtLeast(0.1f)
        val aw = (r - l).coerceAtLeast(1f); val ah = (bt - t).coerceAtLeast(1f)
        if (fit == 1) {
            // esticar: a área recortada ocupa o teclado inteiro, sem sobrar nem faltar nada
            src.set(l.toInt(), t.toInt(), (l + aw).toInt().coerceAtMost(bmp.width), (t + ah).toInt().coerceAtMost(bmp.height))
        } else {
            val s = maxOf(w / aw, h / ah)
            val vw = w / s; val vh = h / s
            val sx = l + (aw - vw) / 2f
            val sy = t + (ah - vh) * pos.coerceIn(0f, 1f)
            src.set(sx.toInt(), sy.toInt(), (sx + vw).toInt().coerceAtMost(bmp.width), (sy + vh).toInt().coerceAtMost(bmp.height))
        }
        dst.set(b)
    }

    override fun draw(c: Canvas) {
        if (src.width() <= 0 || src.height() <= 0) return
        val save = c.save()
        c.clipPath(path)
        c.drawBitmap(bmp, src, dst, paint)
        if (dim > 0f) c.drawColor(Color.argb((dim * alphaV).toInt().coerceIn(0, 255), 0, 0, 0))
        c.restoreToCount(save)
    }

    override fun setAlpha(a: Int) { alphaV = a; paint.alpha = a; invalidateSelf() }
    override fun getAlpha() = alphaV
    override fun setColorFilter(cf: ColorFilter?) { paint.colorFilter = cf }
    @Deprecated("Deprecated in Java")
    override fun getOpacity() = PixelFormat.TRANSLUCENT
}

/** Fundo da imagem com o modo, o recorte e a posição que estão nas preferências. */
fun Prefs.imageBg(bmp: Bitmap, topR: Float, bottomR: Float = 0f) =
    ImageBgDrawable(bmp, imageDim / 100f, imagePos / 100f, topR, bottomR, imgFit, imgL / 100f, imgT / 100f, imgR / 100f, imgB / 100f)

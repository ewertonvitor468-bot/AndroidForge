package com.example.materialkeyboard.compose

import android.app.Activity
import android.view.View
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import com.example.materialkeyboard.UiTr
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.material3.OutlinedTextField
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import com.example.materialkeyboard.ImageBgDrawable
import com.example.materialkeyboard.L
import com.example.materialkeyboard.Palette
import com.example.materialkeyboard.Prefs
import com.example.materialkeyboard.R
import com.example.materialkeyboard.TLangs
import com.example.materialkeyboard.ThemeImage
import com.example.materialkeyboard.TranslationEngine
import com.example.materialkeyboard.TranslatorPrefs
import com.example.materialkeyboard.tr
import kotlinx.coroutines.delay
import kotlin.math.roundToInt

/** Barra de status, de navegação e fundo da janela na cor do tema do teclado. */
fun Activity.applyMkBars() {
    val pal = Palette.build(this, Prefs.get(this))
    window.statusBarColor = pal.surface
    window.navigationBarColor = pal.surface
    window.decorView.setBackgroundColor(pal.surface)
    WindowCompat.getInsetsController(window, window.decorView).apply {
        isAppearanceLightStatusBars = !pal.isDark
        isAppearanceLightNavigationBars = !pal.isDark
    }
}

@Composable
private fun PageCtx.Flash(text: String, done: String, danger: Boolean = false, action: () -> Unit) {
    var ok by remember { mutableStateOf(false) }
    LaunchedEffect(ok) { if (ok) { delay(1600); ok = false } }
    MkAction(if (ok) "✓ $done" else text, danger) { action(); ok = true }
}

@Composable
fun TranslatorScreen(prefs: Prefs) = PageHost(prefs) {
    val appCtx = LocalContext.current
    val tp = remember { TranslatorPrefs.get(appCtx) }
    val codes = TLangs.all.map { it.short }
    var status by remember { mutableStateOf("Verificando modelos baixados…".tr()) }
    val reload = {
        TranslationEngine.downloadedLanguages { have ->
            val names = TLangs.all.filter { it.code in have }.map { it.name.tr() }
            status = if (names.isEmpty()) "Nenhum modelo baixado ainda.".tr() else L.f("Baixados: %s.", names.joinToString(", "))
        }
    }
    LaunchedEffect(Unit) { reload() }
    MkCard("Idiomas".tr()) {
        MkNote("Traduz o que você digita, no próprio aparelho (Google ML Kit), e insere no app com um toque. Mais de 40 idiomas, incluindo árabe, persa, hindi, chinês, japonês e coreano.".tr())
        Text("Idioma de origem".tr(), color = MaterialTheme.colorScheme.onSurface, fontWeight = FontWeight.Medium)
        ChipRow(codes, TLangs.indexOf(tp.source)) {
            val c = TLangs.all[it].code
            if (c == tp.target) tp.target = tp.source
            tp.source = c; refresh()
        }
        Text("Idioma de destino".tr(), color = MaterialTheme.colorScheme.onSurface, fontWeight = FontWeight.Medium)
        ChipRow(codes, TLangs.indexOf(tp.target)) {
            val c = TLangs.all[it].code
            if (c == tp.source) tp.source = tp.target
            tp.target = c; refresh()
        }
        MkAction("⇄  " + "Trocar idiomas".tr()) { val a = tp.source; tp.source = tp.target; tp.target = a; refresh() }
    }
    MkCard("Atualização".tr()) {
        MkSlider("Pausa antes de traduzir".tr(), tp.delayMs, 200, 2000, " ms") { tp.delayMs = it }
        MkNote("A tradução se atualiza sozinha quando você para de digitar por esse tempo. No teclado, o botão ⏸ pausa e retoma.".tr())
    }
    MkCard("Modelos de idioma".tr()) {
        MkSwitch("Baixar só no Wi-Fi".tr(), "Cada idioma tem cerca de 30 MB, baixados só quando você precisa e não vêm no app".tr(), tp.wifiOnly) { tp.wifiOnly = it; refresh() }
        Text(status, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f), style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(vertical = 8.dp))
        MkAction("Excluir modelos baixados".tr(), true) { TranslationEngine.deleteModels { reload() } }
        MkNote("A tradução acontece no aparelho. A internet só é usada para baixar os modelos. Em campos de senha o tradutor fica desativado.".tr())
    }
    var voiceKey by remember { mutableStateOf(prefs.voiceKeyNow()) }
    MkCard("Ditado por voz".tr()) {
        MkNote("O microfone usa o reconhecimento de voz do próprio Android: nada para baixar, começa a ouvir na hora. Em aparelhos mais novos, funciona até sem internet. Opcional: com uma chave do Groq (gsk_) ou da OpenAI (sk-), o áudio vai para a nuvem, com mais precisão. Deixe em branco para usar o reconhecimento do Android.".tr())
        OutlinedTextField(voiceKey, { voiceKey = it.trim(); prefs.putString("voiceKey", voiceKey) }, singleLine = true,
            modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp), label = { Text("Chave da API".tr()) })
    }
}

@Composable
fun LanguageScreen(prefs: Prefs, onChanged: () -> Unit) = PageHost(prefs) {
    val cs = MaterialTheme.colorScheme
    val codes = listOf(Prefs.LANG_PT, Prefs.LANG_EN, Prefs.LANG_ES, Prefs.LANG_AR, Prefs.LANG_RU, Prefs.LANG_FR, Prefs.LANG_TR, Prefs.LANG_VI)
    val ptNames = mapOf(Prefs.LANG_PT to "Português", Prefs.LANG_EN to "Inglês", Prefs.LANG_RU to "Russo", Prefs.LANG_ES to "Espanhol", Prefs.LANG_AR to "Árabe", Prefs.LANG_FR to "Francês", Prefs.LANG_TR to "Turco", Prefs.LANG_VI to "Vietnamita")
    MkCard("Idioma".tr()) {
        codes.forEach { c ->
            val native = L.NATIVE[c] ?: c
            val translated = (ptNames[c] ?: c).tr()
            Row(Modifier.fillMaxWidth().clickable {
                if (prefs.language != c || prefs.uiLang.isNotEmpty()) { prefs.putString("uiLang", ""); prefs.putString("language", c); L.code = c; onChanged() }
            }.padding(vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(native, color = cs.onSurface, fontWeight = FontWeight.Medium)
                    if (translated != native) Text(translated, color = cs.onSurface.copy(alpha = 0.62f), style = MaterialTheme.typography.bodySmall)
                }
                AnimatedVisibility(prefs.language == c, enter = scaleIn(spring(Spring.DampingRatioMediumBouncy)), exit = scaleOut()) {
                    Icon(painterResource(R.drawable.ic_check), null, tint = cs.primary, modifier = Modifier.size(26.dp))
                }
            }
        }
        MkNote("O idioma escolhido vale para o teclado e para todo o aplicativo.".tr())
    }
    // ---- v65.5: idioma só dos menus do app, em dezenas de línguas (o teclado e o Tradutor ficam como estão) ----
    MkCard("Idioma do aplicativo".tr()) {
        val ctx = LocalContext.current
        var query by remember { mutableStateOf("") }
        var tick by remember { mutableIntStateOf(0) }
        var errorCode by remember { mutableStateOf<String?>(null) }
        // enquanto traduz, atualiza o andamento a cada instante
        LaunchedEffect(UiTr.workingCode) { while (UiTr.workingCode != null) { delay(300); tick++ } }
        val busy = UiTr.workingCode
        val all = TLangs.all.filter { it.code !in UiTr.BUILT_IN }
        val q = query.trim().lowercase()
        val shown = if (q.isEmpty()) all else all.filter { it.name.lowercase().contains(q) || it.code.lowercase() == q }
        MkNote("Escolha a língua dos menus e textos do aplicativo. O teclado (as letras) continua no idioma que você escolheu acima, e o Tradutor não muda. A tradução é feita no aparelho, uma vez por idioma (precisa de internet só para baixar o modelo, cerca de 30 MB).".tr())
        // "igual ao teclado"
        val followSel = prefs.uiLang.isEmpty()
        Row(Modifier.fillMaxWidth().clickable {
            if (!followSel && busy == null) { prefs.putString("uiLang", ""); L.code = prefs.language; onChanged() }
        }.padding(vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Igual ao teclado".tr(), color = cs.onSurface, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
            AnimatedVisibility(followSel, enter = scaleIn(spring(Spring.DampingRatioMediumBouncy)), exit = scaleOut()) {
                Icon(painterResource(R.drawable.ic_check), null, tint = cs.primary, modifier = Modifier.size(26.dp))
            }
        }
        OutlinedTextField(query, { query = it }, singleLine = true, modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
            label = { Text("Buscar idioma".tr()) })
        if (busy != null) {
            val name = TLangs.of(busy).name
            Text(L.f("Traduzindo o app para %s: %d de %d", name, UiTr.done, UiTr.total) + if (tick < 0) "" else "",
                color = cs.primary, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(vertical = 8.dp))
        }
        errorCode?.let {
            Text("Não foi possível baixar o idioma. Verifique a conexão e tente de novo.".tr(), color = cs.error,
                style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(vertical = 8.dp))
        }
        shown.forEach { lg ->
            val sel = prefs.uiLang == lg.code
            Row(Modifier.fillMaxWidth().clickable {
                if (busy != null || sel) return@clickable
                errorCode = null
                UiTr.ensure(lg.code) { ok ->
                    if (ok) { prefs.putString("uiLang", lg.code); L.code = lg.code; onChanged() }
                    else { errorCode = lg.code; tick++ }
                }
                tick++
            }.padding(vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(lg.name, color = cs.onSurface, fontWeight = FontWeight.Medium)
                    if (!UiTr.isReady(lg.code)) Text("Tradução automática (baixa uma vez)".tr(), color = cs.onSurface.copy(alpha = 0.62f), style = MaterialTheme.typography.bodySmall)
                }
                AnimatedVisibility(sel, enter = scaleIn(spring(Spring.DampingRatioMediumBouncy)), exit = scaleOut()) {
                    Icon(painterResource(R.drawable.ic_check), null, tint = cs.primary, modifier = Modifier.size(26.dp))
                }
            }
        }
        MkNote("Textos em tradução automática podem ter pequenos erros. Quando algo não estiver traduzido, aparece em inglês.".tr())
    }
    MkCard("Botão de idioma".tr()) {
        // o botão do globo só alterna entre os idiomas ligados aqui
        val on = prefs.langList.split(",").map { it.trim() }.filter { it in codes }.toSet()
        codes.forEach { c ->
            val checked = c in on
            MkSwitch(L.NATIVE[c] ?: c, null, checked) { want ->
                val next = if (want) on + c else on - c
                if (next.isNotEmpty()) { prefs.putString("langList", codes.filter { it in next }.joinToString(",")); refresh() }
            }
        }
        MkNote("O botão do globo alterna só entre os idiomas ligados aqui. Pelo menos um fica ligado.".tr())
    }
    MkCard("Dicas de digitação".tr()) {
        MkNote("Español: layout QWERTY com ñ; segure as vogais para os acentos (á é í ó ú ü) e « . » para ¿ ¡. العربية: layout árabe padrão, da direita para a esquerda; segure ا ي و ه para hamza e variantes, a tecla ـَ para as vogais curtas (harakat) e « . » para ، ؟ ؛.".tr())
        MkNote("Русский: layout ЙЦУКЕН com sugestões; segure «е» para ё e «ь» para ъ. Français: layout AZERTY; segure uma vogal para acentos (é è ê à ç). Türkçe: layout Q turco (ç ğ ı ö ş ü), com İ e I certos nas maiúsculas. Tiếng Việt: digite em Telex (aa→â, aw→ă, ow→ơ, dd→đ; s f r x j = acentos).".tr())
    }
}

@Composable
fun BarScreen(prefs: Prefs) = PageHost(prefs) {
    MkCard("Botão ao lado do espaço".tr()) {
        ChipRow(listOf("Idioma".tr(), "Emoji".tr(), "Nenhum".tr()), prefs.langKey) { prefs.putInt("langKey", it); refresh() }
        MkNote("Idioma: um toque troca entre os idiomas que você ligou em Idioma → Botão de idioma, como no Gboard. Emoji: o botão de emoji passa a ficar ao lado do espaço, no lugar do idioma. Nenhum: tira o botão.".tr())
    }
    MkCard("Modo uma mão".tr()) {
        ChipRow(listOf("Desligado".tr(), "Esquerda".tr(), "Direita".tr()), prefs.oneHand) { prefs.putInt("oneHand", it); refresh() }
        MkNote("O teclado encolhe para o lado escolhido e ganha uma faixa com os botões de voltar à largura total e trocar de lado. Também dá para ligar pelo ícone de uma mão na barra (Posicionar as teclas).".tr())
    }
    MkCard("Teclado flutuante".tr()) {
        MkSwitch("Flutuante".tr(), "Arraste pela alça no topo para mover o teclado pela tela. O app por trás não é empurrado.".tr(), prefs.floating) { prefs.putBool("floating", it); refresh() }
        MkNote("No modo flutuante o cenário animado e o vídeo de fundo ficam desligados.".tr())
    }
    MkCard("Barra deslizável".tr()) {
        ChipRow(listOf("Começa à esquerda".tr(), "Começa à direita".tr()), prefs.barSide) { prefs.putInt("barSide", it); refresh() }
        MkNote("Quando os ícones não cabem, deslize a barra para os lados. Aqui você escolhe de que lado ela começa.".tr())
    }
    MkCard("Posicionar as teclas".tr()) {
        MkNote("Para mudar a ordem, tirar ou colocar mais ícones, abra o teclado e toque no ícone de posicionar (quatro blocos com setas) na barra de ícones.".tr())
        Flash("Restaurar a barra padrão".tr(), "Barra restaurada") { prefs.putString("barItems", Prefs.DEFAULT_BAR) }
    }
    MkCard("Posicionar Keycaps".tr()) {
        MkNote("Arraste uma tecla de letra sobre outra para trocar as duas de lugar (por exemplo, P no lugar do Q e Q no lugar do P). A disposição fica salva para cada layout: QWERTY, العربية e Русский. Para começar, abra o teclado, toque na seta para expandir e toque no ícone de quatro blocos com setas na barra de ícones e escolha Posicionar Keycaps.".tr())
        Flash("Restaurar letras do teclado".tr(), "Letras restauradas") { prefs.clearKeyRows() }
    }
}

/** Medidas reais do teclado (em dp) para a prévia ter a mesma proporção e a imagem esticada bater com as teclas de verdade. */
private class BoardDims(val wDp: Float, val hDp: Float, val keyH: Float, val sc: Float)

private fun boardDims(ctx: android.content.Context, prefs: Prefs): BoardDims {
    val dm = ctx.resources.displayMetrics
    val land = ctx.resources.configuration.orientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE
    val sc = prefs.keyboardScale.coerceIn(70, 130) / 100f
    val rows = 4 + if (prefs.numberRow) 1 else 0
    val keyH = prefs.keyHeight * sc * (if (land) 0.8f else 1f)
    val w = dm.widthPixels / dm.density
    return BoardDims(w, 4f + 44f * sc + keyH * rows + 8f, keyH, sc)
}

private class Cell(val label: String, val w: Float, val gap: Boolean = false)

/** Teclas de amostra desenhadas só como guia (contorno), na mesma disposição e tamanho do teclado. */
@Composable
private fun SampleKeys(prefs: Prefs, d: BoardDims, tint: androidx.compose.ui.graphics.Color, modifier: Modifier) {
    androidx.compose.foundation.Canvas(modifier) {
        val u = size.width / d.wDp
        val gx = maxOf(prefs.keyGap - 1, 1) * u
        val gy = (prefs.keyGap + 1) * u
        val rad = androidx.compose.ui.geometry.CornerRadius(prefs.keyRadius * u)
        val padX = 6f * u
        val fill = tint.copy(alpha = 0.16f)
        val txt = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
            color = android.graphics.Color.WHITE
            textAlign = android.graphics.Paint.Align.CENTER
            textSize = 15f * u * d.sc
            setShadowLayer(3f * u, 0f, 0f, android.graphics.Color.BLACK)
        }
        // faixa de ícones
        val barTop = 4f * u
        val barH = 44f * d.sc * u
        val bx = padX + 4f * u
        val barPos = androidx.compose.ui.geometry.Offset(bx, barTop + 2f * u)
        val barSize = androidx.compose.ui.geometry.Size(size.width - 2f * bx, barH - 4f * u)
        drawRoundRect(fill, barPos, barSize, androidx.compose.ui.geometry.CornerRadius(20f * u))
        drawRoundRect(tint, barPos, barSize, androidx.compose.ui.geometry.CornerRadius(20f * u),
            style = androidx.compose.ui.graphics.drawscope.Stroke(1.5f * u))
        val rows = ArrayList<List<Cell>>()
        if (prefs.numberRow) rows.add("1234567890".map { Cell(it.toString(), 1f) })
        rows.add("qwertyuiop".map { Cell(it.toString(), 1f) })
        rows.add(listOf(Cell("", 0.5f, true)) + "asdfghjkl".map { Cell(it.toString(), 1f) } + Cell("", 0.5f, true))
        rows.add(listOf(Cell("\u21E7", 1.5f)) + "zxcvbnm".map { Cell(it.toString(), 1f) } + Cell("\u232B", 1.5f))
        rows.add(listOf(Cell("?123", 1.5f), Cell("PT", 1f), Cell("", 5f), Cell(".", 1f), Cell("\u21B5", 1.5f)))
        var y = barTop + barH
        val kh = d.keyH * u
        val avail = size.width - 2f * padX
        for (row in rows) {
            val total = row.sumOf { it.w.toDouble() }.toFloat()
            var x = padX
            for (c in row) {
                val cw = avail * c.w / total
                if (!c.gap) {
                    val pos = androidx.compose.ui.geometry.Offset(x + gx, y + gy)
                    val sz = androidx.compose.ui.geometry.Size(cw - 2f * gx, kh - 2f * gy)
                    drawRoundRect(fill, pos, sz, rad)
                    drawRoundRect(tint, pos, sz, rad, style = androidx.compose.ui.graphics.drawscope.Stroke(1.2f * u))
                    if (c.label.isNotEmpty()) drawContext.canvas.nativeCanvas.drawText(c.label, pos.x + sz.width / 2f, pos.y + sz.height / 2f + txt.textSize * 0.35f, txt)
                }
                x += cw
            }
            y += kh
        }
    }
}

@Composable
fun ImageScreen(prefs: Prefs, onPick: () -> Unit, onRemove: () -> Unit) = PageHost(prefs) {
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    val hasImage = ThemeImage.file(ctx).exists()
    val bmp = if (hasImage) ThemeImage.get(ctx, prefs.themeImageRev) else null
    var pos by remember { mutableFloatStateOf(prefs.imagePos.toFloat()) }
    var dim by remember { mutableFloatStateOf(prefs.imageDim.toFloat()) }
    var fit by remember { mutableIntStateOf(prefs.imgFit) }
    var cl by remember { mutableFloatStateOf(prefs.imgL.toFloat()) }
    var ct by remember { mutableFloatStateOf(prefs.imgT.toFloat()) }
    var cr by remember { mutableFloatStateOf(prefs.imgR.toFloat()) }
    var cb by remember { mutableFloatStateOf(prefs.imgB.toFloat()) }
    var sample by remember { mutableStateOf(prefs.imgSample) }
    val r = with(LocalDensity.current) { 24.dp.toPx() }
    val dims = remember(prefs.keyboardScale, prefs.keyHeight, prefs.numberRow) { boardDims(ctx, prefs) }
    Box(Modifier.fillMaxWidth().aspectRatio(dims.wDp / dims.hDp).clip(RoundedCornerShape(24.dp)).background(card), contentAlignment = Alignment.Center) {
        if (bmp != null) {
            AndroidView({ c -> View(c) }, Modifier.fillMaxSize()) { v ->
                v.background = ImageBgDrawable(bmp, dim / 100f, pos / 100f, r, r, fit, cl / 100f, ct / 100f, cr / 100f, cb / 100f)
            }
            if (sample) SampleKeys(prefs, dims, cs.primary, Modifier.fillMaxSize())
        } else Text("Nenhuma imagem escolhida".tr(), color = cs.onSurface.copy(alpha = 0.7f))
    }
    Button(onPick, Modifier.fillMaxWidth().height(52.dp)) {
        Text(if (hasImage) "Trocar imagem de referência".tr() else "Escolher imagem de referência".tr(), fontWeight = FontWeight.SemiBold)
    }
    if (!hasImage) { MkNote("Escolha a imagem de um teclado que você gostou (uma captura de tela serve). Ela é esticada para o tamanho exato do seu teclado. A foto fica salva só dentro do app; nenhuma permissão de arquivos é necessária.".tr()); return@PageHost }
    MkCard {
        MkSwitch("Usar imagem no teclado".tr(), null, prefs.themeImage) { prefs.putBool("themeImage", it); refresh() }
        MkSwitch("Mostrar teclas de amostra".tr(), "Contorno das teclas de verdade sobre a prévia, para você alinhar a imagem. Não aparece no teclado.".tr(), sample) { sample = it; prefs.putBool("imgSample", it) }
        if (com.example.materialkeyboard.VideoBg.file(ctx).exists())
            MkSwitch("Animar com o vídeo".tr(), "Toca em loop, sem som, só com o teclado aberto".tr(), prefs.videoBg) { prefs.putBool("videoBg", it); refresh() }
    }
    MkCard("Encaixe da imagem".tr()) {
        ChipRow(listOf("Cortar".tr(), "Esticar para encaixar".tr()), fit) { fit = it; prefs.putInt("imgFit", it) }
        MkNote("Esticar: a imagem (ou só a parte que você deixar depois do recorte) é esticada até as quatro bordas do teclado, sem faltar nada. Cortar: mantém a proporção e corta o que sobra.".tr())
        Live("Recortar esquerda".tr(), cl, 0, 45, "%", { cl = it.toFloat() }) { prefs.putInt("imgL", it) }
        Live("Recortar topo".tr(), ct, 0, 45, "%", { ct = it.toFloat() }) { prefs.putInt("imgT", it) }
        Live("Recortar direita".tr(), cr, 0, 45, "%", { cr = it.toFloat() }) { prefs.putInt("imgR", it) }
        Live("Recortar embaixo".tr(), cb, 0, 45, "%", { cb = it.toFloat() }) { prefs.putInt("imgB", it) }
        if (fit == 0) Live("Posição da imagem".tr(), pos, 0, 100, "%", { pos = it.toFloat() }) { prefs.putInt("imagePos", it) }
        MkNote("Dica: recorte as bordas da captura (barra do celular, setas, botões) até as teclas da imagem ficarem em cima das teclas de amostra.".tr())
        MkAction("Zerar recorte".tr()) {
            cl = 0f; ct = 0f; cr = 0f; cb = 0f
            prefs.putInt("imgL", 0); prefs.putInt("imgT", 0); prefs.putInt("imgR", 0); prefs.putInt("imgB", 0)
        }
    }
    MkCard("Ajustes".tr()) {
        Live("Escurecer imagem".tr(), dim, 0, 80, "%", { dim = it.toFloat() }) { prefs.putInt("imageDim", it) }
        MkSlider("Opacidade das teclas".tr(), prefs.keyAlpha, 10, 100, "%") { prefs.putInt("keyAlpha", it) }
        if (android.os.Build.VERSION.SDK_INT >= 31)
            MkSlider("Desfoque do fundo".tr(), prefs.videoBlur, 0, 100, "%") { prefs.putInt("videoBlur", it) }
        MkNote("Teclas mais transparentes mostram mais a imagem. O texto troca de cor sozinho para ficar legível.".tr())
    }
    MkCard("Deixar invisível".tr()) {
        MkSwitch("Teclas das letras".tr(), "Some só o desenho da tecla; a letra continua aparecendo. Use quando a imagem já traz as teclas.".tr(), prefs.hideKeys) { prefs.putBool("hideKeys", it); refresh() }
        MkSwitch("Teclas especiais".tr(), "Shift, apagar, 123 e as outras teclas de função.".tr(), prefs.hideSpecial) { prefs.putBool("hideSpecial", it); refresh() }
        MkSwitch("Tecla de ação".tr(), "A tecla de enter / buscar / enviar.".tr(), prefs.hideAccent) { prefs.putBool("hideAccent", it); refresh() }
        MkSwitch("Fundo da barra de ícones".tr(), "Tira a pílula atrás dos ícones e das sugestões.".tr(), prefs.barStyle == 1) { prefs.putInt("barStyle", if (it) 1 else 0); refresh() }
    }
    MkAction("Remover imagem".tr(), true) { ThemeImage.delete(ctx); prefs.clearImage(); onRemove() }
}

/** Slider que atualiza a prévia na hora e só grava nas preferências ao soltar. */
@Composable
private fun PageCtx.Live(title: String, value: Float, min: Int, max: Int, unit: String, live: (Int) -> Unit, save: (Int) -> Unit) {
    val cs = MaterialTheme.colorScheme
    Column(Modifier.fillMaxWidth().padding(top = 12.dp)) {
        Row { Text(title, color = cs.onSurface, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
            Text("${value.roundToInt()}$unit", color = cs.primary, fontWeight = FontWeight.Bold) }
        Slider(value, { live(it.roundToInt()) }, valueRange = min.toFloat()..max.toFloat(), onValueChangeFinished = { save(value.roundToInt()) })
    }
}

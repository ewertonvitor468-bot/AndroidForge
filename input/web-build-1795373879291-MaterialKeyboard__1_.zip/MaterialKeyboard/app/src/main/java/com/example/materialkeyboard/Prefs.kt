package com.example.materialkeyboard

import android.content.Context
import android.content.SharedPreferences
import android.os.Handler
import android.os.Looper

/**
 * Configurações persistidas em SharedPreferences.
 * Os valores ficam em campos em memória (leitura instantânea no caminho de digitação)
 * e são atualizados por um listener, então mudanças feitas na tela de configurações
 * valem imediatamente no teclado.
 */
class Prefs private constructor(ctx: Context) {

    private val sp: SharedPreferences =
        ctx.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    @Volatile var vibrate = true
    @Volatile var vibrateStrength = 50          // 1..100
    @Volatile var vibrateOnSpace = true
    @Volatile var sound = false
    @Volatile var soundVolume = 50              // 0..100
    @Volatile var soundType = 0                 // índice em SoundBank.NAMES (pacote de som)
    @Volatile var theme = THEME_SYSTEM          // 0 sistema, 1 claro, 2 escuro
    @Volatile var useCustomColor = true
    @Volatile var customColor = 0xFF22C55E.toInt()   // verde padrão
    @Volatile var keyRadius = 12                // dp
    @Volatile var boardRadius = 26              // dp: cantos de cima do teclado
    @Volatile var keyHeight = 58                // dp
    @Volatile var textScale = 108             // % do tamanho do texto/ícones
    @Volatile var autoCorrect = false
    @Volatile var suggestions = true
    @Volatile var nextWord = true
    @Volatile var autoCaps = true
    @Volatile var numberRow = false
    @Volatile var language = LANG_EN            // padrão: inglês. "pt" | "en" | "ru" | "es" | "ar" | "fr" | "tr" | "vi"
    @Volatile var typeOnRelease = true          // v65.6: a letra só entra ao SOLTAR a tecla (antes ela entrava ao encostar)
    @Volatile var deleteSlide = true            // v65.5: segurar o apagar e deslizar para a esquerda seleciona palavras; ao soltar, apaga (como no Gboard)
    @Volatile var uiLang = ""                   // v65.5: idioma só dos menus do app (qualquer idioma do ML Kit). Vazio = igual ao do teclado
    @Volatile var langList = "en,pt"            // idiomas que o botão de idioma alterna (códigos separados por vírgula)
    @Volatile var clipboardEnabled = true
    @Volatile var keyboardScale = 100           // % do tamanho geral do teclado (70..130)
    @Volatile var fluid = true                  // animações fluidas (molas estilo Material You)
    @Volatile var themeImage = false            // usa imagem da galeria como fundo
    @Volatile var themeImageRev = 0             // muda sempre que a imagem é trocada
    @Volatile var imageDim = 25                 // % de escurecimento da imagem
    @Volatile var imagePos = 50                 // posição vertical do recorte (0..100)
    @Volatile var keyAlpha = 60                 // % de opacidade das teclas sobre a imagem
    @Volatile var imgFit = 0                    // 0 = cortar (preenche e corta), 1 = esticar a imagem de referência até as bordas do teclado
    @Volatile var imgL = 0                      // recorte da imagem (em % de cada lado) antes de encaixar no teclado
    @Volatile var imgT = 0
    @Volatile var imgR = 0
    @Volatile var imgB = 0
    @Volatile var imgSample = true              // mostra teclas de amostra sobre a prévia da imagem
    @Volatile var hideKeys = false              // teclas de letras invisíveis (a imagem já traz as teclas)
    @Volatile var hideSpecial = false           // teclas especiais invisíveis (shift, apagar, 123...)
    @Volatile var hideAccent = false            // tecla de ação invisível (enter)
    @Volatile var smartTouch = true             // toque entre teclas vai para a tecla mais próxima
    @Volatile var fontColorOn = false          // mudar cor das fontes (só letras das teclas)
    @Volatile var fontColor = 0xFFFFFFFF.toInt()
    @Volatile var animSpeed = 100              // % da velocidade das animações (50..200)
    @Volatile var animBounce = 50              // 0..100 elasticidade
    @Volatile var altSpeed = 100               // % da animação dos acentos
    @Volatile var longPressMs = 500            // ms para abrir os acentos
    @Volatile var repeatSpeed = 100            // % da repetição ao segurar setas/apagar
    @Volatile var preciseCorrect = false        // corretor mais preciso
    @Volatile var soundPitch = 100              // % do tom (50..200)
    @Volatile var soundHumanize = true          // varia o tom levemente a cada toque
    @Volatile var keySounds = IntArray(SoundBank.Slot.COUNT) { -1 }   // som por tecla (-1 = som geral)
    @Volatile var keyStyle = 0                  // 0 Material You, 1 iOS (sombra), 2 One UI (brilho)
    @Volatile var spaceSlide = SPACE_SLIDE_CURSOR  // barra de espaço: 0 = deslizar padrão (Gboard), 1 = deslizar com modo cursor
    @Volatile var keyLeft = ","                 // tecla personalizável à esquerda do espaço
    @Volatile var keyRight = "."                // tecla personalizável à direita do espaço
    @Volatile var blurAmount = 85             // blur atrás do teclado no estilo Vidro (Android 12+)
    @Volatile var expressive = true             // visual Expressive: formas uniformes (ignora formatos ondulados)
    @Volatile var keyShape = 0                  // 0..9 (KeyShapes.NAMES)
    @Volatile var accentShape = 0               // 0 = igual às demais; 1..10 = formato próprio de Enter/Shift ativo
    @Volatile var keyGap = 3                    // dp entre as teclas
    @Volatile var fontStyle = 0                 // fonte das teclas
    @Volatile var pressGlow = true              // brilho que se espalha a partir do toque
    @Volatile var scene = 0                     // Cenário animado: 0 desligado, 1 outono, 2 inverno, 3 tempestade
    @Volatile var patch = ""                   // id do patch ativo (Patches.ALL); vazio = nenhum
    // Bichinhos (0 cachorro, 1 gato, 2 coelho)
    val petOn = BooleanArray(3)
    val petBody = IntArray(3) { PET_BODY[it] }
    val petDetail = IntArray(3) { PET_DETAIL[it] }
    val petName = Array(3) { PET_NAMES[it] }
    @Volatile var petSize = 34                  // dp (altura do bichinho em pé)
    @Volatile var petsTouch = true              // tocar nos bichinhos / balões
    @Volatile var patchFavs = ""               // ids favoritos, separados por vírgula
    @Volatile var preset = 0                    // 0 = nenhum; 1..N = tema pronto (Palette.PRESETS)

    @Volatile var keyPreview = true             // balão da tecla ao tocar
    @Volatile var previewSize = 100             // % do tamanho do balão
    @Volatile var previewShape = 0              // 0 arredondado, 1 círculo, 2 quadrado, 3 pílula
    @Volatile var altShape = 4                  // formato das bolhas dos acentos/idiomas (PopupShapes.NAMES): 4 cookie (padrão)
    @Volatile var previewColor = 0              // 0 destaque, 1 especial, 2 tecla, 3 minha cor
    @Volatile var previewHue = 260              // matiz (0..360) da cor própria
    @Volatile var previewAnim = true
    @Volatile var barSide = 0                   // barra de ícones deslizável: 0 começa pela esquerda, 1 pela direita
    @Volatile var barItems = DEFAULT_BAR        // itens visíveis da barra, em ordem (ids separados por vírgula)
    @Volatile var showDemo = false              // botão Demo na linha extra (desligado por padrão)
    @Volatile var oneHand = 0                   // modo uma mão: 0 desligado, 1 teclado à esquerda, 2 à direita
    @Volatile var floating = false              // teclado flutuante (arrastável)
    @Volatile var floatScale = 100              // % do tamanho do teclado flutuante (60..110), ajustável pelos botões − / + da alça
    @Volatile var glide = true                  // digitação por deslize
    @Volatile var autofill = true               // sugestões de preenchimento automático (senhas, endereços) na barra
    @Volatile var langKey = 0                   // tecla ao lado do espaço: 0 idioma, 1 emoji, 2 nenhuma
    // v54.2: personalização ilimitada (todos entram em EXTRA_KEYS, então os temas podem defini-los e "Remover patch" restaura)
    @Volatile var micShape = 0                  // formato do botão do microfone (BarShapes.NAMES): 0 cookie, 1 flor, 2 círculo, 3 squircle, 4 quadrado, 5 selo
    @Volatile var toolShape = 0                 // formato do botão de seta (mais ferramentas), mesma lista
    @Volatile var keyBorder = 0                 // borda fina das teclas (dp, 0 = sem borda)
    @Volatile var keyDepth = 0                  // profundidade 3D das teclas (dp, 0 = a do estilo)
    @Volatile var barStyle = 0                  // faixa de ícones: 0 pílula, 1 reta (sem fundo), 2 retangular
    // v60: fundo do teclado (vale para todos os temas)
    @Volatile var bgOpacity = 100               // % de opacidade do fundo do teclado (0..100)
    @Volatile var bgBlur = 0                    // intensidade do desfoque atrás do teclado (0..100, Android 12+)
    @Volatile var videoBg = false               // usa o vídeo animado (theme_bg.mp4) como fundo
    @Volatile var videoBlur = 0                 // desfoque do vídeo/imagem de fundo (0..100, Android 12+)

    private val listeners = mutableListOf<() -> Unit>()

    // Um patch grava vários campos de uma vez: o load() é imediato, mas os ouvintes (teclado) são avisados
    // uma única vez por rodada, para o teclado atualizar sem piscar.
    private val main = Handler(Looper.getMainLooper())
    private val notifyRun = Runnable { listeners.toList().forEach { it() } }
    // Opacidade e desfoque do fundo têm caminho leve: só reaplicam o fundo, sem reconstruir o teclado.
    private val bgListeners = mutableListOf<() -> Unit>()
    private val bgRun = Runnable { bgListeners.toList().forEach { it() } }
    private val spListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        load()
        if (key == "bgOpacity" || key == "bgBlur" || key == "videoBlur") { main.removeCallbacks(bgRun); main.post(bgRun) }
        else { main.removeCallbacks(notifyRun); main.post(notifyRun) }
    }

    init {
        // Keys Café: carrega a biblioteca de temas instalados antes de qualquer desenho (Patches.byId a consulta)
        com.example.materialkeyboard.keyscafe.ThemeLibrary.attach(ctx)
        // remove restos da antiga IA (chave de API e modelo) de instalações anteriores
        if (sp.contains("aiKey") || sp.contains("aiModel")) sp.edit().remove("aiKey").remove("aiModel").apply()
        // v41: teclas mais "gordas", no estilo Gboard (uma vez só; depois o usuário ajusta como quiser)
        if (sp.getInt("layoutVer", 0) < 41) {
            sp.edit().putInt("keyHeight", 58).putInt("keyRadius", 12).putInt("keyGap", 3)
                .putInt("textScale", 108).putInt("layoutVer", 41).apply()
        }
        UiTr.init(ctx)
        load()
        sp.registerOnSharedPreferenceChangeListener(spListener)
    }

    fun addListener(l: () -> Unit) { listeners.add(l) }
    fun removeListener(l: () -> Unit) { listeners.remove(l) }
    fun addBgListener(l: () -> Unit) { bgListeners.add(l) }
    fun removeBgListener(l: () -> Unit) { bgListeners.remove(l) }

    private fun load() {
        vibrate = sp.getBoolean("vibrate", true)
        vibrateStrength = sp.getInt("vibrateStrength", 50)
        vibrateOnSpace = sp.getBoolean("vibrateOnSpace", true)
        sound = sp.getBoolean("sound", false)
        soundVolume = sp.getInt("soundVolume", 50)
        // v65.6: 5 pacotes de som (licença "só uso pessoal") saíram do app e os de baixo foram renumerados (antigos 4,5,6 -> 3,4,5).
        // Migração única do som escolhido: o que apontava para um pacote removido volta ao primeiro (geral) ou ao som geral (por tecla).
        if (sp.getInt("soundPackRev", 0) < 1) {
            fun mv(i: Int): Int = when { i < 0 || i >= SoundBank.CUSTOM -> i; i <= 2 -> i; i in 4..6 -> i - 1; else -> -2 }   // -2 = removido
            val ed = sp.edit()
            ed.putInt("soundType", mv(sp.getInt("soundType", 0)).let { if (it == -2) 0 else it })
            for (k in 0 until SoundBank.Slot.COUNT) {
                val old = sp.getInt("keySound$k", -1)
                if (old != -1) ed.putInt("keySound$k", mv(old).let { if (it == -2) -1 else it })
            }
            ed.putInt("soundPackRev", 1).apply()
        }
        soundType = sp.getInt("soundType", 0)
        theme = sp.getInt("theme", THEME_SYSTEM)
        useCustomColor = sp.getBoolean("useCustomColor", true)
        customColor = sp.getInt("customColor", 0xFF22C55E.toInt())
        keyRadius = sp.getInt("keyRadius", 12)
        boardRadius = sp.getInt("boardRadius", 26)
        keyHeight = sp.getInt("keyHeight", 58)
        textScale = sp.getInt("textScale", 108)
        autoCorrect = sp.getBoolean("autoCorrectV2", false)
        suggestions = sp.getBoolean("suggestions", true)
        nextWord = sp.getBoolean("nextWord", true)
        autoCaps = sp.getBoolean("autoCaps", true)
        numberRow = sp.getBoolean("numberRow", false)
        language = (sp.getString("language", LANG_EN) ?: LANG_EN).let { if (it == "ja") LANG_PT else it }   // japonês foi removido: quem usava volta ao português; quem nunca escolheu fica em inglês
        typeOnRelease = sp.getBoolean("typeOnRelease", true)
        deleteSlide = sp.getBoolean("deleteSlide", true)
        uiLang = sp.getString("uiLang", "") ?: ""
        L.code = if (uiLang.isNotEmpty()) uiLang else language
        langList = sp.getString("langList", null) ?: listOf(LANG_EN, LANG_PT, language).distinct().joinToString(",")   // quem já usava outro idioma não o perde do botão
        clipboardEnabled = sp.getBoolean("clipboardEnabled", true)
        keyboardScale = sp.getInt("keyboardScale", 100)
        fluid = sp.getBoolean("fluid", true)
        themeImage = sp.getBoolean("themeImage", false)
        themeImageRev = sp.getInt("themeImageRev", 0)
        imageDim = sp.getInt("imageDim", 25)
        imagePos = sp.getInt("imagePos", 50)
        keyAlpha = sp.getInt("keyAlpha", 60)
        imgFit = sp.getInt("imgFit", 0).coerceIn(0, 1)
        imgL = sp.getInt("imgL", 0).coerceIn(0, 45)
        imgT = sp.getInt("imgT", 0).coerceIn(0, 45)
        imgR = sp.getInt("imgR", 0).coerceIn(0, 45)
        imgB = sp.getInt("imgB", 0).coerceIn(0, 45)
        imgSample = sp.getBoolean("imgSample", true)
        hideKeys = sp.getBoolean("hideKeys", false)
        hideSpecial = sp.getBoolean("hideSpecial", false)
        hideAccent = sp.getBoolean("hideAccent", false)
        smartTouch = sp.getBoolean("smartTouch", true)
        preset = sp.getInt("preset", 0)
        patch = sp.getString("patch", "") ?: ""
        scene = sp.getInt("scene", 0)
        patchFavs = sp.getString("patchFavs", "") ?: ""
        for (k in 0 until 3) {
            petOn[k] = sp.getBoolean("petOn$k", false)
            petBody[k] = sp.getInt("petBody$k", PET_BODY[k])
            petDetail[k] = sp.getInt("petDetail$k", PET_DETAIL[k])
            petName[k] = (sp.getString("petName$k", PET_NAMES[k]) ?: PET_NAMES[k]).ifBlank { PET_NAMES[k] }
        }
        petSize = sp.getInt("petSize", 34)
        petsTouch = sp.getBoolean("petsTouch", true)
        fontColorOn = sp.getBoolean("fontColorOn", false)
        fontColor = sp.getInt("fontColor", 0xFFFFFFFF.toInt())
        preciseCorrect = sp.getBoolean("preciseCorrect", false)
        animSpeed = sp.getInt("animSpeed", 100)
        animBounce = sp.getInt("animBounce", 50)
        altSpeed = sp.getInt("altSpeed", 100)
        longPressMs = sp.getInt("longPressMs", 500)
        repeatSpeed = sp.getInt("repeatSpeed", 100)
        soundPitch = sp.getInt("soundPitch", 100)
        soundHumanize = sp.getBoolean("soundHumanize", true)
        keySounds = IntArray(SoundBank.Slot.COUNT) { sp.getInt("keySound$it", -1) }
        keyStyle = sp.getInt("keyStyle", 0)
        pressGlow = sp.getBoolean("pressGlow", true)
        expressive = sp.getBoolean("expressive", true)
        keyShape = sp.getInt("keyShape", 0); accentShape = sp.getInt("accentShape", 0)
        keyGap = sp.getInt("keyGap", 3); fontStyle = sp.getInt("fontStyle", 0)
        spaceSlide = sp.getInt("spaceSlide", SPACE_SLIDE_CURSOR).coerceIn(0, 1)
        keyLeft = sp.getString("keyLeft", ",") ?: ","
        keyRight = sp.getString("keyRight", ".") ?: "."
        blurAmount = sp.getInt("blurAmount", 85)
        keyPreview = sp.getBoolean("keyPreview", true)
        previewSize = sp.getInt("previewSize", 100)
        previewShape = sp.getInt("previewShape", 0)
        altShape = sp.getInt("altShape", 4).coerceIn(0, PopupShapes.NAMES.size - 1)
        previewColor = sp.getInt("previewColor", 0)
        previewHue = sp.getInt("previewHue", 260)
        previewAnim = sp.getBoolean("previewAnim", true)
        barSide = sp.getInt("barSide", 0)
        barItems = sp.getString("barItems", DEFAULT_BAR) ?: DEFAULT_BAR
        langKey = sp.getInt("langKey", 0)
        oneHand = sp.getInt("oneHand", 0).coerceIn(0, 2)
        floating = sp.getBoolean("floating", false)
        floatScale = sp.getInt("floatScale", 100).coerceIn(60, 110)
        glide = sp.getBoolean("glide", true)
        autofill = sp.getBoolean("autofill", true)
        showDemo = sp.getBoolean("showDemo", false)
        micShape = sp.getInt("micShape", 0); toolShape = sp.getInt("toolShape", 0)
        bgOpacity = sp.getInt("bgOpacity", 100); bgBlur = sp.getInt("bgBlur", 0); videoBg = sp.getBoolean("videoBg", false)
        videoBlur = sp.getInt("videoBlur", 0)
        keyBorder = sp.getInt("keyBorder", 0); keyDepth = sp.getInt("keyDepth", 0); barStyle = sp.getInt("barStyle", 0)
        AnimCfg.speed = animSpeed.coerceIn(50, 200) / 100f
        AnimCfg.bounce = animBounce.coerceIn(0, 100)
        AnimCfg.altSpeed = altSpeed.coerceIn(50, 200) / 100f
        AnimCfg.longPressMs = longPressMs.coerceIn(150, 1000).toLong()
        AnimCfg.repeatSpeed = repeatSpeed.coerceIn(50, 300) / 100f
    }

    /** Primeira execução: o app mostra o assistente de boas-vindas até isto ser true. */
    var onboarded: Boolean
        get() = sp.getBoolean("onboarded", false)
        set(v) { sp.edit().putBoolean("onboarded", v).apply() }

    fun putImage() = sp.edit().putBoolean("themeImage", true).putBoolean("videoBg", false).putInt("themeImageRev", themeImageRev + 1).apply()
    /** Vídeo importado: a imagem (primeiro quadro) entra como capa e o vídeo é ligado. */
    fun putVideo() = sp.edit().putBoolean("themeImage", true).putBoolean("videoBg", true).putInt("themeImageRev", themeImageRev + 1).apply()
    fun clearImage() = sp.edit().putBoolean("themeImage", false).putBoolean("videoBg", false).putInt("themeImageRev", themeImageRev + 1).apply()

    /** Sons usados no momento (geral + por tecla), para pré-carregar. */
    fun usedSoundTypes(): Set<Int> = (keySounds.filter { it >= 0 } + soundType).toSet()

    fun putBool(k: String, v: Boolean) = sp.edit().putBoolean(k, v).apply()
    fun putInt(k: String, v: Int) {
        val e = sp.edit().putInt(k, v)
        // escolher tema pronto ou modo claro/escuro à mão tira o patch (ele mandaria nas cores)
        if (k == "preset" || k == "theme") e.putString("patch", "").putString("patchPrev", "")
        e.apply()
    }
    fun putString(k: String, v: String) = sp.edit().putString(k, v).apply()
    /** Chave opcional do ditado por voz na nuvem (Groq/OpenAI). Lida direto do armazenamento: vale na hora, sem recarregar. */
    fun voiceKeyNow(): String = sp.getString("voiceKey", "") ?: ""

    /** Disposição das letras escolhida pela pessoa (Posicionar Keycaps): fileiras separadas por "|". Vazio = padrão. */
    fun keyRows(layoutId: String): String = sp.getString("rows_$layoutId", "") ?: ""
    fun clearKeyRows() { sp.edit().remove("rows_qwerty").remove("rows_abnt").remove("rows_ru").remove("rows_es").remove("rows_ar").apply() }
    fun putFontColor(c: Int) = sp.edit().putInt("fontColor", c).putBoolean("fontColorOn", true).apply()
    fun putCustomColor(c: Int) = sp.edit().putInt("customColor", c).putBoolean("useCustomColor", true).putInt("preset", 0)
        .putString("patch", "").putString("patchPrev", "").apply()

    // ---------- Patches (Keys Café) ----------
    private fun patchState(): Map<String, Int> = linkedMapOf(
        "preset" to preset, "customColor" to customColor, "keyStyle" to keyStyle, "keyShape" to keyShape, "keyAlpha" to keyAlpha,
        "keyRadius" to keyRadius, "keyGap" to keyGap, "fontStyle" to fontStyle, "blurAmount" to blurAmount,
        "pressGlow" to if (pressGlow) 1 else 0, "useCustomColor" to if (useCustomColor) 1 else 0) + extraState()
    private val patchBools = setOf("pressGlow", "useCustomColor", "fontColorOn", "previewAnim", "expressive")

    /** Estado atual das chaves extras do passo 3 (balão, texto, animação, cantos, cenário). */
    private fun extraState(): Map<String, Int> = linkedMapOf(
        "boardRadius" to boardRadius, "accentShape" to accentShape, "textScale" to textScale,
        "fontColorOn" to if (fontColorOn) 1 else 0, "fontColor" to fontColor,
        "previewShape" to previewShape, "previewSize" to previewSize, "previewColor" to previewColor,
        "previewHue" to previewHue, "previewAnim" to if (previewAnim) 1 else 0,
        "animSpeed" to animSpeed, "animBounce" to animBounce, "scene" to scene,
        "expressive" to if (expressive) 1 else 0, "micShape" to micShape, "toolShape" to toolShape,
        "keyBorder" to keyBorder, "keyDepth" to keyDepth, "barStyle" to barStyle)

    /** Aplica um patch: um único edit()/apply(). Guarda o estado anterior só na primeira vez (ao trocar de patch ele se mantém). */
    fun setPatch(id: String, ints: Map<String, Int>, bools: Map<String, Boolean>, extras: Map<String, Int> = emptyMap()) {
        val hadPatch = (sp.getString("patch", "") ?: "").isNotEmpty()
        val prev = if (!hadPatch) patchState().entries.joinToString(",") { "${it.key}=${it.value}" }
                   else sp.getString("patchPrev", "") ?: ""
        val e = sp.edit()
        e.putString("patch", id); e.putString("patchPrev", prev)
        ints.forEach { (k, v) -> e.putInt(k, v) }
        bools.forEach { (k, v) -> e.putBoolean(k, v) }
        // Extras do tema; o que ele não define volta ao valor de antes do patch (trocar de tema não herda o do anterior).
        val saved = parseSaved(prev)
        EXTRA_KEYS.forEach { (k, d) ->
            val v = extras[k] ?: saved[k] ?: d
            if (k in patchBools) e.putBoolean(k, v != 0) else e.putInt(k, v)
        }
        e.apply()
    }

    private fun parseSaved(s: String): Map<String, Int> = s.split(",").mapNotNull {
        val kv = it.split("="); if (kv.size == 2) kv[1].toIntOrNull()?.let { v -> kv[0] to v } else null }.toMap()

    /** Remove o patch e volta ao tema anterior; sem estado guardado, volta ao padrão verde. */
    fun removePatch() {
        val saved = parseSaved(sp.getString("patchPrev", "") ?: "")
        val def = mapOf("preset" to 0, "customColor" to 0xFF22C55E.toInt(), "keyStyle" to 0, "keyShape" to 0, "keyAlpha" to 60,
            "keyRadius" to 12, "keyGap" to 3, "fontStyle" to 0, "blurAmount" to 85, "pressGlow" to 1, "useCustomColor" to 1)
        val e = sp.edit()
        (def + EXTRA_KEYS).forEach { (k, d) -> val v = saved[k] ?: d; if (k in patchBools) e.putBoolean(k, v != 0) else e.putInt(k, v) }
        e.putString("patch", "").putString("patchPrev", "")
        e.apply()
    }

    fun toggleFav(id: String) {
        val l = (sp.getString("patchFavs", "") ?: "").split(",").filter { it.isNotEmpty() }.toMutableList()
        if (!l.remove(id)) l.add(id)
        sp.edit().putString("patchFavs", l.joinToString(",")).apply()
    }

    /** Restaura tudo, preservando o histórico do clipboard (que é guardado em outro arquivo). */
    fun resetAll() {
        val ob = sp.getBoolean("onboarded", false)
        sp.edit().clear().putBoolean("onboarded", ob).commit()
        load()
        listeners.toList().forEach { it() }
    }

    companion object {
        const val SPACE_SLIDE_GBOARD = 0   // deslizar no espaço move o cursor, teclas continuam visíveis
        const val SPACE_SLIDE_CURSOR = 1   // deslizar no espaço esconde as teclas e abre o painel de cursor
        /** Chaves que um tema do Keys Café pode definir além do [Patch] básico (passo 3), com o valor padrão do app. */
        val EXTRA_KEYS: Map<String, Int> = linkedMapOf(
            "boardRadius" to 26, "accentShape" to 0, "textScale" to 108, "fontColorOn" to 0, "fontColor" to 0xFFFFFFFF.toInt(),
            "previewShape" to 0, "previewSize" to 100, "previewColor" to 0, "previewHue" to 260, "previewAnim" to 1,
            "animSpeed" to 100, "animBounce" to 50, "scene" to 0,
            "expressive" to 1, "micShape" to 0, "toolShape" to 0, "keyBorder" to 0, "keyDepth" to 0, "barStyle" to 0)
        val PET_BODY = intArrayOf(0xFFC68642.toInt(), 0xFFF2A65A.toInt(), 0xFFF4F1EC.toInt())
        val PET_DETAIL = intArrayOf(0xFF5A3A1E.toInt(), 0xFFFFB3B8.toInt(), 0xFFFFB6C1.toInt())
        val PET_NAMES = arrayOf("Rex", "Mia", "Fofo")
        const val FILE = "keyboard_prefs"
        const val THEME_SYSTEM = 0
        const val THEME_LIGHT = 1
        const val THEME_DARK = 2
        const val LANG_PT = "pt"
        const val LANG_EN = "en"
        const val LANG_RU = "ru"
        const val LANG_ES = "es"
        const val LANG_AR = "ar"
        const val LANG_FR = "fr"
        const val LANG_TR = "tr"
        const val LANG_VI = "vi"
        /** Ordem padrão da barra de ícones (ver KeyboardService.BAR_ITEMS). */
        const val DEFAULT_BAR = "emoji,clip,translate,settings,position"
        const val LANG_KEY_LANG = 0
        const val LANG_KEY_EMOJI = 1
        const val LANG_KEY_NONE = 2

        @Volatile private var inst: Prefs? = null
        fun get(ctx: Context): Prefs =
            inst ?: synchronized(this) { inst ?: Prefs(ctx).also { inst = it } }
    }
}

package com.example.materialkeyboard

import com.example.materialkeyboard.compose.*
import androidx.core.view.WindowCompat
import androidx.compose.ui.platform.ComposeView
import com.example.materialkeyboard.compose.ThemeScreen
import com.google.android.material.color.DynamicColorsOptions
import androidx.appcompat.app.AppCompatDelegate
import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.net.Uri
import android.graphics.Typeface
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.graphics.ColorUtils
import androidx.dynamicanimation.animation.DynamicAnimation
import com.google.android.material.button.MaterialButton
import com.google.android.material.button.MaterialButtonToggleGroup
import com.google.android.material.color.DynamicColors
import com.google.android.material.color.MaterialColors
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.materialswitch.MaterialSwitch
import com.google.android.material.slider.Slider
import com.google.android.material.R as M

/**
 * Configurações organizadas em categorias. A tela inicial mostra o estado da ativação, um campo de teste
 * e a lista de categorias; cada categoria abre sua própria página. Tudo é gravado em Prefs e aplicado
 * ao teclado na hora.
 */
class SettingsActivity : AppCompatActivity() {

    private lateinit var prefs: Prefs
    private lateinit var topBar: LinearLayout
    private lateinit var titleView: TextView
    private lateinit var scroll: ScrollView
    private lateinit var content: LinearLayout
    private var page = HOME
    private val stack = ArrayList<String>()           // histórico de páginas (voltar)
    private var backing = false
    private val tab = androidx.compose.runtime.mutableStateOf(HOME)
    private lateinit var bottomBar: View
    private var soundKey = -1                       // página SOUNDS: -1 = som geral, senão o slot da tecla
    private var customSwitch: MaterialSwitch? = null
    private var preview: SoundBank? = null
    private var imagePreview: View? = null

    private val back = object : OnBackPressedCallback(false) {
        override fun handleOnBackPressed() { goBack() }
    }

    private val pickAudio = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) try {
            val name = (contentResolver.query(uri, null, null, null, null)?.use { c ->
                val i = c.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
                if (c.moveToFirst() && i >= 0) c.getString(i) else null
            } ?: "som.wav").replace(Regex("[^\\w. -]"), "_")
            val f = java.io.File(SoundBank.customDir(this), "${System.currentTimeMillis()}_$name")
            contentResolver.openInputStream(uri)?.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
            if (f.length() > 1_000_000) { f.delete(); android.widget.Toast.makeText(this, "Arquivo muito grande (máx. 1 MB). Use um som curto.".tr(), android.widget.Toast.LENGTH_LONG).show() }
            else { val idx = SoundBank.customFiles(this).indexOf(f); prefs.putInt("soundType", SoundBank.CUSTOM + idx); if (!prefs.sound) prefs.putBool("sound", true) }
            refreshPage()
        } catch (_: Exception) { android.widget.Toast.makeText(this, "Não foi possível importar o arquivo.".tr(), android.widget.Toast.LENGTH_SHORT).show() }
    }

    private val pickImage = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) importImage(uri)
    }

    // Keys Café: importar um tema (.mkt) e exportar um tema instalado
    private val pickTheme = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) importTheme(uri)
    }
    private var pendingExport: String? = null
    private val saveTheme = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val id = pendingExport
        pendingExport = null
        val uri = r.data?.data
        if (r.resultCode == RESULT_OK && uri != null && id != null) exportTheme(id, uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        val pf = Prefs.get(this)
        // claro/escuro e cor das configurações seguem o tema escolhido no teclado
        wasDark = Palette.isDark(this, pf)
        delegate.localNightMode = if (wasDark) AppCompatDelegate.MODE_NIGHT_YES else AppCompatDelegate.MODE_NIGHT_NO
        val seed: Int? = Palette.presetOf(pf)?.accent?.toInt() ?: Patches.of(pf)?.accent?.toInt() ?: if (pf.useCustomColor) pf.customColor else null
        if (seed != null) DynamicColors.applyToActivityIfAvailable(this, DynamicColorsOptions.Builder().setContentBasedSource(seed).build())
        else DynamicColors.applyToActivityIfAvailable(this)
        super.onCreate(savedInstanceState)
        prefs = pf
        if (!prefs.onboarded) {                       // primeira vez: assistente de boas-vindas
            startActivity(Intent(this, OnboardingActivity::class.java))
            finish()
            return
        }
        onBackPressedDispatcher.addCallback(this, back)

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; fitsSystemWindows = true }
        rootView = root
        topBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(4), dp(16), dp(4))
            visibility = View.GONE
        }
        val onSurface = MaterialColors.getColor(this, M.attr.colorOnSurface, Color.WHITE)
        topBar.addView(iconButton(this, R.drawable.ic_back, onSurface, "Voltar".tr(), 48) { goBack() })
        titleView = TextView(this).apply {
            setTextAppearance(M.style.TextAppearance_Material3_TitleLarge)
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            textSize = 24f
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(8) }
        }
        topBar.addView(titleView)
        var tx = 0f
        topBar.setOnTouchListener { _, e ->
            when (e.action) {
                android.view.MotionEvent.ACTION_DOWN -> tx = e.x
                android.view.MotionEvent.ACTION_UP -> if (e.x - tx > dp(80)) goBack()
            }
            false
        }
        root.addView(topBar, LinearLayout.LayoutParams(-1, -2))

        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(4), dp(16), dp(48))
        }
        scroll = ScrollView(this).apply { addView(content) }
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        bottomBar = ComposeView(this).apply { setContent { BottomTabs(prefs, tab.value) { show(it) } } }
        root.addView(bottomBar, LinearLayout.LayoutParams(-1, -2))
        setContentView(root)
        applyBars()
        prefs.addListener(barListener)
        show(HOME, animate = false)
    }

    private lateinit var rootView: LinearLayout
    private var wasDark = false
    private val barListener: () -> Unit = {
        runOnUiThread { if (Palette.isDark(this, prefs) != wasDark) recreate() else applyBars() }
    }

    /** Barra de status e de navegação com a MESMA cor de fundo das configurações (cor do tema do teclado). */
    private fun applyBars() {
        val pal = Palette.build(this, prefs)
        rootView.setBackgroundColor(pal.surface)
        window.statusBarColor = pal.surface
        window.navigationBarColor = pal.surface
        WindowCompat.getInsetsController(window, window.decorView).apply {
            isAppearanceLightStatusBars = !pal.isDark
            isAppearanceLightNavigationBars = !pal.isDark
        }
    }

    override fun onResume() {
        super.onResume()
        if (::content.isInitialized && page == HOME) show(HOME, animate = false)   // atualiza o estado da ativação
    }

    override fun onDestroy() { if (::prefs.isInitialized) prefs.removeListener(barListener); preview?.release(); super.onDestroy() }

    private fun dp(v: Int) = (v * resources.displayMetrics.density + 0.5f).toInt()
    private fun color(attr: Int, fb: Int = Color.GRAY) = MaterialColors.getColor(this, attr, fb)

    // ---------- Navegação ----------

    private fun show(p: String, animate: Boolean = true) {
        if (p in TOP) { stack.clear(); stack.add(p); tab.value = p } else if (stack.lastOrNull() != p) stack.add(p)
        page = p
        back.isEnabled = stack.size > 1 || p != HOME
        bottomBar.visibility = if (p in TOP) View.VISIBLE else View.GONE
        content.removeAllViews()
        customSwitch = null
        imagePreview = null
        card = null
        topBar.visibility = if (p in TOP) View.GONE else View.VISIBLE
        titleView.text = (TITLES[p] ?: "").tr()
        when (p) {
            HOME -> buildHome()
            THEMES -> buildThemes()
            KB -> buildKeyboardTab()
            ADV -> buildAdv()
            EMOJI -> buildEmoji()
            ABOUT -> buildAbout()
            APPEARANCE -> buildAppearance()
            PATCHES -> buildPatches()
            IMAGE -> buildImage()
            SIZE -> buildSize()
            ANIM -> buildAnim()
            FEEDBACK -> buildFeedback()
            SOUNDS -> buildSounds()
            TRANSLATOR -> buildTranslator()
            TYPING -> buildTyping()
            CLIP -> buildClipboard()
            MORE -> buildMore()
            LANG -> buildLanguage()
            KEYS -> buildKeys()
            PREVIEW -> buildPreview()
            BAR -> buildBar()
            UPDATES -> buildUpdates()
        }
        if (animate) {
            scroll.scrollTo(0, 0)
            val fwd = !backing && p !in TOP                       // entrando numa página: desliza da direita; voltando: da esquerda
            content.settle()
            content.translationX = (if (fwd) 36f else -36f) * resources.displayMetrics.density
            content.springTo(DynamicAnimation.TRANSLATION_X, 0f, 360f, 0.82f)
            content.cascade(fromY = 26f, step = 34L)
            if (fwd) titleView.springIn(fromY = 8f, fromScale = 0.94f, stiffness = 420f, damping = 0.7f)
        }
    }

    private fun goBack() {
        if (stack.size < 2) { if (page != HOME) show(HOME); return }
        stack.removeAt(stack.size - 1)
        backing = true; show(stack.last()); backing = false
    }

    /** Recria a página atual mantendo a rolagem (usado quando algo muda a estrutura da página). */
    private fun refreshPage() {
        val y = scroll.scrollY
        show(page, animate = false)
        scroll.post { scroll.scrollTo(0, y) }
    }

    // ---------- Início ----------

    private fun isEnabled(): Boolean = try {
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
            .enabledInputMethodList.any { it.packageName == packageName }
    } catch (_: Exception) { false }

    private fun isSelected(): Boolean = try {
        Settings.Secure.getString(contentResolver, Settings.Secure.DEFAULT_INPUT_METHOD)
            ?.startsWith("$packageName/") == true
    } catch (_: Exception) { false }

    private fun versionName(): String = try { packageManager.getPackageInfo(packageName, 0).versionName ?: "" } catch (_: Exception) { "" }

    /** Android não deixa um app ativar o teclado sozinho: abre a tela certa do sistema. */
    private fun toggleKeyboard() {
        if (isEnabled() && !isSelected()) (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
        else startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
    }

    private fun lp() = LinearLayout.LayoutParams(-1, -2)

    private fun buildHome() {
        com.example.materialkeyboard.updates.UpdateChecker.refreshIfDue(this)   // verificação automática (no máx. a cada 6 h)
        val ready = isEnabled() && isSelected()
        val newer = com.example.materialkeyboard.updates.UpdateChecker.cachedNewer(this)
        // Tudo organizado por assunto numa tela só (como os Ajustes do iOS)
        val sections = listOf(
            NavSection("Aparência".tr(), listOf(
                NavItem(R.drawable.ic_palette, "Temas".tr(), "Tema, cores e formato das teclas".tr(), THEMES),
                NavItem(R.drawable.ic_patch, "Patches".tr(), patchSummary(), PATCHES),
                NavItem(R.drawable.ic_image, "Imagem de fundo".tr(), if (prefs.themeImage) "Ativada · foto da galeria".tr() else "Use uma foto da sua galeria".tr(), IMAGE))),
            NavSection("Teclado".tr(), listOf(
                NavItem(R.drawable.ic_tune, "Teclas".tr(), "Estilo, formato, fonte e espaço".tr(), KEYS),
                NavItem(R.drawable.ic_size, "Tamanho do teclado".tr(), L.f("Geral: %d%%  ·  teclas: %ddp", prefs.keyboardScale, prefs.keyHeight), SIZE),
                NavItem(R.drawable.ic_position, "Barra de ícones".tr(), "Ordem, deslizar e botão de idioma".tr(), BAR),
                NavItem(R.drawable.ic_popup, "Popup das teclas".tr(), if (prefs.keyPreview) "Ligado · formato, cor e tamanho".tr() else "Desligado".tr(), PREVIEW),
                NavItem(R.drawable.ic_anim, "Animações".tr(), if (prefs.fluid) "Animações fluidas ligadas".tr() else "Animações simples".tr(), ANIM))),
            NavSection("Digitação".tr(), listOf(
                NavItem(R.drawable.ic_star, "Sugestões".tr(), "Ative sugestões de palavras".tr(), TYPING),
                NavItem(R.drawable.ic_translate, "Tradução".tr(), "Traduza enquanto digita".tr(), TRANSLATOR),
                NavItem(R.drawable.ic_emoji, "Emojis".tr(), "Gerencie seus emojis".tr(), EMOJI),
                NavItem(R.drawable.ic_clipboard, "Área de transferência".tr(), "Acesse seus itens copiados".tr(), CLIP))),
            NavSection("Som e vibração".tr(), soundItems()),
            NavSection("Geral".tr(), listOf(
                NavItem(R.drawable.ic_globe, "Idioma".tr(), L.NATIVE[prefs.language] ?: "", LANG),
                NavItem(R.drawable.ic_update, "Atualizações".tr(),
                    if (newer != null) L.f("Nova versão %s disponível", newer.versionName) else "Novas versões, novidades e download do APK".tr(), UPDATES),
                NavItem(R.drawable.ic_expand, "Mais opções".tr(), "Assistente e restaurar padrões".tr(), MORE),
                NavItem(R.drawable.ic_info, "Sobre".tr(), "Informações do app".tr(), ABOUT))))
        content.addView(ComposeView(this).apply {
            setContent { HomeScreen(prefs, ready, versionName(), sections, { toggleKeyboard() }, { show(MORE) }, { show(it) }) }
        }, lp())
    }

    private fun patchSummary(): String =
        if (prefs.patch.isNotEmpty()) L.f("Patch ativo: %s", Patches.byId(prefs.patch)?.name?.tr() ?: "") else L.f("Keys Café · %d temas prontos", Patches.ALL.size + Patches.CLASSIC_LIST.size)

    private fun soundItems() = listOf(
        NavItem(R.drawable.ic_sound, "Som e vibração".tr(), if (prefs.vibrate || prefs.sound) "Feedback ao digitar ligado".tr() else "Desligados".tr(), FEEDBACK),
        NavItem(R.drawable.ic_play, "Sons do teclado".tr(), if (prefs.sound) SoundBank.label(prefs.soundType) else "Desligado".tr(), SOUNDS))

    private fun buildThemes() {
        val items = listOf(
            NavItem(R.drawable.ic_palette, "Aparência".tr(), "Tema, cores e formato das teclas".tr(), APPEARANCE),
            NavItem(R.drawable.ic_patch, "Patches".tr(), patchSummary(), PATCHES),
            NavItem(R.drawable.ic_image, "Imagem de fundo".tr(), if (prefs.themeImage) "Ativada · foto da galeria".tr() else "Use uma foto da sua galeria".tr(), IMAGE))
        content.addView(ComposeView(this).apply { setContent { ListScreen(prefs, "Temas".tr(), null, items) { show(it) } } }, lp())
    }

    private fun buildKeyboardTab() {
        addTop(testField("Teste aqui (as mudanças aparecem na hora)".tr()))
        val live = PreviewKeyboard(this, prefs)
        val sections = listOf(
            NavSection("Teclado".tr(), listOf(
                NavItem(R.drawable.ic_tune, "Teclas".tr(), "Estilo, formato, fonte e espaço".tr(), KEYS),
                NavItem(R.drawable.ic_size, "Tamanho do teclado".tr(), L.f("Geral: %d%%  ·  teclas: %ddp", prefs.keyboardScale, prefs.keyHeight), SIZE),
                NavItem(R.drawable.ic_position, "Barra de ícones".tr(), "Ordem, deslizar e botão de idioma".tr(), BAR),
                NavItem(R.drawable.ic_popup, "Popup das teclas".tr(), if (prefs.keyPreview) "Ligado · formato, cor e tamanho".tr() else "Desligado".tr(), PREVIEW),
                NavItem(R.drawable.ic_anim, "Animações".tr(), if (prefs.fluid) "Animações fluidas ligadas".tr() else "Animações simples".tr(), ANIM))),
            NavSection("Som e vibração".tr(), soundItems()))
        content.addView(ComposeView(this).apply { setContent { SectionsScreen(prefs, "Teclado".tr(), live, sections) { show(it) } } }, lp())
    }

    private fun buildAdv() {
        val newer = com.example.materialkeyboard.updates.UpdateChecker.cachedNewer(this)
        val items = listOf(
            NavItem(R.drawable.ic_globe, "Idioma".tr(), L.NATIVE[prefs.language] ?: "", LANG),
            NavItem(R.drawable.ic_update, "Atualizações".tr(),
                if (newer != null) L.f("Nova versão %s disponível", newer.versionName) else "Novas versões, novidades e download do APK".tr(), UPDATES),
            NavItem(R.drawable.ic_expand, "Mais opções".tr(), "Assistente e restaurar padrões".tr(), MORE))
        content.addView(ComposeView(this).apply { setContent { ListScreen(prefs, null, null, items) { show(it) } } }, lp())
    }

    private fun buildEmoji() {
        content.addView(ComposeView(this).apply { setContent { EmojiScreen(prefs) { show(BAR) } } }, lp())
    }

    private fun buildAbout() {
        content.addView(ComposeView(this).apply {
            setContent {
                AboutScreen(prefs, versionName(), { show(UPDATES) }, {
                    prefs.onboarded = false
                    startActivity(Intent(this@SettingsActivity, OnboardingActivity::class.java)); finish()
                })
            }
        }, lp())
    }

    private fun statusCard(ready: Boolean): View {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(16), dp(18), dp(16))
            background = GradientDrawable().apply {
                cornerRadius = dp(20).toFloat()
                setColor(color(if (ready) M.attr.colorSurfaceContainer else M.attr.colorTertiaryContainer))
            }
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) }
        }
        val fg = color(if (ready) M.attr.colorOnSurface else M.attr.colorOnTertiaryContainer)
        val sub = color(if (ready) M.attr.colorOnSurfaceVariant else M.attr.colorOnTertiaryContainer)
        box.addView(TextView(this).apply {
            text = if (ready) "Teclado pronto ✓".tr() else "Falta pouco para usar".tr()
            textSize = 17f
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            setTextColor(fg)
        })
        box.addView(TextView(this).apply {
            text = if (ready) "O Material Keyboard está ativado e selecionado.".tr()
            else "Ative e selecione o Material Keyboard nas configurações do Android.".tr()
            textSize = 13f
            setTextColor(sub)
            setPadding(0, dp(4), 0, 0)
        })
        if (!ready) {
            box.addView(MaterialButton(this).apply {
                text = "Terminar configuração".tr()
                setOnClickListener {
                    prefs.onboarded = false
                    startActivity(Intent(this@SettingsActivity, OnboardingActivity::class.java))
                    finish()
                }
            }, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(12) })
        }
        return box
    }

    private fun testField(hint: String): View = EditText(this).apply {
        this.hint = hint
        textSize = 15f
        setHintTextColor(ColorUtils.setAlphaComponent(color(M.attr.colorOnSurfaceVariant), 170))
        background = GradientDrawable().apply { cornerRadius = dp(16).toFloat(); setColor(color(M.attr.colorSurfaceContainer)) }
        setPadding(dp(16), dp(14), dp(16), dp(14))
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(4); bottomMargin = dp(8) }
    }

    private fun groupLabel(text: String) = section(text)

    private fun navRow(icon: Int, title: String, summary: String, target: String) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(14), dp(12), dp(14))
            background = ripple()
            setOnClickListener { show(target) }
        }
        row.addView(ImageView(this).apply {
            setImageDrawable(ContextCompat.getDrawable(this@SettingsActivity, icon)?.mutate())
            setColorFilter(color(M.attr.colorOnSurfaceVariant))
        }, LinearLayout.LayoutParams(dp(24), dp(24)).apply { marginEnd = dp(16) })
        row.addView(textColumn(title, summary, oneLine = true))
        row.addView(chevron())
        add(row, inset = 56)
    }

    private fun buildAppearance() {
        content.addView(ComposeView(this).apply { setContent { ThemeScreen(prefs) } }, LinearLayout.LayoutParams(-1, -2))
    }

    private fun buildUpdates() {
        content.addView(ComposeView(this).apply { setContent { UpdatesScreen(prefs) } }, LinearLayout.LayoutParams(-1, -2))
    }

    private fun buildPatches() {
        addTop(testField("Digite aqui para ver as mudanças".tr()))
        content.addView(ComposeView(this).apply {
            setContent {
                PatchesScreen(prefs, onImport = { pickTheme.launch("*/*") }, onExport = { id ->
                    pendingExport = id
                    saveTheme.launch(Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                        addCategory(Intent.CATEGORY_OPENABLE)
                        type = "application/octet-stream"
                        putExtra(Intent.EXTRA_TITLE, "$id.mkt")
                    })
                })
            }
        }, LinearLayout.LayoutParams(-1, -2))
    }

    /** Lê, valida e instala o .mkt escolhido. Tudo fora da thread principal; o resultado volta por Toast. */
    private fun importTheme(uri: Uri) {
        Toast.makeText(this, "Importando tema…".tr(), Toast.LENGTH_SHORT).show()
        Thread {
            val msg: String = try {
                val read = contentResolver.openInputStream(uri)?.use { com.example.materialkeyboard.keyscafe.ThemeLibrary.readPackage(it) }
                when (read) {
                    null -> "Não foi possível abrir o arquivo".tr()
                    is com.example.materialkeyboard.keyscafe.PackageRead.Fail -> read.reason.tr()
                    is com.example.materialkeyboard.keyscafe.PackageRead.Ok -> when (val r = com.example.materialkeyboard.keyscafe.ThemeLibrary.install(read, "file")) {
                        is com.example.materialkeyboard.keyscafe.InstallResult.Fail -> r.reason.tr()
                        is com.example.materialkeyboard.keyscafe.InstallResult.Ok -> {
                            // se o tema atualizado é o que está ativo, reaplica para o teclado pegar as cores novas
                            if (prefs.patch == r.spec.id) com.example.materialkeyboard.keyscafe.ThemeLibrary.apply(prefs, r.spec.id)
                            L.f("Tema instalado: %s", r.spec.name)
                        }
                    }
                }
            } catch (_: Exception) { "Não foi possível abrir o arquivo".tr() }
            runOnUiThread {
                if (isFinishing) return@runOnUiThread
                Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
                if (page == PATCHES) refreshPage()
            }
        }.start()
    }

    private fun exportTheme(id: String, uri: Uri) {
        Thread {
            val built = com.example.materialkeyboard.keyscafe.ThemeLibrary.export(id)
            val ok = built is com.example.materialkeyboard.keyscafe.PackageBuild.Ok && try {
                val out = contentResolver.openOutputStream(uri)
                if (out == null) false else { out.use { it.write(built.bytes) }; true }
            } catch (_: Exception) { false }
            runOnUiThread {
                if (isFinishing) return@runOnUiThread
                Toast.makeText(this, (if (ok) "Tema exportado" else "Não foi possível exportar o tema").tr(), Toast.LENGTH_SHORT).show()
            }
        }.start()
    }

    private fun fontColorSection() {
        section("Cor das fontes".tr())
        val sw = switchRow("Mudar cor das fontes".tr(), "Muda só a cor das letras do teclado".tr(), prefs.fontColorOn) { prefs.putBool("fontColorOn", it) }
        val cols = intArrayOf(0xFFFFFFFF.toInt(), 0xFF000000.toInt(), 0xFFFFEB3B.toInt(), 0xFF4DD0E1.toInt(),
            0xFF69F0AE.toInt(), 0xFFFF80AB.toInt(), 0xFFFFAB40.toInt(), 0xFFFF5252.toInt())
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(dp(12), dp(14), dp(12), dp(10)) }
        cols.forEach { c ->
            row.addView(View(this).apply {
                layoutParams = LinearLayout.LayoutParams(0, dp(36), 1f).apply { setMargins(dp(3), 0, dp(3), 0) }
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL; setColor(c)
                    setStroke(dp(if (prefs.fontColorOn && (prefs.fontColor or 0xFF000000.toInt()) == c) 3 else 1),
                        if (prefs.fontColorOn && (prefs.fontColor or 0xFF000000.toInt()) == c) color(M.attr.colorPrimary) else ColorUtils.setAlphaComponent(Color.GRAY, 120))
                }
                setOnClickListener { prefs.putFontColor(c); sw.isChecked = true; refreshPage() }
            })
        }
        add(row)
        val hue = FloatArray(3).also { Color.colorToHSV(prefs.fontColor, it) }[0]
        add(TextView(this).apply {
            text = "Matiz da cor da fonte".tr()
            alpha = 0.7f
            setTextAppearance(M.style.TextAppearance_Material3_BodySmall)
            setPadding(dp(16), dp(2), dp(16), 0)
        })
        add(Slider(this).apply {
            valueFrom = 0f; valueTo = 360f; stepSize = 1f
            value = Math.round(hue).coerceIn(0, 360).toFloat()
            addOnSliderTouchListener(object : Slider.OnSliderTouchListener {
                override fun onStartTrackingTouch(slider: Slider) {}
                override fun onStopTrackingTouch(slider: Slider) {
                    prefs.putFontColor(Color.HSVToColor(floatArrayOf(slider.value, 0.55f, 1f)))
                    sw.isChecked = true
                }
            })
        })
    }

    private fun buildImage() {
        addTop(testField("Teste aqui".tr()))
        content.addView(ComposeView(this).apply { setContent { ImageScreen(prefs, { pickImage.launch("image/*") }, { refreshPage() }) } }, LinearLayout.LayoutParams(-1, -2))
    }

    private fun updatePreview(pos: Float = prefs.imagePos / 100f, dim: Float = prefs.imageDim / 100f) {
        val v = imagePreview ?: return
        val bmp = ThemeImage.get(this, prefs.themeImageRev) ?: return
        v.background = ImageBgDrawable(bmp, dim, pos, dp(24).toFloat(), dp(24).toFloat(), prefs.imgFit, prefs.imgL / 100f, prefs.imgT / 100f, prefs.imgR / 100f, prefs.imgB / 100f)
    }

    private fun importImage(uri: Uri) {
        Toast.makeText(this, "Carregando imagem…".tr(), Toast.LENGTH_SHORT).show()
        Thread {
            val ok = ThemeImage.import(this, uri)
            runOnUiThread {
                if (isFinishing) return@runOnUiThread
                if (ok) { VideoBg.delete(this); prefs.putImage(); Toast.makeText(this, "Imagem aplicada ao teclado".tr(), Toast.LENGTH_SHORT).show() }
                else Toast.makeText(this, "Não foi possível abrir essa imagem".tr(), Toast.LENGTH_SHORT).show()
                if (page == IMAGE) refreshPage()
            }
        }.start()
    }

    private fun buildSize() {
        addTop(testField("Teste aqui para ver o tamanho".tr()))
        content.addView(ComposeView(this).apply { setContent { SizeScreen(prefs) } }, LinearLayout.LayoutParams(-1, -2))
    }

    private fun setScale(v: Int) { prefs.putInt("keyboardScale", v); refreshPage() }

    /** Teclas de demonstração (ao vivo) usadas nas páginas Teclas e Animações. */
    private fun demoKeys(): ArrayList<KeyView> {
        val pk = PreviewKeyboard(this, prefs)
        addTop(pk)
        return ArrayList(pk.keys)
    }

    private fun buildAnim() {
        addTop(testField("Digite aqui para sentir as animações".tr()))
        val keys = demoKeys()
        content.addView(ComposeView(this).apply { setContent { AnimScreen(prefs) { f -> keys.forEach { k -> k.fluid = f } } } }, LinearLayout.LayoutParams(-1, -2))
    }

    private fun buildKeys() {
        addTop(testField("Digite aqui para ver as mudanças".tr()))
        val keys = demoKeys()
        val hooks = KeysHooks({ v -> keys.forEach { it.keyStyle = v } }, { v -> keys.forEach { it.shape = v } },
            { v -> keys.forEach { it.fontStyle = v } }, { v -> keys.forEach { it.glow = v } })
        content.addView(ComposeView(this).apply { setContent { KeysScreen(prefs, hooks) } }, LinearLayout.LayoutParams(-1, -2))
    }

    private fun buildPreview() {
        addTop(testField("Toque nas teclas para ver o popup; segure uma letra para ver os acentos".tr()))
        content.addView(ComposeView(this).apply { setContent { PreviewScreen(prefs) } }, LinearLayout.LayoutParams(-1, -2))
    }

    private fun popupShapePicker() {
        add(TextView(this).apply {
            text = "Formato".tr()
            setTextAppearance(M.style.TextAppearance_Material3_BodyLarge)
            setPadding(dp(16), dp(14), dp(16), 0)
        })
        val on = color(M.attr.colorPrimary); val off = color(M.attr.colorSecondaryContainer)
        val scroller = android.widget.HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        val rowView = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(dp(12), dp(12), dp(12), dp(12)) }
        val cols = ArrayList<LinearLayout>()
        var cur = prefs.previewShape
        fun tile(i: Int) = PopupShapeTile(this, i, cur == i, on, off)
        PopupShapes.NAMES.forEachIndexed { i, name ->
            val col = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; gravity = android.view.Gravity.CENTER_HORIZONTAL
                addView(tile(i), LinearLayout.LayoutParams(dp(68), dp(56)))
                addView(TextView(this@SettingsActivity).apply { text = name.tr(); textSize = 11f; gravity = android.view.Gravity.CENTER })
                setPadding(dp(4), 0, dp(4), 0)
            }
            col.setOnClickListener {
                cur = i; prefs.putInt("previewShape", i)
                // troca só as miniaturas (sem recriar a página) e a escolhida dá um pop elástico
                cols.forEachIndexed { j, c -> c.removeViewAt(0); c.addView(tile(j), 0, LinearLayout.LayoutParams(dp(68), dp(56))) }
                col.getChildAt(0).pop(0.7f, 0L, 520f, 0.38f)
                col.wiggle(6f)
            }
            cols.add(col); rowView.addView(col)
        }
        scroller.addView(rowView)
        add(scroller)
    }

    private fun buildTranslator() {
        addTop(testField("Digite aqui e abra o tradutor pelo ícone de tradução do teclado".tr()))
        content.addView(ComposeView(this).apply { setContent { TranslatorScreen(prefs) } }, LinearLayout.LayoutParams(-1, -2))
    }

    private fun buildFeedback() {
        SoundBank.customFiles(this)
        val hooks = SoundHooks(
            pickGeneral = { soundKey = -1; show(SOUNDS) },
            pickKey = { i -> soundKey = i; show(SOUNDS) },
            add = { pickAudio.launch("audio/*") },
            removeAll = {
                SoundBank.customDir(this).listFiles()?.forEach { it.delete() }; SoundBank.customNames = emptyList()
                if (prefs.soundType >= SoundBank.CUSTOM) prefs.putInt("soundType", 0)
                SoundBank.Slot.NAMES.indices.forEach { if (prefs.keySounds[it] >= SoundBank.CUSTOM) prefs.putInt("keySound$it", -1) }
                refreshPage()
            },
            resetKeys = { SoundBank.Slot.NAMES.indices.forEach { prefs.putInt("keySound$it", -1) }; refreshPage() })
        content.addView(ComposeView(this).apply { setContent { FeedbackScreen(prefs, hooks) } }, LinearLayout.LayoutParams(-1, -2))
    }

    /** Seleção e teste dos sons (geral ou de uma tecla): prévia ao vivo + cartões com ▶ para testar. */
    private fun buildSounds() {
        val types = SoundBank.NAMES.indices.toList() + SoundBank.customFiles(this).indices.map { SoundBank.CUSTOM + it }
        val bank = preview ?: SoundBank(this).also { preview = it }
        val key = soundKey
        content.addView(ComposeView(this).apply {
            setContent {
                SoundsScreen(prefs, key, types,
                    onTest = { t -> Thread {
                        bank.prepare(t); Thread.sleep(250)
                        val v = prefs.soundVolume.coerceAtLeast(40) / 100f; val pt = prefs.soundPitch / 100f
                        for (c in listOf("h", "o", "l", "a", "space", "shift", "back", "enter")) { bank.play(t, c, v, pt, false); Thread.sleep(80); bank.play(t, c + "_up", v, pt, false); Thread.sleep(150) }
                    }.start() },
                    onPick = { t ->
                        if (key < 0) prefs.putInt("soundType", t) else prefs.putInt("keySound$key", t)
                        if (!prefs.sound) prefs.putBool("sound", true)
                    })
            }
        }, LinearLayout.LayoutParams(-1, -2))
    }

    private fun buildTyping() {
        content.addView(ComposeView(this).apply { setContent { TypingScreen(prefs) } }, LinearLayout.LayoutParams(-1, -2))
    }

    private fun buildClipboard() {
        content.addView(ComposeView(this).apply {
            setContent { ClipScreen(prefs) { ClipboardStore.get(this@SettingsActivity).clear(); Toast.makeText(this@SettingsActivity, "Histórico apagado".tr(), Toast.LENGTH_SHORT).show() } }
        }, LinearLayout.LayoutParams(-1, -2))
    }

    private fun buildLanguage() {
        content.addView(ComposeView(this).apply { setContent { LanguageScreen(prefs) { refreshPage() } } }, LinearLayout.LayoutParams(-1, -2))
    }

    private fun buildBar() {
        content.addView(ComposeView(this).apply { setContent { BarScreen(prefs) } }, LinearLayout.LayoutParams(-1, -2))
    }

    private fun buildMore() {
        content.addView(ComposeView(this).apply {
            setContent {
                MoreScreen(prefs, onWizard = {
                    prefs.onboarded = false
                    startActivity(Intent(this@SettingsActivity, OnboardingActivity::class.java)); finish()
                }, onReset = {
                    MaterialAlertDialogBuilder(this@SettingsActivity)
                        .setTitle("Restaurar padrões?".tr())
                        .setMessage("Todas as configurações voltam ao valor original e a imagem de fundo é removida.".tr())
                        .setNegativeButton("Cancelar".tr(), null)
                        .setPositiveButton("Restaurar".tr()) { _, _ -> ThemeImage.delete(this@SettingsActivity); prefs.resetAll(); TranslatorPrefs.get(this@SettingsActivity).clear(); refreshPage() }
                        .show()
                })
            }
        }, LinearLayout.LayoutParams(-1, -2))
    }


    // ---------- Componentes ----------

    // ---------- Cartões agrupados (visual minimalista) ----------

    private var card: LinearLayout? = null

    /** Adiciona algo fora dos cartões; o próximo item começa um cartão novo. */
    private fun addTop(v: View, lp: android.view.ViewGroup.LayoutParams? = null) {
        if (lp != null) content.addView(v, lp) else content.addView(v)
        card = null
    }

    private fun newCard(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = GradientDrawable().apply { cornerRadius = dp(24).toFloat(); setColor(ColorUtils.setAlphaComponent(Palette.build(this@SettingsActivity, prefs).keyNormal, 140)) }
        clipToOutline = true
        val afterLabel = content.childCount > 0 && content.getChildAt(content.childCount - 1) is TextView
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = if (afterLabel) 0 else dp(12) }
    }.also { content.addView(it); card = it }

    private fun divider(insetDp: Int): View = View(this).apply {
        setBackgroundColor(ColorUtils.setAlphaComponent(color(M.attr.colorOutlineVariant), 150))
        layoutParams = LinearLayout.LayoutParams(-1, maxOf(1, dp(1) / 2)).apply { marginStart = dp(insetDp) }
    }

    /** Põe uma linha no cartão atual (criando-o se preciso), com divisória fina antes. */
    private fun add(v: View, inset: Int = 16, divided: Boolean = true) {
        val c = card ?: newCard()
        if (divided && c.childCount > 0) c.addView(divider(inset))
        c.addView(v)
    }

    private fun ripple(): android.graphics.drawable.Drawable = RippleDrawable(
        ColorStateList.valueOf(ColorUtils.setAlphaComponent(color(M.attr.colorOnSurface), 26)), null,
        android.graphics.drawable.ColorDrawable(Color.WHITE))

    private fun chevron(): View = ImageView(this).apply {
        setImageDrawable(ContextCompat.getDrawable(this@SettingsActivity, R.drawable.ic_chevron)?.mutate())
        setColorFilter(color(M.attr.colorOnSurfaceVariant))
        alpha = 0.6f
        layoutParams = LinearLayout.LayoutParams(dp(24), dp(24))
    }

    private fun actionRow(text: String, danger: Boolean, onClick: () -> Unit): TextView = TextView(this).apply {
        this.text = text
        textSize = 15f
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        setTextColor(color(if (danger) M.attr.colorError else M.attr.colorPrimary))
        setPadding(dp(16), dp(15), dp(16), dp(15))
        background = ripple()
        setOnClickListener { onClick() }
    }


    private fun soundButton(text: String, onClick: () -> Unit) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(14), dp(12), dp(14))
            background = ripple()
            setOnClickListener { onClick() }
        }
        row.addView(TextView(this).apply {
            this.text = text; textSize = 15f
            setTextColor(color(M.attr.colorOnSurface))
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        })
        row.addView(chevron())
        add(row)
    }

    /** Lista de todos os sons, agrupados por pacote no rótulo; cada item toca uma prévia. */
    private fun pickSound(title: String, current: Int, withDefault: Boolean, onPick: (Int) -> Unit) {
        val allTypes = SoundBank.NAMES.indices.toList() + SoundBank.customFiles(this).indices.map { SoundBank.CUSTOM + it }
        val labels = (if (withDefault) listOf("Padrão (som geral)".tr()) else emptyList()) +
            allTypes.map { SoundBank.label(it) }
        val off = if (withDefault) 1 else 0
        val bank = preview ?: SoundBank(this).also { preview = it }
        var chosen = current
        val checked = if (withDefault && current < 0) 0 else allTypes.indexOf(current).coerceAtLeast(0) + off
        MaterialAlertDialogBuilder(this)
            .setTitle(title)
            .setSingleChoiceItems(labels.toTypedArray(), checked) { _, which ->
                chosen = if (which - off < 0) -1 else allTypes[which - off]
                val t = chosen
                if (t >= 0) Thread {
                    bank.prepare(t)
                    Thread.sleep(450)
                    val v = (prefs.soundVolume.coerceAtLeast(40)) / 100f; val pt = prefs.soundPitch / 100f
                    for (c in listOf("h", "o", "space", "shift", "enter")) { bank.play(t, c, v, pt, false); Thread.sleep(90); bank.play(t, c + "_up", v, pt, false); Thread.sleep(130) }
                }.start()
            }
            .setNegativeButton("Cancelar".tr(), null)
            .setPositiveButton("OK".tr()) { _, _ -> onPick(chosen) }
            .show()
    }

    /** Som geral das teclas (pacotes clássicos, espaciais, futuristas e suaves). */
    private fun soundPicker() {
        soundButton(L.f("Som das teclas: %s", SoundBank.label(prefs.soundType))) {
            pickSound("Som das teclas".tr(), prefs.soundType, false) { v ->
                prefs.putInt("soundType", v)
                if (!prefs.sound) prefs.putBool("sound", true)
                refreshPage()
            }
        }
    }

    /** Faixa de miniaturas dos formatos. [sameOption]: o primeiro item "=" significa igual às demais teclas. */
    private fun shapePicker(current: Int, sameOption: Boolean, onPick: (Int) -> Unit) {
        val sc = android.widget.HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        val rowV = LinearLayout(this).apply { setPadding(dp(12), dp(12), dp(12), dp(12)) }
        val on = color(M.attr.colorPrimary); val off = color(M.attr.colorSecondaryContainer)
        val tiles = ArrayList<Pair<Int, android.view.View>>()
        var cur = current
        fun add(id: Int, label: String) {
            val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = android.view.Gravity.CENTER; setPadding(dp(4), 0, dp(4), 0) }
            fun tile(sel: Boolean) = if (id < 0) TextView(this).apply { text = "="; gravity = android.view.Gravity.CENTER; textSize = 22f
                setTextColor(if (sel) color(M.attr.colorOnPrimary) else color(M.attr.colorOnSecondaryContainer))
                setBackgroundColor(if (sel) on else off) } else ShapeTile(this, id, sel, on, off)
            var t = tile(cur == id)
            col.addView(t, LinearLayout.LayoutParams(dp(76), dp(52)))
            col.addView(TextView(this).apply { text = label; textSize = 11f; gravity = android.view.Gravity.CENTER })
            col.setOnClickListener {
                cur = id; onPick(id)
                col.removeViewAt(0); t = tile(true); col.addView(t, 0, LinearLayout.LayoutParams(dp(76), dp(52)))
                tiles.forEach { (tid, c) -> if (tid != id) { val g = c as LinearLayout; g.removeViewAt(0); g.addView(if (tid < 0) TextView(this).apply { text = "="; gravity = android.view.Gravity.CENTER; textSize = 22f; setBackgroundColor(off) } else ShapeTile(this, tid, false, on, off), 0, LinearLayout.LayoutParams(dp(76), dp(52))) } }
                col.animate().scaleX(1.12f).scaleY(1.12f).setDuration(110).withEndAction { col.animate().scaleX(1f).scaleY(1f).setDuration(220).setInterpolator(android.view.animation.OvershootInterpolator(3f)).start() }.start()
            }
            tiles.add(id to col); rowV.addView(col)
        }
        if (sameOption) add(-1, "Igual".tr())
        KeyShapes.NAMES.forEachIndexed { i, n -> add(i, n.tr()) }
        sc.addView(rowV); add(sc)
    }

    /** Título grande e pesado + selo ondulado colorido (estilo Expressive). */
    /** Rótulo pequeno e discreto; o que vier depois entra num novo cartão. */
    private fun section(title: String) {
        card = null
        content.addView(TextView(this).apply {
            text = title.uppercase()
            textSize = 12f
            letterSpacing = 0.08f
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            setTextColor(color(M.attr.colorPrimary))
            setPadding(dp(16), dp(26), dp(16), dp(8))
        })
    }

    private fun note(text: String) {
        add(TextView(this).apply {
            this.text = text
            textSize = 13f
            setLineSpacing(0f, 1.12f)
            setTextColor(color(M.attr.colorOnSurfaceVariant))
            setPadding(dp(16), dp(10), dp(16), dp(14))
        }, divided = false)
    }

    private fun textColumn(title: String, subtitle: String?, oneLine: Boolean = false): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        addView(TextView(this@SettingsActivity).apply {
            text = title
            textSize = 16f
            setTextColor(color(M.attr.colorOnSurface))
        })
        if (subtitle != null) addView(TextView(this@SettingsActivity).apply {
            text = subtitle
            textSize = 13f
            setTextColor(color(M.attr.colorOnSurfaceVariant))
            setPadding(0, dp(2), 0, 0)
            if (oneLine) { maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END }
        })
    }

    private fun switchRow(title: String, subtitle: String?, checked: Boolean, onChange: (Boolean) -> Unit): MaterialSwitch {
        val sw = MaterialSwitch(this).apply {
            isChecked = checked
            setOnCheckedChangeListener { b, v -> b.pop(0.9f, 0L, 600f, 0.45f); onChange(v) }
        }
        add(LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(12), dp(12), dp(12))
            background = ripple()
            addView(textColumn(title, subtitle).apply { (layoutParams as LinearLayout.LayoutParams).marginEnd = dp(12) })
            addView(sw)
            setOnClickListener { sw.toggle() }
        })
        return sw
    }

    private fun sliderRow(title: String, value: Int, min: Int, max: Int, unit: String, onSave: (Int) -> Unit) =
        sliderRowLive(title, value, min, max, unit, null, onSave)

    private fun sliderRowLive(
        title: String, value: Int, min: Int, max: Int, unit: String,
        live: ((Int) -> Unit)?, onSave: (Int) -> Unit
    ) {
        val label = TextView(this).apply {
            text = "$value$unit"; textSize = 14f
            setTextColor(color(M.attr.colorOnSurfaceVariant))
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(8), 0, dp(8), 0)
            addView(TextView(this@SettingsActivity).apply {
                text = title; textSize = 16f
                setTextColor(color(M.attr.colorOnSurface))
                layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
            })
            addView(label)
        }
        val slider = Slider(this).apply {
            valueFrom = min.toFloat()
            valueTo = max.toFloat()
            stepSize = 1f
            this.value = value.coerceIn(min, max).toFloat()
            addOnChangeListener { _, v, fromUser ->
                label.text = "${v.toInt()}$unit"
                if (fromUser) live?.invoke(v.toInt())
            }
            addOnSliderTouchListener(object : Slider.OnSliderTouchListener {
                override fun onStartTrackingTouch(slider: Slider) {}
                override fun onStopTrackingTouch(slider: Slider) { onSave(slider.value.toInt()) }
            })
        }
        add(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), dp(14), dp(8), dp(2))
            addView(header)
            addView(slider)
        })
    }

    private fun segmented(title: String, options: List<String>, selected: Int, onSelect: (Int) -> Unit) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(14))
        }
        box.addView(TextView(this).apply {
            text = title; textSize = 16f
            setTextColor(color(M.attr.colorOnSurface))
            setPadding(0, 0, 0, dp(10))
        })
        val group = MaterialButtonToggleGroup(this).apply {
            isSingleSelection = true
            isSelectionRequired = true
        }
        val ids = ArrayList<Int>()
        options.forEach { label ->
            val b = MaterialButton(this, null, M.attr.materialButtonOutlinedStyle).apply {
                text = label
                id = View.generateViewId()
                textSize = 13f
                isAllCaps = false
                maxLines = 1
                ellipsize = android.text.TextUtils.TruncateAt.END
                insetTop = 0; insetBottom = 0
                minHeight = dp(40)
                setPadding(dp(4), 0, dp(4), 0)
                layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
            }
            ids.add(b.id)
            group.addView(b)
        }
        group.check(ids[selected.coerceIn(0, ids.size - 1)])
        group.addOnButtonCheckedListener { _, checkedId, isChecked ->
            if (isChecked) { group.findViewById<View>(checkedId)?.pop(0.92f, 0L, 600f, 0.45f); onSelect(ids.indexOf(checkedId)) }
        }
        box.addView(group, LinearLayout.LayoutParams(-1, -2))
        add(box)
    }

    /** Faixa de temas prontos: cada cartão mostra fundo, teclas e cor de destaque do tema. */
    private fun presetPicker() {
        val scroller = android.widget.HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        val rowView = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(12), dp(12), dp(12), dp(12))
        }
        fun card(name: String, index: Int, surface: Int, key: Int, special: Int, accent: Int) {
            val selected = prefs.preset == index && !prefs.themeImage
            val col = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
                layoutParams = LinearLayout.LayoutParams(dp(84), -2).apply { marginEnd = dp(10) }
                setOnClickListener {
                    prefs.putInt("preset", index)
                    if (index != 0) prefs.putBool("useCustomColor", false)
                    refreshPage()
                }
            }
            val swatch = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(8), dp(8), dp(8), dp(8))
                layoutParams = LinearLayout.LayoutParams(dp(84), dp(64))
                background = GradientDrawable().apply {
                    cornerRadius = dp(16).toFloat(); setColor(surface)
                    setStroke(dp(if (selected) 3 else 1), if (selected) color(M.attr.colorPrimary) else ColorUtils.setAlphaComponent(Color.GRAY, 90))
                }
            }
            fun keyRow(vararg cols: Int) = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutParams = LinearLayout.LayoutParams(-1, 0, 1f).apply { topMargin = dp(2); bottomMargin = dp(2) }
                cols.forEach { c ->
                    addView(View(this@SettingsActivity).apply {
                        layoutParams = LinearLayout.LayoutParams(0, -1, 1f).apply { setMargins(dp(2), 0, dp(2), 0) }
                        background = GradientDrawable().apply { cornerRadius = dp(4).toFloat(); setColor(c) }
                    })
                }
            }
            swatch.addView(keyRow(key, key, key, key))
            swatch.addView(keyRow(key, key, key))
            swatch.addView(keyRow(special, key, accent))
            col.addView(swatch)
            col.addView(TextView(this).apply {
                text = name
                gravity = Gravity.CENTER
                maxLines = 1
                setTextAppearance(M.style.TextAppearance_Material3_LabelMedium)
                setPadding(0, dp(4), 0, 0)
            })
            rowView.addView(col)
        }
        card("Padrão".tr(), 0, color(M.attr.colorSurfaceContainerHigh), color(M.attr.colorSurface),
            color(M.attr.colorSecondaryContainer), color(M.attr.colorPrimary))
        Palette.PRESETS.forEachIndexed { i, p ->
            card(p.name.tr(), i + 1, p.surface.toInt(), p.normal.toInt(), p.special.toInt(), p.accent.toInt())
        }
        scroller.addView(rowView)
        add(scroller)
    }

    private fun colorPicker() {
        val swatches = listOf(0xFF3F6BFF, 0xFF7B5CFA, 0xFFD6336C, 0xFFE8590C, 0xFF2F9E44, 0xFF0C8599, 0xFF495057)
            .map { it.toInt() }
        val rowView = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(16), dp(14), dp(16), dp(10))
        }
        swatches.forEach { c ->
            rowView.addView(View(this).apply {
                layoutParams = LinearLayout.LayoutParams(dp(36), dp(36)).apply { marginEnd = dp(10) }
                background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(c) }
                contentDescription = "Cor".tr()
                setOnClickListener {
                    val hadPreset = prefs.preset != 0
                    prefs.putCustomColor(c); customSwitch?.isChecked = true
                    if (hadPreset) { refreshPage(); return@setOnClickListener }
                    scaleX = 0.8f; scaleY = 0.8f
                    springTo(DynamicAnimation.SCALE_X, 1f, 500f, 0.4f)
                    springTo(DynamicAnimation.SCALE_Y, 1f, 500f, 0.4f)
                }
            })
        }
        add(rowView)
        // Slider com stepSize=1 só aceita inteiros (senão lança IllegalStateException): matiz arredondado.
        val hue = FloatArray(3).also { Color.colorToHSV(prefs.customColor, it) }[0]
        val slider = Slider(this).apply {
            valueFrom = 0f; valueTo = 360f; stepSize = 1f
            value = Math.round(hue).coerceIn(0, 360).toFloat()
            addOnSliderTouchListener(object : Slider.OnSliderTouchListener {
                override fun onStartTrackingTouch(slider: Slider) {}
                override fun onStopTrackingTouch(slider: Slider) {
                    val hadPreset = prefs.preset != 0
                    prefs.putCustomColor(Color.HSVToColor(floatArrayOf(slider.value, 0.65f, 0.85f)))
                    customSwitch?.isChecked = true
                    if (hadPreset) refreshPage()
                }
            })
        }
        add(TextView(this).apply {
            text = "Matiz da cor personalizada".tr()
            alpha = 0.7f
            setTextAppearance(M.style.TextAppearance_Material3_BodySmall)
            setPadding(dp(16), dp(2), dp(16), 0)
        })
        add(slider)
    }

    private fun buttonRow(vararg items: Pair<String, () -> Unit>): View {
        val danger = listOf("Restaurar configurações padrão", "Apagar histórico", "Excluir modelos baixados").map { it.tr() }
        if (items.size == 1) return actionRow(items[0].first, items[0].first in danger, items[0].second)
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            items.forEachIndexed { i, (label, action) ->
                if (i > 0) addView(View(this@SettingsActivity).apply {
                    setBackgroundColor(ColorUtils.setAlphaComponent(color(M.attr.colorOutlineVariant), 150))
                    layoutParams = LinearLayout.LayoutParams(maxOf(1, dp(1) / 2), dp(24)).apply { gravity = Gravity.CENTER_VERTICAL }
                })
                addView(actionRow(label, false, action).apply {
                    gravity = Gravity.CENTER
                    layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
                })
            }
        }
    }

    companion object {
        private const val HOME = "home"
        private const val THEMES = "themes"
        private const val KB = "kb"
        private const val ADV = "adv"
        private const val EMOJI = "emoji"
        private const val ABOUT = "about"
        private val TOP = setOf(HOME, KB, THEMES)      // páginas das abas (barra inferior)
        private const val APPEARANCE = "appearance"
        private const val PATCHES = "patches"
        private const val IMAGE = "image"
        private const val SIZE = "size"
        private const val ANIM = "anim"
        private const val FEEDBACK = "feedback"
        private const val TRANSLATOR = "translator"
        private const val TYPING = "typing"
        private const val CLIP = "clip"
        private const val MORE = "more"
        private const val LANG = "lang"
        private const val KEYS = "keys"
        private const val PREVIEW = "preview"
        private const val BAR = "bar"
        private const val UPDATES = "updates"
        private const val SOUNDS = "sounds"
        private val TITLES = mapOf(
            APPEARANCE to "Aparência", PATCHES to "Patches", IMAGE to "Imagem de fundo", SIZE to "Tamanho do teclado",
            ANIM to "Animações", FEEDBACK to "Som e vibração", TRANSLATOR to "Tradutor", TYPING to "Digitação",
            CLIP to "Área de transferência", MORE to "Mais opções", LANG to "Idioma",
            SOUNDS to "Sons do teclado", ADV to "Configurações", EMOJI to "Emojis", ABOUT to "Sobre", KEYS to "Teclas", PREVIEW to "Popup das teclas", BAR to "Barra de ícones", UPDATES to "Atualizações"
        )
    }
}

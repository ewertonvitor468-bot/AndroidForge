> **Licença / License:** a partir da v65.5 o Material Keyboard é software proprietário (todos os direitos reservados). Veja `LICENSE`. / From v65.5 on, Material Keyboard is proprietary software (all rights reserved). See `LICENSE`.

## v66: sem animes, balão mais fluido e teclado flutuante redondo e redimensionável
- **Aba Animes removida por completo** (`Animes.kt`, `assets/animes/`, UI, preferências e traduções): APK bem mais leve. O fundo por foto/vídeo da galeria continua.
- **Balão da tecla (`KeyPreview`)**: antes a janela inteira era reposicionada no sistema a cada toque, o que atrasava a digitação rápida e mostrava o texto novo no lugar da tecla anterior. Agora a janela é fixa e só o balão se move dentro dela (com um deslizar curto de mola entre teclas).
- **Variações (`AltPopup`)**: `finish()` não devolve mais uma variação velha se outro popup abriu no meio.
- **Teclado flutuante**: cantos arredondados nos quatro lados (mínimo de 22 dp) com sombra suave, sem reservar espaço da barra de navegação. A alça de cima ganhou os botões **−** e **+** (passos de 5%, de 60% a 110%), e há um controle deslizante em Tamanho > "Tamanho do teclado flutuante" (`floatScale`).

## v65.6: digitar ao soltar e idiomas no botão de idioma
- **Digitar ao soltar**: a letra agora só entra quando você levanta o dedo (antes entrava ao encostar, rápido demais). Som e vibração continuam ao encostar. Dá para voltar ao modo antigo em Teclado > Gestos > "Digitar ao soltar".
- **Botão de idioma (globo)**: toque = próximo idioma (ao soltar). Segurar = mostra os idiomas ativos para escolher, mais um botão "＋" que abre a lista dos idiomas que faltam; tocar em um adiciona e já troca.
- **Sons**: removidos 5 pacotes de som de terceiros com licença "só uso pessoal" (não podem ser redistribuídos). Restam 6 pacotes; o som que você tinha escolhido é migrado sozinho (se apontava para um removido, volta ao primeiro).

## v65.5: novo ícone, idioma do aplicativo em 40+ línguas e gesto de apagar deslizando
- **Ícone novo** em todo o app (launcher, redondo, adaptativo e tema monocromático do Android 13+); a tela inicial usa o ícone do app e acompanha.
- **Idioma do aplicativo** (Configurações > Idioma): menus e textos em 40+ línguas além das 8 do teclado (hindi, bengali, indonésio, chinês, japonês, coreano, alemão, italiano, polonês, ucraniano, urdu, tailandês etc.). Tradução automática no aparelho (ML Kit), feita uma vez por idioma e guardada. O teclado e o Tradutor ficam como estavam. "Igual ao teclado" volta ao comportamento antigo.
- **Gesto do Gboard:** segure o apagar e deslize para a esquerda para selecionar palavra por palavra; ao soltar, apaga. Liga/desliga em Teclado > Gestos.

## v62: aba Animes (vídeos de fundo embutidos), sem esticar, com desfoque

- **Imagem de fundo → aba "Animes"**: 5 vídeos já dentro do app (`assets/animes/anime1..5.mp4` + miniaturas `.jpg`), sem áudio, sem a tela final do TikTok. Tocar na miniatura aplica o vídeo (`Animes.kt`, `SettingsActivity.applyAnime`). Para acrescentar mais: coloque `animeN.mp4` e `animeN.jpg` na pasta e aumente `Animes.COUNT`.
- **Sem esticar**: o `TextureView` esticava o vídeo; `VideoBgView.fit()` agora amplia com a mesma proporção até cobrir o teclado (largura e altura) e corta as sobras. O controle "Posição da imagem" escolhe a parte vertical que aparece.
- **Opacidade das teclas**: o slider (já existente) agora vai de 10 a 100% e vale também para os vídeos.
- **Desfoque do fundo** (novo, `videoBlur`): slider na página Imagem; usa `RenderEffect`, então só aparece no Android 12+.
- Sem som: `setVolume(0f, 0f)` e os arquivos não têm faixa de áudio.
- Removida a linha `resourceConfigurations` do `app/build.gradle.kts` (o PocketCode recusa a instrução); o APK fica um pouco maior.
- **Altura do vídeo = altura do teclado** (antes ocupava a tela inteira e ficava ampliado demais): `buildUi()` ajusta a altura do `VideoBgView` à do teclado.
- Vídeos reencodados a 640 px de largura, 30 fps, crf 28 (31 no anime4), com nitidez leve (a fonte original tem 576 px). O APK cresce ~15 MB.
- NÃO COMPILADO (sem Android SDK neste ambiente).

## v61: francês, turco e vietnamita (sai o japonês)

- **Idiomas do teclado agora:** Português, English, Español, العربية, Русский, **Français**, **Türkçe**, **Tiếng Việt**. Japonês removido (`Kana.kt` apagado, coluna japonesa da tabela de textos tirada de `Lang.kt`). Quem estava em japonês volta ao português. Mandarim ficou de fora.
- **Francês:** AZERTY (`azertyuiop / qsdfghjklm / wxcvbn'`, com o apóstrofo na terceira fileira para l', j', qu'); segurar uma vogal abre os acentos (é è ê à ç œ...).
- **Turco:** teclado Q turco (`qwertyuıopğü / asdfghjklşi / zxcvbnmöç`). Maiúsculas corretas: i → İ e ı → I (`up()` em `KeyboardService.kt` e `low()`/`up()` em `Suggestions.kt`, com `Locale("tr")`).
- **Vietnamita:** QWERTY + **Telex** (`Telex.kt`): aa→â, ee→ê, oo→ô, aw→ă, ow→ơ, uw→ư, dd→đ, tons s/f/r/x/j (z tira), repetir a tecla desfaz. A palavra é recomposta a cada tecla, então o tom troca de lugar sozinho (hoaf → hòa, hoafn → hoàn). Apagar refaz as teclas a partir do que está na tela. Desligado em campos de senha, e-mail e URL. Autocorreção desligada em vietnamita (a distância de edição estragaria as palavras já acentuadas). Segurar a vogal também dá os tons prontos.
- **Dicionários:** francês, turco e vietnamita usam a lista FrequencyWords (50 mil palavras), baixada uma vez ao escolher o idioma, como os outros (`DictionaryDownloader.kt`). Nada disso entra no APK. Sem sugestão de próxima palavra nesses três.
- **Voz e corretor do Android:** fr-FR, tr-TR, vi-VN. **Tradutor (ML Kit):** FR, TR e VI no lugar de JA.
- **Interface do app:** em francês, turco e vietnamita os textos aparecem em inglês por enquanto (só pt/en/es/ar/ru têm tradução).
- **Tamanho:** `resourceConfigurations` limita os recursos de bibliotecas aos 8 idiomas acima. `isMinifyEnabled` continua falso (ligar o R8 reduz mais, mas precisa de teste).
- NÃO COMPILADO (sem Android SDK neste ambiente). A lógica do Telex foi testada à parte (52 casos + ida e volta de `toRaw`/`compose`), mas o teclado em si não rodou.

## v58: novo menu de configurações

- Tela inicial refeita: cabeçalho (ícone, nome e versão), cartão **Ativar o teclado**, atalhos (Temas, Configurações, Emojis, Área de transferência, Tradução, Sugestões, Sobre) e barra inferior com abas Configurações / Teclado / Temas.
- Aba **Teclado**: campo de teste + prévia ao vivo + Teclas, Tamanho, Barra, Popup, Animações, Som. Aba **Temas**: Aparência, Patches, Imagem de fundo.
- Novas páginas **Emojis** e **Sobre**. Sem recursos premium.
- Versão exibida vem do `versionName`. Para subir: mude só `appVersion` em `app/build.gradle.kts` (58 → 59 → 60...).
- NÃO COMPILADO (sem Android SDK neste ambiente).

# Material Keyboard

## v56.1: configurações reorganizadas, prévia ao vivo e sons

- Configurações reagrupadas (Tema, Teclado, Digitação, Som e vibração, Geral) em cartões com animações.
- Prévia do teclado em tempo real (cores, formato, estilo, altura, fonte); tocar nas teclas toca o som e vibra.
- Nova página "Sons do teclado": escolher e testar (▶) cada pacote, geral ou por tecla.
- Pacotes 8–11 (Apex PRO, Orange Deluxe, Keychron Q3 Blue, WOB Rainy 75) integrados. Novos pacotes: coloque `assets/sounds/p<N>/` (a-z, space, enter, back, shift, sym, comma, period, num; `_up` opcional; ogg/wav/mp3) e `name.txt` com o nome. São detectados sozinhos.
- NÃO COMPILADO (sem build neste ambiente).

## v54.7: atualizações pelo GitHub Releases
**Estado de compilação: NÃO validada** (sem Android SDK neste ambiente; só checagem de colchetes).
- A aba **Atualizações** agora lê o **último release do GitHub** (`updates/UpdatesConfig.kt`: dono e repositório), sem Supabase.
- **Para lançar uma versão**: aumente `versionCode`/`versionName` em `app/build.gradle.kts`, compile, crie um release com a **tag igual ao versionName** (ex.: `v54.8`) e anexe o `.apk`. Pronto: o app mostra "Nova versão".
- A comparação é pelo **nome da versão (tag)**, não pelo versionCode. O APK precisa ser assinado com a mesma chave do instalado.
- O repositório precisa ser **público**. O Supabase segue em uso só para temas/comentários/moderação.
- `versionCode` 14 → **15**, `versionName` 54.5 → **54.7**.

Teclado Android (`InputMethodService`) em Kotlin, com **Material You** (cores dinâmicas do Android 12+).

## v54.4: nova versão do APK
**Estado de compilação: NÃO validada** (sem Android SDK/kotlinc neste ambiente; só checagem de colchetes em todos os `.kt`).
- **ThemeBoard**: botão **Criar tema** no topo da loja (ao lado de Fechar); fecha a loja e abre o Editor de temas. Depois de salvar, o tema aparece em Keys Café e em ThemeBoard → Meus temas → Publicar. (`ThemeBoardScreen.kt`, `PatchesScreen.kt`, `Lang.kt`)
- `versionCode` 12 → **13** e `versionName` 54.3 → **54.4** (`app/build.gradle.kts`). Para a aba Atualizações oferecer esta versão, publique no Supabase uma linha com `version_code = 13`, `is_published = true`, e o APK assinado com a mesma chave da instalada.

## v54.2: aba Clássicos, personalização ilimitada e 5 temas novos — NÃO COMPILADO
**Estado de compilação: NÃO validada** (sem Android SDK/kotlinc neste ambiente; só checagem de colchetes). Compile com `./gradlew assembleDebug` e me mande qualquer erro.

- **Nova aba "Clássicos"** (Patches → Clássicos), com 5 temas em `Patches.CLASSIC_LIST` (ficam fora da lista geral):
  **Padrão 2017** (teclas retas com sombra fina, faixa reta, botões redondos) · **Mecânico** (keycaps 3D, botões quadrados) ·
  **Material** (Enter em cookie, balão e microfone em flor, seta em cookie) · **Padrão Gboard** · **Gboard Escuro** (o quinto foi escolha minha: a versão escura do Gboard).
- **Microfone sem a flor fixa**: o botão do microfone e o da seta agora têm formato escolhido (`BarShapes`: Cookie, Flor, Círculo, Squircle, Quadrado, Selo; o padrão continua Cookie, então nada muda para quem não mexer).
  Novo `BadgeDrawable` substitui o `CookieDrawable` na barra. Prefs: `micShape`, `toolShape`.
- **Personalização ilimitada** (mesmos controles na aba Clássicos, em Teclas e no Editor de temas): estilo **Mecânico** (`keyStyle` 4, keycap 3D em `KeyView`),
  **borda** das teclas (`keyBorder`), **profundidade 3D** (`keyDepth`, vale para qualquer estilo), **formas livres** (`expressive` desligado libera Enter em cookie/flor etc.),
  formato do microfone e da seta, e **estilo da faixa de ícones** (`barStyle`: pílula, reta sem fundo como o Gboard, retangular).
- Tudo isso entrou em `Prefs.EXTRA_KEYS`: os temas podem definir esses valores, "Remover patch" restaura, e o ThemeSpec/JSON guarda em `keys.key_border`, `keys.key_depth`, `keys.expressive` e no bloco novo `bar` (`mic_shape`, `tool_shape`, `bar_style`). `spec_version` continua 1 (campos novos são opcionais; apps antigos os ignoram).
- **Editor de temas**: "Personalizar o tema ativo no editor" abre o editor já com o tema (clássico ou patch) carregado; nova seção "Barra e microfone"; a prévia mostra borda e profundidade.
- **5 temas novos** em Patches: Fliperama Neon (Jogos), Limão Tonal (Material You), Estilo Mensageiro Verde (Marcas), Vidro Gelo (Liquid Glass) e AMOLED Azul.
- Textos novos traduzidos (EN/RU/JA) em `Lang.kt`. Versão: `versionName` 54.2, `versionCode` 11.
- Arquivos: `Prefs.kt`, `Patches.kt`, `KeyView.kt`, `KeyboardService.kt`, `ExpressiveShapes.kt`, `compose/PatchesScreen.kt`, `compose/ThemeEditorScreen.kt`, `compose/SettingsPages2.kt`, `keyscafe/ThemeSpec*.kt`, `keyscafe/ThemeLibrary.kt`, `Lang.kt`.

## v32: Posicionar Keycaps (trocar as letras de lugar) e engrenagem
**Estado de compilação: NÃO validada** (sem Android SDK neste ambiente; só checagem de colchetes e de XML). Compile com `./gradlew assembleDebug` e corrija o que aparecer.

- **Posicionar Keycaps** (o que a v31 errou: ela reordenava os ícones da barra). Agora: toque no ícone de quatro blocos com setas na barra de ícones; abre o menu **Posicionar as teclas**, onde a primeira opção é **Posicionar Keycaps** (abaixo dela continua a lista para ordenar os ícones da barra). No modo, **arraste uma letra sobre outra**: as duas trocam de lugar (P no lugar do Q e Q no lugar do P). Dá para trocar entre fileiras, sem limite. Uma tecla "fantasma" segue o dedo e a de destino ganha um anel. **Concluído** sai do modo; **Restaurar** volta ao padrão. A disposição é salva por layout (QWERTY, ABNT2, Русский) em `rows_<layout>` (`Prefs.keyRows`). Configurações → Barra de ícones também tem "Restaurar letras do teclado".
- **Ícone de configurações** (`ic_kb_settings.xml`) agora é uma **engrenagem**.
- O botão **Demo** da linha extra vem **desligado**; para ligar: Configurações → Mais opções → Mostrar botão Demo (`Prefs.showDemo`).
- Arquivos: `KeyView.kt` (`KeyRoot`: arrastar/trocar; `KeyView.ring`), `KeyboardService.kt` (`setKeycapMode`, `swapLetters`, `currentRows`, faixa de edição), `compose/MkPanels.kt`, `Prefs.kt`, `SettingsActivity.kt`, `Lang.kt`.

## v31: barra de ícones, posicionar as teclas e botão de idioma
**Estado de compilação: NÃO validada** (sem Android SDK neste ambiente; só checagem de colchetes e de XML). Compile com `./gradlew assembleDebug` e corrija o que aparecer.

- **Ícone de configurações novo** (`ic_kb_settings.xml`): teclado em perspectiva com três fileiras, inspirado no logo do app. Substitui o ícone de "sliders" na barra.
- **Barra de ícones deslizável**: os ícones ficam num `HorizontalScrollView`; se não couberem, a barra desliza para os lados. Em Configurações → Barra de ícones dá para escolher se ela começa pela esquerda ou pela direita (`Prefs.barSide`).
- **Posicionar as teclas** (novo ícone `ic_position.xml` na barra): abre um painel no lugar das teclas, com a lista "Na barra" (▲ ▼ para mudar a ordem, ✕ para tirar) e "Adicionar à barra" (idioma, selecionar tudo, copiar, colar, ocultar teclado, além dos que saíram). "Posicionar as teclas" nunca pode ser removido, para sempre haver caminho de volta. Há também "Restaurar". A lista fica em `Prefs.barItems`.
- **Botão de idioma** ao lado esquerdo da barra de espaço (como no Gboard): um toque troca PT → EN → RU → JA. Em Configurações → Barra de ícones (ou no próprio painel) ele pode ser removido ou trocado pelo **emoji**; nesse caso o emoji sai da barra e aparece ali (`Prefs.langKey`). Atenção: o idioma do teclado é o mesmo de todo o app, então trocar o idioma também troca a língua dos textos.
- Arquivos: `KeyboardService.kt` (barra, painel, tecla ao lado do espaço), `KeyView.kt` (`ICON_GLOBE`), `Prefs.kt`, `SettingsActivity.kt` (página `BAR`), `Lang.kt` (traduções).

## Material 3 Expressive com Jetpack Compose (v30)
**Estado de compilação: NÃO validada.** O ambiente em que a v30 foi escrita não tem Android SDK nem acesso ao Maven; o Gradle falhou já ao resolver o plugin do Android. Só foi feita checagem de sintaxe dos arquivos Kotlin novos. Compile com `./gradlew assembleDebug` e corrija o que aparecer.

### Correção v30.1
- Painel Demo aparecia mas não reagia: o ciclo de vida do Compose era pausado ao esconder a janela do teclado e o relógio de quadros ficava parado. Agora o ciclo fica sempre ativo (`ImeComposeOwner`).

### O que entrou
- **Área visual real**: a janela do teclado agora é um `FrameLayout` com (1) o teclado de sempre e (2) um **overlay Compose de tamanho total que não recebe toque** (tudo passa às teclas). Está vazio, reservado para efeitos futuros.
- **Painel interativo "Demo"**: botão **Demo** na barra extra (seta de expandir). Abre um painel Compose no lugar das teclas, como o de clipboard/emoji; criado só ao abrir (baixo uso de memória) e some ao voltar.
- **Motion Scheme Expressive** (`MkMotion.kt`): molas *spatial* (com quique) e *effects* (sem quique), 3 velocidades; respeita a opção de animações fluidas (desligada = `snap`).
- **Tema** (`MkTheme.kt`): Material 3 com formas grandes, tipografia enfática e cores vindas do **mesmo `Palette` do teclado** (Material You dinâmico ou tema escolhido), para Views e Compose ficarem idênticos.
- **Componentes reutilizáveis** (`MkComponents.kt`): `MkButton` (preenchido/tonal/contorno), `MkToggleButton`, `MkIconButton`, `MkButtonGroup` (conectado), `MkExpandableSection`, `MkMenu`/`MkMenuItem` (entrada em cascata), `MkBackArrow`. Mudam de **forma** ao pressionar/selecionar e fazem mola de escala; o estado animado é lido só na fase de desenho.
- Telas antigas (Views) **não foram migradas**; digitação, teclas e `InputMethodService` intactos.

### Por que o Expressive é implementação própria (compatibilidade verificada na documentação oficial)
- Material3 **1.4.0 estável removeu** as APIs Expressive ("troque para 1.5.0-alpha"); elas só existem em Material3 1.5.x.
- Material3 1.5.0-alpha24+ usa **Compose 1.12**, que exige **compileSdk 37** e **AGP 9.2.0+** (blog de agosto/2026: mínimo 9.1.1; notas do Compose Material: 9.2.0). Compose 1.13 exige ainda Kotlin 2.2.
- Esta base usa AGP 8.5.2, Kotlin 2.0.0 e compileSdk 34. Subir tudo isso sem poder compilar seria arriscado, então ficou **Compose BOM 2024.09.03 (Compose 1.7.3 / Material3 1.3.0)** e o Expressive foi feito sobre ele, na camada `compose/`.
- Os valores das molas seguem a especificação M3 Expressive (spatial 0.6/800, 0.8/380, 0.8/200; effects 1.0/3800, 1600, 800); não foram conferidos contra a biblioteca.
- **Caminho de migração futuro**: AGP 9.2+ (e o Gradle exigido por ele), compileSdk 37, Material3 1.5.x; depois trocar `MaterialTheme` por `MaterialExpressiveTheme` em `MkTheme` e `MkMotionScheme` por `MotionScheme.expressive()`. Atenção: o AGP 9 muda a configuração do Kotlin (plugin embutido); valide num branch.
- minSdk continua 26.

## Recursos
- Layouts QWERTY, ABNT2 (ç, acentos ´ e ~ por tecla morta) e símbolos (`?123`); linha de números opcional
- Digitação instantânea: teclas desenhadas em Canvas, ação no toque inicial; vibração, som e sugestões rodam fora da thread principal
- Animações leves: toque nas teclas, transição entre painéis, barra de ferramentas e ferramentas extras
- Barra superior: 📋 clipboard, 😀 emojis, 🌐 tradutor, 🎤 microfone (Digitação por voz do Google; plano B: reconhecimento de voz do Google), ⚙️ configurações e botão para expandir (selecionar tudo, copiar, colar, cortar, mover cursor, ocultar)
- Clipboard: até 50 itens, texto e imagens/prints (com miniatura), toque para colar, apagar um ou todos; ignora senhas/cartões/chaves/e-mails e itens marcados como sensíveis pelo sistema; não grava com um campo de senha em foco
- Autocorreção, sugestões, próxima palavra, maiúsculas automáticas (PT-BR e EN)
- Configurações salvas (SharedPreferences) e aplicadas na hora: vibração (intensidade), som (volume e 8 sons: Clique, Bolha, Metal, Madeira, Gota, Pop, Mecânico, Suave), tema claro/escuro/sistema, cor personalizada, arredondamento das teclas e do teclado, altura e tamanho do texto, idioma de todo o app (Português, English, Русский e 日本語 por romaji), ABNT2, restaurar padrões

## Tradutor (substitui a antiga IA)
- Tradução **no aparelho** com Google ML Kit (PT, EN, RU, ES, JA), enquanto você digita: a barra do tradutor (ícone 🌐) atualiza sozinha após uma pequena pausa; origem/destino à escolha, pausar/retomar, **Inserir** no app e **Desfazer**
- Os modelos de idioma **não vêm no APK**: cada par é baixado automaticamente, uma única vez, só quando há algo para traduzir (opção de só Wi-Fi e de excluir modelos em Configurações → Tradutor)
- Desativado em campos de senha

## Novidades da v2.5
- **Clipboard sem travar**: a captura de clipboard não usa mais `coerceToText()` (podia abrir leitura/URI de outro app na hora e travar o teclado); texto puro continua instantâneo, e qualquer leitura de imagem roda fora da thread principal, sempre protegida por try/catch
- **Clipboard aceita imagens**: prints e figurinhas copiados em outros apps entram no histórico (miniatura no painel) e podem ser colados com um toque, via `InputConnection.commitContent`, nos campos que aceitarem — se o app de destino não aceitar, o teclado avisa em vez de falhar calado
- **Filtro de sensíveis de verdade**: cópias marcadas como sensíveis pelo próprio Android (Android 13+) e qualquer cópia feita com um campo de senha em foco agora são realmente ignoradas pelo histórico, como o app já dizia fazer
- **Reforço de correção em código aberto**: com "Melhorar precisão do corretor" ligado, quando o dicionário embutido não resolve, o teclado consulta de forma assíncrona (nunca trava a digitação) o corretor ortográfico do próprio Android (TextServicesManager/SpellCheckerSession, parte aberta do AOSP), que traz um dicionário bem maior no idioma escolhido em "Idioma do teclado"

## Novidades da v2.2
- **Toque inteligente**: tocar numa fresta entre as teclas, na borda ou logo abaixo da última fileira digita a tecla mais próxima (desligável em Configurações → Digitação)
- **12 temas prontos**: Meia-noite, Oceano, Floresta, Pôr do sol, Dracula, Nord, Café, Neon, Sakura, Lavanda, Menta e Papel (Configurações → Aparência)
- **Novo ícone**: M + teclado, adaptativo e temático

## Novidades da v2.1
- **Digitação sem "bugar"**: molas das teclas reaproveitadas (sem alocação a cada toque), animação de entrada só quando o teclado abre (não a cada campo) e sem mover as teclas, painel antigo nunca mais fica "fantasma" sobre as teclas, palavra em andamento descartada quando o cursor é movido por fora
- **Autocorreção conservadora** e desligada por padrão (só troca letra errada/invertida com candidato único; não transforma mais "fica" em "ficar")
- **Segurar a tecla por 0,5 s** abre as variações: ç č ć ã á à â é ê í ó õ ô ú ñ ß ¿ ¡ € etc., com animação de mola; arraste e solte para escolher
- **Barra extra removida**: a faixa de sugestões vazia sumiu; as sugestões aparecem no lugar dos ícones, só quando existem
- **Ícone do app** (logo do teclado) em vez do robô do Android, com ícone adaptativo e temático

## Novidades da v2.0
- **Assistente de boas-vindas** na primeira abertura (animado): Bem-vindo → Ativar teclado → Selecionar teclado
- **Configurações reorganizadas** em categorias: Aparência, Imagem de fundo, Tamanho, Animações, Som e vibração, Digitação, Área de transferência, Mais opções
- **Tamanho do teclado** (70%–130%) com atalhos Pequeno / Ideal / Grande
- **Tema com imagem**: escolha uma foto da galeria (sem permissão de arquivos), ajuste posição, escurecimento e opacidade das teclas
- **Animações fluidas**: molas estilo Material You nas teclas, painéis, entrada do teclado e menus
- **Correção do modo escuro**: teclas claras com letras invisíveis; a paleta agora é calculada com contraste garantido

## Como compilar
1. Abra no Android Studio e rode, **ou** envie ao GitHub — a Action gera o APK em *Actions → Build APK → Artifacts*.
2. Instale o app, abra-o e toque em **Ativar** e depois **Selecionar**.

## Requisitos
Android 8.0+ (API 26). Cores dinâmicas no Android 12+.

## Microfone (ditado dentro do teclado)

O microfone usa o `SpeechRecognizer` do Android: o reconhecimento roda em segundo plano, **sem abrir o teclado do Google nem qualquer tela**; o texto é inserido direto no seu teclado.

- **Uso:** 1º toque escuta (ícone vira "pausa" e para sozinho quando você para de falar); 2º toque encerra na hora; tocar enquanto processa cancela.
- **Idioma:** segue o idioma do teclado (pt-BR/en-US/ru-RU/ja-JP). Usa o pacote offline do sistema se estiver instalado (`EXTRA_PREFER_OFFLINE`); senão, precisa de internet.
- **Permissão:** `RECORD_AUDIO`, pedida por `MicPermissionActivity` (transparente).
- **Sem dependências nativas:** nada de NDK, modelos ou bibliotecas extras.
- **Arquivos:** `SpeechVoice.kt`, `MicPermissionActivity.kt`, `KeyboardService.startVoice()`.

## Patches · Keys Café (v37)
Nova página **Patches** (Início → Visual). Biblioteca `Patches.kt` com 13 temas completos (paleta + acabamento), separada de `Palette.PRESETS`:
Jogos 3 · Material You 3 · Marcas 2 · Liquid Glass 1 · AMOLED 4. Aplicar grava tudo num único `edit()/apply()` (`Prefs.setPatch`),
guarda o estado anterior e `Remover patch` restaura (`Prefs.removePatch`). Com imagem de fundo ativa, só o acabamento é aplicado.
O estilo Vidro (`keyStyle` 3) foi renovado como Liquid Glass (`KeyView.drawGlass`).

### Cenário animado (v39)
Seção em Patches com 3 cenários: **Outono** (folhas vermelhas), **Inverno** (flocos de neve) e **Tempestade** (chuva e relâmpagos).
São só partículas: `SceneDrawable` (`Scenes.kt`) é transparente e entra como foreground do teclado, então funciona sobre qualquer tema, cor ou imagem.
É uma preferência própria (`Prefs.scene`), independente dos patches. Usa `Choreographer` e só anima com o teclado visível.

## Keys Café · passo 1 (contrato ThemeSpec + biblioteca local) — NÃO COMPILADO

Fundação do Keys Café e do futuro ThemeBoard, **sem mudar nada do visual do teclado**. Código novo em
`app/src/main/java/com/example/materialkeyboard/keyscafe/`:

- `ThemeSpec.kt` — modelo do tema (v1) e limites. É só dados.
- `ThemeSpecJson.kt` — lê/escreve `theme.json` com validação rígida (tipos, faixas, tamanhos, caracteres de controle).
- `ThemePackage.kt` — pacote `.mkt` (zip): lista fechada de nomes, limites de tamanho, proteção contra zip-slip e zip-bomb,
  só imagens (png/jpg/webp); **sons e fontes ainda são recusados**.
- `ThemeSpecMapper.kt` — ThemeSpec ⇄ `Patch` ⇄ preferências atuais (`capture`).
- `ThemeLibrary.kt` — biblioteca local (`filesDir/keyscafe/<id>/`): instalar, aplicar, remover, exportar. Offline e sem Supabase.

Alterações em arquivos existentes (4 linhas): `Patches.kt` (categoria `COMMUNITY` e `byId` também consulta a biblioteca),
`Prefs.kt` (`ThemeLibrary.attach(ctx)` no `init`) e `Lang.kt` (tradução de "Comunidade").

Passo 1 aplica paleta + acabamento (as mesmas chaves de `Patches.apply`, então "Remover patch" continua restaurando tudo).
Gradientes, animação, balão, texto e imagem já são lidos/validados/guardados, mas só passam a ser desenhados/aplicados no passo 2.

**Status:** escrito sem acesso a compilador (sem Android SDK/kotlinc no ambiente). Compile antes de usar:
`./gradlew assembleDebug`. Pacotes de teste em `docs/keyscafe-fixtures/`.

## Keys Café · passo 2 (tela de temas instalados) — NÃO COMPILADO

Primeira parte visível do Keys Café, na página **Patches** (`PatchesScreen.kt` + `SettingsActivity.kt`):

- Chip **Comunidade**: lista os temas instalados (os embutidos continuam iguais). Favoritos passou a ser o último chip.
- **Importar tema (.mkt)**: abre o seletor de arquivos, valida o pacote e instala (em segundo plano; resultado por Toast).
- **Salvar meu visual como tema**: pede um nome e guarda o visual atual do teclado na biblioteca (não funciona com imagem de fundo ligada).
- Segurar um tema da Comunidade abre a prévia em tela cheia, com **Exportar tema** (grava um .mkt no local escolhido) e **Remover tema**.
- Instalar por cima de um tema ativo reaplica o tema para o teclado pegar as cores novas.

Ainda NÃO desenha gradientes nem aplica animação/balão/texto/imagem do tema (passo 3). Teste: importe
`docs/keyscafe-fixtures/valido.mkt`; os três `RECUSAR-*.mkt` devem mostrar uma mensagem de erro e não instalar nada.

## Keys Café · passo 3 (aplicar o resto do tema) — NÃO COMPILADO

Agora aplicar um tema da Comunidade também define, no mesmo `edit()/apply()` do patch:
cantos do teclado (`boardRadius`), formato do destaque (`accentShape`), tamanho e cor do texto (`textScale`, `fontColor`),
balão de prévia (forma, tamanho, cor, matiz, animação), animação (velocidade, elasticidade) e cenário (`scene`).

- `Prefs.EXTRA_KEYS` lista essas chaves e seus padrões; `patchState()` as inclui, então **"Remover patch" restaura tudo**.
- `Patch.extras` (vazio nos temas embutidos) leva os valores do `ThemeSpec` via `ThemeSpecMapper.extras`.
  Ao trocar de tema, o que o novo tema não define volta ao valor de antes do patch (não herda do tema anterior).
- `keyscafe/ThemeGradients.kt` + 1 linha em `KeyboardService.kt`: desenha o gradiente de **fundo** (`target = "surface"`).

Ainda NÃO feito: gradientes de tecla/destaque (exigem mexer no `KeyView`), imagem de fundo do tema e sons/fontes do pacote.
O Supabase (ThemeBoard) continua sem nenhuma linha de código: a biblioteca só espera um pacote e chama `ThemeLibrary.install`.

## Keys Café · passo 4 (gradientes de tecla + ThemeBoard online) — NÃO COMPILADO

- **Gradientes** de tecla e de destaque do tema: `KeyView.gradColors/gradAngle` + `ThemeGradients.forKey`
  (teclas especiais ficam lisas; com imagem de fundo ligada os gradientes são ignorados).
- **ThemeBoard (Supabase)**: `keyscafe/ThemeBoardApi.kt` (HttpURLConnection + org.json, sem dependência nova) e
  `compose/ThemeBoardScreen.kt` (explorar, buscar, ordenar, baixar, aplicar, publicar, denunciar, login por e-mail/senha).
- O servidor JÁ existia no projeto Supabase; o app segue o esquema dele. Ver `docs/supabase/README.md`.
- URL/chave ficam em `keyscafe/ThemeBoardConfig.kt` (sem BuildConfig nem local.properties: o PocketCode não compila isso). Vazios = a parte online some.
- Ainda de fora: avaliar/comentar dentro do app, imagem de fundo no tema aplicado, sons/fontes no pacote,
  moderação automática por IA (próxima fase). Decisão: o login fica no Supabase Auth, sem Firebase.

## Keys Café · passo 5 (editor de temas) — NÃO COMPILADO

- `compose/ThemeEditorScreen.kt`: editor em tela cheia com prévia ao vivo no topo. Parte do visual atual, de um tema em
  branco ou de um tema meu (`meu-…`) sem imagem de fundo. Seções: cores, gradientes (fundo/teclas/destaque, 2 a 4 cores,
  ângulo), teclas (estilo, formatos, cantos, espaço, opacidade, desfoque), texto, balão e animação/cenário.
- `compose/ColorPicker.kt`: seletor de cor (matiz/saturação/brilho + hexadecimal), `NumSlider`, `SwitchRow`.
- `keyscafe/ThemePreviewRenderer.kt`: miniatura WebP desenhada com Canvas ao salvar (o tema já sai com imagem para o ThemeBoard).
- Entrada: Patches → "Editor de temas". Salvar grava na biblioteca local; "Salvar e aplicar" já ativa o tema.
- Limites: não edita imagem de fundo, sons ou fontes; a prévia ao vivo mostra cantos e espaços, não os formatos especiais.

## ThemeBoard · fila de moderação — NÃO COMPILADO

Novo: `compose/ModerationScreen.kt` (fila de moderação) e uma seção de moderação em `keyscafe/ThemeBoardApi.kt`
(`isModerator`, `pendingThemes`, `reviewPackage`, `moderateTheme`, `openReports`, `moderateReport`).
Em `ThemeBoardScreen.kt`: o botão **Moderar** (só para moderadores) abre a fila. Servidor: `docs/supabase/README.md`.
Escrito sem compilador; compile antes de usar e me mande qualquer erro.

## Menu em páginas, Patches com carregamento e dicionário aberto — NÃO COMPILADO

- **Tela inicial** (`SettingsPages.kt`, `HomeScreen`/`MkTile`): os grupos viram 4 páginas que deslizam para o lado (Visual, Teclas, Digitação e feedback, Geral), com abas, bolinhas e cartões em grade.
- **Patches** (`PatchesScreen.kt`): na primeira abertura os cartões entram em etapas, com barra de progresso real; depois abre direto (`patchesWarm`). Os patches agora são faixas por categoria que deslizam para o lado.
- **Dicionário aberto** (`OpenDictionary.kt`, `Suggestions.kt`): soma `assets/dict/<idioma>.txt` ao dicionário embutido em segundo plano. Os arquivos não vão no projeto: `bash tools/baixar_dicionarios.sh`. Buscas por palavra exata passaram a usar `HashSet`/`HashMap`.

### Dicionário (v53)
O app baixa sozinho (1x por dia no máximo, só se faltar) a lista aberta FrequencyWords (50 mil palavras por idioma, CC-BY-SA 4.0) para `filesDir/dict/<idioma>.txt` (`DictionaryDownloader.kt`). Botão manual em Configurações → Digitação → Dicionário. A autocorreção passou a escolher o candidato muito mais comum em vez de desistir. Dicionário do HeliBoard/AOSP não foi usado: é binário (precisa da biblioteca nativa do AOSP) e o app é GPL.

### v54: Patches em abas e textos traduzidos
- `PatchesScreen.kt` agora separa em abas: **Patches** (temas prontos), **Cenário**, **Bichinhos**, **Keys Café** (sua coleção: importar, salvar, editor) e **ThemeBoard** (loja online). A aba "Comunidade" saiu; os temas do usuário ficam em Keys Café → Meus temas.
- `Lang.kt`: +230 textos que só existiam em português (bichinhos, ThemeBoard, editor, nomes e descrições dos patches, mensagens de erro, dicionário). Mensagens com código no fim ("... (404).") são traduzidas pelo modelo (`tFallback`).

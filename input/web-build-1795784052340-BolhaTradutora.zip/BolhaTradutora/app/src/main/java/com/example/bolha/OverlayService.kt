package com.example.bolha

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.view.*
import android.widget.*
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.*
import kotlinx.coroutines.tasks.await
import kotlin.math.abs

class OverlayService : Service() {

    private lateinit var wm: WindowManager
    private val main = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    private var bubble: TextView? = null
    private var card: View? = null

    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var vDisplay: VirtualDisplay? = null
    private var sw = 0
    private var sh = 0

    // Troque por JapaneseTextRecognizerOptions / ChineseTextRecognizerOptions / KoreanTextRecognizerOptions
    // (e adicione a dependência correspondente) se precisar ler esses alfabetos.
    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        startAsForeground()

        val code = intent?.getIntExtra("code", 0) ?: 0
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33)
            intent?.getParcelableExtra("data", Intent::class.java) else @Suppress("DEPRECATION") intent?.getParcelableExtra("data")
        if (data == null) { stopSelf(); return START_NOT_STICKY }

        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mpm.getMediaProjection(code, data).also {
            it.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() { stopSelf() }
            }, main)
        }
        setupCapture()
        showBubble()
        return START_NOT_STICKY
    }

    private fun startAsForeground() {
        val chId = "bolha"
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(chId, "Bolha Tradutora", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, chId)
            .setContentTitle("Bolha Tradutora ativa")
            .setContentText("Toque na bolha para traduzir a tela")
            .setSmallIcon(android.R.drawable.ic_menu_edit)
            .build()
        if (Build.VERSION.SDK_INT >= 29)
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        else startForeground(1, n)
    }

    // ---------- Captura de tela ----------
    // Android 14+: só pode criar UM VirtualDisplay por projeção, então criamos uma vez e reutilizamos.
    private fun setupCapture() {
        val dpi: Int
        if (Build.VERSION.SDK_INT >= 30) {
            val b = wm.currentWindowMetrics.bounds
            sw = b.width(); sh = b.height()
            dpi = resources.configuration.densityDpi
        } else {
            val m = DisplayMetrics()
            @Suppress("DEPRECATION") wm.defaultDisplay.getRealMetrics(m)
            sw = m.widthPixels; sh = m.heightPixels; dpi = m.densityDpi
        }
        reader = ImageReader.newInstance(sw, sh, PixelFormat.RGBA_8888, 2)
        vDisplay = projection!!.createVirtualDisplay(
            "bolha", sw, sh, dpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader!!.surface, null, main
        )
    }

    private suspend fun grabScreen(): Bitmap? {
        repeat(15) { // tenta por ~1,5s até chegar um frame novo
            val img = reader?.acquireLatestImage()
            if (img != null) {
                val p = img.planes[0]
                val rowPad = p.rowStride - p.pixelStride * sw
                val full = Bitmap.createBitmap(sw + rowPad / p.pixelStride, sh, Bitmap.Config.ARGB_8888)
                full.copyPixelsFromBuffer(p.buffer)
                img.close()
                return Bitmap.createBitmap(full, 0, 0, sw, sh)
            }
            delay(100)
        }
        return null
    }

    // ---------- Bolha arrastável ----------
    private fun overlayType() = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY

    private fun showBubble() {
        val size = (56 * resources.displayMetrics.density).toInt()
        val params = WindowManager.LayoutParams(
            size, size, overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 24; y = 400 }

        val v = TextView(this).apply {
            text = "文A"
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            textSize = 18f
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0xE61A73E8.toInt()) }
            elevation = 12f
        }

        var startX = 0; var startY = 0; var tx = 0f; var ty = 0f; var moved = false
        val slop = ViewConfiguration.get(this).scaledTouchSlop
        v.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { startX = params.x; startY = params.y; tx = e.rawX; ty = e.rawY; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - tx; val dy = e.rawY - ty
                    if (abs(dx) > slop || abs(dy) > slop) moved = true
                    if (moved) { params.x = (startX + dx).toInt(); params.y = (startY + dy).toInt(); wm.updateViewLayout(v, params) }
                }
                MotionEvent.ACTION_UP -> if (!moved) onBubbleClick()
            }
            true
        }
        wm.addView(v, params)
        bubble = v
    }

    // ---------- Clique: captura -> OCR -> tradução -> card ----------
    private fun onBubbleClick() {
        removeCard()
        scope.launch {
            bubble?.visibility = View.INVISIBLE // some da captura (e força novo frame)
            delay(200)
            val bmp = grabScreen()
            bubble?.visibility = View.VISIBLE
            if (bmp == null) { showCard("Não consegui capturar a tela. Tente de novo."); return@launch }

            showCard("Traduzindo…")
            try {
                val ocr = withContext(Dispatchers.Default) {
                    recognizer.process(InputImage.fromBitmap(bmp, 0)).await()
                }
                // Mantém só blocos com texto e ordena de cima pra baixo
                val text = ocr.textBlocks
                    .sortedBy { it.boundingBox?.top ?: 0 }
                    .joinToString("\n") { it.text }
                showCard(Translator.translate(text))
            } catch (e: Exception) {
                showCard("Erro: ${e.message}")
            }
        }
    }

    private fun showCard(text: String) {
        removeCard()
        val d = resources.displayMetrics.density
        val tv = TextView(this).apply {
            this.text = text
            setTextColor(Color.WHITE)
            textSize = 16f
            setTextIsSelectable(false)
        }
        val scroll = ScrollView(this).apply { addView(tv) }
        val close = TextView(this).apply {
            this.text = "✕"; setTextColor(Color.WHITE); textSize = 20f
            setPadding((12 * d).toInt(), 0, (4 * d).toInt(), 0)
            setOnClickListener { removeCard() }
        }
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding((16 * d).toInt(), (12 * d).toInt(), (12 * d).toInt(), (12 * d).toInt())
            background = GradientDrawable().apply { cornerRadius = 16 * d; setColor(0xF0202124.toInt()) }
            addView(scroll, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            addView(close, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        val params = WindowManager.LayoutParams(
            (sw - 32 * d).toInt(), (sh * 0.45f).toInt().coerceAtMost((400 * d).toInt()), overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; y = (48 * d).toInt() }
        wm.addView(row, params)
        card = row
    }

    private fun removeCard() {
        card?.let { runCatching { wm.removeView(it) } }
        card = null
    }

    override fun onDestroy() {
        scope.cancel()
        removeCard()
        bubble?.let { runCatching { wm.removeView(it) } }
        vDisplay?.release(); reader?.close(); projection?.stop()
        super.onDestroy()
    }
}

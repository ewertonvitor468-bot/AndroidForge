package com.example.bolha

import com.google.mlkit.nl.languageid.LanguageIdentification
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * Qualidade: usa o Claude (muito melhor com contexto, gírias e textos de tela).
 * Se não tiver chave ou estiver sem internet, cai no ML Kit (offline, qualidade média).
 */
object Translator {

    // Cole sua chave da API da Anthropic aqui (veja o aviso de segurança no SETUP.md)
    private const val CLAUDE_API_KEY = ""
    private const val CLAUDE_MODEL = "claude-haiku-5-5" // rápido e barato; use claude-sonnet-5-5 para mais qualidade
    private const val TARGET_NAME = "português do Brasil"
    private val TARGET_ML = TranslateLanguage.PORTUGUESE

    suspend fun translate(text: String): String {
        if (text.isBlank()) return "Nenhum texto encontrado na tela."
        if (CLAUDE_API_KEY.isNotBlank()) {
            try {
                return withClaude(text)
            } catch (e: Exception) {
                // sem internet / erro de API -> fallback offline
            }
        }
        return withMlKit(text)
    }

    private suspend fun withClaude(text: String): String = withContext(Dispatchers.IO) {
        val body = JSONObject().apply {
            put("model", CLAUDE_MODEL)
            put("max_tokens", 2000)
            put(
                "system",
                "Você é um tradutor profissional. Traduza o texto para $TARGET_NAME de forma natural e fiel, " +
                    "mantendo o tom, gírias e termos de interface. O texto veio de OCR de uma captura de tela e " +
                    "pode ter ruído ou linhas quebradas: junte o que for óbvio. Responda SOMENTE com a tradução, " +
                    "sem explicações. Se já estiver em $TARGET_NAME, devolva igual."
            )
            put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", text)))
        }
        val conn = (URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 10_000
            readTimeout = 30_000
            doOutput = true
            setRequestProperty("content-type", "application/json")
            setRequestProperty("x-api-key", CLAUDE_API_KEY)
            setRequestProperty("anthropic-version", "2023-06-01")
        }
        conn.outputStream.use { it.write(body.toString().toByteArray()) }
        if (conn.responseCode != 200) error("HTTP ${conn.responseCode}")
        val resp = JSONObject(conn.inputStream.bufferedReader().readText())
        resp.getJSONArray("content").getJSONObject(0).getString("text").trim()
    }

    private suspend fun withMlKit(text: String): String {
        val code = LanguageIdentification.getClient().identifyLanguage(text).await()
        if (code == "und") return text
        val source = TranslateLanguage.fromLanguageTag(code) ?: return text
        if (source == TARGET_ML) return text
        val translator = Translation.getClient(
            TranslatorOptions.Builder().setSourceLanguage(source).setTargetLanguage(TARGET_ML).build()
        )
        return try {
            translator.downloadModelIfNeeded().await() // baixa ~30MB na 1ª vez de cada idioma
            translator.translate(text).await()
        } finally {
            translator.close()
        }
    }
}
